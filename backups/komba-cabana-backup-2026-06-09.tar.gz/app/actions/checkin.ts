'use server'

import { db } from '@/lib/db'
import { reservations } from '@/lib/db/schema'
import { eq, and, isNull, or } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'
import { randomBytes } from 'crypto'

// ============ GUEST SELF CHECK-IN ============

type GuestSlot = 'first' | 'second'

// Generate or fetch the check-in token for a reservation guest slot.
// 'first' = main guest, 'second' = second guest on the reservation.
export async function getOrCreateCheckinToken(
  reservationId: string,
  slot: GuestSlot = 'first'
): Promise<string> {
  const tokenColumn = slot === 'second' ? reservations.secondCheckinToken : reservations.checkinToken

  const existing = await db
    .select({
      first: reservations.checkinToken,
      second: reservations.secondCheckinToken,
    })
    .from(reservations)
    .where(eq(reservations.id, reservationId))
    .limit(1)

  const current = slot === 'second' ? existing[0]?.second : existing[0]?.first
  if (current) {
    return current
  }

  const token = randomBytes(24).toString('hex')
  await db
    .update(reservations)
    .set(slot === 'second' ? { secondCheckinToken: token } : { checkinToken: token })
    .where(eq(reservations.id, reservationId))

  revalidatePath('/')
  return token
}

// Public: fetch the reservation data needed for the guest check-in form.
// Detects whether the token belongs to the first or second guest and
// returns that guest's fields under unified keys, plus the guest's name.
// Only returns guest-relevant fields, never prices or internal data.
// Returns null if token invalid or guest already checked out.
export async function getReservationByToken(token: string) {
  if (!token) return null

  const rows = await db
    .select()
    .from(reservations)
    .where(
      and(
        or(eq(reservations.checkinToken, token), eq(reservations.secondCheckinToken, token)),
        isNull(reservations.checkedOutAt)
      )
    )
    .limit(1)

  const res = rows[0]
  if (!res) return null

  const isSecond = res.secondCheckinToken === token

  if (isSecond) {
    return {
      id: res.id,
      slot: 'second' as const,
      guestName: res.secondGuestName,
      arrival: res.arrival,
      departure: res.departure,
      bungalow: res.bungalow,
      nationality: res.secondNationality,
      passport: res.secondPassport,
      dateOfBirth: res.secondDateOfBirth,
      placeOfBirth: res.secondPlaceOfBirth,
      fatherName: res.secondFatherName,
      motherName: res.secondMotherName,
      profession: res.secondProfession,
      domicile: res.secondDomicile,
      passportDate: res.secondPassportDate,
      passportLieu: res.secondPassportLieu,
      venantDe: res.secondVenantDe,
      validiteVisa: res.secondValiditeVisa,
      allantA: res.secondAllantA,
    }
  }

  return {
    id: res.id,
    slot: 'first' as const,
    guestName: res.guestName,
    arrival: res.arrival,
    departure: res.departure,
    bungalow: res.bungalow,
    nationality: res.nationality,
    passport: res.passport,
    dateOfBirth: res.dateOfBirth,
    placeOfBirth: res.placeOfBirth,
    fatherName: res.fatherName,
    motherName: res.motherName,
    profession: res.profession,
    domicile: res.domicile,
    passportDate: res.passportDate,
    passportLieu: res.passportLieu,
    venantDe: res.venantDe,
    validiteVisa: res.validiteVisa,
    allantA: res.allantA,
  }
}

// Public: save the guest-provided check-in data.
// Scoped strictly to the reservation+slot matching the token.
export async function submitCheckinByToken(
  token: string,
  data: {
    guestName?: string
    nationality?: string
    passport?: string
    dateOfBirth?: string
    placeOfBirth?: string
    fatherName?: string
    motherName?: string
    profession?: string
    domicile?: string
    passportDate?: string
    passportLieu?: string
    venantDe?: string
    validiteVisa?: string
    allantA?: string
  }
) {
  if (!token) return { success: false, error: 'Invalid link' }

  // Verify the token maps to an active reservation and detect the slot
  const rows = await db
    .select({
      id: reservations.id,
      first: reservations.checkinToken,
      second: reservations.secondCheckinToken,
    })
    .from(reservations)
    .where(
      and(
        or(eq(reservations.checkinToken, token), eq(reservations.secondCheckinToken, token)),
        isNull(reservations.checkedOutAt)
      )
    )
    .limit(1)

  if (!rows[0]) {
    return { success: false, error: 'Link expired or invalid' }
  }

  const isSecond = rows[0].second === token

  // Map unified keys to the right columns (first vs second guest)
  const fieldMap: Record<string, { first: string; second: string }> = {
    guestName: { first: 'guestName', second: 'secondGuestName' },
    nationality: { first: 'nationality', second: 'secondNationality' },
    passport: { first: 'passport', second: 'secondPassport' },
    dateOfBirth: { first: 'dateOfBirth', second: 'secondDateOfBirth' },
    placeOfBirth: { first: 'placeOfBirth', second: 'secondPlaceOfBirth' },
    fatherName: { first: 'fatherName', second: 'secondFatherName' },
    motherName: { first: 'motherName', second: 'secondMotherName' },
    profession: { first: 'profession', second: 'secondProfession' },
    domicile: { first: 'domicile', second: 'secondDomicile' },
    passportDate: { first: 'passportDate', second: 'secondPassportDate' },
    passportLieu: { first: 'passportLieu', second: 'secondPassportLieu' },
    venantDe: { first: 'venantDe', second: 'secondVenantDe' },
    validiteVisa: { first: 'validiteVisa', second: 'secondValiditeVisa' },
    allantA: { first: 'allantA', second: 'secondAllantA' },
  }

  // Only write the fields the guest actually provided (non-empty)
  const updates: Record<string, string> = {}
  for (const [key, value] of Object.entries(data)) {
    if (value && fieldMap[key]) {
      const column = isSecond ? fieldMap[key].second : fieldMap[key].first
      updates[column] = value
    }
  }

  if (Object.keys(updates).length > 0) {
    await db.update(reservations).set(updates).where(eq(reservations.id, rows[0].id))
  }

  revalidatePath('/')
  return { success: true }
}
