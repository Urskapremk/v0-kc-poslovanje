'use server'

import { db } from '@/lib/db'
import { housekeepingSchedule } from '@/lib/db/schema'
import { and, gte, lte, eq } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'
import type { Shift, ScheduleEntry } from '@/lib/housekeeping'

// Format a Date to YYYY-MM-DD without timezone shifts
function ymd(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

// Get all schedule entries for a given month (1-12)
export async function getHousekeepingSchedule(year: number, month: number): Promise<ScheduleEntry[]> {
  const start = `${year}-${String(month).padStart(2, '0')}-01`
  const lastDay = new Date(year, month, 0).getDate()
  const end = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`

  const rows = await db
    .select()
    .from(housekeepingSchedule)
    .where(and(gte(housekeepingSchedule.date, start), lte(housekeepingSchedule.date, end)))

  return rows.map((r) => ({
    id: r.id,
    date: typeof r.date === 'string' ? r.date : ymd(new Date(r.date as unknown as string)),
    staffName: r.staffName,
    shift: r.shift as Shift,
  }))
}

// Update or insert a single cell (one staff member's shift on one day)
export async function setHousekeepingShift(date: string, staffName: string, shift: Shift): Promise<void> {
  const existing = await db
    .select()
    .from(housekeepingSchedule)
    .where(and(eq(housekeepingSchedule.date, date), eq(housekeepingSchedule.staffName, staffName)))

  if (existing.length > 0) {
    await db
      .update(housekeepingSchedule)
      .set({ shift })
      .where(eq(housekeepingSchedule.id, existing[0].id))
  } else {
    await db.insert(housekeepingSchedule).values({
      id: `hk-${date}-${staffName}-${Math.random().toString(36).slice(2, 8)}`,
      date,
      staffName,
      shift,
    })
  }
  revalidatePath('/statistika')
}

/**
 * Generate the schedule for a whole month following the rules:
 * - 3 housekeepers: Eniki, Felicia, Christaline
 * - Each works 6 days, every 7th day off
 * - Normal day (all 3 work): Christaline MORNING + one of (Eniki/Felicia) MORNING, the other AFTERNOON.
 *   Eniki & Felicia alternate weekly (one week morning, next week afternoon).
 * - When Eniki or Felicia is OFF: only 2 work that day -> 1 MORNING + 1 AFTERNOON
 *   (Christaline covers the missing person)
 * - Off days are staggered so Eniki and Felicia are never off on the same day.
 *
 * Returns the generated entries (also written to DB, overwriting that month).
 */
export async function generateHousekeepingSchedule(year: number, month: number): Promise<ScheduleEntry[]> {
  const lastDay = new Date(year, month, 0).getDate()

  // Clear existing entries for this month first
  const start = `${year}-${String(month).padStart(2, '0')}-01`
  const end = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`
  await db
    .delete(housekeepingSchedule)
    .where(and(gte(housekeepingSchedule.date, start), lte(housekeepingSchedule.date, end)))

  const entries: { date: string; staffName: string; shift: Shift }[] = []

  // Day index 0-based from the 1st of the month.
  // Off-day pattern (every 7th day off, staggered):
  //   Eniki off when dayIndex % 7 === 0
  //   Felicia off when dayIndex % 7 === 3
  //   Christaline off when dayIndex % 7 === 6 (only day she rests; she covers otherwise)
  for (let d = 1; d <= lastDay; d++) {
    const dayIndex = d - 1
    const date = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`

    const enikiOff = dayIndex % 7 === 0
    const feliciaOff = dayIndex % 7 === 3
    const christalineOff = dayIndex % 7 === 6

    let eniki: Shift = 'MORNING'
    let felicia: Shift = 'AFTERNOON'
    let christaline: Shift = 'MORNING'

    if (christalineOff) {
      // Christaline rests; Eniki morning, Felicia afternoon (both work)
      christaline = 'OFF'
      eniki = 'MORNING'
      felicia = 'AFTERNOON'
    } else if (enikiOff) {
      // Eniki off -> Christaline covers. Only 2 work: 1 morning + 1 afternoon
      eniki = 'OFF'
      christaline = 'MORNING'
      felicia = 'AFTERNOON'
    } else if (feliciaOff) {
      // Felicia off -> Christaline covers. Only 2 work: 1 morning + 1 afternoon
      felicia = 'OFF'
      christaline = 'MORNING'
      eniki = 'AFTERNOON'
    } else {
      // Normal day, all 3 work: 2 morning + 1 afternoon.
      // Eniki & Felicia alternate weekly: one week morning, next week afternoon.
      // Christaline always morning (pairs with whoever is on the morning shift).
      const weekIndex = Math.floor(dayIndex / 7)
      christaline = 'MORNING'
      if (weekIndex % 2 === 0) {
        eniki = 'MORNING'
        felicia = 'AFTERNOON'
      } else {
        eniki = 'AFTERNOON'
        felicia = 'MORNING'
      }
    }

    entries.push({ date, staffName: 'Eniki', shift: eniki })
    entries.push({ date, staffName: 'Felicia', shift: felicia })
    entries.push({ date, staffName: 'Christaline', shift: christaline })
  }

  await db.insert(housekeepingSchedule).values(
    entries.map((e) => ({
      id: `hk-${e.date}-${e.staffName}-${Math.random().toString(36).slice(2, 8)}`,
      date: e.date,
      staffName: e.staffName,
      shift: e.shift,
    }))
  )

  revalidatePath('/statistika')

  return entries.map((e, i) => ({ id: `gen-${i}`, ...e }))
}
