'use server'

import { db } from '@/lib/db'
import { reservations, transfers, orderItems, settings, boats, routes, supplements, routeSupplements, supplierPricing, sellingPricing, excursions, excursionPricing, excursionSellingPricing, excursionBookings, bentralReservations, guests, payments, agencies, products, lunchProviders, deliveryNotes, deliveryNoteItems, scheduledExcursions, staff, invoiceDiscounts } from '@/lib/db/schema'
import { eq, and, or, lte, gte, desc, isNull, isNotNull, sql } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'

// Generate unique ID
function uid(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`
}

// ============ SETTINGS ============

export async function getExchangeRate(): Promise<number> {
  const result = await db
    .select()
    .from(settings)
    .where(eq(settings.key, 'exchangeRate'))
    .limit(1)
  
  if (result.length > 0) {
    return Number(result[0].value) || 4800
  }
  return 4800
}

export async function updateExchangeRate(rate: number) {
  await db
    .insert(settings)
    .values({ key: 'exchangeRate', value: String(rate) })
    .onConflictDoUpdate({
      target: settings.key,
      set: { value: String(rate) }
    })
  revalidatePath('/')
}

// ============ INVOICE DISCOUNTS ============

export async function getInvoiceDiscounts(reservationId: string) {
  return db
    .select()
    .from(invoiceDiscounts)
    .where(eq(invoiceDiscounts.reservationId, reservationId))
    .orderBy(invoiceDiscounts.createdAt)
}

export async function addInvoiceDiscount(
  reservationId: string,
  kind: 'stay' | 'item',
  label: string,
  amountAr: number,
) {
  await db.insert(invoiceDiscounts).values({
    id: uid('disc'),
    reservationId,
    kind,
    label: label.trim() || (kind === 'stay' ? 'Discount on stay' : 'Free item'),
    amountAr: Math.max(0, Math.round(amountAr || 0)),
  })
  revalidatePath(`/racun/${reservationId}`)
}

export async function deleteInvoiceDiscount(id: string, reservationId: string) {
  await db.delete(invoiceDiscounts).where(eq(invoiceDiscounts.id, id))
  revalidatePath(`/racun/${reservationId}`)
}

// ============ RESERVATIONS ============

// Get a single reservation by ID (including archived)
export async function getReservationById(reservationId: string) {
  const [res] = await db.select().from(reservations).where(eq(reservations.id, reservationId)).limit(1)
  if (!res) return null
  
  const resOrders = await db.select().from(orderItems).where(eq(orderItems.reservationId, reservationId))
  const resPayments = await db.select().from(payments).where(eq(payments.reservationId, reservationId))
  const resTransfers = await db.select().from(transfers).where(eq(transfers.reservationId, reservationId))
  const resDeliveryNotes = await db.select().from(deliveryNotes).where(eq(deliveryNotes.reservationId, reservationId))
  const rate = await getExchangeRate()
  
  return {
    ...res,
    arrival: res.arrival ? (typeof res.arrival === 'string' ? res.arrival : res.arrival.toISOString().split('T')[0]) : '',
    departure: res.departure ? (typeof res.departure === 'string' ? res.departure : res.departure.toISOString().split('T')[0]) : '',
    checkedInAt: res.checkedInAt ? (typeof res.checkedInAt === 'string' ? res.checkedInAt : res.checkedInAt.toISOString()) : null,
    checkedOutAt: res.checkedOutAt ? (typeof res.checkedOutAt === 'string' ? res.checkedOutAt : res.checkedOutAt.toISOString()) : null,
    totalAmount: Number(res.totalAmount) || 0,
    amountPaid: Number(res.amountPaid) || 0,
    agencyCommission: Number(res.agencyCommission) || 0,
    orderItems: resOrders.map(o => ({
      id: o.id,
      name: o.name,
      category: o.category,
      priceAr: o.priceAr || 0,
      paymentStatus: o.paymentStatus,
      eventDate: o.eventDate
    })),
    payments: resPayments.map(p => ({
      id: p.id,
      amount: Number(p.amount),
      currency: p.currency,
      method: p.method,
      paidAt: p.paidAt ? (typeof p.paidAt === 'string' ? p.paidAt : p.paidAt.toISOString()) : '',
      notes: p.notes
    })),
    transfers: resTransfers.map(t => ({
      id: t.id,
      direction: t.direction,
      paymentStatus: t.paymentStatus
    })),
    deliveryNotesTotal: resDeliveryNotes.reduce((sum, dn) => sum + (dn.totalAr || 0), 0),
    exchangeRate: rate
  }
}

// ============ RESERVATIONS ============

export async function getReservations() {
  return db.select().from(reservations).orderBy(desc(reservations.arrival))
}

export async function getReservationWithDetails(id: string) {
  const [reservation] = await db.select().from(reservations).where(eq(reservations.id, id))
  if (!reservation) return null
  
  const reservationTransfers = await db.select().from(transfers).where(eq(transfers.reservationId, id))
  const reservationOrders = await db.select().from(orderItems).where(eq(orderItems.reservationId, id))
  
  const arrivalTransfer = reservationTransfers.find(t => t.type === 'arrival')
  const departureTransfer = reservationTransfers.find(t => t.type === 'departure')
  
  return {
    ...reservation,
    transfers: {
      arrival: arrivalTransfer ? {
        route: arrivalTransfer.route || '',
        time: arrivalTransfer.time || '',
        flightNumber: arrivalTransfer.flightNumber || '',
        flightTime: arrivalTransfer.flightTime || '',
        pickupDate: arrivalTransfer.pickupDate || '',
        notes: arrivalTransfer.notes || '',
        boatId: arrivalTransfer.boatId || '',
        boatPortTime: arrivalTransfer.boatPortTime || '',
        hermanAirportTime: arrivalTransfer.hermanAirportTime || '',
        dilipOrderedAt: arrivalTransfer.dilipOrderedAt?.toISOString() || null,
        hermanOrderedAt: arrivalTransfer.hermanOrderedAt?.toISOString() || null,
        guestPrice: Number(arrivalTransfer.guestPrice) || 0,
        paymentStatus: arrivalTransfer.paymentStatus || 'UNPAID'
      } : { route: '', time: '', flightNumber: '', flightTime: '', pickupDate: '', notes: '', boatId: '', boatPortTime: '', hermanAirportTime: '', dilipOrderedAt: null, hermanOrderedAt: null, guestPrice: 0, paymentStatus: 'UNPAID' },
      departure: departureTransfer ? {
        route: departureTransfer.route || '',
        time: departureTransfer.time || '',
        flightNumber: departureTransfer.flightNumber || '',
        flightTime: departureTransfer.flightTime || '',
        pickupDate: departureTransfer.pickupDate || '',
        notes: departureTransfer.notes || '',
        boatId: departureTransfer.boatId || '',
        boatPortTime: departureTransfer.boatPortTime || '',
        hermanAirportTime: departureTransfer.hermanAirportTime || '',
        dilipOrderedAt: departureTransfer.dilipOrderedAt?.toISOString() || null,
        hermanOrderedAt: departureTransfer.hermanOrderedAt?.toISOString() || null,
        guestPrice: Number(departureTransfer.guestPrice) || 0,
        paymentStatus: departureTransfer.paymentStatus || 'UNPAID'
      } : { route: '', time: '', flightNumber: '', flightTime: '', pickupDate: '', notes: '', boatId: '', boatPortTime: '', hermanAirportTime: '', dilipOrderedAt: null, hermanOrderedAt: null, guestPrice: 0, paymentStatus: 'UNPAID' }
    },
    orderItems: reservationOrders.map(o => ({
      id: o.id,
      name: o.name,
      category: o.category,
      qty: o.qty,
      priceAr: o.priceAr,
      paymentStatus: o.paymentStatus,
      eventDate: o.eventDate
    }))
  }
}

export async function createReservation(data: {
  guestName: string
  bungalow: string
  pax: number
  arrival: string
  departure: string
  bookingSource?: string
  agencyName?: string
  agencyCommission?: number
  }) {
  const id = uid('res')
  await db.insert(reservations).values({
  id,
  guestName: data.guestName,
  bungalow: data.bungalow,
  pax: data.pax,
  arrival: data.arrival,
  departure: data.departure,
  status: 'RESERVED',
  bookingSource: data.bookingSource || null,
  agencyName: data.agencyName || null,
  agencyCommission: data.agencyCommission ? String(data.agencyCommission) : '0',
  })
  revalidatePath('/')
  return id
}

export async function updateReservation(id: string, data: Partial<{
  guestName: string
  secondGuestName: string
  bungalow: string
  pax: number
  arrival: string
  departure: string
  status: string
  bookingSource: string
  agencyName: string
  agencyCommission: number
  nationality: string
  passport: string
  dateOfBirth: string
  placeOfBirth: string
  fatherName: string
  motherName: string
  profession: string
  domicile: string
  passportDate: string
  passportLieu: string
  venantDe: string
  validiteVisa: string
  allantA: string
  secondNationality: string
  secondPassport: string
  secondDateOfBirth: string
  secondPlaceOfBirth: string
  secondFatherName: string
  secondMotherName: string
  secondProfession: string
  secondDomicile: string
  secondPassportDate: string
  secondPassportLieu: string
  secondVenantDe: string
  secondValiditeVisa: string
  secondAllantA: string
  email: string
  phone: string
  allergies: string
  honeymoon: boolean
  noTransferNeeded: boolean
  notes: string
  checkedInAt: string | null
  checkedOutAt: string | null
  mealPlan: string
  mealPlanPaymentStatus: string
  totalAmount: number
  amountPaid: number
  groupId: string | null
  isMainReservation: boolean
  sharedInvoice: boolean
}>) {
  // Convert checkedInAt/checkedOutAt string to Date if present, or null to clear
  const updateData: Record<string, unknown> = { ...data, updatedAt: new Date() }
  if (data.checkedInAt !== undefined) {
    updateData.checkedInAt = data.checkedInAt ? new Date(data.checkedInAt) : null
  }
  if (data.checkedOutAt !== undefined) {
    updateData.checkedOutAt = data.checkedOutAt ? new Date(data.checkedOutAt) : null
  }
  // Convert agencyCommission to string for decimal column
  if (data.agencyCommission !== undefined) {
    updateData.agencyCommission = String(data.agencyCommission)
  }
  await db.update(reservations)
    .set(updateData)
    .where(eq(reservations.id, id))
  // Note: revalidatePath removed to prevent input focus loss during typing
  // User can manually refresh to see changes
}

export async function deleteReservation(id: string) {
  await db.delete(reservations).where(eq(reservations.id, id))
  revalidatePath('/')
}

// ============ RESERVATION GROUPS ============

// Create a new group with the given reservation as main
export async function createReservationGroup(mainReservationId: string) {
  const groupId = uid('grp')
  await db.update(reservations)
    .set({ groupId, isMainReservation: true })
    .where(eq(reservations.id, mainReservationId))
  revalidatePath('/')
  return groupId
}

// Link a reservation to an existing group
export async function linkReservationToGroup(reservationId: string, groupId: string) {
  await db.update(reservations)
    .set({ groupId, isMainReservation: false })
    .where(eq(reservations.id, reservationId))
  revalidatePath('/')
}

// Unlink a reservation from its group
export async function unlinkReservationFromGroup(reservationId: string) {
  // First check if this is the main reservation
  const [res] = await db.select().from(reservations).where(eq(reservations.id, reservationId))
  if (!res) return
  
  if (res.isMainReservation && res.groupId) {
    // Find another reservation in the group to make main
    const [nextMain] = await db.select()
      .from(reservations)
      .where(and(
        eq(reservations.groupId, res.groupId),
        sql`${reservations.id} != ${reservationId}`
      ))
      .limit(1)
    
    if (nextMain) {
      // Make the next one main
      await db.update(reservations)
        .set({ isMainReservation: true })
        .where(eq(reservations.id, nextMain.id))
    }
  }
  
  // Unlink this reservation
  await db.update(reservations)
    .set({ groupId: null, isMainReservation: false })
    .where(eq(reservations.id, reservationId))
  
  revalidatePath('/')
}

// Get all reservations in a group
export async function getGroupReservations(groupId: string) {
  return db.select().from(reservations).where(eq(reservations.groupId, groupId))
}

// ============ TRANSFERS ============

export async function updateTransfer(reservationId: string, type: 'arrival' | 'departure', data: {
  route?: string
  time?: string
  flightNumber?: string
  flightTime?: string
  pickupDate?: string
  notes?: string
  boatId?: string
  boatPortTime?: string
  hermanAirportTime?: string
  dilipOrderedAt?: Date | null
  hermanOrderedAt?: Date | null
  guestPrice?: number
  paymentStatus?: string
  executed?: boolean
  executedAt?: string | null
}) {
  const existing = await db.select().from(transfers)
    .where(and(eq(transfers.reservationId, reservationId), eq(transfers.type, type)))
    .limit(1)
  
  if (existing.length > 0) {
    await db.update(transfers)
      .set({
        route: data.route ?? existing[0].route,
        time: data.time ?? existing[0].time,
        flightNumber: data.flightNumber ?? existing[0].flightNumber,
        flightTime: data.flightTime ?? existing[0].flightTime,
        pickupDate: data.pickupDate ?? existing[0].pickupDate,
        notes: data.notes ?? existing[0].notes,
        boatId: data.boatId ?? existing[0].boatId,
        boatPortTime: data.boatPortTime ?? existing[0].boatPortTime,
        hermanAirportTime: data.hermanAirportTime ?? existing[0].hermanAirportTime,
        dilipOrderedAt: data.dilipOrderedAt !== undefined ? data.dilipOrderedAt : existing[0].dilipOrderedAt,
        hermanOrderedAt: data.hermanOrderedAt !== undefined ? data.hermanOrderedAt : existing[0].hermanOrderedAt,
        guestPrice: data.guestPrice !== undefined ? String(data.guestPrice) : existing[0].guestPrice,
        paymentStatus: data.paymentStatus ?? existing[0].paymentStatus,
        executed: data.executed !== undefined ? data.executed : existing[0].executed,
        executedAt: data.executedAt !== undefined ? (data.executedAt ? new Date(data.executedAt) : null) : existing[0].executedAt
      })
      .where(eq(transfers.id, existing[0].id))
  } else {
    await db.insert(transfers).values({
      id: uid('tr'),
      reservationId,
      type,
      route: data.route || '',
      time: data.time || '',
      flightNumber: data.flightNumber,
      flightTime: data.flightTime,
      pickupDate: data.pickupDate,
      notes: data.notes,
      boatId: data.boatId,
      boatPortTime: data.boatPortTime,
      hermanAirportTime: data.hermanAirportTime,
      dilipOrderedAt: data.dilipOrderedAt,
      hermanOrderedAt: data.hermanOrderedAt,
      boatId: data.boatId,
      guestPrice: String(data.guestPrice || 0),
      paymentStatus: data.paymentStatus || 'UNPAID',
      executed: data.executed || false,
      executedAt: data.executedAt ? new Date(data.executedAt) : null
    })
  }
  revalidatePath('/')
}

export async function deleteTransfer(reservationId: string, type: 'arrival' | 'departure') {
  await db.delete(transfers)
    .where(and(eq(transfers.reservationId, reservationId), eq(transfers.type, type)))
  revalidatePath('/')
}

// ============ ORDER ITEMS ============

export async function addOrderItem(reservationId: string, data: {
  name: string
  category: string
  qty: number
  priceAr: number
  paymentStatus?: string
  eventDate?: string // Date when the item/service occurs (for excursions, transfers)
}) {
  await db.insert(orderItems).values({
    id: uid('ord'),
    reservationId,
    name: data.name,
    category: data.category,
    qty: data.qty,
    priceAr: data.priceAr,
    paymentStatus: data.paymentStatus || 'UNPAID',
    eventDate: data.eventDate || null
  })
  revalidatePath('/')
}

export async function deleteOrderItem(id: string) {
  await db.delete(orderItems).where(eq(orderItems.id, id))
  revalidatePath('/')
}

export async function getOrderItems(reservationId: string) {
  return await db.select().from(orderItems).where(eq(orderItems.reservationId, reservationId))
}

export async function updateOrderItemPaymentStatus(id: string, status: string) {
  await db.update(orderItems).set({ paymentStatus: status }).where(eq(orderItems.id, id))
  revalidatePath('/')
}

// ============ DASHBOARD DATA ============

export async function getDashboardData() {
  // Only fetch ACTIVE reservations (not checked out) for dashboard performance
  const allReservations = await db.select().from(reservations)
    .where(isNull(reservations.checkedOutAt))
    .orderBy(desc(reservations.arrival))
  const allTransfers = await db.select().from(transfers)
  const allOrders = await db.select().from(orderItems)
  const allExcursionBookings = await db.select().from(excursionBookings)
  const allPayments = await db.select().from(payments)
  const allDeliveryNotes = await db.select().from(deliveryNotes)
  const allDeliveryNoteItems = await db.select().from(deliveryNoteItems)
  const rate = await getExchangeRate()
  
  // Fetch additional data needed by frontend
  const allBoats = await db.select().from(boats).where(eq(boats.active, true))
  const allRoutes = await db.select().from(routes).where(eq(routes.active, true))
  const allSellingPricing = await db.select().from(sellingPricing)
  const allExcursions = await db.select().from(excursions).where(eq(excursions.active, true))
  const allExcursionSellingPricing = await db.select().from(excursionSellingPricing)
  const allExcursionPricing = await db.select().from(excursionPricing).where(eq(excursionPricing.active, true))
const allLunchProviders = await db.select().from(lunchProviders).where(eq(lunchProviders.active, true))
const allScheduledExcursions = await db.select().from(scheduledExcursions).orderBy(scheduledExcursions.date)
const allStaff = await db.select().from(staff).where(eq(staff.active, true)).orderBy(staff.name)
  
  // Get meal products (category = "Prehrana") for meal plan pricing
  const allProducts = await db.select().from(products).where(eq(products.active, true))
  const mealProducts = allProducts.filter(p => p.category === 'Prehrana').map(p => ({
    id: p.id,
    name: p.name,
    priceAr: p.priceAr || 0
  }))
  
  // Build reservation data with transfers and orders
  const reservationsWithDetails = allReservations.map(res => {
    const resTransfers = allTransfers.filter(t => t.reservationId === res.id)
    const resOrders = allOrders.filter(o => o.reservationId === res.id)
    const resExcursions = allExcursionBookings.filter(e => e.reservationId === res.id)
    const resPayments = allPayments.filter(p => p.reservationId === res.id)
    const resDeliveryNotes = allDeliveryNotes.filter(dn => dn.reservationId === res.id)
    const resDeliveryNoteItems = allDeliveryNoteItems.filter(dni => 
      resDeliveryNotes.some(dn => dn.id === dni.deliveryNoteId)
    )
    
    const arrivalTransfer = resTransfers.find(t => t.type === 'arrival')
    const departureTransfer = resTransfers.find(t => t.type === 'departure')
    
    return {
      ...res,
      transfers: {
        arrival: arrivalTransfer ? {
          route: arrivalTransfer.route || '',
          time: arrivalTransfer.time || '',
          flightNumber: arrivalTransfer.flightNumber || '',
          flightTime: arrivalTransfer.flightTime || '',
          pickupDate: arrivalTransfer.pickupDate || '',
          notes: arrivalTransfer.notes || '',
          boatId: arrivalTransfer.boatId || '',
          boatPortTime: arrivalTransfer.boatPortTime || '',
          hermanAirportTime: arrivalTransfer.hermanAirportTime || '',
          dilipOrderedAt: arrivalTransfer.dilipOrderedAt?.toISOString() || null,
          hermanOrderedAt: arrivalTransfer.hermanOrderedAt?.toISOString() || null,
          guestPrice: Number(arrivalTransfer.guestPrice) || 0,
          paymentStatus: arrivalTransfer.paymentStatus || 'UNPAID',
          executed: arrivalTransfer.executed || false,
          executedAt: arrivalTransfer.executedAt?.toISOString() || null
        } : { route: '', time: '', flightNumber: '', flightTime: '', pickupDate: '', notes: '', boatId: '', boatPortTime: '', hermanAirportTime: '', dilipOrderedAt: null, hermanOrderedAt: null, guestPrice: 0, paymentStatus: 'UNPAID', executed: false, executedAt: null },
        departure: departureTransfer ? {
          route: departureTransfer.route || '',
          time: departureTransfer.time || '',
          flightNumber: departureTransfer.flightNumber || '',
          flightTime: departureTransfer.flightTime || '',
          pickupDate: departureTransfer.pickupDate || '',
          notes: departureTransfer.notes || '',
          boatId: departureTransfer.boatId || '',
          boatPortTime: departureTransfer.boatPortTime || '',
          hermanAirportTime: departureTransfer.hermanAirportTime || '',
          dilipOrderedAt: departureTransfer.dilipOrderedAt?.toISOString() || null,
          hermanOrderedAt: departureTransfer.hermanOrderedAt?.toISOString() || null,
          guestPrice: Number(departureTransfer.guestPrice) || 0,
          paymentStatus: departureTransfer.paymentStatus || 'UNPAID',
          executed: departureTransfer.executed || false,
          executedAt: departureTransfer.executedAt?.toISOString() || null
        } : { route: '', time: '', flightNumber: '', flightTime: '', pickupDate: '', notes: '', boatId: '', boatPortTime: '', hermanAirportTime: '', dilipOrderedAt: null, hermanOrderedAt: null, guestPrice: 0, paymentStatus: 'UNPAID' }
      },
      orderItems: resOrders.map(o => ({
        id: o.id,
        name: o.name,
        category: o.category,
        qty: o.qty,
        priceAr: o.priceAr,
        paymentStatus: o.paymentStatus,
        eventDate: o.eventDate
      })),
      payments: resPayments.map(p => ({
        id: p.id,
        amount: Number(p.amount),
        currency: p.currency,
        method: p.method,
        paidAt: p.paidAt ? (typeof p.paidAt === 'string' ? p.paidAt : (p.paidAt instanceof Date ? p.paidAt.toISOString() : String(p.paidAt))) : '',
        notes: p.notes
      })),
      deliveryNotesTotal: resDeliveryNotes.reduce((sum, dn) => sum + (dn.totalAr || 0), 0),
      barItems: resDeliveryNoteItems.map(dni => {
        const note = resDeliveryNotes.find(dn => dn.id === dni.deliveryNoteId)
        return {
          id: dni.id,
          productName: dni.productName,
          category: dni.category,
          quantity: dni.quantity,
          priceAr: dni.priceAr,
          totalAr: dni.totalAr,
          noteDate: note?.date ? (typeof note.date === 'string' ? note.date.split('T')[0] : note.date.toISOString().split('T')[0]) : new Date().toISOString().split('T')[0],
          noteStatus: note?.status || 'open',
          staffName: dni.staffName
        }
      }),
excursions: resExcursions.map(e => ({
  id: e.id,
  excursionId: e.excursionId,
  boatId: e.boatId,
  date: e.date,
  pax: e.pax,
  guestPrice: e.guestPrice ? Number(e.guestPrice) : 0,
  entranceFee: e.entranceFee ? Number(e.entranceFee) : 0,
  lunchPrice: e.lunchPrice ? Number(e.lunchPrice) : 0,
  lunchPax: e.lunchPax || 0,
  paymentStatus: e.paymentStatus,
  lunchProviderId: e.lunchProviderId,
  dilipOrderedAt: e.dilipOrderedAt?.toISOString() || null
  }))
    }
  })
  
  return {
    reservations: reservationsWithDetails,
    exchangeRate: rate,
    mealProducts,
    allProducts: allProducts.map(p => ({
      id: p.id,
      name: p.name,
      category: p.category,
      priceAr: p.priceAr || 0
    })),
    boats: allBoats,
    routes: allRoutes,
    sellingPricing: allSellingPricing,
    excursions: allExcursions,
    excursionSellingPricing: allExcursionSellingPricing,
    excursionPricing: allExcursionPricing,
    lunchProviders: allLunchProviders,
    scheduledExcursions: allScheduledExcursions.map(s => {
      // Normalize date to YYYY-MM-DD format
      const schedDate = String(s.date).split('T')[0]
      
      const matchingBookings = allExcursionBookings.filter(b => {
        const bookDate = String(b.date).split('T')[0]
        return schedDate === bookDate
      })
      
      return {
        id: s.id,
        date: s.date,
        excursionType: s.excursionType,
        isOption: s.isOption,
        notes: s.notes,
        guests: matchingBookings
          .map(b => {
            const res = allReservations.find(r => r.id === b.reservationId)
            return res ? { 
              reservationId: res.id, 
              guestName: res.guestName, 
              bungalow: res.bungalow,
              pax: b.pax 
            } : null
          })
          .filter(Boolean)
      }
    }),
    staff: allStaff.map(s => ({
      id: s.id,
      name: s.name,
      role: s.role,
      pin: s.pin
    }))
  }
}

// ============ CHECK OVERLAP ============

export async function checkOverlap(bungalow: string, arrival: string, departure: string, excludeId?: string) {
  // Get all reservations for this bungalow
  const existingReservations = await db.select().from(reservations).where(
    eq(reservations.bungalow, bungalow)
  )
  
  // Filter to find actual overlaps
  // Key rule: departure day of one guest = arrival day of another guest is OK (same day turnover)
  // So we check: new arrival < existing departure AND new departure > existing arrival
  // This means arrival ON departure day is allowed
  const overlapping = existingReservations.filter(r => {
    // Skip the reservation being edited
    if (excludeId && r.id === excludeId) return false
    
    // Check for real overlap (excluding same-day turnover)
    // Overlap exists if: new guest arrives BEFORE existing guest leaves AND new guest leaves AFTER existing guest arrives
    // arrival < r.departure (not <=) means arriving on departure day is OK
    // departure > r.arrival (not >=) means leaving on arrival day is OK
    return arrival < r.departure && departure > r.arrival
  })
  
  return overlapping.length > 0
}

// ============ TRANSFER PRICING ============

// --- BOATS ---
export async function getBoats() {
  return db.select().from(boats).where(eq(boats.active, true)).orderBy(boats.name)
}

export async function createBoat(data: { name: string; engine: string; maxPax: number }) {
  const id = uid('boat')
  await db.insert(boats).values({ id, ...data })
  revalidatePath('/')
  return id
}

export async function updateBoat(id: string, data: { name?: string; engine?: string; maxPax?: number }) {
  await db.update(boats).set(data).where(eq(boats.id, id))
  revalidatePath('/')
}

export async function deleteBoat(id: string) {
  await db.update(boats).set({ active: false }).where(eq(boats.id, id))
  revalidatePath('/')
}

// --- ROUTES ---
export async function getRoutes() {
  return db.select().from(routes).where(eq(routes.active, true)).orderBy(routes.name)
}

export async function createRoute(data: { name: string; type: string; baseRouteId?: string }) {
  const id = uid('route')
  await db.insert(routes).values({ id, ...data })
  revalidatePath('/')
  return id
}

export async function updateRoute(id: string, data: { name?: string; type?: string; baseRouteId?: string | null }) {
  await db.update(routes).set(data).where(eq(routes.id, id))
  revalidatePath('/')
}

export async function deleteRoute(id: string) {
  await db.update(routes).set({ active: false }).where(eq(routes.id, id))
  revalidatePath('/')
}

// --- SUPPLEMENTS ---
export async function getSupplements() {
  return db.select().from(supplements).where(eq(supplements.active, true)).orderBy(supplements.name)
}

export async function createSupplement(data: { name: string; priceAr: number }) {
  const id = uid('supp')
  await db.insert(supplements).values({ id, ...data })
  revalidatePath('/')
  return id
}

export async function updateSupplement(id: string, data: { name?: string; priceAr?: number }) {
  await db.update(supplements).set(data).where(eq(supplements.id, id))
  revalidatePath('/')
}

export async function deleteSupplement(id: string) {
  await db.update(supplements).set({ active: false }).where(eq(supplements.id, id))
  revalidatePath('/')
}

// --- ROUTE SUPPLEMENTS ---
export async function getRouteSupplements() {
  return db.select().from(routeSupplements)
}

export async function addRouteSupplement(routeId: string, supplementId: string) {
  const id = uid('rs')
  await db.insert(routeSupplements).values({ id, routeId, supplementId })
  revalidatePath('/')
}

export async function removeRouteSupplement(id: string) {
  await db.delete(routeSupplements).where(eq(routeSupplements.id, id))
  revalidatePath('/')
}

// --- SUPPLIER PRICING ---
export async function getSupplierPricing() {
  return db.select().from(supplierPricing).where(eq(supplierPricing.active, true))
}

export async function upsertSupplierPrice(boatId: string, routeId: string, priceAr: number) {
  const existing = await db.select().from(supplierPricing)
    .where(and(eq(supplierPricing.boatId, boatId), eq(supplierPricing.routeId, routeId)))
    .limit(1)
  
  if (existing.length > 0) {
    await db.update(supplierPricing).set({ priceAr, active: true }).where(eq(supplierPricing.id, existing[0].id))
  } else {
    await db.insert(supplierPricing).values({ id: uid('sp'), boatId, routeId, priceAr })
  }
  revalidatePath('/')
}

export async function deleteSupplierPrice(id: string) {
  await db.update(supplierPricing).set({ active: false }).where(eq(supplierPricing.id, id))
  revalidatePath('/')
}

// --- SELLING PRICING ---
export async function getSellingPricing() {
  return db.select().from(sellingPricing).where(eq(sellingPricing.active, true))
}

export async function upsertSellingPrice(boatId: string, routeId: string, prices: {
  pricePax1: number; pricePax2: number; pricePax3: number;
  pricePax4: number; pricePax5: number; pricePax6: number;
}) {
  const existing = await db.select().from(sellingPricing)
    .where(and(eq(sellingPricing.boatId, boatId), eq(sellingPricing.routeId, routeId)))
    .limit(1)
  
  const data = {
    pricePax1: String(prices.pricePax1),
    pricePax2: String(prices.pricePax2),
    pricePax3: String(prices.pricePax3),
    pricePax4: String(prices.pricePax4),
    pricePax5: String(prices.pricePax5),
    pricePax6: String(prices.pricePax6),
  }
  
  if (existing.length > 0) {
    await db.update(sellingPricing).set({ ...data, active: true }).where(eq(sellingPricing.id, existing[0].id))
  } else {
    await db.insert(sellingPricing).values({ id: uid('sell'), boatId, routeId, ...data })
  }
  revalidatePath('/')
}

export async function deleteSellingPrice(id: string) {
  await db.update(sellingPricing).set({ active: false }).where(eq(sellingPricing.id, id))
  revalidatePath('/')
}

// --- GET ALL PRICING DATA ---
export async function getTransferPricingData() {
  const [boatsData, routesData, supplementsData, routeSupplementsData, supplierData, sellingData] = await Promise.all([
    getBoats(),
    getRoutes(),
    getSupplements(),
    getRouteSupplements(),
    getSupplierPricing(),
    getSellingPricing()
  ])
  
  return {
    boats: boatsData,
    routes: routesData,
    supplements: supplementsData,
    routeSupplements: routeSupplementsData,
    supplierPricing: supplierData,
    sellingPricing: sellingData
  }
}

// ============ EXCURSION PRICING ============

// --- EXCURSIONS ---
export async function getExcursions() {
  return db.select().from(excursions).where(eq(excursions.active, true)).orderBy(excursions.name)
}

export async function createExcursion(data: { name: string; guidePriceAr: number; entranceFeeAr?: number; lunchPriceAr?: number }) {
  const id = uid('exc')
  await db.insert(excursions).values({ id, ...data })
  revalidatePath('/')
  return id
}

export async function updateExcursion(id: string, data: { name?: string; guidePriceAr?: number; entranceFeeAr?: number; lunchPriceAr?: number }) {
  await db.update(excursions).set(data).where(eq(excursions.id, id))
  revalidatePath('/')
}

export async function deleteExcursion(id: string) {
  await db.update(excursions).set({ active: false }).where(eq(excursions.id, id))
  revalidatePath('/')
}

// --- EXCURSION PRICING ---
export async function getExcursionPricing() {
  return db.select().from(excursionPricing).where(eq(excursionPricing.active, true))
}

export async function upsertExcursionPrice(excursionId: string, boatId: string, priceAr: number) {
  const existing = await db.select().from(excursionPricing)
    .where(and(eq(excursionPricing.excursionId, excursionId), eq(excursionPricing.boatId, boatId)))
    .limit(1)
  
  if (existing.length > 0) {
    await db.update(excursionPricing).set({ priceAr, active: true }).where(eq(excursionPricing.id, existing[0].id))
  } else {
    await db.insert(excursionPricing).values({ id: uid('ep'), excursionId, boatId, priceAr })
  }
  revalidatePath('/')
}

export async function deleteExcursionPrice(id: string) {
  await db.update(excursionPricing).set({ active: false }).where(eq(excursionPricing.id, id))
  revalidatePath('/')
}

// --- EXCURSION SELLING PRICING ---
export async function getExcursionSellingPricing() {
  return db.select().from(excursionSellingPricing).where(eq(excursionSellingPricing.active, true))
}

export async function upsertExcursionSellingPrice(excursionId: string, boatId: string, prices: {
  pricePax1: number; pricePax2: number; pricePax3: number;
  pricePax4: number; pricePax5: number; pricePax6: number;
}) {
  const existing = await db.select().from(excursionSellingPricing)
    .where(and(eq(excursionSellingPricing.excursionId, excursionId), eq(excursionSellingPricing.boatId, boatId)))
    .limit(1)
  
  const data = {
    pricePax1: String(prices.pricePax1),
    pricePax2: String(prices.pricePax2),
    pricePax3: String(prices.pricePax3),
    pricePax4: String(prices.pricePax4),
    pricePax5: String(prices.pricePax5),
    pricePax6: String(prices.pricePax6),
  }
  
  if (existing.length > 0) {
    await db.update(excursionSellingPricing).set({ ...data, active: true }).where(eq(excursionSellingPricing.id, existing[0].id))
  } else {
    await db.insert(excursionSellingPricing).values({ id: uid('esp'), excursionId, boatId, ...data })
  }
  revalidatePath('/')
}

// --- GET ALL EXCURSION DATA ---
export async function getExcursionPricingData() {
  const [boatsData, excursionsData, pricingData, sellingData] = await Promise.all([
    getBoats(),
    getExcursions(),
    getExcursionPricing(),
    getExcursionSellingPricing()
  ])
  
  return {
    boats: boatsData,
    excursions: excursionsData,
    pricing: pricingData,
    sellingPricing: sellingData
  }
}

// ============ AGENCIES ============

export async function getAgencies() {
  return db.select().from(agencies).where(eq(agencies.active, true)).orderBy(agencies.name)
}

export async function createAgency(data: { name: string; contactPerson?: string; email?: string; phone?: string; notes?: string }) {
  const id = uid('agency')
  await db.insert(agencies).values({
    id,
    name: data.name,
    contactPerson: data.contactPerson || null,
    email: data.email || null,
    phone: data.phone || null,
    notes: data.notes || null,
  })
  revalidatePath('/')
  return id
}

export async function updateAgency(id: string, data: Partial<{ name: string; contactPerson: string; email: string; phone: string; notes: string; active: boolean }>) {
  await db.update(agencies).set(data).where(eq(agencies.id, id))
  revalidatePath('/')
}

export async function deleteAgency(id: string) {
  await db.update(agencies).set({ active: false }).where(eq(agencies.id, id))
  revalidatePath('/')
}

// ============ BENTRAL RESERVATIONS ============

// Parse date from Bentral format (DD.MM.YYYY) to ISO format (YYYY-MM-DD)
function parseBentralDate(dateStr: string): string {
  const parts = dateStr.trim().split('.')
  if (parts.length !== 3) return dateStr
  const [day, month, year] = parts
  return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`
}

// Parse Bentral CSV line (semicolon separated, handles quoted fields with newlines)
function parseBentralCSVLine(line: string): string[] {
  const result: string[] = []
  let current = ''
  let inQuotes = false
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i]
    if (char === '"') {
      inQuotes = !inQuotes
    } else if (char === ';' && !inQuotes) {
      result.push(current.trim())
      current = ''
    } else {
      current += char
    }
  }
  result.push(current.trim())
  return result
}

export async function importBentralCSV(csvContent: string) {
  const lines = csvContent.split('\n')
  const dataLines: string[] = []
  
  // Find data lines (skip header rows, join multiline entries)
  let currentLine = ''
  let inMultiline = false
  
  for (const line of lines) {
    // Skip empty lines and header rows
    if (!line.trim()) continue
    if (line.startsWith('Rezervacije') || line.startsWith('Objekt:') || line.startsWith('Datum prihoda:') || line.startsWith('Št. rezervacije;')) continue
    if (line.startsWith(';;;;')) continue
    
    // Handle multiline fields (quoted text with newlines)
    const quoteCount = (line.match(/"/g) || []).length
    
    if (inMultiline) {
      currentLine += '\n' + line
      if (quoteCount % 2 === 1) {
        inMultiline = false
        dataLines.push(currentLine)
        currentLine = ''
      }
    } else if (quoteCount % 2 === 1) {
      // Start of multiline
      currentLine = line
      inMultiline = true
    } else {
      // Normal line
      if (line.includes(';')) {
        dataLines.push(line)
      }
    }
  }
  
  let imported = 0
  let updated = 0
  let skipped = 0
  
  for (const line of dataLines) {
    try {
      const fields = parseBentralCSVLine(line)
      if (fields.length < 15) continue
      
      const [externalId, status, , source, guestName, country, checkInRaw, checkOutRaw, nightsStr, adultsStr, childrenStr, childrenAges, units, currency, amountStr, guestNotes, ownNotes] = fields
      
      if (!externalId || !guestName || !checkInRaw || !checkOutRaw) continue
      
      const checkIn = parseBentralDate(checkInRaw)
      const checkOut = parseBentralDate(checkOutRaw)
      const nights = parseInt(nightsStr) || 0
      const adults = parseInt(adultsStr) || 1
      const children = parseInt(childrenStr) || 0
      const amount = amountStr ? amountStr.replace(',', '.') : '0'
      
      // Check if reservation exists
      const existing = await db.select().from(bentralReservations).where(eq(bentralReservations.externalId, externalId)).limit(1)
      
      if (existing.length > 0) {
        // Update existing
        await db.update(bentralReservations).set({
          status,
          source: source || null,
          guestName,
          country: country || null,
          checkIn,
          checkOut,
          nights,
          adults,
          children,
          childrenAges: childrenAges || null,
          units: units || null,
          currency: currency || 'EUR',
          amount,
          guestNotes: guestNotes || null,
          ownNotes: ownNotes || null,
          updatedAt: new Date(),
        }).where(eq(bentralReservations.id, existing[0].id))
        updated++
      } else {
        // Insert new
        await db.insert(bentralReservations).values({
          id: uid('br'),
          externalId,
          status,
          source: source || null,
          guestName,
          country: country || null,
          checkIn,
          checkOut,
          nights,
          adults,
          children,
          childrenAges: childrenAges || null,
          units: units || null,
          currency: currency || 'EUR',
          amount,
          guestNotes: guestNotes || null,
          ownNotes: ownNotes || null,
        })
        imported++
      }
    } catch (e) {
      skipped++
    }
  }
  
  revalidatePath('/')
  return { imported, updated, skipped }
}

export async function getBentralReservations(filters?: { status?: string; fromDate?: string; toDate?: string }) {
  let query = db.select().from(bentralReservations).where(eq(bentralReservations.active, true))
  
  // Apply filters if provided
  const conditions = [eq(bentralReservations.active, true)]
  
  if (filters?.status && filters.status !== 'all') {
    conditions.push(eq(bentralReservations.status, filters.status))
  }
  
  if (filters?.fromDate) {
    conditions.push(gte(bentralReservations.checkIn, filters.fromDate))
  }
  
  if (filters?.toDate) {
    conditions.push(lte(bentralReservations.checkIn, filters.toDate))
  }
  
  return db.select().from(bentralReservations)
    .where(and(...conditions))
    .orderBy(bentralReservations.checkIn)
}

export async function deleteBentralReservation(id: string) {
  await db.update(bentralReservations).set({ active: false }).where(eq(bentralReservations.id, id))
  revalidatePath('/')
}

// ============ GUESTS ============

export async function getGuests() {
  return db.select().from(guests).where(eq(guests.active, true)).orderBy(guests.name)
}

export async function findOrCreateGuest(data: { name: string; email?: string; phone?: string; country?: string }) {
  // Try to find existing guest by name (could also match by email if provided)
  const existing = await db.select().from(guests)
    .where(and(eq(guests.name, data.name), eq(guests.active, true)))
    .limit(1)
  
  if (existing.length > 0) {
    // Update with any new info
    if (data.email || data.phone || data.country) {
      await db.update(guests).set({
        email: data.email || existing[0].email,
        phone: data.phone || existing[0].phone,
        country: data.country || existing[0].country,
        updatedAt: new Date(),
      }).where(eq(guests.id, existing[0].id))
    }
    return existing[0]
  }
  
  // Create new guest
  const id = uid('guest')
  await db.insert(guests).values({ id, ...data })
  const [newGuest] = await db.select().from(guests).where(eq(guests.id, id))
  return newGuest
}

// ============ TRANSFER BENTRAL TO MAIN SYSTEM ============

export async function transferBentralReservation(bentralId: string) {
  // Get Bentral reservation
  const [bentral] = await db.select().from(bentralReservations).where(eq(bentralReservations.id, bentralId))
  if (!bentral) throw new Error('Bentral rezervacija ne obstaja')
  if (bentral.transferred) throw new Error('Rezervacija je ze prenesena')
  
  // Find or create guest
  const guest = await findOrCreateGuest({
    name: bentral.guestName,
    country: bentral.country || undefined,
  })
  
  // Create main reservation
  const reservationId = uid('res')
  // Determine amount paid based on Bentral status
  const isPaid = bentral.status.toLowerCase().includes('placano') || bentral.status.toLowerCase().includes('plačano')
  const amountPaid = isPaid ? bentral.amount : '0'
  
  await db.insert(reservations).values({
    id: reservationId,
    guestId: guest.id,
    bentralReservationId: bentral.id,
    guestName: bentral.guestName,
    bungalow: bentral.units || 'TBD',
    pax: bentral.adults + bentral.children,
    arrival: bentral.checkIn,
    departure: bentral.checkOut,
    checkIn: bentral.checkIn,
    checkOut: bentral.checkOut,
    adults: bentral.adults,
    children: bentral.children,
    status: bentral.status === 'Preklicano' ? 'CANCELLED' : 'RESERVED',
    bookingSource: bentral.source || 'Direct',
    nationality: bentral.country,
    notes: [bentral.guestNotes, bentral.ownNotes].filter(Boolean).join('\n---\n') || undefined,
    totalAmount: bentral.amount,
    amountPaid: amountPaid,
    currency: bentral.currency || 'EUR',
  })
  
  // Mark Bentral reservation as transferred
  await db.update(bentralReservations).set({
    transferred: true,
    reservationId: reservationId,
    updatedAt: new Date(),
  }).where(eq(bentralReservations.id, bentralId))
  
  revalidatePath('/')
  return { reservationId, guestId: guest.id }
}

// Delete reservation and optionally the guest card
export async function deleteReservationAndGuest(reservationId: string, deleteGuest: boolean = false) {
  // Get reservation to find guest and bentral link
  const [res] = await db.select().from(reservations).where(eq(reservations.id, reservationId))
  if (!res) throw new Error('Rezervacija ne obstaja')
  
  // Reset bentral reservation if linked
  if (res.bentralReservationId) {
    await db.update(bentralReservations).set({
      transferred: false,
      reservationId: null,
      updatedAt: new Date(),
    }).where(eq(bentralReservations.id, res.bentralReservationId))
  }
  
  // Delete reservation
  await db.delete(reservations).where(eq(reservations.id, reservationId))
  
  // Delete guest if requested and no other reservations exist for this guest
  if (deleteGuest && res.guestId) {
    const otherReservations = await db.select().from(reservations)
      .where(eq(reservations.guestId, res.guestId))
      .limit(1)
    
    if (otherReservations.length === 0) {
      await db.update(guests).set({ active: false }).where(eq(guests.id, res.guestId))
    }
  }
  
  revalidatePath('/')
}

// ============ PAYMENTS ============

const PAYMENT_METHODS = ['card', 'transfer', 'orange_money', 'cash'] as const

export async function getPayments(reservationId: string) {
  return db.select().from(payments)
    .where(eq(payments.reservationId, reservationId))
    .orderBy(desc(payments.paidAt))
}

export async function addPayment(data: {
  reservationId: string
  amount: string
  method: string
  paidAt: string
  notes?: string
}) {
  const id = uid('pay')
  await db.insert(payments).values({
    id,
    reservationId: data.reservationId,
    amount: data.amount,
    method: data.method,
    paidAt: data.paidAt,
    notes: data.notes,
  })
  
  // Update reservation amountPaid
  const allPayments = await db.select().from(payments).where(eq(payments.reservationId, data.reservationId))
  const totalPaid = allPayments.reduce((sum, p) => sum + Number(p.amount), 0)
  await db.update(reservations).set({ amountPaid: totalPaid.toString() }).where(eq(reservations.id, data.reservationId))
  
  revalidatePath('/')
  return id
}

export async function deletePayment(id: string) {
  const [payment] = await db.select().from(payments).where(eq(payments.id, id))
  if (!payment) return
  
  await db.delete(payments).where(eq(payments.id, id))
  
  // Recalculate reservation amountPaid
  const allPayments = await db.select().from(payments).where(eq(payments.reservationId, payment.reservationId))
  const totalPaid = allPayments.reduce((sum, p) => sum + Number(p.amount), 0)
  await db.update(reservations).set({ amountPaid: totalPaid.toString() }).where(eq(reservations.id, payment.reservationId))
  
  revalidatePath('/')
}

// ============ EXCURSION BOOKINGS ============

export async function getExcursionBookings(reservationId: string) {
  return await db.select().from(excursionBookings).where(eq(excursionBookings.reservationId, reservationId))
}

export async function addExcursionBooking(reservationId: string, data: {
  excursionId: string
  boatId?: string
  date?: string
  pax?: number
  guestPrice?: number
  entranceFee?: number
  lunchPrice?: number
  lunchPax?: number
  paymentStatus?: string
  notes?: string
}) {
  const id = uid('excbk')
  await db.insert(excursionBookings).values({
    id,
    reservationId,
    excursionId: data.excursionId,
    boatId: data.boatId || null,
    date: data.date || null,
    pax: data.pax || 1,
    guestPrice: String(data.guestPrice || 0),
    entranceFee: String(data.entranceFee || 0),
    lunchPrice: String(data.lunchPrice || 0),
    lunchPax: data.lunchPax || 0,
    paymentStatus: data.paymentStatus || 'UNPAID',
    notes: data.notes || null,
  })

  // If the guest is ALREADY checked in, the check-in flow has already run and
  // won't add this excursion automatically. So we add it to the order now,
  // dated to the excursion day — exactly like the check-in logic does.
  const [res] = await db
    .select({ checkedInAt: reservations.checkedInAt })
    .from(reservations)
    .where(eq(reservations.id, reservationId))
    .limit(1)

  if (res?.checkedInAt) {
    const [excursion] = await db
      .select({ name: excursions.name })
      .from(excursions)
      .where(eq(excursions.id, data.excursionId))
      .limit(1)
    const excursionName = excursion?.name || 'Izlet'
    const pax = data.pax || 1
    const isPaid = (data.paymentStatus || 'UNPAID') === 'PAID'

    // Build included items list (boat, entrance fee, lunch) — same as check-in
    const included: string[] = []
    if (data.boatId) {
      const [boat] = await db.select({ name: boats.name }).from(boats).where(eq(boats.id, data.boatId)).limit(1)
      if (boat?.name) included.push(boat.name)
    }
    if (data.entranceFee && data.entranceFee > 0) included.push('vstopnina')
    const includedText = included.length > 0 ? ` | Vklj: ${included.join(', ')}` : ''

    // Total price = guest price + entrance fee + lunch price (EUR), converted to Ariary
    const exchangeRate = await getExchangeRate()
    const totalPriceEur = (data.guestPrice || 0) + (data.entranceFee || 0) + (data.lunchPrice || 0)
    const totalPriceAr = Math.round(totalPriceEur * exchangeRate)

    await db.insert(orderItems).values({
      id: uid('ord'),
      reservationId,
      name: `Izlet: ${excursionName} - ${pax} pax${includedText}`,
      category: 'Izlet',
      qty: 1,
      priceAr: isPaid ? 0 : totalPriceAr, // If paid, evidence only (0 Ar)
      paymentStatus: isPaid ? 'PAID' : 'UNPAID',
      eventDate: data.date || null, // Excursion happens on its specific date
    })
  }

  revalidatePath('/')
  return id
}

export async function updateExcursionBooking(id: string, data: Partial<{
  excursionId: string
  boatId: string
  date: string
  pax: number
  guestPrice: number
  entranceFee: number
  lunchPrice: number
  lunchPax: number
  lunchProviderId: string
  paymentStatus: string
  notes: string
  dilipOrderedAt: string
}>) {
  const updateData: Record<string, unknown> = {}
  if (data.excursionId !== undefined) updateData.excursionId = data.excursionId
  if (data.boatId !== undefined) updateData.boatId = data.boatId || null
  if (data.date !== undefined) updateData.date = data.date || null
  if (data.pax !== undefined) updateData.pax = data.pax
  if (data.guestPrice !== undefined) updateData.guestPrice = String(data.guestPrice)
  if (data.entranceFee !== undefined) updateData.entranceFee = String(data.entranceFee)
  if (data.lunchPrice !== undefined) updateData.lunchPrice = String(data.lunchPrice)
  if (data.lunchPax !== undefined) updateData.lunchPax = data.lunchPax
  if (data.lunchProviderId !== undefined) updateData.lunchProviderId = data.lunchProviderId || null
  if (data.paymentStatus !== undefined) updateData.paymentStatus = data.paymentStatus
  if (data.notes !== undefined) updateData.notes = data.notes || null
  if (data.dilipOrderedAt !== undefined) updateData.dilipOrderedAt = new Date(data.dilipOrderedAt)
  
  await db.update(excursionBookings).set(updateData).where(eq(excursionBookings.id, id))
  revalidatePath('/')
}

export async function deleteExcursionBooking(id: string) {
  await db.delete(excursionBookings).where(eq(excursionBookings.id, id))
  revalidatePath('/')
}

// ============ CHECK-OUT & ARCHIVE ============

// Complete checkout with payments
export async function completeCheckout(reservationId: string, checkoutPayments: Array<{
  amount: number
  currency: string
  method: string
  notes?: string
}>) {
  // Add all checkout payments
  for (const payment of checkoutPayments) {
    const id = `pay-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`
    await db.insert(payments).values({
      id,
      reservationId,
      amount: String(payment.amount),
      currency: payment.currency,
      method: payment.method,
      paidAt: new Date(),
      notes: payment.notes || null
    })
  }
  
  // Close any open delivery notes
  await db.update(deliveryNotes)
    .set({ status: 'closed' })
    .where(and(
      eq(deliveryNotes.reservationId, reservationId),
      eq(deliveryNotes.status, 'open')
    ))
  
  // Update reservation with total paid amount
  const allPayments = await db.select().from(payments).where(eq(payments.reservationId, reservationId))
  const totalPaid = allPayments.reduce((sum, p) => sum + Number(p.amount), 0)
  
  await db.update(reservations)
    .set({ 
      checkedOutAt: new Date(),
      amountPaid: String(totalPaid)
    })
    .where(eq(reservations.id, reservationId))
  
  revalidatePath('/')
}

export async function checkOutReservation(reservationId: string) {
  // Close any open delivery notes
  await db.update(deliveryNotes)
    .set({ status: 'closed' })
    .where(and(
      eq(deliveryNotes.reservationId, reservationId),
      eq(deliveryNotes.status, 'open')
    ))
  
  // Set checkout timestamp
  await db.update(reservations)
    .set({ checkedOutAt: new Date() })
    .where(eq(reservations.id, reservationId))
  
  revalidatePath('/')
}

export async function getArchivedReservations(page: number = 1, limit: number = 20) {
  const offset = (page - 1) * limit
  
  // Get archived reservations (with checkedOutAt)
  const archived = await db.select().from(reservations)
    .where(isNotNull(reservations.checkedOutAt))
    .orderBy(desc(reservations.checkedOutAt))
    .limit(limit)
    .offset(offset)
  
  // Get total count for pagination
  const countResult = await db.select().from(reservations)
    .where(isNotNull(reservations.checkedOutAt))
  const total = countResult.length
  
  // Fetch related data for these reservations
  const reservationIds = archived.map(r => r.id)
  
  const archivedOrders = reservationIds.length > 0 
    ? await db.select().from(orderItems).where(
        or(...reservationIds.map(id => eq(orderItems.reservationId, id)))
      )
    : []
  
  const archivedDeliveryNotes = reservationIds.length > 0
    ? await db.select().from(deliveryNotes).where(
        or(...reservationIds.map(id => eq(deliveryNotes.reservationId, id)))
      )
    : []
  
  const archivedPayments = reservationIds.length > 0
    ? await db.select().from(payments).where(
        or(...reservationIds.map(id => eq(payments.reservationId, id)))
      )
    : []
  
  const rate = await getExchangeRate()
  
  return {
    reservations: archived.map(res => {
      const resOrders = archivedOrders.filter(o => o.reservationId === res.id)
      const resDeliveryNotes = archivedDeliveryNotes.filter(dn => dn.reservationId === res.id)
      const resPayments = archivedPayments.filter(p => p.reservationId === res.id)
      
      const servicesTotal = resOrders.reduce((sum, o) => sum + (o.priceAr || 0), 0)
      const barTotal = resDeliveryNotes.reduce((sum, dn) => sum + (dn.totalAr || 0), 0)
      
      return {
        ...res,
        arrival: res.arrival ? (typeof res.arrival === 'string' ? res.arrival : res.arrival.toISOString().split('T')[0]) : '',
        departure: res.departure ? (typeof res.departure === 'string' ? res.departure : res.departure.toISOString().split('T')[0]) : '',
        checkedInAt: res.checkedInAt ? (typeof res.checkedInAt === 'string' ? res.checkedInAt : res.checkedInAt.toISOString()) : null,
        checkedOutAt: res.checkedOutAt ? (typeof res.checkedOutAt === 'string' ? res.checkedOutAt : res.checkedOutAt.toISOString()) : null,
        totalAmount: Number(res.totalAmount) || 0,
        amountPaid: Number(res.amountPaid) || 0,
        servicesTotal,
        barTotal,
        grandTotal: servicesTotal + barTotal,
        payments: resPayments.map(p => ({
          amount: Number(p.amount),
          method: p.method,
          paidAt: p.paidAt ? (typeof p.paidAt === 'string' ? p.paidAt : p.paidAt.toISOString()) : ''
        }))
      }
    }),
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit)
    },
    exchangeRate: rate
  }
}

// ============ VOUCHER DATA ============

export async function getExcursionVoucherData(bookingId: string) {
  // Get the excursion booking
  const [booking] = await db.select().from(excursionBookings).where(eq(excursionBookings.id, bookingId)).limit(1)
  if (!booking) return null

  // Get the excursion details
  const [excursion] = await db.select().from(excursions).where(eq(excursions.id, booking.excursionId)).limit(1)
  if (!excursion) return null

  // Get the reservation details
  const [reservation] = await db.select().from(reservations).where(eq(reservations.id, booking.reservationId)).limit(1)
  if (!reservation) return null

  return {
    booking: {
      id: booking.id,
      date: booking.date ? (typeof booking.date === 'string' ? booking.date : booking.date.toISOString().split('T')[0]) : null,
      pax: booking.pax,
      notes: booking.notes,
    },
    excursion: {
      name: excursion.name,
      description: excursion.description,
      imageUrl: excursion.imageUrl,
    },
    reservation: {
      guestName: reservation.guestName,
      secondGuestName: reservation.secondGuestName,
      honeymoon: reservation.honeymoon,
      pax: reservation.pax,
    }
  }
}

// ============ TRANSFER VOUCHER DATA ============

export async function getTransferVoucherData(reservationId: string, type: 'arrival' | 'departure') {
  // Get the reservation
  const [reservation] = await db.select().from(reservations).where(eq(reservations.id, reservationId)).limit(1)
  if (!reservation) return null

  // Get the transfer
  const [transfer] = await db.select().from(transfers).where(
    and(
      eq(transfers.reservationId, reservationId),
      eq(transfers.type, type)
    )
  ).limit(1)
  if (!transfer) return null

  // Get the route name
  const [route] = await db.select().from(transferRoutes).where(eq(transferRoutes.id, transfer.route || '')).limit(1)
  
  // Get the bungalow name
  const allBungalows = await db.select().from(bungalows)
  const bungalow = allBungalows.find(b => b.id === reservation.bungalow)

  return {
    guestName: reservation.guestName,
    secondGuestName: reservation.secondGuestName,
    bungalowName: bungalow?.name || '',
    routeName: route?.name || '',
    date: type === 'arrival' 
      ? (transfer.pickupDate || reservation.arrival)
      : (transfer.pickupDate || reservation.departure),
    time: type === 'arrival' ? transfer.flightTime : transfer.pickupTime,
    pax: reservation.pax || 1,
    flightNumber: transfer.flightNumber,
    paymentStatus: transfer.paymentStatus,
  }
}

// ============ SCHEDULED EXCURSIONS (Fanja's planned trips) ============

export async function getScheduledExcursions() {
  return await db.select().from(scheduledExcursions).orderBy(scheduledExcursions.date)
}

export async function addScheduledExcursion(data: { 
  date: string; 
  excursionType: string; 
  isOption?: boolean; 
  notes?: string 
}) {
  const id = uid('sched')
  await db.insert(scheduledExcursions).values({
    id,
    date: data.date,
    excursionType: data.excursionType,
    isOption: data.isOption || false,
    notes: data.notes || null,
  })
  revalidatePath('/')
  return id
}

export async function updateScheduledExcursion(id: string, data: Partial<{
  date: string;
  excursionType: string;
  isOption: boolean;
  notes: string;
}>) {
  await db.update(scheduledExcursions).set(data).where(eq(scheduledExcursions.id, id))
  revalidatePath('/')
}

export async function deleteScheduledExcursion(id: string) {
  await db.delete(scheduledExcursions).where(eq(scheduledExcursions.id, id))
  revalidatePath('/')
}

// Get scheduled excursions with guest bookings for each date
export async function getScheduledExcursionsWithGuests() {
  const scheduled = await db.select().from(scheduledExcursions).orderBy(scheduledExcursions.date)
  const bookings = await db.select().from(excursionBookings)
  const allReservations = await db.select().from(reservations).where(isNull(reservations.checkedOutAt))
  
  return scheduled.map(s => {
    // Find all bookings on this date
    const guestsOnDate = bookings
      .filter(b => b.date === s.date)
      .map(b => {
        const res = allReservations.find(r => r.id === b.reservationId)
        return res ? { 
          reservationId: res.id, 
          guestName: res.guestName, 
          bungalow: res.bungalow,
          pax: b.pax 
        } : null
      })
      .filter(Boolean)
    
    return {
      ...s,
      guests: guestsOnDate,
    }
  })
}

// ============ TAKSE (TAXES) ============

const COMMUNAL_TAX_PER_PERSON_NIGHT = 2000 // Ar - občinska taksa na osebo na noč
const TOURIST_TAX_PER_ROOM_NIGHT = 1000 // Ar - turistična taksa na sobo (bungalov) na noč

// Helper: parse a YYYY-MM-DD date string into a UTC date (midnight)
function parseDateOnly(value: string | Date | null | undefined): Date | null {
  if (!value) return null
  const s = typeof value === 'string' ? value : value.toISOString().slice(0, 10)
  const m = s.slice(0, 10).match(/^(\d{4})-(\d{2})-(\d{2})$/)
  if (!m) return null
  return new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])))
}

// Count how many nights of a stay [start, end) fall within [monthStart, monthEnd)
function nightsInMonth(start: Date, end: Date, monthStart: Date, monthEnd: Date): number {
  const from = start > monthStart ? start : monthStart
  const to = end < monthEnd ? end : monthEnd
  const ms = to.getTime() - from.getTime()
  if (ms <= 0) return 0
  return Math.round(ms / (1000 * 60 * 60 * 24))
}

export type TaxLineItem = {
  reservationId: string
  guestName: string
  bungalow: string
  pax: number
  nights: number
  arrival: string
  departure: string
  communalTax: number
  touristTax: number
  total: number
}

export type MonthlyTaxes = {
  year: number
  month: number // 1-12
  lineItems: TaxLineItem[]
  totalPax: number
  totalNights: number
  totalRoomNights: number
  communalTotal: number
  touristTotal: number
  grandTotal: number
}

export async function getTaxesForMonth(year: number, month: number): Promise<MonthlyTaxes> {
  // month is 1-12
  const monthStart = new Date(Date.UTC(year, month - 1, 1))
  const monthEnd = new Date(Date.UTC(year, month, 1)) // first day of next month

  // Fetch ALL reservations (active + archived) - taxes apply regardless of checkout state
  const allReservations = await db.select().from(reservations)

  const lineItems: TaxLineItem[] = []

  for (const r of allReservations) {
    // Prefer actual check-in/check-out dates, fall back to arrival/departure
    const startStr = r.checkIn || r.arrival
    const endStr = r.checkOut || r.departure
    const start = parseDateOnly(startStr)
    const end = parseDateOnly(endStr)
    if (!start || !end) continue

    const nights = nightsInMonth(start, end, monthStart, monthEnd)
    if (nights <= 0) continue

    const pax = r.pax || 0
    const communalTax = COMMUNAL_TAX_PER_PERSON_NIGHT * pax * nights
    const touristTax = TOURIST_TAX_PER_ROOM_NIGHT * nights // 1 bungalow = 1 room

    lineItems.push({
      reservationId: r.id,
      guestName: r.guestName,
      bungalow: r.bungalow,
      pax,
      nights,
      arrival: (startStr || '').slice(0, 10),
      departure: (endStr || '').slice(0, 10),
      communalTax,
      touristTax,
      total: communalTax + touristTax,
    })
  }

  // Sort by bungalow then arrival
  lineItems.sort((a, b) => a.bungalow.localeCompare(b.bungalow) || a.arrival.localeCompare(b.arrival))

  const communalTotal = lineItems.reduce((s, i) => s + i.communalTax, 0)
  const touristTotal = lineItems.reduce((s, i) => s + i.touristTax, 0)
  const totalNights = lineItems.reduce((s, i) => s + i.nights, 0)
  const totalRoomNights = lineItems.reduce((s, i) => s + i.nights, 0)
  const totalPax = lineItems.reduce((s, i) => s + i.pax * i.nights, 0)

  return {
    year,
    month,
    lineItems,
    totalPax,
    totalNights,
    totalRoomNights,
    communalTotal,
    touristTotal,
    grandTotal: communalTotal + touristTotal,
  }
}
