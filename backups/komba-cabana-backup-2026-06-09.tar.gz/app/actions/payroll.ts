'use server'

import { db } from '@/lib/db'
import { sql } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'
import {
  calcQuarterlyContributions,
  getQuarterMonths,
  getQuarterDeadline,
  getQuarter,
  DEFAULT_NET_SALARY,
} from '@/lib/payroll'

// --- Mesecni obracun (payroll_entries) ---

export async function getPayrollEntries(year: number, month: number) {
  const result = await db.execute(
    sql`SELECT * FROM payroll_entries WHERE year = ${year} AND month = ${month}`
  )
  return result.rows.map((r) => ({
    id: r.id as string,
    staffId: r.staffId as string,
    staffName: r.staffName as string,
    year: r.year as number,
    month: r.month as number,
    baseSalary: Number(r.baseSalary),
  }))
}

export async function upsertPayrollEntry(data: {
  staffId: string
  staffName: string
  year: number
  month: number
  baseSalary: number
}) {
  // poisci obstojeci vnos za tega delavca v tem obdobju
  const existing = await db.execute(
    sql`SELECT id FROM payroll_entries WHERE "staffId" = ${data.staffId} AND year = ${data.year} AND month = ${data.month} LIMIT 1`
  )

  if (existing.rows.length > 0) {
    const id = existing.rows[0].id as string
    await db.execute(
      sql`UPDATE payroll_entries SET "baseSalary" = ${data.baseSalary}, "staffName" = ${data.staffName} WHERE id = ${id}`
    )
    revalidatePath('/statistika')
    return id
  }

  const id = `pay-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
  await db.execute(
    sql`INSERT INTO payroll_entries (id, "staffId", "staffName", year, month, "baseSalary")
        VALUES (${id}, ${data.staffId}, ${data.staffName}, ${data.year}, ${data.month}, ${data.baseSalary})`
  )
  revalidatePath('/statistika')
  return id
}

export async function deletePayrollEntry(id: string) {
  await db.execute(sql`DELETE FROM payroll_entries WHERE id = ${id}`)
  revalidatePath('/statistika')
}

// --- Cetrtletni prispevki ---

// Sesteje bazne place rednih zaposlenih v izbranem cetrtletju.
// Za vsak mesec v cetrtletju: ce ima delavec shranjen vnos -> uporabi ga,
// sicer privzeta neto placa. Tako se prispevki racunajo avtomaticno za vse redne zaposlene.
export async function getQuarterlyContributions(year: number, quarter: number) {
  const months = getQuarterMonths(quarter)

  // vsi trenutno redno zaposleni
  const staffResult = await db.execute(
    sql`SELECT id FROM staff_members WHERE "isRegularEmployee" = true`
  )
  const regularIds = staffResult.rows.map((r) => r.id as string)

  // shranjeni vnosi za cetrtletje
  const entriesResult = await db.execute(
    sql`SELECT "staffId", month, "baseSalary" FROM payroll_entries
        WHERE year = ${year} AND month = ANY(${sql.raw(`'{${months.join(',')}}'::integer[]`)})`
  )
  const savedByKey: Record<string, number> = {}
  for (const r of entriesResult.rows) {
    savedByKey[`${r.staffId as string}-${r.month as number}`] = Number(r.baseSalary)
  }

  // sestej: za vsakega rednega zaposlenega x vsak mesec v cetrtletju
  let sumOfBaseSalaries = 0
  for (const staffId of regularIds) {
    for (const m of months) {
      sumOfBaseSalaries += savedByKey[`${staffId}-${m}`] ?? DEFAULT_NET_SALARY
    }
  }

  const contributions = calcQuarterlyContributions(sumOfBaseSalaries)
  const deadline = getQuarterDeadline(year, quarter)

  // status placila
  const statusResult = await db.execute(
    sql`SELECT paid, "paidAt" FROM contribution_payments WHERE year = ${year} AND quarter = ${quarter} LIMIT 1`
  )
  const paid = statusResult.rows[0]?.paid === true
  const paidAt = (statusResult.rows[0]?.paidAt as string) ?? null

  return {
    year,
    quarter,
    months,
    sumOfBaseSalaries,
    cnaps: contributions.cnaps,
    omino: contributions.omino,
    fmfp: contributions.fmfp,
    total: contributions.total,
    deadline: deadline.toISOString(),
    paid,
    paidAt,
  }
}

export async function setContributionPaid(
  year: number,
  quarter: number,
  paid: boolean
) {
  // izracunaj trenutne zneske, da jih shranimo ob oznaki placila
  const data = await getQuarterlyContributions(year, quarter)

  const existing = await db.execute(
    sql`SELECT id FROM contribution_payments WHERE year = ${year} AND quarter = ${quarter} LIMIT 1`
  )

  if (existing.rows.length > 0) {
    const id = existing.rows[0].id as string
    await db.execute(
      sql`UPDATE contribution_payments
          SET paid = ${paid},
              "paidAt" = ${paid ? new Date().toISOString() : null},
              "cnapsAmount" = ${data.cnaps},
              "ominoAmount" = ${data.omino},
              "fmfpAmount" = ${data.fmfp},
              "totalAmount" = ${data.total}
          WHERE id = ${id}`
    )
  } else {
    const id = `contrib-${year}-${quarter}`
    await db.execute(
      sql`INSERT INTO contribution_payments (id, year, quarter, "cnapsAmount", "ominoAmount", "fmfpAmount", "totalAmount", paid, "paidAt")
          VALUES (${id}, ${year}, ${quarter}, ${data.cnaps}, ${data.omino}, ${data.fmfp}, ${data.total}, ${paid}, ${paid ? new Date().toISOString() : null})`
    )
  }

  revalidatePath('/statistika')
}

// Opozorila za dashboard: prispevki z rokom <= 30 dni in se neplacani
export async function getUpcomingContributionAlerts() {
  const now = new Date()
  const alerts: {
    year: number
    quarter: number
    cnaps: number
    omino: number
    fmfp: number
    total: number
    deadline: string
    daysLeft: number
    paid: boolean
  }[] = []

  // preveri zadnja 4 cetrtletja (trenutno + prejsnja)
  const currentYear = now.getFullYear()
  const currentMonth = now.getMonth() + 1
  const currentQuarter = getQuarter(currentMonth)

  const periods: { year: number; quarter: number }[] = []
  for (let i = 0; i < 4; i++) {
    let q = currentQuarter - i
    let y = currentYear
    while (q < 1) {
      q += 4
      y -= 1
    }
    periods.push({ year: y, quarter: q })
  }

  for (const p of periods) {
    // opozorilo prikazi samo ce je bil za to cetrtletje dejansko narejen obracun
    // (obstaja vsaj en shranjen payroll_entry) -> prepreci lazna opozorila za nazaj
    const months = getQuarterMonths(p.quarter)
    const hasEntries = await db.execute(
      sql`SELECT 1 FROM payroll_entries
          WHERE year = ${p.year} AND month = ANY(${sql.raw(`'{${months.join(',')}}'::integer[]`)})
          LIMIT 1`
    )
    if (hasEntries.rows.length === 0) continue

    const data = await getQuarterlyContributions(p.year, p.quarter)
    if (data.total <= 0) continue
    if (data.paid) continue

    const deadline = new Date(data.deadline)
    const daysLeft = Math.ceil(
      (deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
    )

    // prikazi ce je rok v 30 dneh ali ze pretekel (in neplacano)
    if (daysLeft <= 30) {
      alerts.push({
        year: p.year,
        quarter: p.quarter,
        cnaps: data.cnaps,
        omino: data.omino,
        fmfp: data.fmfp,
        total: data.total,
        deadline: data.deadline,
        daysLeft,
        paid: data.paid,
      })
    }
  }

  // sortiraj po roku (najbolj nujno prvo)
  alerts.sort((a, b) => a.daysLeft - b.daysLeft)
  return alerts
}
