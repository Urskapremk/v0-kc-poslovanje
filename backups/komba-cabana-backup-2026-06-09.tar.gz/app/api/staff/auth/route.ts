import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { staff } from '@/lib/db/schema'
import { eq, and } from 'drizzle-orm'

export async function POST(request: NextRequest) {
  const { pin } = await request.json()
  
  if (!pin || pin.length !== 4) {
    return NextResponse.json({ error: 'Invalid PIN' }, { status: 400 })
  }
  
  const staffMember = await db.query.staff.findFirst({
    where: and(eq(staff.pin, pin), eq(staff.active, true))
  })
  
  if (!staffMember) {
    return NextResponse.json({ error: 'Invalid PIN' }, { status: 401 })
  }
  
  // Return staff info (in production, you'd set a secure cookie/session)
  return NextResponse.json({
    id: staffMember.id,
    name: staffMember.name,
    role: staffMember.role,
  })
}
