'use client'

import React, { useState } from 'react'
import useSWR from 'swr'
import Link from 'next/link'
import { ArrowLeft, ChevronLeft, ChevronRight, Search, Calendar, Users, Home, FileText, Printer } from 'lucide-react'
import { getArchivedReservations } from '@/app/actions/komba'

const fetcher = async (page: number) => {
  return await getArchivedReservations(page, 20)
}

export default function ArhivPage() {
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  
  const { data, isLoading, error } = useSWR(['archived', page], () => fetcher(page), {
    revalidateOnFocus: false
  })
  
  const formatDate = (dateStr: string) => {
    if (!dateStr) return ''
    const d = new Date(dateStr)
    return d.toLocaleDateString('sl-SI', { day: 'numeric', month: 'short', year: 'numeric' })
  }
  
  const formatAr = (ar: number) => {
    return new Intl.NumberFormat('sl-SI').format(ar).replace(/,/g, '.') + ' Ar'
  }
  
  const formatEur = (ar: number, rate: number) => {
    const eur = ar / rate
    return eur.toFixed(2) + ' EUR'
  }
  
  // Filter reservations by search
  const filteredReservations = data?.reservations?.filter(res => {
    if (!search) return true
    const searchLower = search.toLowerCase()
    return (
      res.guestName?.toLowerCase().includes(searchLower) ||
      res.bungalow?.toLowerCase().includes(searchLower) ||
      res.email?.toLowerCase().includes(searchLower)
    )
  }) || []
  
  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-[#0a0f1a]/95 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/" className="p-2 rounded-lg bg-white/5 text-white/60 hover:bg-white/10 hover:text-white">
                <ArrowLeft className="h-5 w-5" />
              </Link>
              <div>
                <h1 className="text-xl font-bold text-[#f1d07a]">Arhiv</h1>
                <p className="text-white/40 text-sm">Pretekle rezervacije</p>
              </div>
            </div>
            {data?.pagination && (
              <p className="text-white/40 text-sm">
                {data.pagination.total} rezervacij
              </p>
            )}
          </div>
          
          {/* Search */}
          <div className="mt-4 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
            <input
              type="text"
              placeholder="Išči po imenu, bungalovu, emailu..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-[#78b7ff]/50"
            />
          </div>
        </div>
      </header>
      
      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 py-6">
        {isLoading ? (
          <div className="text-center py-12 text-white/40">Nalagam...</div>
        ) : error ? (
          <div className="text-center py-12 text-red-400">Napaka pri nalaganju</div>
        ) : filteredReservations.length === 0 ? (
          <div className="text-center py-12 text-white/40">
            {search ? 'Ni rezultatov za iskanje' : 'Ni arhiviranih rezervacij'}
          </div>
        ) : (
          <div className="space-y-3">
            {filteredReservations.map((res) => (
              <div
                key={res.id}
                className="p-4 rounded-2xl bg-white/[0.03] border border-white/10"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Home className="h-4 w-4 text-[#f1d07a]" />
                      <span className="text-[#f1d07a] font-medium">{res.bungalow}</span>
                    </div>
                    <h3 className="text-white text-lg font-medium mt-1">{res.guestName}</h3>
                    <div className="flex items-center gap-4 mt-2 text-white/50 text-sm">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5" />
                        {formatDate(res.arrival)} - {formatDate(res.departure)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-3.5 w-3.5" />
                        {res.pax} oseb
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[#78b7ff] font-bold">
                      {formatEur(res.grandTotal, data?.exchangeRate || 4800)}
                    </p>
                    <p className="text-white/40 text-xs mt-0.5">
                      {formatAr(res.grandTotal)}
                    </p>
                    <p className="text-white/30 text-xs mt-2">
                      Odjava: {formatDate(res.checkedOutAt || '')}
                    </p>
                  </div>
                </div>
                
                {/* Payment summary */}
                <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-sm">
                  <div className="text-white/50">
                    <span>Storitve: {formatEur(res.servicesTotal, data?.exchangeRate || 4800)}</span>
                    <span className="mx-2">•</span>
                    <span>Bar: {formatEur(res.barTotal, data?.exchangeRate || 4800)}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Link
                      href={`/racun/${res.id}?view=true`}
                      className="flex items-center gap-1.5 text-[#f1d07a] hover:underline"
                    >
                      <Printer className="h-3.5 w-3.5" />
                      Racun
                    </Link>
                    <Link
                      href={`/dobavnice/${res.id}`}
                      className="flex items-center gap-1.5 text-[#78b7ff] hover:underline"
                    >
                      <FileText className="h-3.5 w-3.5" />
                      Dobavnica
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        {/* Pagination */}
        {data?.pagination && data.pagination.totalPages > 1 && (
          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg bg-white/5 text-white/60 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <span className="text-white/60">
              {page} / {data.pagination.totalPages}
            </span>
            <button
              onClick={() => setPage(p => Math.min(data.pagination.totalPages, p + 1))}
              disabled={page === data.pagination.totalPages}
              className="p-2 rounded-lg bg-white/5 text-white/60 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        )}
      </main>
    </div>
  )
}
