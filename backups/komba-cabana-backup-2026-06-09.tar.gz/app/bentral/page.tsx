"use client";

import React from "react";
import Link from "next/link";
import { RefreshCw, ArrowLeft, Database } from "lucide-react";
import { LuxuryButton, LuxuryBadge, LuxurySelect, GlassCard, SectionHeader } from "@/components/komba/ui/luxury-components";
import { getBentralReservations, importBentralCSV, transferBentralReservation } from "@/app/actions/komba";

export default function BentralPage() {
  const [bentralData, setBentralData] = React.useState<{
    id: string; externalId: string; status: string; source: string | null; guestName: string;
    country: string | null; checkIn: string; checkOut: string; nights: number; adults: number;
    children: number; childrenAges: string | null; units: string | null; currency: string | null;
    amount: string; guestNotes: string | null; ownNotes: string | null;
    transferred: boolean | null; reservationId: string | null;
  }[] | null>(null);
  const [importing, setImporting] = React.useState(false);
  const [transferring, setTransferring] = React.useState<string | null>(null);
  const [importResult, setImportResult] = React.useState<{ imported: number; updated: number; skipped: number } | null>(null);
  const [statusFilter, setStatusFilter] = React.useState("all");
  const [showTransferred, setShowTransferred] = React.useState(false);
  const [message, setMessage] = React.useState<string | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  function showMsg(msg: string) {
    setMessage(msg);
    setTimeout(() => setMessage(null), 3000);
  }

  async function loadBentralData() {
    const data = await getBentralReservations({ status: statusFilter });
    setBentralData(data as typeof bentralData);
  }

  React.useEffect(() => { loadBentralData(); }, [statusFilter]);

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setImporting(true);
    setImportResult(null);
    
    try {
      const text = await file.text();
      const result = await importBentralCSV(text);
      setImportResult(result);
      loadBentralData();
      showMsg(`Import uspesen: ${result.imported} novih, ${result.updated} posodobljenih`);
    } catch {
      showMsg("Napaka pri importu!");
    }
    
    setImporting(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  async function handleTransfer(id: string) {
    setTransferring(id);
    try {
      await transferBentralReservation(id);
      showMsg("Rezervacija prenesena v sistem!");
      loadBentralData();
    } catch {
      showMsg("Napaka pri prenosu!");
    }
    setTransferring(null);
  }

  const statusOptions = [
    { value: "all", label: "Vsi statusi" },
    { value: "Potrjeno", label: "Potrjeno" },
    { value: "Plačano (1. del)", label: "Placano (1. del)" },
    { value: "Ponudba", label: "Ponudba" },
    { value: "Preklicano", label: "Preklicano" },
    { value: "Ni odziva", label: "Ni odziva" },
  ];

  const getStatusVariant = (status: string): "petrol" | "gold" | "ocean" | "danger" | "default" => {
    if (status === "Potrjeno") return "petrol";
    if (status === "Plačano (1. del)") return "ocean";
    if (status === "Ponudba") return "gold";
    if (status === "Preklicano") return "danger";
    return "default";
  };

  const getSourceBadge = (source: string | null) => {
    if (!source) return <LuxuryBadge variant="gold">Direct</LuxuryBadge>;
    if (source === "Booking.com") return <LuxuryBadge variant="ocean">Booking</LuxuryBadge>;
    if (source === "Airbnb") return <LuxuryBadge variant="danger">Airbnb</LuxuryBadge>;
    return <LuxuryBadge>{source}</LuxuryBadge>;
  };

  return (
    <main className="min-h-screen bg-[#0d1420] px-4 py-8">
      {/* Toast */}
      {message && (
        <div className="fixed top-4 right-4 z-50 rounded-xl bg-[#6fc8a3] px-4 py-2 text-sm font-medium text-[#0d1420] shadow-lg">
          {message}
        </div>
      )}

      <div className="mx-auto max-w-6xl space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white/70 transition-all hover:bg-white/10 hover:text-white">
              <ArrowLeft className="h-4 w-4" />
              Nazaj
            </Link>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#78b7ff]/20">
                <Database className="h-5 w-5 text-[#78b7ff]" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Bentral</h1>
                <p className="text-xs text-white/50">Channel Manager</p>
              </div>
            </div>
          </div>
        </div>

        {/* Import Section */}
        <GlassCard>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <SectionHeader eyebrow="Channel Manager" title="Bentral Rezervacije" subtitle="Uvozi rezervacije iz Bentral sistema" />
            <div className="flex gap-3">
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
              />
              <LuxuryButton variant="petrol" onClick={() => fileInputRef.current?.click()} disabled={importing}>
                {importing ? "Uvazam..." : "Uvozi CSV"}
              </LuxuryButton>
            </div>
          </div>

          {importResult && (
            <div className="mt-4 rounded-2xl border border-[#6fc8a3]/30 bg-[#6fc8a3]/10 p-4">
              <p className="text-sm text-[#6fc8a3]">
                Import zakljucen: <strong>{importResult.imported}</strong> novih rezervacij, <strong>{importResult.updated}</strong> posodobljenih, <strong>{importResult.skipped}</strong> preskocenih
              </p>
            </div>
          )}

          <div className="mt-6 flex gap-4">
            <div className="w-48">
              <LuxurySelect label="Filter po statusu" value={statusFilter} onChange={setStatusFilter} options={statusOptions} />
            </div>
          </div>
        </GlassCard>

        {/* Reservations List */}
        <GlassCard>
          <div className="flex items-center justify-between">
            <SectionHeader eyebrow="Reservations" title="Seznam rezervacij" subtitle={bentralData ? `${bentralData.filter(r => showTransferred || !r.transferred).length} rezervacij` : "Nalagam..."} />
            <label className="flex items-center gap-2 text-sm text-white/50">
              <input type="checkbox" checked={showTransferred} onChange={e => setShowTransferred(e.target.checked)} className="rounded" />
              Prikazi prenesene
            </label>
          </div>
          
          {!bentralData ? (
            <div className="mt-8 flex justify-center">
              <RefreshCw className="h-6 w-6 animate-spin text-[#f1d07a]" />
            </div>
          ) : bentralData.filter(r => showTransferred || !r.transferred).length === 0 ? (
            <p className="mt-8 text-center text-white/50">Ni rezervacij. Uvozi CSV iz Bentral.</p>
          ) : (
            <div className="mt-6 space-y-4">
              {bentralData.filter(r => showTransferred || !r.transferred).map(res => (
                <div key={res.id} className={`rounded-2xl border p-5 ${res.transferred ? 'border-[#6fc8a3]/30 bg-[#6fc8a3]/5' : 'border-white/[0.08] bg-white/[0.02]'}`}>
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="font-medium text-white">{res.guestName}</h4>
                        <LuxuryBadge variant={getStatusVariant(res.status)}>{res.status}</LuxuryBadge>
                        {getSourceBadge(res.source)}
                        {res.transferred && <LuxuryBadge variant="petrol">Preneseno</LuxuryBadge>}
                      </div>
                      <p className="mt-2 text-sm text-white/60">
                        <span className="text-[#78b7ff]">{res.checkIn}</span> → <span className="text-[#78b7ff]">{res.checkOut}</span>
                        <span className="ml-2 text-white/40">({res.nights} noci)</span>
                      </p>
                      <p className="mt-1 text-sm text-white/50">
                        {res.adults} odrasli{res.children > 0 && `, ${res.children} otroci`}
                        {res.country && <span className="ml-2">• {res.country}</span>}
                      </p>
                      {res.units && <p className="mt-1 text-xs text-white/40 line-clamp-1">{res.units}</p>}
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <p className="text-lg font-light text-[#f1d07a]">{res.amount} {res.currency}</p>
                      <p className="text-xs text-white/40">#{res.externalId}</p>
                      {!res.transferred && res.status !== "Preklicano" ? (
                        <LuxuryButton 
                          variant="ocean" 
                          onClick={() => handleTransfer(res.id)}
                          disabled={transferring === res.id}
                        >
                          {transferring === res.id ? "Prenasam..." : "Prenesi v sistem"}
                        </LuxuryButton>
                      ) : res.transferred ? (
                        <Link href="/">
                          <LuxuryButton variant="ghost">
                            Odpri rezervacijo
                          </LuxuryButton>
                        </Link>
                      ) : (
                        <span className="text-xs text-white/30">Preklicano</span>
                      )}
                    </div>
                  </div>
                  {(res.guestNotes || res.ownNotes) && (
                    <div className="mt-4 border-t border-white/5 pt-4">
                      {res.guestNotes && <p className="text-xs text-white/50"><span className="text-white/30">Gost:</span> {res.guestNotes.slice(0, 200)}{res.guestNotes.length > 200 && "..."}</p>}
                      {res.ownNotes && <p className="mt-1 text-xs text-[#6fc8a3]/70"><span className="text-[#6fc8a3]/50">Opombe:</span> {res.ownNotes}</p>}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </GlassCard>
      </div>
    </main>
  );
}
