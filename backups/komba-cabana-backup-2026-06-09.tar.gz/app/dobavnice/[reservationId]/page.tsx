'use client'

import React, { useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import useSWR from 'swr'
import Link from 'next/link'
import { ArrowLeft, Plus, ReceiptText, FileText, Utensils, Ship, Compass, Trash2, Home, ChevronDown, Users } from 'lucide-react'
import { getDeliveryNotesForReservation, getOrCreateDeliveryNote, closeDeliveryNote } from '@/app/actions/delivery'
import { getDashboardData, getOrderItems, deleteOrderItem } from '@/app/actions/komba'

const fetcher = async (reservationId: string) => {
  const [notes, dashboard, orderItems] = await Promise.all([
    getDeliveryNotesForReservation(reservationId),
    getDashboardData(),
    getOrderItems(reservationId)
  ])
  const reservation = dashboard.reservations.find(r => r.id === reservationId)
  
  // Check if this reservation is part of a group with sharedInvoice enabled
  // We need to check the MAIN reservation's sharedInvoice setting
  let allNotes = notes
  let allOrderItems = orderItems
  let groupReservations: typeof dashboard.reservations = []
  let isSharedInvoice = false
  
  if (reservation?.groupId) {
    // Find the main reservation in the group to check sharedInvoice
    const mainReservation = dashboard.reservations.find(r => r.groupId === reservation.groupId && r.isMainReservation)
    isSharedInvoice = mainReservation?.sharedInvoice || reservation?.sharedInvoice || false
    
    if (isSharedInvoice) {
      // Get all OTHER reservations in the group
      groupReservations = dashboard.reservations.filter(r => r.groupId === reservation.groupId && r.id !== reservationId)
      
      // Fetch delivery notes and order items for all group members
      const groupData = await Promise.all(
        groupReservations.map(async r => {
          const [gNotes, gOrderItems] = await Promise.all([
            getDeliveryNotesForReservation(r.id),
            getOrderItems(r.id)
          ])
          return { reservationId: r.id, bungalow: r.bungalow, notes: gNotes, orderItems: gOrderItems }
        })
      )
      
      // Combine all notes and order items, marking which bungalow they're from
      for (const gd of groupData) {
        const shortBungalow = gd.bungalow?.split(';')[0]?.split('/')[0]?.trim() || gd.bungalow
        allNotes = [...allNotes, ...gd.notes.map(n => ({ ...n, fromBungalow: shortBungalow }))]
        allOrderItems = [...allOrderItems, ...gd.orderItems.map(i => ({ ...i, fromBungalow: shortBungalow }))]
      }
    }
  }
  
  return { 
    notes: allNotes, 
    reservation, 
    orderItems: allOrderItems, 
    exchangeRate: dashboard.exchangeRate || 4800,
    groupReservations,
    isSharedInvoice
  }
}

export default function DobavnicePage() {
  const params = useParams()
  const router = useRouter()
  const [expandedNotes, setExpandedNotes] = useState<Record<string, boolean>>({})
  const reservationId = params.reservationId as string
  
const { data, error, isLoading, mutate } = useSWR(
  reservationId ? `dobavnice-${reservationId}` : null,
  () => fetcher(reservationId),
  { revalidateOnFocus: true, revalidateOnMount: true, dedupingInterval: 0 }
  )
  
  const [creating, setCreating] = React.useState(false)
  
  async function handleCreateNew() {
    if (!data?.reservation) return
    setCreating(true)
    try {
      await getOrCreateDeliveryNote(
        reservationId,
        data.reservation.bungalow,
        data.reservation.guestName
      )
      mutate()
    } catch (err) {
      console.error('Error creating delivery note:', err)
    }
    setCreating(false)
  }

  async function handleDeleteOrderItem(id: string) {
    if (confirm('Res zelis odstraniti ta artikel?')) {
      await deleteOrderItem(id)
      mutate()
    }
  }
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0a0f1a] flex items-center justify-center">
        <div className="text-white/50">Nalagam...</div>
      </div>
    )
  }
  
  if (error || !data) {
    return (
      <div className="min-h-screen bg-[#0a0f1a] flex items-center justify-center">
        <div className="text-red-400">Napaka pri nalaganju</div>
      </div>
    )
  }
  
  const { notes, reservation, orderItems, exchangeRate, groupReservations, isSharedInvoice } = data
  
  // Get short bungalow name for current reservation
  const shortBungalow = reservation?.bungalow?.split(';')[0]?.split('/')[0]?.trim() || reservation?.bungalow
  
  // Group order items by category
  const accommodationItems = orderItems.filter(i => i.category === 'Bivanje')
  const mealItems = orderItems.filter(i => i.category === 'Prehrana')
  const transferItems = orderItems.filter(i => i.category === 'Transfer')
  const excursionItems = orderItems.filter(i => i.category === 'Izlet')
  const otherItems = orderItems.filter(i => !['Bivanje', 'Prehrana', 'Transfer', 'Izlet'].includes(i.category || ''))
  
  // Calculate totals
  const orderItemsTotal = orderItems.reduce((sum, i) => sum + Number(i.priceAr || 0), 0)
  const deliveryNotesTotal = notes.reduce((sum, n) => sum + (n.totalAr || 0), 0)
  const grandTotalAr = orderItemsTotal + deliveryNotesTotal
  const grandTotalEur = grandTotalAr / exchangeRate
  
  const formatAr = (ar: number) => ar.toLocaleString('sl-SI')
  const formatEur = (eur: number) => eur.toFixed(2)
  const arToEur = (ar: number) => ar / exchangeRate
  
  return (
    <div className="min-h-screen bg-[#0a0f1a]">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-[#0a0f1a]/95 backdrop-blur-lg border-b border-white/10 px-4 py-4">
        <div className="max-w-2xl mx-auto flex items-center gap-4">
          <Link
            href="/"
            className="p-2 rounded-xl bg-white/5 text-white/70 hover:bg-white/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold text-white">{reservation?.guestName || 'Gost'}</h1>
              {isSharedInvoice && (
                <span className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-purple-500/20 border border-purple-500/30 text-purple-300 text-[10px]">
                  <Users className="h-3 w-3" />
                  Skupna
                </span>
              )}
            </div>
            <p className="text-sm text-white/50">
              {shortBungalow}
              {isSharedInvoice && groupReservations.length > 0 && (
                <span className="text-purple-300/70">
                  {' + '}{groupReservations.map(r => r.bungalow?.split(';')[0]?.split('/')[0]?.trim()).join(', ')}
                </span>
              )}
            </p>
          </div>
          <Link href={`/staff?bungalow=${encodeURIComponent(reservation?.bungalow || '')}`}>
            <button className="p-2 rounded-xl bg-[#6fc8a3]/20 text-[#6fc8a3] hover:bg-[#6fc8a3]/30">
              <Plus className="h-5 w-5" />
            </button>
          </Link>
        </div>
      </div>
      
      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Summary Card - EUR as main, Ar below */}
        <div className="rounded-2xl border border-[#f1d07a]/20 bg-[#f1d07a]/5 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-white/40 uppercase tracking-wider">Skupaj za placilo</p>
              <p className="text-2xl font-bold text-[#f1d07a] mt-1">
                {formatEur(arToEur(grandTotalAr))} EUR
              </p>
              <p className="text-sm text-white/50">{formatAr(grandTotalAr)} Ar</p>
            </div>
            <div className="text-right text-xs text-white/40">
              <p>Storitve: {formatEur(arToEur(orderItemsTotal))} EUR</p>
              <p>Bar: {formatEur(arToEur(deliveryNotesTotal))} EUR</p>
            </div>
          </div>
        </div>

        {/* BAR SECTION - Today's items from delivery notes */}
        {(() => {
          const allBarItems = notes.flatMap(note => 
            (note.items || []).map(item => ({
              ...item,
              noteDate: note.date,
              noteStatus: note.status
            }))
          )
          if (allBarItems.length === 0) return null
          return (
            <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
              <div className="px-4 py-3 border-b border-white/10 flex items-center gap-2 bg-[#6fc8a3]/5">
                <FileText className="h-4 w-4 text-[#6fc8a3]" />
                <span className="text-sm font-medium text-[#6fc8a3]">Bar (danes)</span>
                <span className="text-xs text-white/40 ml-auto">{allBarItems.length} postavk</span>
              </div>
              <div className="divide-y divide-white/5">
                {allBarItems.map((item: any) => (
                  <div key={item.id} className="px-4 py-3 flex items-center justify-between">
                    <div className="flex-1">
                      <p className="text-sm text-white">{item.quantity}x {item.productName}</p>
                      <p className="text-[10px] text-white/40 mt-0.5">
                        {new Date(item.noteDate).toLocaleDateString('sl-SI', { day: 'numeric', month: 'short' })}
                        {item.noteStatus === 'open' && <span className="ml-2 text-[#6fc8a3]">Odprta</span>}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-white">{formatEur(arToEur(item.priceAr * item.quantity))} EUR</p>
                      <p className="text-xs text-white/40">{formatAr(item.priceAr * item.quantity)} Ar</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        })()}

        {/* Close Day Button - if there's any open delivery note */}
        {(() => {
          const openNote = notes.find(n => n.status === 'open');
          if (!openNote) return null;
          const noteDate = new Date(openNote.date);
          return (
            <button
              onClick={async () => {
                await closeDeliveryNote(openNote.id);
                mutate();
              }}
              className="w-full rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-sm font-medium text-white/70 hover:bg-white/10 transition-colors flex items-center justify-center gap-2"
            >
              <FileText className="h-4 w-4" />
              Zaključi dan ({noteDate.toLocaleDateString('sl-SI', { day: 'numeric', month: 'short' })})
            </button>
          );
        })()}

        {/* ACCOMMODATION SECTION */}
        {accommodationItems.length > 0 && (
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
            <div className="px-4 py-3 border-b border-white/10 flex items-center gap-2 bg-[#f1d07a]/5">
              <Home className="h-4 w-4 text-[#f1d07a]" />
              <span className="text-sm font-medium text-[#f1d07a]">Bivanje</span>
            </div>
            <div className="divide-y divide-white/5">
              {accommodationItems.map(item => (
                <div key={item.id} className="px-4 py-3 flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-white">{item.name}</p>
                      {isSharedInvoice && (item as any).fromBungalow && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300">{(item as any).fromBungalow}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] text-white/40">
                        {(item.eventDate || item.createdAt) ? new Date(item.eventDate || item.createdAt).toLocaleDateString('sl-SI', { day: 'numeric', month: 'short', year: 'numeric' }) : ''}
                      </span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${item.paymentStatus === 'PAID' ? 'bg-[#6fc8a3]/20 text-[#6fc8a3]' : 'bg-red-500/20 text-red-400'}`}>
                        {item.paymentStatus === 'PAID' ? 'PLACANO' : 'ZA PLACILO'}
                      </span>
                    </div>
                  </div>
                  <div className="text-right flex items-center gap-3">
                    <div>
                      <p className="text-sm font-medium text-white">{formatEur(arToEur(Number(item.priceAr)))} EUR</p>
                      <p className="text-xs text-white/40">{formatAr(Number(item.priceAr))} Ar</p>
                    </div>
                    <button onClick={() => handleDeleteOrderItem(item.id)} className="p-1.5 rounded-lg hover:bg-red-500/20 text-white/30 hover:text-red-400">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MEAL PLAN SECTION */}
        {mealItems.length > 0 && (
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
            <div className="px-4 py-3 border-b border-white/10 flex items-center gap-2 bg-[#f1d07a]/5">
              <Utensils className="h-4 w-4 text-[#f1d07a]" />
              <span className="text-sm font-medium text-[#f1d07a]">Prehrana</span>
            </div>
            <div className="divide-y divide-white/5">
              {mealItems.map(item => (
                <div key={item.id} className="px-4 py-3 flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-white">{item.name}</p>
                      {isSharedInvoice && (item as any).fromBungalow && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300">{(item as any).fromBungalow}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] text-white/40">
                        {(item.eventDate || item.createdAt) ? new Date(item.eventDate || item.createdAt).toLocaleDateString('sl-SI', { day: 'numeric', month: 'short', year: 'numeric' }) : ''}
                      </span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${item.paymentStatus === 'PAID' ? 'bg-[#6fc8a3]/20 text-[#6fc8a3]' : 'bg-red-500/20 text-red-400'}`}>
                        {item.paymentStatus === 'PAID' ? 'PLACANO' : 'ZA PLACILO'}
                      </span>
                    </div>
                  </div>
                  <div className="text-right flex items-center gap-3">
                    <div>
                      <p className="text-sm font-medium text-white">{formatEur(arToEur(Number(item.priceAr)))} EUR</p>
                      <p className="text-xs text-white/40">{formatAr(Number(item.priceAr))} Ar</p>
                    </div>
                    <button onClick={() => handleDeleteOrderItem(item.id)} className="p-1.5 rounded-lg hover:bg-red-500/20 text-white/30 hover:text-red-400">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* OTHER ITEMS SECTION */}
        {otherItems.length > 0 && (
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
            <div className="px-4 py-3 border-b border-white/10 flex items-center gap-2 bg-white/5">
              <ReceiptText className="h-4 w-4 text-white/60" />
              <span className="text-sm font-medium text-white/60">Ostalo</span>
            </div>
            <div className="divide-y divide-white/5">
              {otherItems.map(item => (
                <div key={item.id} className="px-4 py-3 flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-white">{item.name}</p>
                      {isSharedInvoice && (item as any).fromBungalow && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300">{(item as any).fromBungalow}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] text-white/40">
                        {(item.eventDate || item.createdAt) ? new Date(item.eventDate || item.createdAt).toLocaleDateString('sl-SI', { day: 'numeric', month: 'short', year: 'numeric' }) : ''}
                      </span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${item.paymentStatus === 'PAID' ? 'bg-[#6fc8a3]/20 text-[#6fc8a3]' : 'bg-red-500/20 text-red-400'}`}>
                        {item.paymentStatus === 'PAID' ? 'PLACANO' : 'ZA PLACILO'}
                      </span>
                    </div>
                  </div>
                  <div className="text-right flex items-center gap-3">
                    <div>
                      <p className="text-sm font-medium text-white">{formatEur(arToEur(Number(item.priceAr)))} EUR</p>
                      <p className="text-xs text-white/40">{formatAr(Number(item.priceAr))} Ar</p>
                    </div>
                    <button onClick={() => handleDeleteOrderItem(item.id)} className="p-1.5 rounded-lg hover:bg-red-500/20 text-white/30 hover:text-red-400">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* DAILY DELIVERY NOTES (Bar) */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
          <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between bg-[#6fc8a3]/5">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-[#6fc8a3]" />
              <span className="text-sm font-medium text-[#6fc8a3]">Dnevne dobavnice (Bar)</span>
            </div>
            <button
              onClick={handleCreateNew}
              disabled={creating}
              className="text-xs px-3 py-1 rounded-lg bg-[#6fc8a3]/20 text-[#6fc8a3] hover:bg-[#6fc8a3]/30 disabled:opacity-50"
            >
              {creating ? '...' : '+ Nova'}
            </button>
          </div>
          
          {notes.length === 0 ? (
            <div className="p-6 text-center">
              <p className="text-sm text-white/40">Ni dnevnih dobavnic</p>
            </div>
          ) : (
            <div className="divide-y divide-white/5">
              {notes.map((note) => {
                const noteDate = new Date(note.date)
                const isToday = note.date === new Date().toISOString().split('T')[0]
                const isOpen = note.status === 'open'
                
                // Get excursions and transfers for this specific date
                const dayExcursions = excursionItems.filter(i => i.eventDate === note.date)
                const dayTransfers = transferItems.filter(i => i.eventDate === note.date)
                
                // Calculate total for this day (bar + excursions + transfers)
                const barTotalAr = note.totalAr || 0
                const excursionsTotalAr = dayExcursions.reduce((sum, i) => sum + Number(i.priceAr || 0), 0)
                const transfersTotalAr = dayTransfers.reduce((sum, i) => sum + Number(i.priceAr || 0), 0)
                const dayTotalAr = barTotalAr + excursionsTotalAr + transfersTotalAr
                const dayTotalEur = arToEur(dayTotalAr)
                
                return (
                  <div key={note.id} className="border-b border-white/5 last:border-b-0">
                    {/* Note header - clickable for closed notes */}
                    <div 
                      className={`px-4 py-3 flex items-center justify-between bg-white/[0.01] ${!isOpen ? 'cursor-pointer hover:bg-white/[0.03]' : ''}`}
                      onClick={() => {
                        if (!isOpen) {
                          setExpandedNotes(prev => ({ ...prev, [note.id]: !prev[note.id] }))
                        }
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                          isOpen ? 'bg-[#6fc8a3]/20 text-[#6fc8a3]' : 'bg-white/10 text-white/50'
                        }`}>
                          <FileText className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-sm text-white">
                            {noteDate.toLocaleDateString('sl-SI', { weekday: 'short', day: 'numeric', month: 'short' })}
                            {isToday && <span className="ml-2 text-xs text-[#6fc8a3]">DANES</span>}
                          </p>
                          <p className="text-xs text-white/40">
                            {(note.items?.length || 0) + dayExcursions.length + dayTransfers.length} postavk {isOpen ? '• Odprta' : '• Zaprta'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <p className={`text-sm font-medium ${isOpen ? 'text-[#6fc8a3]' : 'text-white/70'}`}>
                            {formatEur(dayTotalEur)} EUR
                          </p>
                          <p className="text-xs text-white/40">{formatAr(dayTotalAr)} Ar</p>
                        </div>
                        {!isOpen && (
                          <ChevronDown className={`h-4 w-4 text-white/40 transition-transform ${expandedNotes[note.id] ? 'rotate-180' : ''}`} />
                        )}
                      </div>
                    </div>
                    {/* Day items - transfers, excursions, bar (visible if open OR expanded) */}
                    {(isOpen || expandedNotes[note.id]) && (
                    <div className="px-4 pb-3">
                      {/* Transfers for this day */}
                      {dayTransfers.map((item) => (
                        <div key={item.id} className="flex items-center justify-between py-1.5 text-xs border-t border-white/5 first:border-t-0">
                          <div className="flex items-center gap-2">
                            <Ship className="h-3 w-3 text-[#78b7ff]" />
                            <span className="text-white/60">{item.name}</span>
                            <span className={`text-[9px] px-1 py-0.5 rounded ${item.paymentStatus === 'PAID' ? 'bg-[#6fc8a3]/20 text-[#6fc8a3]' : 'bg-red-500/20 text-red-400'}`}>
                              {item.paymentStatus === 'PAID' ? 'PLACANO' : 'ZA PLACILO'}
                            </span>
                          </div>
                          <span className="text-white/80">{formatEur(arToEur(Number(item.priceAr)))} EUR</span>
                        </div>
                      ))}
                      {/* Excursions for this day */}
                      {dayExcursions.map((item) => (
                        <div key={item.id} className="flex items-center justify-between py-1.5 text-xs border-t border-white/5 first:border-t-0">
                          <div className="flex items-center gap-2">
                            <Compass className="h-3 w-3 text-[#c084fc]" />
                            <span className="text-white/60">{item.name}</span>
                            <span className={`text-[9px] px-1 py-0.5 rounded ${item.paymentStatus === 'PAID' ? 'bg-[#6fc8a3]/20 text-[#6fc8a3]' : 'bg-red-500/20 text-red-400'}`}>
                              {item.paymentStatus === 'PAID' ? 'PLACANO' : 'ZA PLACILO'}
                            </span>
                          </div>
                          <span className="text-white/80">{formatEur(arToEur(Number(item.priceAr)))} EUR</span>
                        </div>
                      ))}
                      {/* Bar items */}
                      {note.items && note.items.map((item: { id: string; productName: string; quantity: number; priceAr: number }) => (
                        <div key={item.id} className="flex items-center justify-between py-1.5 text-xs border-t border-white/5 first:border-t-0">
                          <span className="text-white/60">{item.quantity}x {item.productName}</span>
                          <span className="text-white/80">{formatEur(arToEur(item.priceAr * item.quantity))} EUR</span>
                        </div>
                      ))}
                    </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>

        {/* Empty state if nothing */}
        {orderItems.length === 0 && notes.length === 0 && (
          <div className="text-center py-12">
            <ReceiptText className="h-12 w-12 mx-auto text-white/20 mb-3" />
            <p className="text-white/40">Ni artiklov na dobavnici</p>
            <p className="text-xs text-white/30 mt-1">Artikli se dodajo ob Check-in</p>
          </div>
        )}
        
        {/* Create Invoice Button */}
        {(orderItems.length > 0 || notes.length > 0) && (
          <div className="pt-4 border-t border-white/10">
            <Link href={`/racun/${reservationId}`}>
              <button className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#f1d07a] to-[#b8892f] text-[#0a0f1a] font-semibold text-sm uppercase tracking-wider hover:opacity-90 transition-all">
                Ustvari racun
              </button>
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
