"use client";

import React, { useState, useEffect } from "react";
import { Ship, Sparkles, Package, Users, Calendar, ArrowLeft, Check } from "lucide-react";
import Link from "next/link";

// Types
type Guest = {
  id: string;
  guestName: string;
  bungalow: string;
  pax: number;
  arrival: string;
  departure: string;
};

type Excursion = {
  id: string;
  name: string;
  guidePriceAr?: number;
  entranceFeeAr?: number;
  lunchPriceAr?: number;
};

type Product = {
  id: string;
  name: string;
  category: string;
  priceAr: number;
};

type Boat = {
  id: string;
  name: string;
};

type LunchProvider = {
  id: string;
  name: string;
};

type ExcursionPricing = {
  excursionId: string;
  boatId: string;
  pricePax1?: number;
  pricePax2?: number;
  pricePax3?: number;
  pricePax4?: number;
  pricePax5?: number;
  pricePax6?: number;
};

// Formatting helpers
const ar = (v: number) => `${Math.round(v).toLocaleString("fr-FR")} Ar`;
const today = () => new Date().toISOString().slice(0, 10);

export default function ReceptionPage() {
  const [activeGuests, setActiveGuests] = useState<Guest[]>([]);
  const [excursions, setExcursions] = useState<Excursion[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [boats, setBoats] = useState<Boat[]>([]);
  const [lunchProviders, setLunchProviders] = useState<LunchProvider[]>([]);
  const [excursionPricing, setExcursionPricing] = useState<ExcursionPricing[]>([]);
  const [exchangeRate, setExchangeRate] = useState(4800);
  const [loading, setLoading] = useState(true);
  
  // Selected guest
  const [selectedGuest, setSelectedGuest] = useState<Guest | null>(null);
  
  // Active tab: excursions, massage, other
  const [activeTab, setActiveTab] = useState<"excursions" | "massage" | "other">("excursions");
  
  // Form states
  const [excursionForm, setExcursionForm] = useState({
    excursionId: "",
    date: today(),
    pax: 2,
    boatId: "",
    lunchProviderId: "",
    paymentStatus: "UNPAID"
  });
  
  const [serviceForm, setServiceForm] = useState({
    productId: "",
    name: "",
    category: "Masaza",
    qty: 1,
    priceAr: 0,
    date: today(),
    paymentStatus: "UNPAID"
  });
  
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");

  // Load data
  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
  setLoading(true);
  try {
  const { getDashboardData } = await import("@/app/actions/komba");
  const { getExcursionSellingPricing } = await import("@/app/actions/pricing");
  const data = await getDashboardData();
  const sellingPricing = await getExcursionSellingPricing();
  
  // Filter active guests (checked in, not checked out)
  const active = data.reservations.filter((r: { checkedInAt?: string | null; checkedOutAt?: string | null }) =>
  r.checkedInAt && !r.checkedOutAt
  );
  setActiveGuests(active);
  setExcursions(data.excursions || []);
  setProducts(data.allProducts || []);
  setBoats(data.boats || []);
  setLunchProviders(data.lunchProviders || []);
  setExcursionPricing(sellingPricing || []);
  setExchangeRate(data.exchangeRate || 4800);
  } catch (e) {
  console.error("Error loading data:", e);
  }
  setLoading(false);
  }

  function showSuccess(msg: string) {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 3000);
  }

  // Get selling price for excursion based on boat and pax
  function getExcursionSellingPrice(excursionId: string, boatId: string, pax: number): number {
    const pricing = excursionPricing.find(ep => ep.excursionId === excursionId && ep.boatId === boatId);
    if (!pricing) return 0;
    
    // Price is in EUR, get based on pax count
    const paxKey = `pricePax${Math.min(Math.max(pax, 1), 6)}` as keyof ExcursionPricing;
    const priceEur = pricing[paxKey] as number || 0;
    
    // Convert to Ariary
    return Math.round(priceEur * exchangeRate);
  }

  // Add excursion to guest's delivery note
  async function handleAddExcursion() {
    if (!selectedGuest || !excursionForm.excursionId) return;
    
    setSaving(true);
    try {
      const { addExcursionBooking } = await import("@/app/actions/komba");
      const { addOrderItem } = await import("@/app/actions/komba");
      
      // Find excursion details
      const exc = excursions.find(e => e.id === excursionForm.excursionId);
      if (!exc) return;
      
      // Add to excursion_bookings
      await addExcursionBooking(selectedGuest.id, {
        excursionId: excursionForm.excursionId,
        date: excursionForm.date,
        pax: excursionForm.pax,
        boatId: excursionForm.boatId || undefined,
        lunchProviderId: excursionForm.lunchProviderId || undefined,
        paymentStatus: excursionForm.paymentStatus
      });
      
      // Calculate total price from SELLING price (not supplier price)
      const lunchProvider = lunchProviders.find(l => l.id === excursionForm.lunchProviderId);
      const lunchName = lunchProvider ? ` | Kosilo: ${lunchProvider.name}` : "";
      const boat = boats.find(b => b.id === excursionForm.boatId);
      const boatName = boat ? ` | Coln: ${boat.name}` : "";
      
      // Get selling price based on excursion + boat + pax
      const totalPriceAr = getExcursionSellingPrice(excursionForm.excursionId, excursionForm.boatId, excursionForm.pax);
      
      // Add to delivery note (order_items)
      await addOrderItem(selectedGuest.id, {
        name: `Izlet: ${exc.name} - ${excursionForm.pax} pax${boatName}${lunchName}`,
        category: "Izlet",
        qty: 1,
        priceAr: excursionForm.paymentStatus === "PAID" ? 0 : totalPriceAr,
        paymentStatus: excursionForm.paymentStatus,
        eventDate: excursionForm.date
      });
      
      // Reset form
      setExcursionForm({
        excursionId: "",
        date: today(),
        pax: selectedGuest.pax,
        boatId: "",
        lunchProviderId: "",
        paymentStatus: "UNPAID"
      });
      
      showSuccess(`Izlet ${exc.name} dodan za ${selectedGuest.guestName}`);
    } catch (e) {
      console.error("Error adding excursion:", e);
    }
    setSaving(false);
  }

  // Add service (massage, other) to guest's delivery note
  async function handleAddService() {
    if (!selectedGuest || !serviceForm.name) return;
    
    setSaving(true);
    try {
      const { addOrderItem } = await import("@/app/actions/komba");
      
      await addOrderItem(selectedGuest.id, {
        name: serviceForm.name,
        category: serviceForm.category,
        qty: serviceForm.qty,
        priceAr: serviceForm.paymentStatus === "PAID" ? 0 : serviceForm.priceAr * serviceForm.qty,
        paymentStatus: serviceForm.paymentStatus,
        eventDate: serviceForm.date
      });
      
      const serviceName = serviceForm.name;
      
      // Reset form but keep date and category
      setServiceForm(prev => ({
        productId: "",
        name: "",
        category: prev.category,
        qty: 1,
        priceAr: 0,
        date: prev.date,
        paymentStatus: "UNPAID"
      }));
      
      showSuccess(`${serviceName} dodan/a za ${selectedGuest.guestName}`);
    } catch (e) {
      console.error("Error adding service:", e);
    }
    setSaving(false);
  }

  // Filter products by category
  const massageProducts = products.filter(p => p.category === "Masaza" || p.category === "Masaža" || p.category === "Wellness");
  const otherProducts = products.filter(p => 
    p.category !== "Masaza" && 
    p.category !== "Masaža" && 
    p.category !== "Wellness" &&
    p.category !== "Prehrana" &&
    p.category !== "Pijaca" &&
    p.category !== "Pijača"
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a1628] flex items-center justify-center">
        <div className="text-white/50">Nalagam...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a1628]">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-white/[0.06] bg-[#0a1628]/95 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/" className="p-2 rounded-xl hover:bg-white/[0.05] text-white/50 hover:text-white transition-colors">
                <ArrowLeft className="h-5 w-5" />
              </Link>
              <div>
                <h1 className="text-xl font-light text-white">Recepcija</h1>
                <p className="text-xs text-white/40">Narocanje storitev med bivanjem</p>
              </div>
            </div>
            
            {selectedGuest && (
              <div className="flex items-center gap-3 px-4 py-2 rounded-xl bg-[#f1d07a]/10 border border-[#f1d07a]/30">
                <div className="w-10 h-10 rounded-full bg-[#f1d07a]/20 flex items-center justify-center">
                  <span className="text-[#f1d07a] font-bold text-sm">{selectedGuest.bungalow.replace(/\D/g, '') || 'B'}</span>
                </div>
                <div>
                  <p className="text-[#f1d07a] font-medium text-sm">{selectedGuest.bungalow}</p>
                  <p className="text-white/50 text-xs">{selectedGuest.guestName}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Success message */}
      {successMsg && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-6 py-3 rounded-xl bg-[#6fc8a3] text-white font-medium shadow-lg flex items-center gap-2">
          <Check className="h-5 w-5" />
          {successMsg}
        </div>
      )}

      <main className="mx-auto max-w-7xl px-4 py-8">
        {/* Guest Selection */}
        {!selectedGuest ? (
          <div>
            <h2 className="text-white/40 text-[10px] uppercase tracking-[0.2em] font-medium mb-4">Izberi gosta</h2>
            
            {activeGuests.length === 0 ? (
              <div className="p-8 rounded-2xl border border-white/[0.06] bg-white/[0.02] text-center">
                <Users className="h-12 w-12 mx-auto text-white/20 mb-4" />
                <p className="text-white/50">Ni aktivnih gostov.</p>
                <p className="text-white/30 text-sm mt-1">Gostje se prikazejo po check-in.</p>
              </div>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {activeGuests.map(guest => (
                  <button
                    key={guest.id}
                    onClick={() => {
                      setSelectedGuest(guest);
                      setExcursionForm(prev => ({ ...prev, pax: guest.pax }));
                    }}
                    className="p-5 rounded-2xl border border-white/[0.06] bg-white/[0.02] hover:bg-white/[0.05] hover:border-[#f1d07a]/30 transition-all text-left group"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-xl bg-[#f1d07a]/10 border border-[#f1d07a]/30 flex items-center justify-center group-hover:bg-[#f1d07a]/20 transition-colors">
                        <span className="text-[#f1d07a] font-bold text-lg">{guest.bungalow.replace(/\D/g, '') || 'B'}</span>
                      </div>
                      <div>
                        <p className="text-[#f1d07a] font-medium">{guest.bungalow}</p>
                        <p className="text-white text-sm mt-0.5">{guest.guestName}</p>
                        <p className="text-white/40 text-xs mt-1">{guest.pax} oseb</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div>
            {/* Back button */}
            <button
              onClick={() => setSelectedGuest(null)}
              className="mb-6 flex items-center gap-2 text-white/50 hover:text-white text-sm transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Nazaj na izbiro gosta
            </button>

            {/* Service Tabs */}
            <div className="flex gap-2 mb-8">
              {[
                { id: "excursions", label: "Izleti", icon: Ship },
                { id: "massage", label: "Masaze", icon: Sparkles },
                { id: "other", label: "Ostale storitve", icon: Package },
              ].map(tab => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as typeof activeTab)}
                    className={`flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-medium transition-all ${
                      isActive
                        ? "bg-[#78b7ff]/20 border border-[#78b7ff]/40 text-[#78b7ff]"
                        : "bg-white/[0.02] border border-white/[0.06] text-white/50 hover:text-white hover:bg-white/[0.05]"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Excursions Tab */}
            {activeTab === "excursions" && (
              <div className="p-6 rounded-2xl border border-white/[0.06] bg-white/[0.02]">
                <h3 className="text-white font-medium mb-6">Naroči izlet</h3>
                
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Izlet</label>
                    <select
                      value={excursionForm.excursionId}
                      onChange={e => setExcursionForm(prev => ({ ...prev, excursionId: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    >
                      <option value="">Izberi izlet</option>
                      {excursions.map(exc => (
                        <option key={exc.id} value={exc.id}>{exc.name}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Datum</label>
                    <input
                      type="date"
                      value={excursionForm.date}
                      onChange={e => setExcursionForm(prev => ({ ...prev, date: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Stevilo oseb</label>
                    <input
                      type="number"
                      min="1"
                      value={excursionForm.pax}
                      onChange={e => setExcursionForm(prev => ({ ...prev, pax: Number(e.target.value) }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    />
                  </div>
                  
  <div>
  <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Coln</label>
  <select
  value={excursionForm.boatId}
  onChange={e => setExcursionForm(prev => ({ ...prev, boatId: e.target.value }))}
  className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
  >
  <option value="">Izberi coln</option>
  {boats
    .filter(b => excursionPricing.some(ep => 
      ep.excursionId === excursionForm.excursionId && 
      ep.boatId === b.id && 
      (ep.pricePax1 || ep.pricePax2 || ep.pricePax3 || ep.pricePax4 || ep.pricePax5 || ep.pricePax6)
    ))
    .map(b => {
      const pricing = excursionPricing.find(ep => ep.excursionId === excursionForm.excursionId && ep.boatId === b.id);
      const paxKey = `pricePax${Math.min(Math.max(excursionForm.pax, 1), 6)}` as keyof ExcursionPricing;
      const priceEur = pricing ? (pricing[paxKey] as number || 0) : 0;
      return (
  <option key={b.id} value={b.id}>{b.name} - {priceEur} EUR</option>
      );
    })}
  </select>
  </div>
  
  {/* Price display */}
  {excursionForm.excursionId && excursionForm.boatId && (
  <div className="p-4 rounded-xl bg-gradient-to-r from-[#f1d07a]/10 to-[#b8892f]/10 border border-[#f1d07a]/20">
    <p className="text-white/50 text-xs uppercase tracking-wider mb-1">Prodajna cena</p>
    <p className="text-2xl font-light text-[#f1d07a]">
      {(() => {
        const pricing = excursionPricing.find(ep => ep.excursionId === excursionForm.excursionId && ep.boatId === excursionForm.boatId);
        const paxKey = `pricePax${Math.min(Math.max(excursionForm.pax, 1), 6)}` as keyof ExcursionPricing;
        const priceEur = pricing ? (pricing[paxKey] as number || 0) : 0;
        return `${priceEur} EUR`;
      })()}
    </p>
    <p className="text-white/40 text-xs mt-1">
      {(() => {
        const priceAr = getExcursionSellingPrice(excursionForm.excursionId, excursionForm.boatId, excursionForm.pax);
        return `= ${ar(priceAr)}`;
      })()}
    </p>
  </div>
  )}
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Kosilo</label>
                    <select
                      value={excursionForm.lunchProviderId}
                      onChange={e => setExcursionForm(prev => ({ ...prev, lunchProviderId: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    >
                      <option value="">Ni izbrano</option>
                      {lunchProviders.map(l => (
                        <option key={l.id} value={l.id}>{l.name}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Status placila</label>
                    <select
                      value={excursionForm.paymentStatus}
                      onChange={e => setExcursionForm(prev => ({ ...prev, paymentStatus: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    >
                      <option value="UNPAID">Za placilo</option>
                      <option value="PAID">Placano</option>
                    </select>
                  </div>
                </div>
                
                {/* Description preview */}
                {excursionForm.excursionId && (
                  <div className="mt-6 p-4 rounded-xl bg-[#78b7ff]/10 border border-[#78b7ff]/20">
                    {(() => {
                      const exc = excursions.find(e => e.id === excursionForm.excursionId);
                      if (!exc) return null;
                      const boat = boats.find(b => b.id === excursionForm.boatId);
                      const lunch = lunchProviders.find(l => l.id === excursionForm.lunchProviderId);
                      return (
                        <div>
                          <p className="text-white font-medium">{exc.name}</p>
                          <p className="text-white/50 text-xs mt-1">
                            Vklj: {boat ? boat.name : 'Coln ni izbran'}{exc.entranceFeeAr ? ', vstopnina' : ''}{lunch ? `, kosilo: ${lunch.name}` : ''}
                          </p>
                        </div>
                      );
                    })()}
                  </div>
                )}
                
                <button
                  onClick={handleAddExcursion}
                  disabled={saving || !excursionForm.excursionId}
                  className="mt-6 w-full py-4 rounded-xl bg-gradient-to-r from-[#78b7ff] to-[#5a9be0] text-white font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg hover:shadow-[#78b7ff]/20 transition-all"
                >
                  {saving ? "Dodajam..." : "Dodaj izlet na dobavnico"}
                </button>
              </div>
            )}

            {/* Massage Tab */}
            {activeTab === "massage" && (
              <div className="p-6 rounded-2xl border border-white/[0.06] bg-white/[0.02]">
                <h3 className="text-white font-medium mb-6">Naroči masažo</h3>
                
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Masaza</label>
                    <select
                      value={serviceForm.productId}
                      onChange={e => {
                        const product = massageProducts.find(p => p.id === e.target.value);
                        if (product) {
                          setServiceForm(prev => ({ 
                            ...prev, 
                            productId: product.id,
                            name: product.name, 
                            category: "Masaza",
                            priceAr: product.priceAr 
                          }));
                        }
                      }}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    >
                      <option value="">Izberi masazo</option>
                      {massageProducts.map(p => (
                        <option key={p.id} value={p.id}>{p.name} - {ar(p.priceAr)}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Datum</label>
                    <input
                      type="date"
                      value={serviceForm.date}
                      onChange={e => setServiceForm(prev => ({ ...prev, date: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Kolicina</label>
                    <input
                      type="number"
                      min="1"
                      value={serviceForm.qty}
                      onChange={e => setServiceForm(prev => ({ ...prev, qty: Number(e.target.value) }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Status placila</label>
                    <select
                      value={serviceForm.paymentStatus}
                      onChange={e => setServiceForm(prev => ({ ...prev, paymentStatus: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    >
                      <option value="UNPAID">Za placilo</option>
                      <option value="PAID">Placano</option>
                    </select>
                  </div>
                </div>
                
                {/* Price preview */}
                {serviceForm.name && (
                  <div className="mt-6 p-4 rounded-xl bg-[#78b7ff]/10 border border-[#78b7ff]/20">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white font-medium">{serviceForm.name}</p>
                        <p className="text-white/50 text-xs mt-1">{serviceForm.qty}× {ar(serviceForm.priceAr)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[#78b7ff] font-medium">{ar(serviceForm.priceAr * serviceForm.qty)}</p>
                        <p className="text-white/40 text-xs">{((serviceForm.priceAr * serviceForm.qty) / exchangeRate).toFixed(2)} EUR</p>
                      </div>
                    </div>
                  </div>
                )}
                
                <button
                  onClick={handleAddService}
                  disabled={saving || !serviceForm.name}
                  className="mt-6 w-full py-4 rounded-xl bg-gradient-to-r from-[#78b7ff] to-[#5a9be0] text-white font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg hover:shadow-[#78b7ff]/20 transition-all"
                >
                  {saving ? "Dodajam..." : "Dodaj masazo na dobavnico"}
                </button>
              </div>
            )}

            {/* Other Services Tab */}
            {activeTab === "other" && (
              <div className="p-6 rounded-2xl border border-white/[0.06] bg-white/[0.02]">
                <h3 className="text-white font-medium mb-6">Ostale storitve</h3>
                
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Storitev</label>
                    <select
                      value={serviceForm.productId}
                      onChange={e => {
                        const product = otherProducts.find(p => p.id === e.target.value);
                        if (product) {
                          setServiceForm(prev => ({ 
                            ...prev, 
                            productId: product.id,
                            name: product.name, 
                            category: product.category,
                            priceAr: product.priceAr 
                          }));
                        }
                      }}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    >
                      <option value="">Izberi storitev</option>
                      {otherProducts.map(p => (
                        <option key={p.id} value={p.id}>{p.name} - {ar(p.priceAr)}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Ali vnesi rocno</label>
                    <input
                      type="text"
                      value={serviceForm.name}
                      onChange={e => setServiceForm(prev => ({ ...prev, name: e.target.value, productId: "" }))}
                      placeholder="Ime storitve"
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40 placeholder:text-white/30"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Datum</label>
                    <input
                      type="date"
                      value={serviceForm.date}
                      onChange={e => setServiceForm(prev => ({ ...prev, date: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Kolicina</label>
                    <input
                      type="number"
                      min="1"
                      value={serviceForm.qty}
                      onChange={e => setServiceForm(prev => ({ ...prev, qty: Number(e.target.value) }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Cena (Ar)</label>
                    <input
                      type="number"
                      min="0"
                      value={serviceForm.priceAr}
                      onChange={e => setServiceForm(prev => ({ ...prev, priceAr: Number(e.target.value) }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white/40 text-[10px] uppercase tracking-wider mb-2">Status placila</label>
                    <select
                      value={serviceForm.paymentStatus}
                      onChange={e => setServiceForm(prev => ({ ...prev, paymentStatus: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-[#78b7ff]/40"
                    >
                      <option value="UNPAID">Za placilo</option>
                      <option value="PAID">Placano</option>
                    </select>
                  </div>
                </div>
                
                {/* Price preview */}
                {serviceForm.name && (
                  <div className="mt-6 p-4 rounded-xl bg-[#78b7ff]/10 border border-[#78b7ff]/20">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white font-medium">{serviceForm.name}</p>
                        <p className="text-white/50 text-xs mt-1">{serviceForm.qty}× {ar(serviceForm.priceAr)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[#78b7ff] font-medium">{ar(serviceForm.priceAr * serviceForm.qty)}</p>
                        <p className="text-white/40 text-xs">{((serviceForm.priceAr * serviceForm.qty) / exchangeRate).toFixed(2)} EUR</p>
                      </div>
                    </div>
                  </div>
                )}
                
                <button
                  onClick={handleAddService}
                  disabled={saving || !serviceForm.name}
                  className="mt-6 w-full py-4 rounded-xl bg-gradient-to-r from-[#78b7ff] to-[#5a9be0] text-white font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg hover:shadow-[#78b7ff]/20 transition-all"
                >
                  {saving ? "Dodajam..." : "Dodaj storitev na dobavnico"}
                </button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
