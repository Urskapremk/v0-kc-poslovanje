import { getTransferVoucherData } from "@/app/actions/komba"
import { notFound } from "next/navigation"

export default async function TransferVoucherPage({ params }: { params: Promise<{ reservationId: string; type: string }> }) {
  const { reservationId, type } = await params
  
  if (type !== 'arrival' && type !== 'departure') {
    notFound()
  }
  
  const data = await getTransferVoucherData(reservationId, type as 'arrival' | 'departure')
  
  if (!data) {
    notFound()
  }
  
  const isArrival = type === 'arrival'
  const badgeColor = isArrival ? '#22c55e' : '#ef4444'
  const badgeText = isArrival ? 'ARRIVAL TRANSFER' : 'DEPARTURE TRANSFER'
  
  return (
    <div className="min-h-screen bg-[#0f1724] flex justify-center p-4">
      <div className="w-full max-w-[500px] bg-white rounded-2xl overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0f1724] to-[#1a2744] px-5 py-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] tracking-[2px] text-white/60 uppercase mb-1">Transfer Voucher</p>
            <h1 className="text-lg font-bold text-[#f1d07a]">KOMBA CABANA</h1>
          </div>
          <div className="w-10 h-10 bg-[#f1d07a] rounded-lg flex items-center justify-center">
            <svg className="w-6 h-6 fill-[#0f1724]" viewBox="0 0 24 24">
              <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
            </svg>
          </div>
        </div>
        
        {/* Content */}
        <div className="p-6">
          {/* Guest */}
          <div className="mb-5">
            <p className="text-[10px] tracking-[1px] uppercase text-slate-400 mb-1">Guest</p>
            <p className="text-2xl font-bold text-[#0f1724]">
              {data.guestName}
              {data.secondGuestName && <><br />{data.secondGuestName}</>}
            </p>
            <p className="text-sm mt-1" style={{ color: badgeColor }}>{data.bungalowName}</p>
          </div>
          
          {/* Badge */}
          <span 
            className="inline-block text-[11px] font-semibold px-3 py-1 rounded-full mb-4"
            style={{ 
              backgroundColor: `${badgeColor}20`, 
              border: `1px solid ${badgeColor}`,
              color: badgeColor 
            }}
          >
            {badgeText}
          </span>
          
          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-4 mb-5">
            <div>
              <p className="text-[10px] tracking-[1px] uppercase text-slate-400 mb-1">Date</p>
              <p className="text-[15px] font-semibold text-[#0f1724]">
                {data.date ? new Date(data.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) : 'TBA'}
              </p>
            </div>
            <div>
              <p className="text-[10px] tracking-[1px] uppercase text-slate-400 mb-1">{isArrival ? 'Time' : 'Pickup Time'}</p>
              <p className="text-[15px] font-semibold text-[#0f1724]">{data.time || 'TBA'}</p>
            </div>
          </div>
          
          {/* Route */}
          <div className="bg-slate-50 rounded-xl p-4 mb-5">
            <p className="text-[10px] tracking-[1px] uppercase text-slate-400 mb-1">Route</p>
            <p className="text-base font-semibold text-[#0f1724]">{data.routeName}</p>
          </div>
          
          {/* Passengers & Flight */}
          <div className="grid grid-cols-2 gap-4 mb-5">
            <div>
              <p className="text-[10px] tracking-[1px] uppercase text-slate-400 mb-1">Passengers</p>
              <p className="text-[15px] font-semibold text-[#0f1724]">{data.pax} {data.pax === 1 ? 'person' : 'persons'}</p>
            </div>
            <div>
              <p className="text-[10px] tracking-[1px] uppercase text-slate-400 mb-1">Flight</p>
              <p className="text-[15px] font-semibold text-[#0f1724]">{data.flightNumber || 'N/A'}</p>
            </div>
          </div>
          
          {/* Logo Section */}
          {isArrival && (
            <div className="bg-gradient-to-br from-[#0f1724]/5 to-[#1a2744]/5 rounded-xl p-5 text-center mb-5">
              <p className="text-[10px] tracking-[2px] uppercase text-slate-400 mb-3">Look for our logo at the airport:</p>
              <img src="/images/komba-logo-gold.png" alt="Komba Cabana" className="h-12 mx-auto" />
            </div>
          )}
          
          {!isArrival && (
            <div className="bg-gradient-to-br from-[#0f1724]/5 to-[#1a2744]/5 rounded-xl p-5 text-center mb-5">
              <img src="/images/komba-logo-gold.png" alt="Komba Cabana" className="h-12 mx-auto" />
            </div>
          )}
        </div>
        
        {/* Instructions */}
        <div className="bg-[#0f1724] text-white p-5">
          {isArrival ? (
            <>
              <p className="text-[13px] leading-relaxed mb-3">
                <strong>Our driver will meet you at the airport with the Komba Cabana Lodge logo.</strong> You will be driven to the port of Hell-Ville (Andoany), where a boat will be waiting to take you directly to Komba Cabana Lodge beach.
              </p>
              <p className="text-[11px] text-white/60">Please present this voucher upon arrival.</p>
            </>
          ) : (
            <>
              <p className="text-[13px] leading-relaxed mb-3">
                <strong>Our team will pick you up from Komba Cabana Lodge beach.</strong> You will be taken by boat to Hell-Ville (Andoany) port, then by car to Nosy Be Airport.
              </p>
              <p className="text-[11px] text-white/60">Please be ready at the reception at the scheduled pickup time.</p>
            </>
          )}
        </div>
        
        {/* Payment Note */}
        {data.paymentStatus !== 'PAID' && data.paymentStatus !== 'PREPAID' && (
          <div className="mx-5 my-4 bg-amber-50 border border-amber-400 rounded-lg p-3 text-center">
            <p className="text-[12px] font-medium text-amber-800">Transfer is payable at checkout during your final bill settlement.</p>
          </div>
        )}
        
        {/* Footer */}
        <div className="py-4 px-6 text-center text-[11px] text-slate-400">
          For questions: info@kombacabana.com
        </div>
      </div>
    </div>
  )
}
