"use client";

import React from "react";

// Glassmorphism card with luxury styling
export function GlassCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-[2rem] border border-white/[0.08] bg-[rgba(15,23,36,0.82)] p-8 shadow-[0_8px_32px_rgba(0,0,0,0.4)] backdrop-blur-xl ${className}`}>
      {children}
    </div>
  );
}

export function SectionHeader({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }) {
  return (
    <div>
      {eyebrow && <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.22em] text-[#94a3b8]">{eyebrow}</p>}
      <h2 className="font-[family-name:var(--font-manrope)] text-[1.4rem] font-light tracking-wide text-[#f8fafc]">{title}</h2>
      {subtitle && <p className="mt-2 text-sm font-light text-[#94a3b8]">{subtitle}</p>}
    </div>
  );
}

export function LuxuryBadge({ children, variant = "default" }: { children: React.ReactNode; variant?: "default" | "petrol" | "ocean" | "danger" | "gold" }) {
  const styles = {
    default: "bg-white/5 border-white/10 text-[#cbd5e1]",
    petrol: "bg-[#6fc8a3]/15 border-[#6fc8a3]/25 text-[#6fc8a3]",
    ocean: "bg-[#78b7ff]/15 border-[#78b7ff]/25 text-[#78b7ff]",
    danger: "bg-[#d94a63]/15 border-[#d94a63]/25 text-[#d94a63]",
    gold: "bg-[#f1d07a]/15 border-[#f1d07a]/25 text-[#f1d07a]",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] ${styles[variant]}`}>
      {children}
    </span>
  );
}

export function LuxuryButton({ children, variant = "gold", className = "", ...props }: { children: React.ReactNode; variant?: "gold" | "petrol" | "ocean" | "ghost" | "danger"; className?: string } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const styles = {
    gold: "bg-gradient-to-r from-[#fff4cc] via-[#f1d07a] to-[#b8892f] text-[#0a0f1a] shadow-[0_4px_20px_rgba(241,208,122,0.25)] hover:shadow-[0_6px_28px_rgba(241,208,122,0.35)]",
    petrol: "bg-gradient-to-r from-[#6fc8a3] to-[#4fa987] text-[#0a0f1a] shadow-[0_4px_20px_rgba(111,200,163,0.25)] hover:shadow-[0_6px_28px_rgba(111,200,163,0.35)]",
    ocean: "bg-gradient-to-r from-[#78b7ff] to-[#5c8fd8] text-[#0a0f1a] shadow-[0_4px_20px_rgba(120,183,255,0.25)] hover:shadow-[0_6px_28px_rgba(120,183,255,0.35)]",
    ghost: "bg-white/[0.03] border border-white/10 text-[#cbd5e1] hover:bg-white/[0.06] hover:border-white/15",
    danger: "bg-gradient-to-r from-[#d94a63] to-[#a83248] text-white shadow-[0_4px_20px_rgba(217,74,99,0.25)] hover:shadow-[0_6px_28px_rgba(217,74,99,0.35)]",
  };
  return (
    <button className={`rounded-[1.2rem] px-6 py-3 text-[11px] font-semibold uppercase tracking-[0.18em] transition-all duration-300 ${styles[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}

// Stabilna input komponenta - uporablja onBlur namesto onChange za preprečevanje izgube fokusa
export function LuxuryInput({ label, value, onChange, type = "text", placeholder }: { label: string; value: string | number; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  const inputRef = React.useRef<HTMLInputElement>(null);
  const initialValue = React.useRef(String(value));
  
  // Update initial value when external value changes and input is not focused
  React.useEffect(() => {
    if (inputRef.current && document.activeElement !== inputRef.current) {
      inputRef.current.value = String(value);
      initialValue.current = String(value);
    }
  }, [value]);
  
  return (
    <div>
      <label className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.2em] text-[#94a3b8]">{label}</label>
      <input
        ref={inputRef}
        type={type}
        className="w-full rounded-[1.1rem] border border-white/10 bg-white/[0.03] px-5 py-3.5 text-[#f8fafc] placeholder:text-[#475569] transition-all duration-300 focus:border-[#f1d07a]/40 focus:outline-none focus:ring-2 focus:ring-[#f1d07a]/10"
        defaultValue={String(value)}
        onBlur={e => {
          if (e.target.value !== initialValue.current) {
            onChange(e.target.value);
            initialValue.current = e.target.value;
          }
        }}
        placeholder={placeholder}
      />
    </div>
  );
}

export function LuxurySelect({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: (string | { value: string; label: string })[] }) {
  return (
    <div>
      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">{label}</label>
      <select
        className="w-full rounded-[1.1rem] border border-white/10 bg-white/5 px-5 py-3 text-white transition-all duration-300 focus:border-[#f1d07a]/50 focus:outline-none focus:ring-2 focus:ring-[#f1d07a]/20 cursor-pointer"
        value={value}
        onChange={e => onChange(e.target.value)}
      >
        {options.map(opt => typeof opt === "string" ? <option key={opt} value={opt} className="bg-[#0a0f1a] text-white">{opt || "—"}</option> : <option key={opt.value} value={opt.value} className="bg-[#0a0f1a] text-white">{opt.label}</option>)}
      </select>
    </div>
  );
}

export function LuxuryCheckbox({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center gap-3 text-sm text-white/70 transition-colors hover:text-white">
      <div className={`flex h-5 w-5 items-center justify-center rounded-lg border transition-all ${checked ? "border-[#f1d07a] bg-[#f1d07a]" : "border-white/20 bg-white/5"}`}>
        {checked && <span className="text-[#0a0f1a] text-xs">✓</span>}
      </div>
      <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)} className="sr-only" />
      {label}
    </label>
  );
}
