'use client'

import React, { useState } from 'react'
import useSWR from 'swr'
import { Printer, Wallet, AlertTriangle, Check, Receipt } from 'lucide-react'
import { getAllStaffMembers } from '@/app/actions/statistics'
import {
  getPayrollEntries,
  upsertPayrollEntry,
  getQuarterlyContributions,
  setContributionPaid,
} from '@/app/actions/payroll'
import {
  calcPayslip,
  calcEmployerContributions,
  getQuarter,
  DEFAULT_NET_SALARY,
  formatAr,
  getCompany,
} from '@/lib/payroll'

const MONTHS_FR = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre',
]

const QUARTER_DEADLINE_LABEL: Record<number, string> = {
  1: 'do konca aprila',
  2: 'do konca julija',
  3: 'do konca oktobra',
  4: 'do konca januarja (naslednje leto)',
}

function formatDateSl(iso: string) {
  const d = new Date(iso)
  return d.toLocaleDateString('sl-SI', { day: 'numeric', month: 'long', year: 'numeric' })
}

function formatDateFr(iso: string | null) {
  if (!iso) return ''
  const d = new Date(iso)
  if (isNaN(d.getTime())) return ''
  return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' })
}

type PrintStaff = {
  name: string
  base: number
  firstName: string
  lastName: string
  dateOfBirth: string | null
  placeOfBirth: string
  documentNumber: string
  company: string
}

export default function PlaceTab({ year, month }: { year: number; month: number }) {
  const [printStaff, setPrintStaff] = useState<PrintStaff | null>(null)
  const [selectedQuarter, setSelectedQuarter] = useState<number>(getQuarter(month))

  const { data: allStaff } = useSWR('all-staff', () => getAllStaffMembers(), {
    refreshInterval: 0,
  })

  const { data: entries, mutate: mutateEntries } = useSWR(
    ['payroll', year, month],
    () => getPayrollEntries(year, month),
    { refreshInterval: 0 }
  )

  const { data: quarterly, mutate: mutateQuarterly } = useSWR(
    ['quarterly', year, selectedQuarter],
    () => getQuarterlyContributions(year, selectedQuarter),
    { refreshInterval: 0 }
  )

  const regularStaff = (allStaff || []).filter((s) => s.isRegularEmployee)

  // map staffId -> baseSalary za izbrani mesec
  const baseByStaff: Record<string, number> = {}
  for (const e of entries || []) {
    baseByStaff[e.staffId] = e.baseSalary
  }

  const getBase = (staffId: string) =>
    baseByStaff[staffId] ?? DEFAULT_NET_SALARY

  const handleSaveBase = async (
    staffId: string,
    staffName: string,
    value: number
  ) => {
    const base = isNaN(value) || value <= 0 ? DEFAULT_NET_SALARY : value
    await upsertPayrollEntry({ staffId, staffName, year, month, baseSalary: base })
    mutateEntries()
    mutateQuarterly()
  }

  const handleTogglePaid = async (paid: boolean) => {
    await setContributionPaid(year, selectedQuarter, paid)
    mutateQuarterly()
  }

  const handlePrint = (staff: PrintStaff) => {
    setPrintStaff(staff)
    // pocakaj na render print bloka
    setTimeout(() => {
      document.body.classList.add('printing-payslip')
      window.print()
      document.body.classList.remove('printing-payslip')
    }, 50)
  }

  // skupni mesecni stroski (vsi redni zaposleni)
  let monthTotalBase = 0
  let monthTotalEmployerCost = 0
  for (const s of regularStaff) {
    const base = getBase(s.id)
    monthTotalBase += base
    monthTotalEmployerCost += calcEmployerContributions(base).totalCost
  }

  const printPayslip = printStaff ? calcPayslip(printStaff.base) : null

  // dni do roka za izbrano cetrtletje
  const deadlineDate = quarterly ? new Date(quarterly.deadline) : null
  const daysLeft = deadlineDate
    ? Math.ceil((deadlineDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
    : null
  const deadlineUrgent =
    quarterly && !quarterly.paid && daysLeft !== null && daysLeft <= 30

  return (
    <div className="space-y-6">
      {/* Header / povzetek */}
      <div className="no-print rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#78b7ff]/15">
              <Wallet className="h-5 w-5 text-[#78b7ff]" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Obračun plač</h3>
              <p className="text-xs text-white/40">
                {MONTHS_FR[month - 1]} {year} — redno zaposleni ({regularStaff.length})
              </p>
            </div>
          </div>
          <div className="flex gap-6">
            <div className="text-right">
              <p className="text-[11px] uppercase tracking-wider text-white/40">Skupaj neto</p>
              <p className="text-lg font-bold text-white">{formatAr(monthTotalBase)}</p>
            </div>
            <div className="text-right">
              <p className="text-[11px] uppercase tracking-wider text-white/40">Strošek delodajalca</p>
              <p className="text-lg font-bold text-[#6fc8a3]">{formatAr(monthTotalEmployerCost)}</p>
            </div>
          </div>
        </div>
      </div>

      {regularStaff.length === 0 && (
        <div className="no-print rounded-2xl border border-white/[0.06] bg-white/[0.02] p-8 text-center">
          <p className="text-sm text-white/50">
            Ni rednih zaposlenih. Označite delavce kot &quot;redno zaposlen&quot; v zavihku &quot;Seznam osebja&quot;.
          </p>
        </div>
      )}

      {/* Seznam rednih zaposlenih z obracunom */}
      <div className="no-print space-y-3">
        {regularStaff.map((s) => {
          const base = getBase(s.id)
          const slip = calcPayslip(base)
          const emp = calcEmployerContributions(base)
          return (
            <div
              key={s.id}
              className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5"
            >
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-[180px]">
                  <p className="text-sm font-semibold text-[#f1d07a]">{s.staffName}</p>
                  <label className="mt-3 block text-[11px] font-medium uppercase tracking-wider text-white/40">
                    Neto plača (Ar)
                  </label>
                  <input
                    type="number"
                    className="mt-1 w-40 rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-2.5 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                    defaultValue={base}
                    onBlur={(e) =>
                      handleSaveBase(s.id, s.staffName, Number(e.target.value))
                    }
                  />
                </div>

                {/* Placilna lista (zaposleni) */}
                <div className="flex-1 min-w-[240px]">
                  <p className="mb-2 text-[11px] uppercase tracking-wider text-white/40">
                    Plačilna lista (odbitki)
                  </p>
                  <div className="space-y-1 text-sm">
                    <Row label="Osnova (neto)" value={formatAr(slip.baseSalary)} />
                    <Row label="CNAPS zaposleni 1%" value={formatAr(slip.cnapsEmployee)} />
                    <Row label="OMINO zaposleni 1%" value={formatAr(slip.ominoEmployee)} />
                    <Row label="IRSA" value={formatAr(slip.irsa)} />
                    <Row label="Skupaj odbitki" value={formatAr(slip.totalDeductions)} muted />
                    <Row label="Bruto" value={formatAr(slip.grossSalary)} strong />
                  </div>
                </div>

                {/* Prispevki delodajalca */}
                <div className="flex-1 min-w-[240px]">
                  <p className="mb-2 text-[11px] uppercase tracking-wider text-white/40">
                    Prispevki delodajalca
                  </p>
                  <div className="space-y-1 text-sm">
                    <Row label="CNAPS delodajalec 14%" value={formatAr(emp.cnapsEmployer)} />
                    <Row label="OMINO delodajalec 7.5%" value={formatAr(emp.ominoEmployer)} />
                    <Row label="FMFP 1%" value={formatAr(emp.fmfpEmployer)} />
                    <Row label="Skupaj prispevki" value={formatAr(emp.totalContributions)} muted />
                    <Row label="Skupni strošek" value={formatAr(emp.totalCost)} strong accent />
                  </div>
                </div>

                <div className="flex items-center">
                  <button
                    onClick={() =>
                      handlePrint({
                        name: s.staffName,
                        base,
                        firstName: s.firstName,
                        lastName: s.lastName,
                        dateOfBirth: s.dateOfBirth,
                        placeOfBirth: s.placeOfBirth,
                        documentNumber: s.documentNumber,
                        company: s.company,
                      })
                    }
                    className="flex items-center gap-2 rounded-xl border border-[#78b7ff]/30 bg-[#78b7ff]/10 px-4 py-2.5 text-sm font-medium text-[#78b7ff] transition hover:bg-[#78b7ff]/20"
                  >
                    <Printer className="h-4 w-4" />
                    Plačilna lista
                  </button>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Cetrtletni prispevki */}
      <div className="no-print rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#6fc8a3]/15">
              <Receipt className="h-5 w-5 text-[#6fc8a3]" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Četrtletni prispevki</h3>
              <p className="text-xs text-white/40">Za plačilo prispevkov državi</p>
            </div>
          </div>
          <div className="flex gap-2">
            {[1, 2, 3, 4].map((q) => (
              <button
                key={q}
                onClick={() => setSelectedQuarter(q)}
                className={`rounded-xl px-4 py-2 text-sm font-medium transition ${
                  selectedQuarter === q
                    ? 'bg-[#78b7ff]/20 text-[#78b7ff]'
                    : 'border border-white/[0.06] text-white/50 hover:bg-white/[0.04]'
                }`}
              >
                Q{q}
              </button>
            ))}
          </div>
        </div>

        {quarterly && (
          <div className="mt-5">
            {deadlineUrgent && (
              <div className="mb-4 flex items-center gap-3 rounded-xl border border-[#e08a8a]/30 bg-[#e08a8a]/10 px-4 py-3">
                <AlertTriangle className="h-5 w-5 shrink-0 text-[#e08a8a]" />
                <p className="text-sm text-[#e08a8a]">
                  {daysLeft !== null && daysLeft < 0
                    ? `Rok za plačilo je potekel pred ${Math.abs(daysLeft)} dnevi!`
                    : `Rok za plačilo čez ${daysLeft} dni!`}{' '}
                  Rok: {formatDateSl(quarterly.deadline)}
                </p>
              </div>
            )}

            <div className="grid gap-4 md:grid-cols-4">
              <StatBox label="CNAPS 14%" value={formatAr(quarterly.cnaps)} />
              <StatBox label="OMINO 7.5%" value={formatAr(quarterly.omino)} />
              <StatBox label="FMFP 1%" value={formatAr(quarterly.fmfp)} />
              <StatBox label="SKUPAJ" value={formatAr(quarterly.total)} accent />
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
              <div className="text-sm text-white/50">
                <p>
                  Vsota neto plač v Q{selectedQuarter}:{' '}
                  <span className="text-white">{formatAr(quarterly.sumOfBaseSalaries)}</span>
                </p>
                <p>
                  Rok plačila: <span className="text-white">{QUARTER_DEADLINE_LABEL[selectedQuarter]}</span>{' '}
                  ({formatDateSl(quarterly.deadline)})
                </p>
              </div>
              <div className="flex items-center gap-3">
                {quarterly.paid ? (
                  <span className="flex items-center gap-2 rounded-xl border border-[#6fc8a3]/30 bg-[#6fc8a3]/10 px-4 py-2 text-sm font-medium text-[#6fc8a3]">
                    <Check className="h-4 w-4" /> Plačano
                    {quarterly.paidAt && ` (${formatDateSl(quarterly.paidAt)})`}
                  </span>
                ) : (
                  <span className="rounded-xl border border-[#e08a8a]/30 bg-[#e08a8a]/10 px-4 py-2 text-sm font-medium text-[#e08a8a]">
                    Neplačano
                  </span>
                )}
                <button
                  onClick={() => handleTogglePaid(!quarterly.paid)}
                  className="rounded-xl border border-white/[0.06] bg-white/[0.04] px-4 py-2 text-sm font-medium text-white transition hover:bg-white/[0.08]"
                >
                  {quarterly.paid ? 'Označi kot neplačano' : 'Označi kot plačano'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ===== PRINT: Placilna lista (francosko, brez barv) ===== */}
      {printStaff && printPayslip && (
        <div className="payslip-print" aria-hidden="true">
          <div className="doc-page">
            <div className="doc-header">
              <img className="doc-logo" src="/images/komba-logo-color.png" alt="Komba Cabana" />
              <p className="doc-company">{getCompany(printStaff.company).name}</p>
              <p className="doc-location">{getCompany(printStaff.company).address}</p>
              <p className="doc-location">Nosy Komba, Madagascar</p>
            </div>
            <div className="doc-title-block">
              <h2 className="doc-title">BULLETIN DE PAIE</h2>
              <p className="doc-subtitle">Fiche de paie mensuelle</p>
            </div>
            <div className="doc-fields">
              {(() => {
                const fullName =
                  [printStaff.lastName, printStaff.firstName].filter(Boolean).join(' ').trim() ||
                  printStaff.name
                const dob = formatDateFr(printStaff.dateOfBirth)
                return (
                  <>
                    <p><span className="doc-label">Nom et prénom:</span> <strong>{fullName}</strong></p>
                    {dob && (
                      <p><span className="doc-label">Date de naissance:</span> <strong>{dob}</strong></p>
                    )}
                    {printStaff.placeOfBirth && (
                      <p><span className="doc-label">Lieu de naissance:</span> <strong>{printStaff.placeOfBirth}</strong></p>
                    )}
                    {printStaff.documentNumber && (
                      <p><span className="doc-label">N° pièce d&apos;identité:</span> <strong>{printStaff.documentNumber}</strong></p>
                    )}
                    <p><span className="doc-label">Mois:</span> <strong>{MONTHS_FR[month - 1]} {year}</strong></p>
                  </>
                )
              })()}
            </div>

            <table className="doc-table pay-table">
              <thead>
                <tr>
                  <th>Désignation</th>
                  <th className="pay-amount">Montant (Ar)</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>Salaire de base (net)</td><td className="pay-amount">{formatAr(printPayslip.baseSalary)}</td></tr>
                <tr><td>CNAPS salarié (1%)</td><td className="pay-amount">{formatAr(printPayslip.cnapsEmployee)}</td></tr>
                <tr><td>OMINO salarié (1%)</td><td className="pay-amount">{formatAr(printPayslip.ominoEmployee)}</td></tr>
                <tr><td>IRSA</td><td className="pay-amount">{formatAr(printPayslip.irsa)}</td></tr>
                <tr className="pay-subtotal"><td>Total des retenues</td><td className="pay-amount">{formatAr(printPayslip.totalDeductions)}</td></tr>
                <tr className="pay-total"><td>Salaire brut</td><td className="pay-amount">{formatAr(printPayslip.grossSalary)}</td></tr>
                <tr className="pay-total"><td>Salaire net à payer</td><td className="pay-amount">{formatAr(printPayslip.netSalary)}</td></tr>
              </tbody>
            </table>

            <div className="doc-signatures">
              <div>
                <p className="doc-sign-line">Signature de l&apos;employé</p>
              </div>
              <div>
                <p className="doc-sign-line">Signature de l&apos;employeur</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <style jsx global>{`
        .payslip-print { display: none; }

        @media print {
          @page { size: portrait; margin: 14mm; }
          body { background: #fff !important; }
          .no-print { display: none !important; }

          body.printing-payslip * { visibility: hidden; }
          body.printing-payslip .payslip-print,
          body.printing-payslip .payslip-print * { visibility: visible; }
          body.printing-payslip .payslip-print {
            display: block !important;
            position: absolute; left: 0; top: 0; width: 100%;
          }

          .payslip-print .doc-page { color: #111; font-family: Georgia, 'Times New Roman', serif; }
          .payslip-print .doc-header { text-align: center; border-bottom: 2px solid #111; padding-bottom: 8px; margin-bottom: 4px; }
          .payslip-print .doc-logo { display: block; margin: 0 auto; height: 56px; width: auto; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .payslip-print .doc-company { font-size: 14px; font-weight: 700; letter-spacing: 0.5px; margin: 6px 0 0; }
          .payslip-print .doc-location { font-size: 12px; font-style: italic; color: #333; margin: 2px 0 0; }
          .payslip-print .doc-title-block { text-align: center; border-bottom: 1px solid #111; padding-bottom: 10px; margin-bottom: 16px; }
          .payslip-print .doc-title { font-size: 20px; font-weight: 700; letter-spacing: 1px; margin: 12px 0 0; }
          .payslip-print .doc-subtitle { font-size: 12px; color: #777; margin: 3px 0 0; }
          .payslip-print .doc-fields { font-size: 13px; line-height: 1.8; margin-bottom: 16px; }
          .payslip-print .doc-fields p { margin: 0; }
          .payslip-print .doc-label { display: inline-block; min-width: 150px; }
          .payslip-print .doc-section-title { font-size: 13px; font-weight: 700; margin: 18px 0 6px; }
          .payslip-print .pay-table { width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 4px; }
          .payslip-print .pay-table th, .payslip-print .pay-table td { border: 1px solid #999; padding: 6px 10px; }
          .payslip-print .pay-table th { background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; font-size: 12px; text-align: left; }
          .payslip-print .pay-amount { text-align: right; white-space: nowrap; }
          .payslip-print .pay-subtotal td { font-weight: 600; background: #f6f6f6 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .payslip-print .pay-total td { font-weight: 700; background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .payslip-print .doc-signatures { display: flex; justify-content: space-between; margin-top: 48px; gap: 40px; }
          .payslip-print .doc-signatures > div { flex: 1; }
          .payslip-print .doc-sign-line { border-top: 1px solid #111; padding-top: 4px; font-size: 12px; text-align: center; }
        }
      `}</style>
    </div>
  )
}

function Row({
  label,
  value,
  muted,
  strong,
  accent,
}: {
  label: string
  value: string
  muted?: boolean
  strong?: boolean
  accent?: boolean
}) {
  return (
    <div className="flex items-center justify-between">
      <span className={`${muted ? 'text-white/40' : 'text-white/60'}`}>{label}</span>
      <span
        className={`tabular-nums ${
          accent ? 'text-[#6fc8a3]' : strong ? 'text-white' : 'text-white/80'
        } ${strong ? 'font-semibold' : ''}`}
      >
        {value}
      </span>
    </div>
  )
}

function StatBox({
  label,
  value,
  accent,
}: {
  label: string
  value: string
  accent?: boolean
}) {
  return (
    <div
      className={`rounded-xl border p-4 ${
        accent
          ? 'border-[#6fc8a3]/30 bg-[#6fc8a3]/10'
          : 'border-white/[0.06] bg-white/[0.02]'
      }`}
    >
      <p className="text-[11px] uppercase tracking-wider text-white/40">{label}</p>
      <p className={`mt-1 text-base font-bold ${accent ? 'text-[#6fc8a3]' : 'text-white'}`}>
        {value}
      </p>
    </div>
  )
}
