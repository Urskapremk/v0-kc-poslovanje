'use client'

import React, { useState } from 'react'
import useSWR from 'swr'
import { Calendar, Wand2, Printer, Sun, Sunset, Moon, FileText } from 'lucide-react'
import {
  getHousekeepingSchedule,
  generateHousekeepingSchedule,
  setHousekeepingShift,
} from '@/app/actions/housekeeping'
import { HOUSEKEEPERS, type Shift } from '@/lib/housekeeping'

const MONTHS = [
  'Januar', 'Februar', 'Marec', 'April', 'Maj', 'Junij',
  'Julij', 'Avgust', 'September', 'Oktober', 'November', 'December',
]

const DAY_NAMES = ['Ned', 'Pon', 'Tor', 'Sre', 'Čet', 'Pet', 'Sob']

// French labels for the printed sheets (housekeepers only read French)
const DAY_NAMES_FR = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam']
const MONTHS_FR = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre',
]

// Color per housekeeper for easy visual scanning
const STAFF_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  Eniki: { bg: 'bg-[#78b7ff]/15', text: 'text-[#78b7ff]', border: 'border-[#78b7ff]/30' },
  Felicia: { bg: 'bg-[#6fc8a3]/15', text: 'text-[#6fc8a3]', border: 'border-[#6fc8a3]/30' },
  Christaline: { bg: 'bg-[#f1d07a]/15', text: 'text-[#f1d07a]', border: 'border-[#f1d07a]/30' },
}

const SHIFT_LABEL: Record<Shift, string> = {
  MORNING: 'Dopoldan 6-12',
  AFTERNOON: 'Popoldan 12-18',
  OFF: 'Prosto',
}

export default function RazporedTab({ year, month }: { year: number; month: number }) {
  const [generating, setGenerating] = useState(false)
  const [selectedStaff, setSelectedStaff] = useState<string | null>(null)
  const { data: schedule, mutate, isLoading } = useSWR(
    ['housekeeping', year, month],
    () => getHousekeepingSchedule(year, month),
    { refreshInterval: 0 }
  )

  const lastDay = new Date(year, month, 0).getDate()
  const firstWeekday = new Date(year, month - 1, 1).getDay() // 0=Sun

  // Map: date -> { staffName -> shift }
  const byDate: Record<string, Record<string, Shift>> = {}
  for (const e of schedule || []) {
    if (!byDate[e.date]) byDate[e.date] = {}
    byDate[e.date][e.staffName] = e.shift
  }

  // Each shift (MORNING or AFTERNOON) is 6 hours. Count worked shifts and hours per housekeeper.
  const HOURS_PER_SHIFT = 6
  const stats: Record<string, { shifts: number; hours: number }> = {}
  for (const name of HOUSEKEEPERS) stats[name] = { shifts: 0, hours: 0 }
  for (const e of schedule || []) {
    if (e.shift === 'MORNING' || e.shift === 'AFTERNOON') {
      if (!stats[e.staffName]) stats[e.staffName] = { shifts: 0, hours: 0 }
      stats[e.staffName].shifts += 1
      stats[e.staffName].hours += HOURS_PER_SHIFT
    }
  }

  const handleGenerate = async () => {
    if (!confirm(`Ustvarim razpored za ${MONTHS[month - 1]} ${year}? To bo prepisalo obstoječi razpored tega meseca.`)) return
    setGenerating(true)
    await generateHousekeepingSchedule(year, month)
    await mutate()
    setGenerating(false)
  }

  const handleCellChange = async (date: string, staffName: string, shift: Shift) => {
    await setHousekeepingShift(date, staffName, shift)
    mutate()
  }

  // Print either the schedule calendar or the attendance sheets.
  const printDoc = (target: 'schedule' | 'attendance') => {
    document.body.classList.add(`printing-${target}`)
    window.print()
    setTimeout(() => document.body.classList.remove(`printing-${target}`), 100)
  }

  const dateStr = (d: number) =>
    `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`

  const hasSchedule = (schedule || []).length > 0

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-4 rounded-2xl bg-white/[0.03] border border-white/10">
        <div>
          <h2 className="text-lg font-bold text-[#f1d07a] flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Razpored sobaric
          </h2>
          <p className="text-white/40 text-sm">{MONTHS[month - 1]} {year} · Eniki, Felicia, Christaline</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerate}
            disabled={generating}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#6fc8a3]/20 text-[#6fc8a3] border border-[#6fc8a3]/30 hover:bg-[#6fc8a3]/30 transition-colors text-sm font-medium disabled:opacity-50"
          >
            <Wand2 className="h-4 w-4" />
            {generating ? 'Ustvarjam...' : hasSchedule ? 'Ponovno ustvari' : 'Ustvari razpored'}
          </button>
          {hasSchedule && (
            <button
              onClick={() => printDoc('schedule')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#78b7ff]/20 text-[#78b7ff] border border-[#78b7ff]/30 hover:bg-[#78b7ff]/30 transition-colors text-sm font-medium"
            >
              <Printer className="h-4 w-4" />
              Natisni razpored
            </button>
          )}
          <button
            onClick={() => printDoc('attendance')}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#f1d07a]/20 text-[#f1d07a] border border-[#f1d07a]/30 hover:bg-[#f1d07a]/30 transition-colors text-sm font-medium"
          >
            <FileText className="h-4 w-4" />
            Natisni evidenco prisotnosti
          </button>
        </div>
      </div>

      {/* Legend (click a name to show only that housekeeper) */}
      <div className="no-print flex flex-wrap items-center gap-3 text-xs">
        {HOUSEKEEPERS.map((name) => {
          const active = selectedStaff === name
          return (
            <button
              key={name}
              type="button"
              onClick={() => setSelectedStaff(active ? null : name)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all ${STAFF_COLORS[name].bg} ${STAFF_COLORS[name].border} ${active ? 'ring-2 ring-offset-1 ring-offset-[#0d1420] ' + STAFF_COLORS[name].text.replace('text-', 'ring-') : 'opacity-100'} ${selectedStaff && !active ? 'opacity-40' : ''}`}
            >
              <span className={`h-2.5 w-2.5 rounded-full ${STAFF_COLORS[name].text}`} style={{ backgroundColor: 'currentColor' }} />
              <span className={STAFF_COLORS[name].text}>{name}</span>
            </button>
          )
        })}
        {selectedStaff && (
          <button
            type="button"
            onClick={() => setSelectedStaff(null)}
            className="px-3 py-1.5 rounded-lg border border-white/15 text-white/50 hover:text-white hover:bg-white/5 transition-colors"
          >
            Pokaži vse
          </button>
        )}
        <div className="flex items-center gap-1 text-white/40"><Sun className="h-3.5 w-3.5" /> Dopoldan 6-12</div>
        <div className="flex items-center gap-1 text-white/40"><Sunset className="h-3.5 w-3.5" /> Popoldan 12-18</div>
        <div className="flex items-center gap-1 text-white/40"><Moon className="h-3.5 w-3.5" /> Prosto</div>
      </div>

      {isLoading ? (
        <div className="p-8 text-center text-white/40">Nalagam razpored...</div>
      ) : !hasSchedule ? (
        <div className="p-8 text-center text-white/40 rounded-2xl bg-white/[0.03] border border-white/10">
          Za ta mesec še ni razporeda. Kliknite &quot;Ustvari razpored&quot;.
        </div>
      ) : (
        <>
          {/* Hours summary per housekeeper (each shift = 6h) */}
          <div className="no-print grid grid-cols-1 sm:grid-cols-3 gap-3">
            {HOUSEKEEPERS.map((name) => {
              const c = STAFF_COLORS[name]
              const s = stats[name] || { shifts: 0, hours: 0 }
              return (
                <div key={name} className={`rounded-2xl border p-4 ${c.bg} ${c.border}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`h-2.5 w-2.5 rounded-full ${c.text}`} style={{ backgroundColor: 'currentColor' }} />
                    <span className={`font-semibold ${c.text}`}>{name}</span>
                  </div>
                  <div className={`text-2xl font-bold ${c.text}`}>{s.hours} <span className="text-sm font-medium opacity-70">ur</span></div>
                  <div className="text-xs text-white/40 mt-1">{s.shifts} izmen × 6 ur</div>
                </div>
              )
            })}
          </div>

          <div className="no-print print-area rounded-2xl bg-white/[0.03] border border-white/10 p-3 sm:p-4 overflow-x-auto">
          <h3 className="print-title hidden text-center text-lg font-bold mb-4">
            Razpored sobaric — {MONTHS[month - 1]} {year}
          </h3>
          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-1.5 min-w-[700px]">
            {DAY_NAMES.map((d) => (
              <div key={d} className="text-center text-[11px] font-semibold uppercase tracking-wider text-white/40 py-1">
                {d}
              </div>
            ))}
            {/* leading blanks */}
            {Array.from({ length: firstWeekday }).map((_, i) => (
              <div key={`blank-${i}`} />
            ))}
            {Array.from({ length: lastDay }).map((_, i) => {
              const day = i + 1
              const ds = dateStr(day)
              const shifts = byDate[ds] || {}
              return (
                <div key={ds} className="day-cell rounded-xl border border-white/10 bg-white/[0.02] p-2 min-h-[120px] flex flex-col gap-1">
                  <div className="text-xs font-semibold text-white/60 mb-1">{day}</div>
                  {HOUSEKEEPERS.filter((name) => !selectedStaff || name === selectedStaff).map((name) => {
                    const shift = shifts[name] || 'OFF'
                    const c = STAFF_COLORS[name]
                    return (
                      <select
                        key={name}
                        value={shift}
                        onChange={(e) => handleCellChange(ds, name, e.target.value as Shift)}
                        className={`shift-select w-full text-[11px] rounded-md px-1.5 py-1 border cursor-pointer ${c.bg} ${c.text} ${c.border} ${shift === 'OFF' ? 'opacity-40' : ''}`}
                      >
                        <option value="MORNING" className="bg-[#0d1420] text-white">{name}: Dop 6-12</option>
                        <option value="AFTERNOON" className="bg-[#0d1420] text-white">{name}: Pop 12-18</option>
                        <option value="OFF" className="bg-[#0d1420] text-white">{name}: Prosto</option>
                      </select>
                    )
                  })}
                </div>
              )
            })}
          </div>
        </div>
        </>
      )}

      {/* Schedule print sheet — clean table, one row per day. Hidden on screen, shown only when printing schedule. */}
      <div className="schedule-print" aria-hidden="true">
        <div className="doc-page">
          <div className="doc-header">
            <img className="doc-logo" src="/images/komba-logo-color.png" alt="Komba Cabana" />
            <p className="doc-location">Nosy Komba, Madagascar</p>
          </div>
          <div className="doc-title-block">
            <h2 className="doc-title">PLANNING DE MÉNAGE {year}</h2>
            <p className="doc-subtitle">Femmes de chambre</p>
          </div>
          <div className="doc-fields">
            {selectedStaff && (
              <p><span className="doc-label">Nom:</span> <strong>{selectedStaff}</strong></p>
            )}
            <p><span className="doc-label">Mois:</span> <strong>{MONTHS_FR[month - 1]} {year}</strong></p>
          </div>
          <table className="doc-table sched-table">
            <thead>
              <tr>
                <th className="sched-col-day">Jour</th>
                <th className="sched-col-date">Date</th>
                {HOUSEKEEPERS.filter((name) => !selectedStaff || name === selectedStaff).map((name) => (
                  <th key={name}>{name}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: lastDay }).map((_, i) => {
                const day = i + 1
                const ds = dateStr(day)
                const shifts = byDate[ds] || {}
                const weekday = new Date(year, month - 1, day).getDay()
                return (
                  <tr key={day}>
                    <td className="sched-col-day">{DAY_NAMES_FR[weekday]}</td>
                    <td className="sched-col-date">{day} {MONTHS_FR[month - 1].slice(0, 4).toLowerCase()}.</td>
                    {HOUSEKEEPERS.filter((name) => !selectedStaff || name === selectedStaff).map((name) => {
                      const shift = (shifts[name] || 'OFF') as Shift
                      return (
                        <td key={name} className="sched-shift">
                          {shift === 'MORNING' ? 'Matin 6h-12h' : shift === 'AFTERNOON' ? 'Après-midi 12h-18h' : '—'}
                        </td>
                      )
                    })}
                  </tr>
                )
              })}
            </tbody>
            <tfoot>
              <tr className="sched-total-row">
                <td colSpan={2} className="sched-total-label">Total heures</td>
                {HOUSEKEEPERS.filter((name) => !selectedStaff || name === selectedStaff).map((name) => (
                  <td key={name} className="sched-total-val">{(stats[name]?.hours ?? 0)} h</td>
                ))}
              </tr>
            </tfoot>
          </table>
          <div className="doc-legend">
            <span><strong>Matin</strong> 6h-12h</span>
            <span><strong>Après-midi</strong> 12h-18h</span>
            <span><strong>—</strong> Repos</span>
          </div>
        </div>
      </div>

      {/* Attendance sheets — one full page per housekeeper. Hidden on screen, shown only when printing attendance. */}
      <div className="attendance-print" aria-hidden="true">
        {HOUSEKEEPERS.filter((name) => !selectedStaff || name === selectedStaff).map((name) => (
          <div key={name} className="attendance-page doc-page">
            <div className="doc-header">
              <img className="doc-logo" src="/images/komba-logo-color.png" alt="Komba Cabana" />
              <p className="doc-location">Nosy Komba, Madagascar</p>
            </div>
            <div className="doc-title-block">
              <h2 className="doc-title">REGISTRE DE PRÉSENCE {year}</h2>
              <p className="doc-subtitle">Femme de chambre</p>
            </div>
            <div className="doc-fields">
              <p><span className="doc-label">Nom:</span> <strong>{name}</strong></p>
              <p><span className="doc-label">Poste:</span> <strong>Femme de chambre</strong></p>
              <p><span className="doc-label">Mois:</span> <strong>{MONTHS_FR[month - 1]} {year}</strong></p>
            </div>
            <table className="doc-table att-table">
              <thead>
                <tr>
                  <th className="att-col-day">Jour</th>
                  <th className="att-col-date">Date</th>
                  <th className="att-col-time">Arrivée</th>
                  <th className="att-col-time">Départ</th>
                  <th className="att-col-sign">Signature</th>
                </tr>
              </thead>
              <tbody>
                {Array.from({ length: lastDay }).map((_, i) => {
                  const day = i + 1
                  const weekday = new Date(year, month - 1, day).getDay()
                  return (
                    <tr key={day}>
                      <td className="att-col-day">{DAY_NAMES_FR[weekday]}</td>
                      <td className="att-col-date">{day} {MONTHS_FR[month - 1].slice(0, 4).toLowerCase()}.</td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
            <div className="doc-legend">
              <span>Total heures prévues: <strong>{stats[name]?.hours ?? 0} h</strong> ({stats[name]?.shifts ?? 0} services × 6 h)</span>
              <span>Signature du responsable: ______________________</span>
            </div>
            <p className="doc-note">Par ma signature, je confirme ma présence au travail pour les jours indiqués.</p>
          </div>
        ))}
      </div>

      <style jsx global>{`
        /* Print-only sheets are hidden on screen */
        .attendance-print { display: none; }
        .schedule-print { display: none; }

        @media print {
          @page { size: portrait; margin: 12mm; }
          body { background: #fff !important; }
          .no-print { display: none !important; }

          /* ===== Shared document style (matches Salary Receipt) ===== */
          .doc-page { color: #111; font-family: Georgia, 'Times New Roman', serif; }
          .doc-header { text-align: center; border-bottom: 2px solid #111; padding-bottom: 8px; margin-bottom: 4px; }
          .doc-logo { display: block; margin: 0 auto; height: 56px; width: auto; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .doc-brand { font-size: 24px; font-weight: 700; letter-spacing: 1px; margin: 0; }
          .doc-location { font-size: 12px; font-style: italic; color: #333; margin: 2px 0 0; }
          .doc-title-block { text-align: center; border-bottom: 1px solid #111; padding-bottom: 10px; margin-bottom: 14px; }
          .doc-title { font-size: 18px; font-weight: 700; letter-spacing: 1px; margin: 12px 0 0; }
          .doc-subtitle { font-size: 12px; color: #777; margin: 3px 0 0; }
          .doc-fields { font-size: 13px; line-height: 1.7; margin-bottom: 14px; }
          .doc-fields p { margin: 0; }
          .doc-label { display: inline-block; min-width: 170px; }
          .doc-table { width: 100%; border-collapse: collapse; font-size: 12px; }
          .doc-table th, .doc-table td { border: 1px solid #999; padding: 4px 8px; height: 22px; }
          .doc-table th { background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; font-size: 11px; }
          .doc-legend { display: flex; justify-content: space-between; flex-wrap: wrap; gap: 16px; font-size: 12px; margin-top: 12px; }
          .doc-note { font-size: 11px; color: #333; margin: 2px 0 0; }

          /* ===== Printing the schedule ===== */
          body.printing-schedule * { visibility: hidden; }
          body.printing-schedule .schedule-print,
          body.printing-schedule .schedule-print * { visibility: visible; }
          body.printing-schedule .schedule-print {
            display: flex !important; flex-direction: column;
            position: absolute; left: 0; top: 0; width: 100%;
            height: 248mm; box-sizing: border-box; overflow: hidden;
          }
          .schedule-print .doc-page { display: flex; flex-direction: column; flex: 1 1 auto; height: 100%; min-height: 0; }
          .sched-table th, .sched-table td { text-align: center; vertical-align: middle; }
          .sched-table { font-size: 11px; flex: 1 1 auto; height: 100%; }
          .sched-table th { font-size: 10px; }
          .sched-table td, .sched-table th { padding: 2px 5px; line-height: 1.2; }
          .schedule-print .doc-header { padding-bottom: 6px; margin-bottom: 4px; flex: 0 0 auto; }
          .schedule-print .doc-logo { height: 48px; }
          .schedule-print .doc-title-block { margin-bottom: 6px; padding-bottom: 6px; flex: 0 0 auto; }
          .schedule-print .doc-title { font-size: 17px; margin: 6px 0 0; }
          .schedule-print .doc-fields { margin-bottom: 6px; line-height: 1.4; font-size: 13px; flex: 0 0 auto; }
          .schedule-print .doc-legend { margin-top: 8px; font-size: 11px; flex: 0 0 auto; }
          .sched-col-day { width: 9%; }
          .sched-col-date { width: 15%; text-align: left !important; }
          .sched-off { color: #aaa; }
          .sched-total-row td { font-weight: 700; background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .sched-total-label { text-align: right !important; }
          .sched-total-val { text-align: center; }

          /* ===== Printing the attendance sheets ===== */
          body.printing-attendance * { visibility: hidden; }
          body.printing-attendance .attendance-print,
          body.printing-attendance .attendance-print * { visibility: visible; }
          body.printing-attendance .attendance-print {
            display: block !important;
            position: absolute; left: 0; top: 0; width: 100%;
          }
          .attendance-page {
            page-break-after: always;
            break-after: page;
            height: 248mm; box-sizing: border-box;
            display: flex; flex-direction: column; overflow: hidden;
          }
          .attendance-page:last-child { page-break-after: auto; break-after: auto; }
          .att-table th, .att-table td { text-align: left; vertical-align: middle; }
          .att-table { font-size: 11px; flex: 1 1 auto; }
          .att-table th { font-size: 10px; }
          .att-table td, .att-table th { padding: 0 8px; line-height: 1.25; }
          .attendance-page .doc-header { flex: 0 0 auto; }
          .attendance-page .doc-title-block { margin-bottom: 5px; flex: 0 0 auto; }
          .attendance-page .doc-fields { margin-bottom: 5px; line-height: 1.4; flex: 0 0 auto; }
          .attendance-page .doc-legend { margin-top: 6px; flex: 0 0 auto; }
          .attendance-page .doc-note { flex: 0 0 auto; }
          .att-col-day { width: 9%; text-align: center; }
          .att-col-date { width: 15%; }
          .att-col-time { width: 18%; }
          .att-col-sign { width: 40%; }
        }
      `}</style>
    </div>
  )
}
