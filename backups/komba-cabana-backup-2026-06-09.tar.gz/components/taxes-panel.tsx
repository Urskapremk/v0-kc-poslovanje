"use client";

import React from "react";
import useSWR from "swr";
import { Landmark, Printer, ChevronLeft, ChevronRight } from "lucide-react";
import { getTaxesForMonth, type MonthlyTaxes } from "@/app/actions/komba";

const ar = (value: unknown) => `${Math.round(Number(value) || 0).toLocaleString("fr-FR")} Ar`;

const MONTH_NAMES = [
  "Januar", "Februar", "Marec", "April", "Maj", "Junij",
  "Julij", "Avgust", "September", "Oktober", "November", "December",
];

export function TaxesPanel() {
  // Default to previous month (taxes are paid by the 5th for the previous month)
  const now = new Date();
  const initial = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const [year, setYear] = React.useState(initial.getFullYear());
  const [month, setMonth] = React.useState(initial.getMonth() + 1); // 1-12

  const { data, isLoading } = useSWR<MonthlyTaxes>(
    ["taxes", year, month],
    () => getTaxesForMonth(year, month),
    { revalidateOnFocus: false }
  );

  const goPrev = () => {
    const d = new Date(year, month - 2, 1);
    setYear(d.getFullYear());
    setMonth(d.getMonth() + 1);
  };
  const goNext = () => {
    const d = new Date(year, month, 1);
    setYear(d.getFullYear());
    setMonth(d.getMonth() + 1);
  };

  const monthLabel = `${MONTH_NAMES[month - 1]} ${year}`;
  // Deadline: 5th of the following month
  const deadline = new Date(year, month, 5);
  const deadlineLabel = deadline.toLocaleDateString("sl-SI", { day: "numeric", month: "long", year: "numeric" });

  const handlePrint = () => {
    if (!data) return;
    const rows = data.lineItems
      .map(
        (i) => `
        <tr>
          <td>${escapeHtml(i.bungalow)}</td>
          <td>${escapeHtml(i.guestName)}</td>
          <td style="text-align:center">${i.pax}</td>
          <td style="text-align:center">${i.nights}</td>
          <td style="text-align:center">${i.arrival} → ${i.departure}</td>
          <td style="text-align:right">${ar(i.communalTax)}</td>
          <td style="text-align:right">${ar(i.touristTax)}</td>
          <td style="text-align:right;font-weight:600">${ar(i.total)}</td>
        </tr>`
      )
      .join("");

    const html = `
<!DOCTYPE html>
<html lang="sl">
<head>
<meta charset="utf-8" />
<title>Takse - ${monthLabel}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #1a1a1a; margin: 40px; }
  h1 { font-size: 22px; margin: 0 0 4px; }
  .sub { color: #555; font-size: 13px; margin-bottom: 2px; }
  .deadline { color: #b91c1c; font-size: 13px; font-weight: 600; margin: 8px 0 20px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th, td { border: 1px solid #ccc; padding: 6px 8px; }
  th { background: #f3f4f6; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; }
  tfoot td { font-weight: 700; background: #fafafa; }
  .totals { margin-top: 24px; display: flex; gap: 40px; }
  .totals .box { border: 1px solid #ccc; border-radius: 8px; padding: 12px 16px; }
  .totals .label { font-size: 11px; text-transform: uppercase; color: #666; letter-spacing: 0.04em; }
  .totals .val { font-size: 18px; font-weight: 700; margin-top: 4px; }
  .grand { font-size: 22px !important; color: #be185d; }
  .meta { margin-top: 8px; font-size: 11px; color: #777; }
</style>
</head>
<body>
  <h1>Komba Cabana — Obračun taks</h1>
  <div class="sub">Obdobje: <strong>${monthLabel}</strong></div>
  <div class="sub">Občinska taksa: 2.000 Ar / osebo / noč &nbsp;·&nbsp; Turistična taksa: 1.000 Ar / bungalov / noč</div>
  <div class="deadline">Rok za plačilo: do ${escapeHtml(deadlineLabel)}</div>
  <table>
    <thead>
      <tr>
        <th>Bungalov</th><th>Gost</th><th>Osebe</th><th>Noči</th><th>Obdobje</th>
        <th style="text-align:right">Občinska</th><th style="text-align:right">Turistična</th><th style="text-align:right">Skupaj</th>
      </tr>
    </thead>
    <tbody>${rows || `<tr><td colspan="8" style="text-align:center;color:#999">Ni podatkov za to obdobje</td></tr>`}</tbody>
    <tfoot>
      <tr>
        <td colspan="5" style="text-align:right">SKUPAJ</td>
        <td style="text-align:right">${ar(data.communalTotal)}</td>
        <td style="text-align:right">${ar(data.touristTotal)}</td>
        <td style="text-align:right">${ar(data.grandTotal)}</td>
      </tr>
    </tfoot>
  </table>
  <div class="totals">
    <div class="box"><div class="label">Občinska taksa</div><div class="val">${ar(data.communalTotal)}</div></div>
    <div class="box"><div class="label">Turistična taksa</div><div class="val">${ar(data.touristTotal)}</div></div>
    <div class="box"><div class="label">Skupaj za plačilo</div><div class="val grand">${ar(data.grandTotal)}</div></div>
  </div>
  <div class="meta">Natisnjeno: ${new Date().toLocaleString("sl-SI")}</div>
  <script>window.onload = function(){ window.print(); }</script>
</body>
</html>`;

    const w = window.open("", "_blank");
    if (w) {
      w.document.write(html);
      w.document.close();
    }
  };

  return (
    <div className="mt-4 rounded-2xl border border-[#f9a8d4]/25 bg-[#1a0f17]/90 backdrop-blur-xl p-5">
      {/* Header row */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-[#f9a8d4] flex items-center gap-2">
          <Landmark className="h-4 w-4" />
          Takse — {monthLabel}
        </h4>
        <div className="flex items-center gap-2">
          {/* Month navigation */}
          <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-white/[0.03] p-1">
            <button
              onClick={goPrev}
              className="rounded-md p-1.5 text-white/60 hover:bg-white/10 hover:text-white transition-colors"
              aria-label="Prejšnji mesec"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="px-2 text-xs font-medium text-white/80 min-w-[90px] text-center">{monthLabel}</span>
            <button
              onClick={goNext}
              className="rounded-md p-1.5 text-white/60 hover:bg-white/10 hover:text-white transition-colors"
              aria-label="Naslednji mesec"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
          <button
            onClick={handlePrint}
            disabled={!data || data.lineItems.length === 0}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#f9a8d4]/30 bg-[#f9a8d4]/10 px-3 py-2 text-xs font-medium text-[#f9a8d4] hover:bg-[#f9a8d4]/20 transition-colors disabled:opacity-40"
          >
            <Printer className="h-3.5 w-3.5" /> Natisni
          </button>
        </div>
      </div>

      {/* Deadline notice */}
      <p className="mb-4 text-[11px] text-white/40">
        Rok za plačilo: <span className="text-[#f9a8d4]/80 font-medium">do {deadlineLabel}</span>
        <span className="mx-2 text-white/20">·</span>
        Občinska 2.000 Ar/os/noč · Turistična 1.000 Ar/bungalov/noč
      </p>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
          <div className="text-[10px] uppercase tracking-wider text-white/40">Občinska</div>
          <div className="mt-1 text-sm font-semibold text-white">{ar(data?.communalTotal || 0)}</div>
        </div>
        <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
          <div className="text-[10px] uppercase tracking-wider text-white/40">Turistična</div>
          <div className="mt-1 text-sm font-semibold text-white">{ar(data?.touristTotal || 0)}</div>
        </div>
        <div className="rounded-xl border border-[#f9a8d4]/25 bg-[#f9a8d4]/[0.06] p-3">
          <div className="text-[10px] uppercase tracking-wider text-[#f9a8d4]/70">Skupaj</div>
          <div className="mt-1 text-base font-bold text-[#f9a8d4]">{ar(data?.grandTotal || 0)}</div>
        </div>
      </div>

      {/* Line items table */}
      {isLoading ? (
        <p className="py-6 text-center text-sm text-white/40">Nalaganje…</p>
      ) : !data || data.lineItems.length === 0 ? (
        <p className="py-6 text-center text-sm text-white/40">Ni gostov z nočitvami v tem mesecu.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wider text-white/40">
                <th className="pb-2 pr-3 font-medium">Bungalov</th>
                <th className="pb-2 pr-3 font-medium">Gost</th>
                <th className="pb-2 px-2 font-medium text-center">Os.</th>
                <th className="pb-2 px-2 font-medium text-center">Noči</th>
                <th className="pb-2 px-3 font-medium text-right">Občinska</th>
                <th className="pb-2 px-3 font-medium text-right">Turistična</th>
                <th className="pb-2 pl-3 font-medium text-right">Skupaj</th>
              </tr>
            </thead>
            <tbody>
              {data.lineItems.map((i) => (
                <tr key={i.reservationId} className="border-t border-white/[0.06]">
                  <td className="py-2 pr-3 text-white/80">{i.bungalow}</td>
                  <td className="py-2 pr-3 text-white/60">{i.guestName}</td>
                  <td className="py-2 px-2 text-center text-white/60">{i.pax}</td>
                  <td className="py-2 px-2 text-center text-white/60">{i.nights}</td>
                  <td className="py-2 px-3 text-right text-white/70">{ar(i.communalTax)}</td>
                  <td className="py-2 px-3 text-right text-white/70">{ar(i.touristTax)}</td>
                  <td className="py-2 pl-3 text-right font-medium text-white">{ar(i.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function escapeHtml(str: string): string {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
