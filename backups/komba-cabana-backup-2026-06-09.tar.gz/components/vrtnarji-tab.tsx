'use client'

import { useMemo, useState } from 'react'
import { Calendar, Printer, Info, FileText } from 'lucide-react'
import {
  GARDENERS,
  POST_LABELS,
  POST_LABELS_FR,
  generateGardenerSchedule,
  computeGardenerStats,
  type GardenPost,
} from '@/lib/gardening'

const MONTHS = [
  'Januar', 'Februar', 'Marec', 'April', 'Maj', 'Junij',
  'Julij', 'Avgust', 'September', 'Oktober', 'November', 'December',
]
const MONTHS_FR = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre',
]
const DAY_NAMES = ['Ned', 'Pon', 'Tor', 'Sre', 'Čet', 'Pet', 'Sob']
const DAY_NAMES_FR = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam']

export default function VrtnarjiTab({ year, month }: { year: number; month: number }) {
  const [selected, setSelected] = useState<string | null>(null)

  const schedule = useMemo(() => generateGardenerSchedule(year, month), [year, month])
  const stats = useMemo(() => computeGardenerStats(schedule), [schedule])
  const lastDay = schedule.length

  const visibleGardeners = GARDENERS.filter((g) => !selected || g === selected)

  function printDoc(target: 'gardeners' | 'gardeners-attendance') {
    document.body.classList.add(`printing-${target}`)
    window.print()
    setTimeout(() => document.body.classList.remove(`printing-${target}`), 500)
  }

  return (
    <div className="space-y-4">
      <style>{`
        @media print {
          @page { size: portrait; margin: 12mm; }
          /* Hide the on-screen UI completely (display:none so it takes no space) */
          body.printing-gardeners .no-print,
          body.printing-gardeners .gardeners-screen,
          body.printing-gardeners-attendance .no-print,
          body.printing-gardeners-attendance .gardeners-screen { display: none !important; }
          body.printing-gardeners * { visibility: hidden; }
          body.printing-gardeners .gardeners-print,
          body.printing-gardeners .gardeners-print * { visibility: visible; }
          body.printing-gardeners .gardeners-print {
            display: flex !important; flex-direction: column;
            position: absolute; left: 0; top: 0; width: 100%;
            height: 248mm; box-sizing: border-box; overflow: hidden;
          }
          .gardeners-print .doc-header { text-align: center; border-bottom: 2px solid #111; padding-bottom: 6px; margin-bottom: 4px; flex: 0 0 auto; }
          .gardeners-print .doc-logo { display: block; margin: 0 auto; height: 48px; width: auto; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .gardeners-print .doc-brand { font-size: 24px; font-weight: 700; letter-spacing: 1px; margin: 0; }
          .gardeners-print .doc-location { font-size: 12px; font-style: italic; color: #333; margin: 2px 0 0; }
          .gardeners-print .doc-title-block { text-align: center; border-bottom: 1px solid #111; padding-bottom: 6px; margin-bottom: 6px; flex: 0 0 auto; }
          .gardeners-print .doc-title { font-size: 17px; font-weight: 700; letter-spacing: 1px; margin: 6px 0 0; }
          .gardeners-print .doc-subtitle { font-size: 12px; color: #777; margin: 2px 0 0; }
          .gardeners-print .doc-fields { font-size: 13px; line-height: 1.4; margin-bottom: 6px; flex: 0 0 auto; }
          .gardeners-print .doc-fields p { margin: 0; }
          .gardeners-print table { width: 100%; border-collapse: collapse; font-size: 11px; color: #111; font-family: Georgia, 'Times New Roman', serif; flex: 1 1 auto; height: 100%; }
          .gardeners-print th, .gardeners-print td { border: 1px solid #999; padding: 2px 5px; line-height: 1.2; text-align: center; vertical-align: middle; }
          .gardeners-print th { background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; font-size: 10px; }
          .gardeners-print .g-day { text-align: left; }
          .gardeners-print .g-total td { font-weight: 700; background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .gardeners-print .doc-legend { font-size: 11px; margin-top: 8px; flex: 0 0 auto; }

          /* ===== Attendance sheets (one page per gardener) ===== */
          body.printing-gardeners-attendance * { visibility: hidden; }
          body.printing-gardeners-attendance .gardeners-att-print,
          body.printing-gardeners-attendance .gardeners-att-print * { visibility: visible; }
          body.printing-gardeners-attendance .gardeners-att-print {
            display: block !important;
            position: absolute; left: 0; top: 0; width: 100%;
          }
          .gardeners-att-print .att-page { page-break-after: always; break-after: page; color: #111; font-family: Georgia, 'Times New Roman', serif; height: 248mm; box-sizing: border-box; display: flex; flex-direction: column; overflow: hidden; }
          .gardeners-att-print .att-page:last-child { page-break-after: auto; break-after: auto; }
          .gardeners-att-print .doc-header { text-align: center; border-bottom: 2px solid #111; padding-bottom: 4px; margin-bottom: 4px; flex: 0 0 auto; }
          .gardeners-att-print .doc-logo { display: block; margin: 0 auto; height: 40px; width: auto; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .gardeners-att-print .doc-brand { font-size: 22px; font-weight: 700; letter-spacing: 1px; margin: 0; }
          .gardeners-att-print .doc-location { font-size: 11px; font-style: italic; color: #333; margin: 1px 0 0; }
          .gardeners-att-print .doc-title-block { text-align: center; border-bottom: 1px solid #111; padding-bottom: 4px; margin-bottom: 5px; flex: 0 0 auto; }
          .gardeners-att-print .doc-title { font-size: 16px; font-weight: 700; letter-spacing: 1px; margin: 4px 0 0; }
          .gardeners-att-print .doc-subtitle { font-size: 11px; color: #777; margin: 2px 0 0; }
          .gardeners-att-print .doc-fields { font-size: 12px; line-height: 1.4; margin-bottom: 5px; flex: 0 0 auto; }
          .gardeners-att-print .doc-fields p { margin: 0; }
          .gardeners-att-print .doc-label { display: inline-block; min-width: 150px; }
          .gardeners-att-print table { width: 100%; border-collapse: collapse; font-size: 11px; color: #111; flex: 1 1 auto; }
          .gardeners-att-print th, .gardeners-att-print td { border: 1px solid #999; padding: 0 8px; line-height: 1.25; text-align: center; vertical-align: middle; }
          .gardeners-att-print th { background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; font-size: 10px; }
          .gardeners-att-print .att-col-day, .gardeners-att-print .att-col-date { text-align: left; }
          .gardeners-att-print .doc-legend { display: flex; justify-content: space-between; flex-wrap: wrap; gap: 12px; font-size: 11px; margin-top: 6px; flex: 0 0 auto; }
          .gardeners-att-print .doc-note { font-size: 10px; color: #333; margin: 3px 0 0; flex: 0 0 auto; }
        }
      `}</style>

      {/* Header */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#6fc8a3] flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Razpored vrtnarjev
          </h2>
          <p className="text-white/40 text-sm">{MONTHS[month - 1]} {year} · {GARDENERS.join(', ')}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => printDoc('gardeners')}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#78b7ff]/20 text-[#78b7ff] border border-[#78b7ff]/30 hover:bg-[#78b7ff]/30 transition-colors text-sm font-medium"
          >
            <Printer className="h-4 w-4" />
            Natisni razpored (FR)
          </button>
          <button
            onClick={() => printDoc('gardeners-attendance')}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#f1d07a]/20 text-[#f1d07a] border border-[#f1d07a]/30 hover:bg-[#f1d07a]/30 transition-colors text-sm font-medium"
          >
            <FileText className="h-4 w-4" />
            Natisni evidenco prisotnosti (FR)
          </button>
        </div>
      </div>

      {/* Draft notice */}
      <div className="no-print flex items-start gap-2 rounded-xl border border-[#f1d07a]/30 bg-[#f1d07a]/10 px-3 py-2 text-xs text-[#f1d07a]">
        <Info className="h-4 w-4 shrink-0 mt-0.5" />
        <span>
          Osnutek: razpored se samodejno izračuna po pravilih (6 dni delo / 1 prost, tedenska rotacija mest, Mario pokriva prostega kot rezerva).
          Še se ne shranjuje in ni urejljiv — ko potrdiš logiko, dodava shranjevanje in ročno urejanje kot pri sobaricah.
        </span>
      </div>

      {/* Legend / filter */}
      <div className="no-print flex flex-wrap items-center gap-2 text-xs">
        {GARDENERS.map((g) => {
          const active = selected === g
          return (
            <button
              key={g}
              type="button"
              onClick={() => setSelected(active ? null : g)}
              className={`px-3 py-1.5 rounded-lg border transition-all ${
                active
                  ? 'bg-[#6fc8a3]/20 text-[#6fc8a3] border-[#6fc8a3]/40'
                  : 'bg-white/5 text-white/60 border-white/10 hover:bg-white/10'
              } ${selected && !active ? 'opacity-40' : ''}`}
            >
              {g}
            </button>
          )
        })}
        {selected && (
          <button
            type="button"
            onClick={() => setSelected(null)}
            className="px-3 py-1.5 rounded-lg border border-white/15 text-white/50 hover:text-white hover:bg-white/5 transition-colors"
          >
            Pokaži vse
          </button>
        )}
      </div>

      {/* Hours summary */}
      <div className="no-print grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {GARDENERS.map((g) => {
          const s = stats[g]
          return (
            <div key={g} className="rounded-2xl border border-[#6fc8a3]/20 bg-[#6fc8a3]/5 p-4">
              <div className="font-semibold text-[#6fc8a3] mb-1">{g}</div>
              <div className="text-2xl font-bold text-[#6fc8a3]">{s.hours} <span className="text-sm font-medium opacity-70">ur</span></div>
              <div className="text-xs text-white/40 mt-1">{s.shifts} izmen × 6 ur</div>
              {s.reserve > 0 && <div className="text-[11px] text-white/30 mt-0.5">+ {s.reserve} dni rezerva</div>}
            </div>
          )
        })}
      </div>

      {/* On-screen schedule table */}
      <div className="no-print rounded-2xl bg-white/[0.03] border border-white/10 p-3 sm:p-4 overflow-x-auto">
        <div className="no-print flex flex-wrap items-center gap-4 mb-3 text-xs text-white/50">
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-3 w-3 rounded-sm bg-[#78b7ff]/40 border border-[#78b7ff]/60" />
            Plaža
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-3 w-3 rounded-sm bg-[#6fc8a3]/40 border border-[#6fc8a3]/60" />
            Vrt
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-3 w-3 rounded-sm bg-white/10 border border-white/20" />
            Rezerva
          </span>
        </div>
        <table className="w-full min-w-[640px] border-collapse text-sm">
          <thead>
            <tr className="text-white/40 text-xs uppercase tracking-wider">
              <th className="text-left py-2 px-2 font-semibold">Dan</th>
              <th className="text-left py-2 px-2 font-semibold">Datum</th>
              {visibleGardeners.map((g) => (
                <th key={g} className="text-left py-2 px-2 font-semibold">{g}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {schedule.map((day, i) => {
              const dayNum = i + 1
              const weekday = new Date(year, month - 1, dayNum).getDay()
              return (
                <tr key={day.date} className="border-t border-white/5">
                  <td className="py-1.5 px-2 text-white/50">{DAY_NAMES[weekday]}</td>
                  <td className="py-1.5 px-2 text-white/70">{dayNum}. {MONTHS[month - 1].slice(0, 3).toLowerCase()}</td>
                  {visibleGardeners.map((g) => {
                    const post = (day.assignments[g] || 'OFF') as GardenPost
                    const isOff = post === 'OFF'
                    const isReserve = post === 'RESERVE'
                    const isBeach = post === 'BEACH_AM' || post === 'BEACH_PM'
                    const isGarden = post === 'GARDEN_AM' || post === 'GARDEN_PM'
                    return (
                      <td key={g} className="py-1.5 px-2">
                        <span
                          className={`inline-block rounded-md px-2 py-0.5 text-xs ${
                            isOff
                              ? 'text-white/25'
                              : isReserve
                                ? 'bg-white/5 text-white/50 border border-white/10'
                                : isBeach
                                  ? 'bg-[#78b7ff]/15 text-[#78b7ff] border border-[#78b7ff]/25'
                                  : 'bg-[#6fc8a3]/15 text-[#6fc8a3] border border-[#6fc8a3]/25'
                          }`}
                        >
                          {POST_LABELS[post]}
                        </span>
                      </td>
                    )
                  })}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* Hidden French print sheet (no colors) */}
      <div className="gardeners-print" aria-hidden="true" style={{ display: 'none' }}>
        <div className="doc-header">
          <img className="doc-logo" src="/images/komba-logo-color.png" alt="Komba Cabana" />
          <p className="doc-location">Nosy Komba, Madagascar</p>
        </div>
        <div className="doc-title-block">
          <h2 className="doc-title">PLANNING DES JARDINIERS {year}</h2>
          <p className="doc-subtitle">Jardiniers</p>
        </div>
        <div className="doc-fields">
          {selected && <p><strong>Nom:</strong> {selected}</p>}
          <p><strong>Mois:</strong> {MONTHS_FR[month - 1]} {year}</p>
        </div>
        <table>
          <thead>
            <tr>
              <th>Jour</th>
              <th>Date</th>
              {visibleGardeners.map((g) => (
                <th key={g}>{g}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {schedule.map((day, i) => {
              const dayNum = i + 1
              const weekday = new Date(year, month - 1, dayNum).getDay()
              return (
                <tr key={day.date}>
                  <td className="g-day">{DAY_NAMES_FR[weekday]}</td>
                  <td className="g-day">{dayNum} {MONTHS_FR[month - 1].slice(0, 4).toLowerCase()}.</td>
                  {visibleGardeners.map((g) => {
                    const post = (day.assignments[g] || 'OFF') as GardenPost
                    return <td key={g}>{post === 'OFF' ? '—' : POST_LABELS_FR[post]}</td>
                  })}
                </tr>
              )
            })}
            <tr className="g-total">
              <td colSpan={2} style={{ textAlign: 'right' }}>Total heures</td>
              {visibleGardeners.map((g) => (
                <td key={g}>{stats[g].hours} h</td>
              ))}
            </tr>
          </tbody>
        </table>
        <div className="doc-legend">
          <span><strong>Plage</strong> 6h-12h / 13h-19h &nbsp;·&nbsp; <strong>Jardin</strong> 7h-13h / 13h-19h &nbsp;·&nbsp; <strong>Réserve</strong> remplaçant &nbsp;·&nbsp; <strong>—</strong> Repos</span>
        </div>
      </div>

      {/* Hidden French attendance sheets — one full page per gardener (no colors) */}
      <div className="gardeners-att-print" aria-hidden="true" style={{ display: 'none' }}>
        {visibleGardeners.map((g) => (
          <div key={g} className="att-page">
            <div className="doc-header">
              <img className="doc-logo" src="/images/komba-logo-color.png" alt="Komba Cabana" />
              <p className="doc-location">Nosy Komba, Madagascar</p>
            </div>
            <div className="doc-title-block">
              <h2 className="doc-title">REGISTRE DE PRÉSENCE {year}</h2>
              <p className="doc-subtitle">Jardinier</p>
            </div>
            <div className="doc-fields">
              <p><span className="doc-label">Nom:</span> <strong>{g}</strong></p>
              <p><span className="doc-label">Poste:</span> <strong>Jardinier</strong></p>
              <p><span className="doc-label">Mois:</span> <strong>{MONTHS_FR[month - 1]} {year}</strong></p>
            </div>
            <table>
              <thead>
                <tr>
                  <th className="att-col-day">Jour</th>
                  <th className="att-col-date">Date</th>
                  <th>Arrivée</th>
                  <th>Départ</th>
                  <th>Signature</th>
                </tr>
              </thead>
              <tbody>
                {Array.from({ length: lastDay }).map((_, i) => {
                  const dayNum = i + 1
                  const weekday = new Date(year, month - 1, dayNum).getDay()
                  return (
                    <tr key={dayNum}>
                      <td className="att-col-day">{DAY_NAMES_FR[weekday]}</td>
                      <td className="att-col-date">{dayNum} {MONTHS_FR[month - 1].slice(0, 4).toLowerCase()}.</td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
            <div className="doc-legend">
              <span>Total heures prévues: <strong>{stats[g].hours} h</strong> ({stats[g].shifts} services × 6 h)</span>
              <span>Signature du responsable: ______________________</span>
            </div>
            <p className="doc-note">Par ma signature, je confirme ma présence au travail pour les jours indiqués.</p>
          </div>
        ))}
      </div>
    </div>
  )
}
