// Shared constants & types for the KITCHEN schedule (osnutek / draft).
// NOTE: This file must NOT contain 'use server' — it exports constants and a
// pure function used by the client component.

export const KITCHEN_STAFF = [
  'Nazira',
  'Francia',
  'Selvira',
  'Verginie',
  'Angelina',
  'Clario',
  'Anifa',
] as const
export type KitchenStaff = (typeof KITCHEN_STAFF)[number]

// 3 fixed shifts (each = 1 chef + 1 assistant), plus OFF
export type KitchenShift = 'MORNING' | 'MIDDLE' | 'EVENING' | 'OFF'

// Slovenian labels (on-screen, for the manager)
export const SHIFT_LABELS: Record<KitchenShift, string> = {
  MORNING: 'Jutranja 6-12',
  MIDDLE: 'Srednja 11-17',
  EVENING: 'Večerna 16-22',
  OFF: 'Prosto',
}

// French labels (printed sheets — kitchen staff read French)
export const SHIFT_LABELS_FR: Record<KitchenShift, string> = {
  MORNING: 'Matin 6h-12h',
  MIDDLE: 'Après-midi 11h-17h',
  EVENING: 'Soir 16h-22h',
  OFF: 'Repos',
}

// Role per person (static). Slovenian (on-screen) + French (print).
export type KitchenRole = 'CHEF' | 'ASSIST' | 'RESERVE'
export const STAFF_ROLE: Record<KitchenStaff, KitchenRole> = {
  Nazira: 'CHEF',
  Francia: 'ASSIST',
  Selvira: 'CHEF',
  Verginie: 'ASSIST',
  Angelina: 'CHEF',
  Clario: 'ASSIST',
  Anifa: 'RESERVE',
}
export const ROLE_LABELS: Record<KitchenRole, string> = {
  CHEF: 'Glavna kuharica',
  ASSIST: 'Pomočnica',
  RESERVE: 'Rezerva',
}
export const ROLE_LABELS_FR: Record<KitchenRole, string> = {
  CHEF: 'Cuisinière',
  ASSIST: 'Aide-cuisinière',
  RESERVE: 'Remplaçante',
}

export const HOURS_PER_SHIFT = 6

// Base (fixed) shift each regular works. Anifa is the reserve (null base).
const BASE_SHIFT: Record<KitchenStaff, KitchenShift | null> = {
  Nazira: 'MORNING',
  Francia: 'MORNING',
  Selvira: 'MIDDLE',
  Verginie: 'MIDDLE',
  Angelina: 'EVENING',
  Clario: 'EVENING',
  Anifa: null,
}

export type DaySchedule = { date: string; assignments: Record<string, KitchenShift> }

/**
 * Generates a kitchen schedule for the given month.
 *
 * Rules implemented:
 *  - 7 people, each works 6 days and is OFF on the 7th. Off-days are staggered
 *    across the 7-person cycle so exactly ONE person is off each day.
 *  - FIXED shifts: Nazira+Francia morning (6-12), Selvira+Verginie middle
 *    (11-17), Angelina+Clario evening (16-22). Each shift = 1 chef + 1 assistant.
 *  - Anifa is the RESERVE: she covers whoever is off (chef OR assistant), taking
 *    their exact shift, so all 3 shifts are always staffed with 2 people.
 *  - On the day Anifa rests, all 6 regulars work their fixed posts.
 */
export function generateKitchenSchedule(year: number, month: number): DaySchedule[] {
  const lastDay = new Date(year, month, 0).getDate()
  const result: DaySchedule[] = []

  for (let day = 1; day <= lastDay; day++) {
    const dayIndex = day - 1
    const offIndex = dayIndex % 7 // 0..6 -> exactly one person off each day
    const offPerson = KITCHEN_STAFF[offIndex]

    const assignments: Record<string, KitchenShift> = {}

    KITCHEN_STAFF.forEach((person) => {
      if (person === offPerson) {
        assignments[person] = 'OFF'
      } else if (person === 'Anifa') {
        // Anifa covers the person who is off (their exact shift). If Anifa is the
        // one off, this branch is skipped (handled above).
        assignments[person] = (BASE_SHIFT[offPerson] as KitchenShift) ?? 'OFF'
      } else {
        assignments[person] = BASE_SHIFT[person] as KitchenShift
      }
    })

    const date = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
    result.push({ date, assignments })
  }

  return result
}

/** Counts worked shifts (each = 6h) per person. */
export function computeKitchenStats(schedule: DaySchedule[]) {
  const stats: Record<string, { shifts: number; hours: number }> = {}
  for (const p of KITCHEN_STAFF) stats[p] = { shifts: 0, hours: 0 }
  for (const day of schedule) {
    for (const p of KITCHEN_STAFF) {
      const shift = day.assignments[p]
      if (shift && shift !== 'OFF') {
        stats[p].shifts += 1
        stats[p].hours += HOURS_PER_SHIFT
      }
    }
  }
  return stats
}
