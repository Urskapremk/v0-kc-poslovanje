// Madagascar payroll calculations - Komba Cabana
// Cisti izracuni in konstante (BREZ 'use server')

// --- Podjetja (2 podjetji na istem naslovu) ---
export const COMPANY_ADDRESS =
  'Villa MADINA I EMPHYTEOSE TN°4507-BO ANDREKAREKA BE'

export type CompanyId = 'tourism' | 'sarl'

export const COMPANIES: Record<CompanyId, { name: string; address: string }> = {
  tourism: {
    name: 'KOMBA CABANA TOURISM SARL',
    address: COMPANY_ADDRESS,
  },
  sarl: {
    name: 'KOMBA CABANA SARL',
    address: COMPANY_ADDRESS,
  },
}

export function getCompany(id: string | null | undefined) {
  return COMPANIES[(id as CompanyId) || 'tourism'] || COMPANIES.tourism
}

// --- Konstante stopenj ---
export const DEFAULT_NET_SALARY = 268700 // Ar

// Zaposleni (odbitki)
export const EMPLOYEE_CNAPS_RATE = 0.01 // 1%
export const EMPLOYEE_OMINO_RATE = 0.01 // 1%
export const IRSA_FLAT = 3000 // Ar
export const IRSA_MIN = 262680 // Ar
export const IRSA_MAX = 423000 // Ar

// Delodajalec (prispevki)
export const EMPLOYER_CNAPS_RATE = 0.14 // 14%
export const EMPLOYER_OMINO_RATE = 0.075 // 7.5%
export const EMPLOYER_FMFP_RATE = 0.01 // 1%

// --- Tipi ---
export type Payslip = {
  baseSalary: number
  cnapsEmployee: number
  ominoEmployee: number
  irsa: number
  totalDeductions: number
  grossSalary: number
  netSalary: number
}

export type EmployerContributions = {
  baseSalary: number
  cnapsEmployer: number
  ominoEmployer: number
  fmfpEmployer: number
  totalContributions: number
  totalCost: number
}

// --- Izracun IRSA ---
export function calcIrsa(baseSalary: number): number {
  if (baseSalary >= IRSA_MIN && baseSalary <= IRSA_MAX) {
    return IRSA_FLAT
  }
  return 0
}

// --- STEP 1: Placilna lista (zaposleni) ---
export function calcPayslip(baseSalary: number): Payslip {
  const cnapsEmployee = Math.round(baseSalary * EMPLOYEE_CNAPS_RATE)
  const ominoEmployee = Math.round(baseSalary * EMPLOYEE_OMINO_RATE)
  const irsa = calcIrsa(baseSalary)
  const totalDeductions = cnapsEmployee + ominoEmployee + irsa
  const grossSalary = baseSalary + totalDeductions
  const netSalary = grossSalary - totalDeductions // = baseSalary
  return {
    baseSalary,
    cnapsEmployee,
    ominoEmployee,
    irsa,
    totalDeductions,
    grossSalary,
    netSalary,
  }
}

// --- STEP 2: Prispevki delodajalca ---
export function calcEmployerContributions(baseSalary: number): EmployerContributions {
  const cnapsEmployer = Math.round(baseSalary * EMPLOYER_CNAPS_RATE)
  const ominoEmployer = Math.round(baseSalary * EMPLOYER_OMINO_RATE)
  const fmfpEmployer = Math.round(baseSalary * EMPLOYER_FMFP_RATE)
  const totalContributions = cnapsEmployer + ominoEmployer + fmfpEmployer
  const totalCost = baseSalary + totalContributions
  return {
    baseSalary,
    cnapsEmployer,
    ominoEmployer,
    fmfpEmployer,
    totalContributions,
    totalCost,
  }
}

// --- STEP 3: Cetrtletni prispevki ---
// quarter: 1-4
export function getQuarter(month: number): number {
  // month 1-12
  return Math.floor((month - 1) / 3) + 1
}

export function getQuarterMonths(quarter: number): number[] {
  const start = (quarter - 1) * 3 + 1
  return [start, start + 1, start + 2]
}

// Rok placila: Q1->30.apr, Q2->31.jul, Q3->31.okt, Q4->31.jan naslednje leto
export function getQuarterDeadline(year: number, quarter: number): Date {
  switch (quarter) {
    case 1:
      return new Date(year, 3, 30) // 30. april (mesec 3 = april)
    case 2:
      return new Date(year, 6, 31) // 31. julij
    case 3:
      return new Date(year, 9, 31) // 31. oktober
    case 4:
      return new Date(year + 1, 0, 31) // 31. januar naslednje leto
    default:
      return new Date(year, 11, 31)
  }
}

// Izracun cetrtletnih prispevkov iz vsote vseh baznih plac v cetrtletju
export function calcQuarterlyContributions(sumOfBaseSalaries: number) {
  const cnaps = Math.round(sumOfBaseSalaries * EMPLOYER_CNAPS_RATE)
  const omino = Math.round(sumOfBaseSalaries * EMPLOYER_OMINO_RATE)
  const fmfp = Math.round(sumOfBaseSalaries * EMPLOYER_FMFP_RATE)
  return {
    sumOfBaseSalaries,
    cnaps,
    omino,
    fmfp,
    total: cnaps + omino + fmfp,
  }
}

// Format Ariary
export function formatAr(value: number): string {
  return new Intl.NumberFormat('fr-FR').format(Math.round(value)) + ' Ar'
}
