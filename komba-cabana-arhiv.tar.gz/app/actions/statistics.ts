'use server'

import { db } from '@/lib/db'
import { 
  reservations, 
  orderItems, 
  deliveryNotes, 
  deliveryNoteItems, 
  transfers,
  products,
  costSettings,
  staffSalaries,
  excursionBookings,
  excursionPricing,
  excursions,
  supplierPricing,
  routes,
  boats,
  marketingExpenses
} from '@/lib/db/schema'
import { eq, and, gte, lte, isNotNull, sql } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'

// Get exchange rate from settings
async function getExchangeRate(): Promise<number> {
  const result = await db.query.settings.findFirst({
    where: (settings, { eq }) => eq(settings.key, 'exchangeRate')
  })
  return result ? Number(result.value) : 4800
}

// Get cost settings
export async function getCostSettings() {
  return await db.select().from(costSettings)
}

// Update cost setting
export async function updateCostSetting(id: string, value: number) {
  await db.update(costSettings)
    .set({ value: String(value), updatedAt: new Date() })
    .where(eq(costSettings.id, id))
}

// --- Marketing expenses / Stroški marketinga ---
// Get marketing expenses for a month
export async function getMarketingExpenses(year: number, month: number, category: string = 'marketing') {
  return await db.select().from(marketingExpenses)
    .where(and(
      eq(marketingExpenses.year, year),
      eq(marketingExpenses.month, month),
      eq(marketingExpenses.category, category)
    ))
    .orderBy(marketingExpenses.createdAt)
}

// Get all marketing expenses for a whole year (for listing, grouped by month)
export async function getMarketingExpensesYear(year: number, category: string = 'marketing') {
  return await db.select().from(marketingExpenses)
    .where(and(
      eq(marketingExpenses.year, year),
      eq(marketingExpenses.category, category)
    ))
    .orderBy(marketingExpenses.date)
}

// Add a marketing expense (date determines the booking month)
export async function addMarketingExpense(date: string, description: string, amount: number, category: string = 'marketing') {
  const d = new Date(date)
  const year = d.getFullYear()
  const month = d.getMonth() + 1
  const id = `mkt-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
  await db.insert(marketingExpenses).values({
    id, category, year, month, date, description, amount: String(amount),
  })
  revalidatePath('/statistika')
}

// Update a marketing expense (date determines the booking month)
export async function updateMarketingExpense(id: string, date: string, description: string, amount: number) {
  const d = new Date(date)
  const year = d.getFullYear()
  const month = d.getMonth() + 1
  await db.update(marketingExpenses)
    .set({ year, month, date, description, amount: String(amount) })
    .where(eq(marketingExpenses.id, id))
  revalidatePath('/statistika')
}

// Delete a marketing expense
export async function deleteMarketingExpense(id: string) {
  await db.delete(marketingExpenses).where(eq(marketingExpenses.id, id))
  revalidatePath('/statistika')
}

// Get staff salaries for a month
export async function getStaffSalaries(year: number, month: number) {
  return await db.select().from(staffSalaries)
    .where(and(
      eq(staffSalaries.year, year),
      eq(staffSalaries.month, month)
    ))
}

// Add or update staff salary
export async function upsertStaffSalary(data: {
  id?: string
  staffType: string
  staffName: string
  year: number
  month: number
  salary: number
  allocateTo: string
}) {
  const id = data.id || `salary-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
  
  if (data.id) {
    await db.update(staffSalaries)
      .set({
        staffType: data.staffType,
        staffName: data.staffName,
        salary: String(data.salary),
        allocateTo: data.allocateTo
      })
      .where(eq(staffSalaries.id, data.id))
  } else {
    await db.insert(staffSalaries).values({
      id,
      staffType: data.staffType,
      staffName: data.staffName,
      year: data.year,
      month: data.month,
      salary: String(data.salary),
      allocateTo: data.allocateTo
    })
  }
  return id
}

// Delete staff salary
export async function deleteStaffSalary(id: string) {
  await db.delete(staffSalaries).where(eq(staffSalaries.id, id))
}

// Get statistics for a month
export async function getMonthlyStatistics(year: number, month: number) {
  const startDate = new Date(year, month - 1, 1)
  const endDate = new Date(year, month, 0) // Last day of month
  
  const startStr = startDate.toISOString().split('T')[0]
  const endStr = endDate.toISOString().split('T')[0]
  
  const rate = await getExchangeRate()
  const costs = await getCostSettings()
  
  // Get staff members active this month
  const allStaff = await getAllStaffMembers()
  const activeStaff = allStaff.filter(s => s.activeMonths?.includes(month))
  
  // Get archived reservations that checked out in this month
  const archivedReservations = await db.select().from(reservations)
    .where(and(
      isNotNull(reservations.checkedOutAt),
      sql`DATE(${reservations.checkedOutAt}) >= ${startStr}`,
      sql`DATE(${reservations.checkedOutAt}) <= ${endStr}`
    ))
  
  const reservationIds = archivedReservations.map(r => r.id)
  
  // Get ALL order items with eventDate in this month (regardless of checkout date)
  const monthOrderItems = await db.select().from(orderItems)
    .where(sql`${orderItems.eventDate} >= ${startDate.toISOString().split('T')[0]} AND ${orderItems.eventDate} <= ${endDate.toISOString().split('T')[0]}`)
  
  // Get ALL delivery notes with date in this month (regardless of checkout date)
  const monthDeliveryNotes = await db.select().from(deliveryNotes)
    .where(sql`${deliveryNotes.date} >= ${startDate.toISOString().split('T')[0]} AND ${deliveryNotes.date} <= ${endDate.toISOString().split('T')[0]}`)
  
  const deliveryNoteIds = monthDeliveryNotes.map(dn => dn.id)
  
  const allDeliveryItems = deliveryNoteIds.length > 0 
    ? await db.select().from(deliveryNoteItems)
        .where(sql`${deliveryNoteItems.deliveryNoteId} IN (${sql.join(deliveryNoteIds.map(id => sql`${id}`), sql`, `)})`)
    : []
  
  // Get all transfers for these reservations
  const allTransfers = await db.select().from(transfers)
    .where(sql`${transfers.reservationId} IN (${sql.join(reservationIds.map(id => sql`${id}`), sql`, `)})`)
  
  // Get all excursion bookings with a date in this month (consistent with revenue,
  // which counts order_items by eventDate regardless of guest checkout).
  // Fallback to reservation-based lookup for older bookings that have no date set.
  const dateBasedExcursionBookings = await db.select().from(excursionBookings)
    .where(sql`${excursionBookings.date} >= ${startStr} AND ${excursionBookings.date} <= ${endStr}`)

  const reservationBasedExcursionBookings = reservationIds.length > 0
    ? await db.select().from(excursionBookings)
        .where(sql`${excursionBookings.date} IS NULL AND ${excursionBookings.reservationId} IN (${sql.join(reservationIds.map(id => sql`${id}`), sql`, `)})`)
    : []

  const allExcursionBookings = [...dateBasedExcursionBookings, ...reservationBasedExcursionBookings]
  
  // Get all excursion pricing (supplier costs)
  const allExcursionPricing = await db.select().from(excursionPricing)
  
  // Get all excursions (for base costs - guide, entrance, lunch)
  const allExcursions = await db.select().from(excursions)
  
  // Get supplier pricing for transfers (boat costs per route)
  const allSupplierPricing = await db.select().from(supplierPricing)
  
  // Get routes for mapping route names to IDs
  const allRoutes = await db.select().from(routes)
  
  // Accommodation revenue - calculate based on nights actually spent in this month
  // A reservation counts if ANY of its nights fall within this month, REGARDLESS of
  // checkout status (consistent with excursions/bar: revenue counts by actual date,
  // not by guest checkout). Includes guests who are still staying.
  const allReservationsForNights = await db.select().from(reservations)
  
  // Filter to reservations that have nights in this month
  const reservationsWithNightsInMonth = allReservationsForNights.filter(r => {
    if (!r.arrival || !r.departure) return false
    const arrival = new Date(r.arrival)
    const departure = new Date(r.departure)
    // Reservation overlaps with month if: arrival <= endDate AND departure > startDate
    return arrival <= endDate && departure > startDate
  })
  
  // Calculate accommodation revenue proportionally based on nights in this month
  let accommodationRevenue = 0
  let totalNightsInMonth = 0
  
  for (const r of reservationsWithNightsInMonth) {
    const arrival = new Date(r.arrival!)
    const departure = new Date(r.departure!)
    const totalNights = Math.ceil((departure.getTime() - arrival.getTime()) / (1000 * 60 * 60 * 24))
    
    if (totalNights <= 0) continue
    
    // Calculate nights that fall within this month
    const effectiveStart = arrival < startDate ? startDate : arrival
    const effectiveEnd = departure > endDate ? new Date(endDate.getTime() + 24 * 60 * 60 * 1000) : departure
    const nightsInMonth = Math.ceil((effectiveEnd.getTime() - effectiveStart.getTime()) / (1000 * 60 * 60 * 24))
    
    if (nightsInMonth <= 0) continue
    
    // Proportional revenue for this month
    const pricePerNight = Number(r.totalAmount || 0) / totalNights
    accommodationRevenue += pricePerNight * nightsInMonth
    totalNightsInMonth += nightsInMonth
  }
  
  // Agency/platform commissions - also proportional to nights in month
  let agencyCommissions = 0
  let optimaplusCommission = 0
  
  for (const r of reservationsWithNightsInMonth) {
    const arrival = new Date(r.arrival!)
    const departure = new Date(r.departure!)
    const totalNights = Math.ceil((departure.getTime() - arrival.getTime()) / (1000 * 60 * 60 * 24))
    
    if (totalNights <= 0) continue
    
    const effectiveStart = arrival < startDate ? startDate : arrival
    const effectiveEnd = departure > endDate ? new Date(endDate.getTime() + 24 * 60 * 60 * 1000) : departure
    const nightsInMonth = Math.ceil((effectiveEnd.getTime() - effectiveStart.getTime()) / (1000 * 60 * 60 * 24))
    
    if (nightsInMonth <= 0) continue
    
    const proportion = nightsInMonth / totalNights
    
    // Agency commission
    agencyCommissions += Number(r.agencyCommission || 0) * proportion
    
    // Optimaplus commission for Booking.com and Airbnb
    if (r.bookingSource === 'Booking.com' || r.bookingSource === 'Airbnb') {
      optimaplusCommission += (Number(r.totalAmount || 0) * 0.07) * proportion
    }
  }
  
  // Use reservationsWithNightsInMonth for commission grouping
  
  // Group commissions by source for reporting
  const commissionsBySource: Record<string, number> = {}
  archivedReservations.forEach(r => {
    const source = r.bookingSource || 'Other'
    const commission = Number(r.agencyCommission || 0)
    if (commission > 0) {
      commissionsBySource[source] = (commissionsBySource[source] || 0) + commission
    }
  })
  // Add Optimaplus to Booking.com and Airbnb
  const bookingOptima = archivedReservations
    .filter(r => r.bookingSource === 'Booking.com')
    .reduce((sum, r) => sum + (Number(r.totalAmount || 0) * 0.07), 0)
  const airbnbOptima = archivedReservations
    .filter(r => r.bookingSource === 'Airbnb')
    .reduce((sum, r) => sum + (Number(r.totalAmount || 0) * 0.07), 0)
  
  // Group agency commissions separately
  const commissionsByAgency: Record<string, number> = {}
  archivedReservations.forEach(r => {
    if (r.agencyName && Number(r.agencyCommission) > 0) {
      commissionsByAgency[r.agencyName] = (commissionsByAgency[r.agencyName] || 0) + Number(r.agencyCommission)
    }
  })
  
  // Total nights in this month (already calculated above)
  const totalNights = totalNightsInMonth
  
  // Transfers
  const transferRevenue = allTransfers.reduce((sum, t) => sum + Number(t.guestPrice || 0), 0)
  
  // Transfer costs - calculate from supplier_pricing based on boatId and route
  const transferCost = allTransfers.reduce((sum, t) => {
    if (!t.boatId) return sum
    
    // Find the route ID - route can be an ID or a name
    let routeId = t.route
    if (t.route && !t.route.startsWith('route-')) {
      // Try to find route by name
      const foundRoute = allRoutes.find(r => r.name === t.route)
      if (foundRoute) routeId = foundRoute.id
    }
    
    // For airport route, use the base route (nosy-be) for boat pricing
    const routeData = allRoutes.find(r => r.id === routeId)
    const pricingRouteId = routeData?.baseRouteId || routeId
    
    // Find supplier price for this boat + route combination
    const pricing = allSupplierPricing.find(sp => 
      sp.boatId === t.boatId && sp.routeId === pricingRouteId
    )
    
    return sum + (pricing?.priceAr || 0)
  }, 0) / rate
  
  // Excursions (Izlet)
  const excursionItems = monthOrderItems.filter(o => o.category === 'Izlet')
  const excursionRevenue = excursionItems.reduce((sum, o) => sum + (o.priceAr || 0), 0) / rate
  
  // Excursion costs (boat rental + guide + entrance + lunch - supplier prices)
  // Calculate cost based on excursion_bookings + excursion_pricing + excursions base costs
  const excursionBoatCost = allExcursionBookings.reduce((sum, booking) => {
    if (!booking.boatId || !booking.excursionId) return sum
    const pricing = allExcursionPricing.find(p => 
      p.excursionId === booking.excursionId && p.boatId === booking.boatId
    )
    if (!pricing) return sum
    // priceAr is the supplier cost for the boat for this excursion
    return sum + (pricing.priceAr || 0)
  }, 0) / rate
  
  // Excursion base costs (guide, entrance, lunch) per pax
  const excursionBaseCost = allExcursionBookings.reduce((sum, booking) => {
    const exc = allExcursions.find(e => e.id === booking.excursionId)
    if (!exc) return sum
    const pax = booking.pax || 1
    const guideCost = exc.guidePriceAr || 0
    const entranceCost = (exc.entranceFeeAr || 0) * pax
    const lunchCost = booking.lunchProviderId ? (exc.lunchPriceAr || 0) * pax : 0
    return sum + guideCost + entranceCost + lunchCost
  }, 0) / rate
  
  const excursionCost = excursionBoatCost + excursionBaseCost
  
  // Meal Plan (Prehrana from order_items - prepaid)
  const mealPlanItems = monthOrderItems.filter(o => o.category === 'Prehrana')
  const mealPlanRevenue = mealPlanItems.reduce((sum, o) => sum + (o.priceAr || 0), 0) / rate
  
  // Meal plan cost (use same percentage as bar_prehrana for food cost)
  // Will be calculated after costMap is created
  
  // Bar items from delivery_note_items grouped by costCategory
  const pijacaDeliveryItems = allDeliveryItems.filter(i => (i as { costCategory?: string }).costCategory === 'pijaca')
  const pijacaDeliveryRevenue = pijacaDeliveryItems.reduce((sum, i) => sum + (i.totalAr || 0), 0) / rate
  
  // Pijača from order_items (added via recepcija or at check-in)
  const pijacaCategories = ['Carbonated Drinks', 'Cocktails', 'Cold Beverages', 'Hot Beverages', 'Spirits', 'Wine', 'Beer', 'Pijaca', 'Pijača']
  const pijacaOrderItems = monthOrderItems.filter(o => pijacaCategories.includes(o.category || ''))
  const pijacaOrderRevenue = pijacaOrderItems.reduce((sum, o) => sum + (o.priceAr || 0), 0) / rate
  
  const pijacaRevenue = pijacaDeliveryRevenue + pijacaOrderRevenue
  
  // Prehrana from delivery_note_items (bar daily orders)
  const barPrehranaDeliveryItems = allDeliveryItems.filter(i => (i as { costCategory?: string }).costCategory === 'prehrana')
  const barPrehranaDeliveryRevenue = barPrehranaDeliveryItems.reduce((sum, i) => sum + (i.totalAr || 0), 0) / rate
  
  // Note: Prehrana from order_items is counted separately as mealPlanRevenue (prepaid meal plans)
  const barPrehranaRevenue = barPrehranaDeliveryRevenue
  
  // Wellness from delivery_note_items
  const wellnessDeliveryItems = allDeliveryItems.filter(i => (i as { costCategory?: string }).costCategory === 'wellness')
  const wellnessDeliveryRevenue = wellnessDeliveryItems.reduce((sum, i) => sum + (i.totalAr || 0), 0) / rate
  const wellnessDeliveryCount = wellnessDeliveryItems.reduce((sum, i) => sum + (i.quantity || 0), 0)
  
  // Wellness/Masaza from order_items (added via recepcija)
  const wellnessOrderItems = monthOrderItems.filter(o => o.category === 'Masaza' || o.category === 'Masaža' || o.category === 'Wellness')
  const wellnessOrderRevenue = wellnessOrderItems.reduce((sum, o) => sum + (o.priceAr || 0), 0) / rate
  const wellnessOrderCount = wellnessOrderItems.length
  
  const wellnessRevenue = wellnessDeliveryRevenue + wellnessOrderRevenue
  const wellnessCount = wellnessDeliveryCount + wellnessOrderCount
  
  const ostaloItems = allDeliveryItems.filter(i => (i as { costCategory?: string }).costCategory === 'ostalo')
  const ostaloRevenue = ostaloItems.reduce((sum, i) => sum + (i.totalAr || 0), 0) / rate
  
  const barTotal = pijacaRevenue + barPrehranaRevenue
  
  const totalRevenue = accommodationRevenue + transferRevenue + excursionRevenue + 
    mealPlanRevenue + wellnessRevenue + ostaloRevenue + barTotal
  
  // Calculate costs
  const costMap = costs.reduce((map, c) => {
    map[c.category] = { type: c.costType, value: Number(c.value) }
    return map
  }, {} as Record<string, { type: string, value: number }>)
  
  const barPijacaCost = costMap.bar_pijaca 
    ? (costMap.bar_pijaca.type === 'percentage' ? pijacaRevenue * costMap.bar_pijaca.value / 100 : costMap.bar_pijaca.value)
    : 0
  
  const barPrehranaCost = costMap.bar_prehrana
    ? (costMap.bar_prehrana.type === 'percentage' ? barPrehranaRevenue * costMap.bar_prehrana.value / 100 : costMap.bar_prehrana.value)
    : 0
  
  const wellnessCost = costMap.wellness
    ? (costMap.wellness.type === 'fixed' ? wellnessCount * costMap.wellness.value : wellnessRevenue * costMap.wellness.value / 100)
    : 0
  
  const ostaloCost = costMap.ostalo
    ? (costMap.ostalo.type === 'percentage' ? ostaloRevenue * costMap.ostalo.value / 100 : costMap.ostalo.value)
    : 0
  
  // Meal plan cost (use same percentage as bar_prehrana for food cost)
  const mealPlanCost = costMap.bar_prehrana
    ? (costMap.bar_prehrana.type === 'percentage' ? mealPlanRevenue * costMap.bar_prehrana.value / 100 : costMap.bar_prehrana.value)
    : 0
  
  // Calculate salary costs - all full monthly salaries (not prorated)
  // Salaries are stored in Ar, convert to EUR using exchange rate
  
  // Operativa salaries (vrtnar, sobarica, barman, kuhinja) - celotna mesečna plača
  // Accommodation salaries (vrtnar, sobarica) - celotna mesečna plača
  const accommodationStaff = activeStaff.filter(s => s.allocateTo === 'accommodation')
  const accommodationSalaryCost = accommodationStaff.reduce((sum, s) => sum + Number(s.monthlySalary), 0) / rate
  
  // Bar salaries - celotna mesečna plača
  const barStaff = activeStaff.filter(s => s.allocateTo === 'bar')
  const barSalaryCost = barStaff.reduce((sum, s) => sum + Number(s.monthlySalary), 0) / rate
  
  // Kuhinja salaries - celotna mesečna plača
  const kuhinjaStaff = activeStaff.filter(s => s.allocateTo === 'kuhinja')
  const kuhinjaSalaryCost = kuhinjaStaff.reduce((sum, s) => sum + Number(s.monthlySalary), 0) / rate
  
  // Management salaries - celotna mesečna plača
  const managementStaff = activeStaff.filter(s => s.allocateTo === 'management')
  const managementSalaryCost = managementStaff.reduce((sum, s) => sum + Number(s.monthlySalary), 0) / rate
  
  // Fixed monthly costs for accommodation
  // Marketing, Booking and Optima plus costs are the sum of individually entered
  // expenses for this month (entered in Kalkulacije > Stroški). No longer fixed/auto-calculated.
  const monthExpenses = await db.select().from(marketingExpenses)
    .where(and(eq(marketingExpenses.year, year), eq(marketingExpenses.month, month)))
  const marketingCost = monthExpenses.filter(e => (e.category || 'marketing') === 'marketing').reduce((sum, e) => sum + Number(e.amount), 0) // EUR
  const bookingCost = monthExpenses.filter(e => e.category === 'booking').reduce((sum, e) => sum + Number(e.amount), 0) // EUR
  const optimaplusCost = monthExpenses.filter(e => e.category === 'optimaplus').reduce((sum, e) => sum + Number(e.amount), 0) // EUR
  const platformCommissionCost = bookingCost + optimaplusCost
  const starlinkCost = 150 // EUR per month
  const fixedAccommodationCosts = marketingCost + starlinkCost

  const totalSalaryCost = accommodationSalaryCost + barSalaryCost + kuhinjaSalaryCost + managementSalaryCost
  const totalCosts = barPijacaCost + barPrehranaCost + wellnessCost + ostaloCost + excursionCost + transferCost + mealPlanCost + totalSalaryCost + platformCommissionCost + fixedAccommodationCosts

  // ===== PER-GUEST BREAKDOWN (analytics) =====
  // Attribute revenue and costs to each reservation/guest. Salaries are allocated
  // proportionally to each guest's total revenue; marketing + Starlink are allocated
  // proportionally to each guest's accommodation revenue (since they relate to lodging).
  type GuestAgg = {
    reservationId: string
    guestName: string
    bungalow: string
    arrival: string | null
    departure: string | null
    nightsInMonth: number
    accommodation: number
    pijaca: number
    prehrana: number
    mealPlan: number
    wellness: number
    wellnessCount: number
    ostalo: number
    excursions: number
    transfers: number
    agencyCommission: number
    optimaplusCommission: number
    excursionCost: number
    transferCost: number
  }
  const guestMap = new Map<string, GuestAgg>()
  const resById = new Map(allReservationsForNights.map(r => [r.id, r]))
  const dnToReservation: Record<string, string | null> = {}
  monthDeliveryNotes.forEach(dn => { dnToReservation[dn.id] = dn.reservationId })

  const getGuest = (id: string, name?: string | null, bungalow?: string | null, arrival?: string | null, departure?: string | null): GuestAgg => {
    let g = guestMap.get(id)
    if (!g) {
      g = {
        reservationId: id, guestName: name || 'Neznano', bungalow: bungalow || '',
        arrival: arrival ?? null, departure: departure ?? null,
        nightsInMonth: 0, accommodation: 0, pijaca: 0, prehrana: 0, mealPlan: 0,
        wellness: 0, wellnessCount: 0, ostalo: 0, excursions: 0, transfers: 0,
        agencyCommission: 0, optimaplusCommission: 0, excursionCost: 0, transferCost: 0,
      }
      guestMap.set(id, g)
    } else if (name && g.guestName === 'Neznano') {
      g.guestName = name
    }
    return g
  }

  // Accommodation + commissions (proportional to nights in month)
  for (const r of reservationsWithNightsInMonth) {
    const arrival = new Date(r.arrival!)
    const departure = new Date(r.departure!)
    const totalN = Math.ceil((departure.getTime() - arrival.getTime()) / 86400000)
    if (totalN <= 0) continue
    const effStart = arrival < startDate ? startDate : arrival
    const effEnd = departure > endDate ? new Date(endDate.getTime() + 86400000) : departure
    const nIn = Math.ceil((effEnd.getTime() - effStart.getTime()) / 86400000)
    if (nIn <= 0) continue
    const prop = nIn / totalN
    const g = getGuest(r.id, r.guestName, r.bungalow, r.arrival, r.departure)
    g.nightsInMonth += nIn
    g.accommodation += (Number(r.totalAmount || 0) / totalN) * nIn
    g.agencyCommission += Number(r.agencyCommission || 0) * prop
    if (r.bookingSource === 'Booking.com' || r.bookingSource === 'Airbnb') {
      g.optimaplusCommission += (Number(r.totalAmount || 0) * 0.07) * prop
    }
  }

  // Helper: resolve guest from a delivery note
  const guestFromDeliveryItem = (deliveryNoteId: string): GuestAgg | null => {
    const resId = dnToReservation[deliveryNoteId]
    if (!resId) return null
    const dn = monthDeliveryNotes.find(d => d.id === deliveryNoteId)
    const r = resById.get(resId)
    return getGuest(resId, r?.guestName || dn?.guestName, r?.bungalow || dn?.bungalow, r?.arrival, r?.departure)
  }

  // Bar / wellness / ostalo from delivery note items
  pijacaDeliveryItems.forEach(i => { const g = guestFromDeliveryItem(i.deliveryNoteId); if (g) g.pijaca += (i.totalAr || 0) / rate })
  barPrehranaDeliveryItems.forEach(i => { const g = guestFromDeliveryItem(i.deliveryNoteId); if (g) g.prehrana += (i.totalAr || 0) / rate })
  wellnessDeliveryItems.forEach(i => { const g = guestFromDeliveryItem(i.deliveryNoteId); if (g) { g.wellness += (i.totalAr || 0) / rate; g.wellnessCount += (i.quantity || 0) } })
  ostaloItems.forEach(i => { const g = guestFromDeliveryItem(i.deliveryNoteId); if (g) g.ostalo += (i.totalAr || 0) / rate })

  // Bar / wellness / meal plan / excursions from order items (have reservationId directly)
  pijacaOrderItems.forEach(o => { if (!o.reservationId) return; const r = resById.get(o.reservationId); const g = getGuest(o.reservationId, r?.guestName, r?.bungalow, r?.arrival, r?.departure); g.pijaca += (o.priceAr || 0) / rate })
  wellnessOrderItems.forEach(o => { if (!o.reservationId) return; const r = resById.get(o.reservationId); const g = getGuest(o.reservationId, r?.guestName, r?.bungalow, r?.arrival, r?.departure); g.wellness += (o.priceAr || 0) / rate; g.wellnessCount += 1 })
  mealPlanItems.forEach(o => { if (!o.reservationId) return; const r = resById.get(o.reservationId); const g = getGuest(o.reservationId, r?.guestName, r?.bungalow, r?.arrival, r?.departure); g.mealPlan += (o.priceAr || 0) / rate })
  excursionItems.forEach(o => { if (!o.reservationId) return; const r = resById.get(o.reservationId); const g = getGuest(o.reservationId, r?.guestName, r?.bungalow, r?.arrival, r?.departure); g.excursions += (o.priceAr || 0) / rate })

  // Excursion supplier costs per booking
  allExcursionBookings.forEach(b => {
    if (!b.reservationId) return
    const r = resById.get(b.reservationId)
    const g = getGuest(b.reservationId, r?.guestName, r?.bungalow, r?.arrival, r?.departure)
    let c = 0
    if (b.boatId && b.excursionId) {
      const p = allExcursionPricing.find(p => p.excursionId === b.excursionId && p.boatId === b.boatId)
      if (p) c += p.priceAr || 0
    }
    const exc = allExcursions.find(e => e.id === b.excursionId)
    if (exc) {
      const pax = b.pax || 1
      c += (exc.guidePriceAr || 0) + (exc.entranceFeeAr || 0) * pax + (b.lunchProviderId ? (exc.lunchPriceAr || 0) * pax : 0)
    }
    g.excursionCost += c / rate
  })

  // Transfers revenue + supplier cost per booking
  allTransfers.forEach(t => {
    if (!t.reservationId) return
    const r = resById.get(t.reservationId)
    const g = getGuest(t.reservationId, r?.guestName, r?.bungalow, r?.arrival, r?.departure)
    g.transfers += Number(t.guestPrice || 0)
    if (t.boatId) {
      let routeId = t.route
      if (t.route && !t.route.startsWith('route-')) {
        const fr = allRoutes.find(rr => rr.name === t.route)
        if (fr) routeId = fr.id
      }
      const rd = allRoutes.find(rr => rr.id === routeId)
      const prId = rd?.baseRouteId || routeId
      const pr = allSupplierPricing.find(sp => sp.boatId === t.boatId && sp.routeId === prId)
      if (pr) g.transferCost += (pr.priceAr || 0) / rate
    }
  })

  // Build final per-guest result with derived costs + allocated overhead
  const rawGuests = Array.from(guestMap.values())
  const sumGuestRevenue = rawGuests.reduce((s, g) => s + g.accommodation + g.pijaca + g.prehrana + g.mealPlan + g.wellness + g.ostalo + g.excursions + g.transfers, 0)
  const sumGuestAccommodation = rawGuests.reduce((s, g) => s + g.accommodation, 0)
  const wellnessUnitCost = costMap.wellness?.type === 'fixed' ? costMap.wellness.value : 0

  const guestBreakdown = rawGuests.map(g => {
    const revenue = g.accommodation + g.pijaca + g.prehrana + g.mealPlan + g.wellness + g.ostalo + g.excursions + g.transfers
    const barPijacaC = costMap.bar_pijaca?.type === 'percentage' ? g.pijaca * costMap.bar_pijaca.value / 100 : 0
    const barPrehranaC = costMap.bar_prehrana?.type === 'percentage' ? g.prehrana * costMap.bar_prehrana.value / 100 : 0
    const mealPlanC = costMap.bar_prehrana?.type === 'percentage' ? g.mealPlan * costMap.bar_prehrana.value / 100 : 0
    const wellnessC = costMap.wellness?.type === 'fixed' ? g.wellnessCount * wellnessUnitCost : (costMap.wellness ? g.wellness * costMap.wellness.value / 100 : 0)
    const ostaloC = costMap.ostalo?.type === 'percentage' ? g.ostalo * costMap.ostalo.value / 100 : 0
    const directCost = barPijacaC + barPrehranaC + mealPlanC + wellnessC + ostaloC + g.excursionCost + g.transferCost
    // Allocated overhead
    const salaryShare = sumGuestRevenue > 0 ? totalSalaryCost * (revenue / sumGuestRevenue) : 0
    const marketingShare = sumGuestAccommodation > 0 ? marketingCost * (g.accommodation / sumGuestAccommodation) : 0
    const starlinkShare = sumGuestAccommodation > 0 ? starlinkCost * (g.accommodation / sumGuestAccommodation) : 0
    const platformShare = sumGuestAccommodation > 0 ? platformCommissionCost * (g.accommodation / sumGuestAccommodation) : 0
    const totalCost = directCost + salaryShare + marketingShare + starlinkShare + platformShare
    return {
      reservationId: g.reservationId,
      guestName: g.guestName,
      bungalow: g.bungalow,
      arrival: g.arrival,
      departure: g.departure,
      nightsInMonth: g.nightsInMonth,
      revenue: {
        accommodation: Math.round(g.accommodation * 100) / 100,
        bar: Math.round((g.pijaca + g.prehrana) * 100) / 100,
        mealPlan: Math.round(g.mealPlan * 100) / 100,
        wellness: Math.round(g.wellness * 100) / 100,
        ostalo: Math.round(g.ostalo * 100) / 100,
        excursions: Math.round(g.excursions * 100) / 100,
        transfers: Math.round(g.transfers * 100) / 100,
        total: Math.round(revenue * 100) / 100,
      },
      costs: {
        direct: Math.round(directCost * 100) / 100,
        salaries: Math.round(salaryShare * 100) / 100,
        marketing: Math.round(marketingShare * 100) / 100,
        starlink: Math.round(starlinkShare * 100) / 100,
        commissions: Math.round(platformShare * 100) / 100,
        total: Math.round(totalCost * 100) / 100,
      },
      profit: Math.round((revenue - totalCost) * 100) / 100,
    }
  }).sort((a, b) => b.profit - a.profit)

  return {
    year,
    month,
    exchangeRate: rate,
    revenue: {
      accommodation: Math.round(accommodationRevenue * 100) / 100,
      bar: { 
        pijaca: Math.round(pijacaRevenue * 100) / 100, 
        prehrana: Math.round(barPrehranaRevenue * 100) / 100, 
        total: Math.round(barTotal * 100) / 100 
      },
      transfers: Math.round(transferRevenue * 100) / 100,
      excursions: Math.round(excursionRevenue * 100) / 100,
      mealPlan: Math.round(mealPlanRevenue * 100) / 100,
      wellness: Math.round(wellnessRevenue * 100) / 100,
      ostalo: Math.round(ostaloRevenue * 100) / 100,
      total: Math.round(totalRevenue * 100) / 100
    },
    costs: {
      barPijaca: Math.round(barPijacaCost * 100) / 100,
      barPrehrana: Math.round(barPrehranaCost * 100) / 100,
      wellness: Math.round(wellnessCost * 100) / 100,
      ostalo: Math.round(ostaloCost * 100) / 100,
      excursions: Math.round(excursionCost * 100) / 100,
      transfers: Math.round(transferCost * 100) / 100,
      mealPlan: Math.round(mealPlanCost * 100) / 100,
      salaries: Math.round(totalSalaryCost * 100) / 100,
      marketing: marketingCost,
      booking: bookingCost,
      optimaplus: optimaplusCost,
      platformCommission: Math.round(platformCommissionCost * 100) / 100,
      starlink: starlinkCost,
      total: Math.round(totalCosts * 100) / 100
    },
    salaryBreakdown: {
      accommodation: Math.round(accommodationSalaryCost * 100) / 100,
      bar: Math.round(barSalaryCost * 100) / 100,
      kuhinja: Math.round(kuhinjaSalaryCost * 100) / 100,
      management: Math.round(managementSalaryCost * 100) / 100
    },
    commissionsByAgency,
    commissionsBySource,
    optimaplusBreakdown: {
      booking: Math.round(bookingOptima * 100) / 100,
      airbnb: Math.round(airbnbOptima * 100) / 100
    },
    profit: Math.round((totalRevenue - totalCosts) * 100) / 100,
    nights: totalNights,
    guests: reservationIds.length,
    guestBreakdown,
    costSettings: costs,
    staffMembers: activeStaff
  }
}

// Get carrier (boat operator) statistics for a month - how much business we gave
// each transporter, number of trips, and how much we paid them.
export async function getCarrierStatistics(year: number, month: number) {
  const startDate = new Date(year, month - 1, 1)
  const endDate = new Date(year, month, 0)
  const startStr = startDate.toISOString().split('T')[0]
  const endStr = endDate.toISOString().split('T')[0]

  const rate = await getExchangeRate()

  // Reservations checked out this month (transfers are tied to reservations)
  const archivedReservations = await db.select().from(reservations)
    .where(and(
      isNotNull(reservations.checkedOutAt),
      sql`DATE(${reservations.checkedOutAt}) >= ${startStr}`,
      sql`DATE(${reservations.checkedOutAt}) <= ${endStr}`
    ))
  const reservationIds = archivedReservations.map(r => r.id)

  const allTransfers = reservationIds.length > 0
    ? await db.select().from(transfers)
        .where(sql`${transfers.reservationId} IN (${sql.join(reservationIds.map(id => sql`${id}`), sql`, `)})`)
    : []

  // Excursion bookings with a date this month (+ fallback by reservation for older rows)
  const dateBasedExcursionBookings = await db.select().from(excursionBookings)
    .where(sql`${excursionBookings.date} >= ${startStr} AND ${excursionBookings.date} <= ${endStr}`)
  const reservationBasedExcursionBookings = reservationIds.length > 0
    ? await db.select().from(excursionBookings)
        .where(sql`${excursionBookings.date} IS NULL AND ${excursionBookings.reservationId} IN (${sql.join(reservationIds.map(id => sql`${id}`), sql`, `)})`)
    : []
  const allExcursionBookings = [...dateBasedExcursionBookings, ...reservationBasedExcursionBookings]

  const allSupplierPricing = await db.select().from(supplierPricing)
  const allExcursionPricing = await db.select().from(excursionPricing)
  const allRoutes = await db.select().from(routes)
  const allBoats = await db.select().from(boats)

  type CarrierAgg = {
    boatId: string
    name: string
    transferTrips: number
    excursionTrips: number
    transferPaidAr: number
    excursionPaidAr: number
  }
  const map = new Map<string, CarrierAgg>()
  const getCarrier = (boatId: string): CarrierAgg => {
    let c = map.get(boatId)
    if (!c) {
      const boat = allBoats.find(b => b.id === boatId)
      c = {
        boatId,
        name: boat?.name || 'Neznan prevoznik',
        transferTrips: 0, excursionTrips: 0,
        transferPaidAr: 0, excursionPaidAr: 0,
      }
      map.set(boatId, c)
    }
    return c
  }

  // Transfers -> supplier_pricing
  for (const t of allTransfers) {
    if (!t.boatId) continue
    let routeId = t.route
    if (t.route && !t.route.startsWith('route-')) {
      const fr = allRoutes.find(r => r.name === t.route)
      if (fr) routeId = fr.id
    }
    const routeData = allRoutes.find(r => r.id === routeId)
    const pricingRouteId = routeData?.baseRouteId || routeId
    const pricing = allSupplierPricing.find(sp => sp.boatId === t.boatId && sp.routeId === pricingRouteId)
    const c = getCarrier(t.boatId)
    c.transferTrips += 1
    c.transferPaidAr += pricing?.priceAr || 0
  }

  // Excursions -> excursion_pricing (boat rental supplier cost)
  for (const b of allExcursionBookings) {
    if (!b.boatId || !b.excursionId) continue
    const pricing = allExcursionPricing.find(p => p.excursionId === b.excursionId && p.boatId === b.boatId)
    const c = getCarrier(b.boatId)
    c.excursionTrips += 1
    c.excursionPaidAr += pricing?.priceAr || 0
  }

  const carriers = Array.from(map.values()).map(c => {
    const totalTrips = c.transferTrips + c.excursionTrips
    const totalPaidAr = c.transferPaidAr + c.excursionPaidAr
    return {
      boatId: c.boatId,
      name: c.name,
      transferTrips: c.transferTrips,
      excursionTrips: c.excursionTrips,
      totalTrips,
      transferPaid: Math.round((c.transferPaidAr / rate) * 100) / 100,
      excursionPaid: Math.round((c.excursionPaidAr / rate) * 100) / 100,
      totalPaid: Math.round((totalPaidAr / rate) * 100) / 100,
      totalPaidAr,
    }
  }).sort((a, b) => b.totalPaidAr - a.totalPaidAr)

  const totals = {
    totalTrips: carriers.reduce((s, c) => s + c.totalTrips, 0),
    transferTrips: carriers.reduce((s, c) => s + c.transferTrips, 0),
    excursionTrips: carriers.reduce((s, c) => s + c.excursionTrips, 0),
    totalPaid: Math.round(carriers.reduce((s, c) => s + c.totalPaid, 0) * 100) / 100,
  }

  return { carriers, totals }
}

// Get carrier statistics aggregated across the whole year (all months combined)
export async function getCarrierStatisticsYearly(year: number) {
  const map = new Map<string, {
    boatId: string
    name: string
    transferTrips: number
    excursionTrips: number
    totalTrips: number
    transferPaid: number
    excursionPaid: number
    totalPaid: number
    totalPaidAr: number
  }>()

  for (let month = 1; month <= 12; month++) {
    const { carriers } = await getCarrierStatistics(year, month)
    for (const c of carriers) {
      let agg = map.get(c.boatId)
      if (!agg) {
        agg = {
          boatId: c.boatId, name: c.name,
          transferTrips: 0, excursionTrips: 0, totalTrips: 0,
          transferPaid: 0, excursionPaid: 0, totalPaid: 0, totalPaidAr: 0,
        }
        map.set(c.boatId, agg)
      }
      agg.transferTrips += c.transferTrips
      agg.excursionTrips += c.excursionTrips
      agg.totalTrips += c.totalTrips
      agg.transferPaid += c.transferPaid
      agg.excursionPaid += c.excursionPaid
      agg.totalPaid += c.totalPaid
      agg.totalPaidAr += c.totalPaidAr
    }
  }

  const carriers = Array.from(map.values())
    .map(c => ({
      ...c,
      transferPaid: Math.round(c.transferPaid * 100) / 100,
      excursionPaid: Math.round(c.excursionPaid * 100) / 100,
      totalPaid: Math.round(c.totalPaid * 100) / 100,
    }))
    .sort((a, b) => b.totalPaidAr - a.totalPaidAr)

  const totals = {
    totalTrips: carriers.reduce((s, c) => s + c.totalTrips, 0),
    transferTrips: carriers.reduce((s, c) => s + c.transferTrips, 0),
    excursionTrips: carriers.reduce((s, c) => s + c.excursionTrips, 0),
    totalPaid: Math.round(carriers.reduce((s, c) => s + c.totalPaid, 0) * 100) / 100,
  }

  return { carriers, totals }
}

// Get yearly statistics
export async function getYearlyStatistics(year: number) {
  const months = []
  for (let month = 1; month <= 12; month++) {
    const stats = await getMonthlyStatistics(year, month)
    months.push(stats)
  }
  
  // Aggregate yearly totals
  const yearly = {
    year,
    revenue: {
      accommodation: 0,
      bar: { pijaca: 0, prehrana: 0, total: 0 },
      transfers: 0,
      excursions: 0,
      mealPlan: 0,
      wellness: 0,
      ostalo: 0,
      total: 0
    },
    costs: {
      barPijaca: 0,
      barPrehrana: 0,
      wellness: 0,
      ostalo: 0,
      salaries: 0,
      total: 0
    },
    profit: 0,
    nights: 0,
    guests: 0
  }
  
  for (const m of months) {
    yearly.revenue.accommodation += m.revenue.accommodation
    yearly.revenue.bar.pijaca += m.revenue.bar.pijaca
    yearly.revenue.bar.prehrana += m.revenue.bar.prehrana
    yearly.revenue.bar.total += m.revenue.bar.total
    yearly.revenue.transfers += m.revenue.transfers
    yearly.revenue.excursions += m.revenue.excursions
    yearly.revenue.mealPlan += m.revenue.mealPlan
    yearly.revenue.wellness += m.revenue.wellness
    yearly.revenue.ostalo += m.revenue.ostalo
    yearly.revenue.total += m.revenue.total
    
    yearly.costs.barPijaca += m.costs.barPijaca
    yearly.costs.barPrehrana += m.costs.barPrehrana
    yearly.costs.wellness += m.costs.wellness
    yearly.costs.ostalo += m.costs.ostalo
    yearly.costs.salaries += m.costs.salaries
    yearly.costs.total += m.costs.total
    
    yearly.profit += m.profit
    yearly.nights += m.nights
    yearly.guests += m.guests
  }
  
  return { yearly, months }
}

// ============ STAFF MEMBERS MANAGEMENT ============

export async function getAllStaffMembers() {
  const result = await db.execute(
    sql`SELECT * FROM staff_members ORDER BY "staffName"`
  )
  return result.rows.map(r => ({
    id: r.id as string,
    staffType: r.staffType as string,
    staffName: r.staffName as string,
    monthlySalary: r.monthlySalary as string,
    allocateTo: r.allocateTo as string,
    activeMonths: r.activeMonths as number[],
    startDate: r.startDate as string | null,
    endDate: r.endDate as string | null,
    active: r.active !== false,
    isRegularEmployee: r.isRegularEmployee === true,
    firstName: (r.firstName as string | null) ?? '',
    lastName: (r.lastName as string | null) ?? '',
    dateOfBirth: r.dateOfBirth as string | null,
    placeOfBirth: (r.placeOfBirth as string | null) ?? '',
    documentNumber: (r.documentNumber as string | null) ?? '',
    documentImagePath: (r.documentImagePath as string | null) ?? '',
    company: (r.company as string | null) ?? 'tourism',
    gender: (r.gender as string | null) ?? '',
    fatherName: (r.fatherName as string | null) ?? '',
    motherName: (r.motherName as string | null) ?? '',
    nationality: (r.nationality as string | null) ?? 'Malgache',
    cnapsNumber: (r.cnapsNumber as string | null) ?? '',
    ominoNumber: (r.ominoNumber as string | null) ?? '',
    ostieNumber: (r.ostieNumber as string | null) ?? '',
    numberOfDependents: Number(r.numberOfDependents ?? 0),
    address: (r.address as string | null) ?? '',
    phone: (r.phone as string | null) ?? '',
    email: (r.email as string | null) ?? '',
    employeePhotoPath: (r.employeePhotoPath as string | null) ?? '',
    notes: (r.notes as string | null) ?? '',
    openingLeaveBalance: Number(r.openingLeaveBalance ?? 0)
  }))
}

export async function upsertStaffMember(data: {
  id?: string
  staffType: string
  staffName: string
  monthlySalary: number
  allocateTo: string
  activeMonths: number[]
  startDate?: string | null
}) {
  const id = data.id || `staff-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
  
  // Convert array to PostgreSQL array literal format using sql.raw()
  const activeMonthsLiteral = sql.raw(`'{${data.activeMonths.join(',')}}'::integer[]`)
  
  await db.execute(
    sql`INSERT INTO staff_members (id, "staffType", "staffName", "monthlySalary", "allocateTo", "activeMonths", "startDate")
        VALUES (${id}, ${data.staffType}, ${data.staffName}, ${data.monthlySalary}, ${data.allocateTo}, ${activeMonthsLiteral}, ${data.startDate || null})
        ON CONFLICT (id) DO UPDATE SET
          "staffType" = ${data.staffType},
          "staffName" = ${data.staffName},
          "monthlySalary" = ${data.monthlySalary},
          "allocateTo" = ${data.allocateTo},
          "activeMonths" = ${activeMonthsLiteral},
          "startDate" = ${data.startDate || null}`
  )
  
  revalidatePath('/statistika')
  return id
}

export async function deleteStaffMember(id: string) {
  await db.execute(sql`DELETE FROM staff_members WHERE id = ${id}`)
  revalidatePath('/statistika')
}

export async function toggleStaffActive(id: string, active: boolean) {
  await db.execute(sql`UPDATE staff_members SET active = ${active} WHERE id = ${id}`)
  revalidatePath('/statistika')
}

export async function setStaffRegularEmployee(id: string, value: boolean) {
  await db.execute(sql`UPDATE staff_members SET "isRegularEmployee" = ${value} WHERE id = ${id}`)
  revalidatePath('/statistika')
}

export async function updateStaffStartDate(id: string, startDate: string | null) {
  await db.execute(sql`UPDATE staff_members SET "startDate" = ${startDate} WHERE id = ${id}`)
  revalidatePath('/statistika')
}

export async function updateStaffPersonalInfo(id: string, data: {
  firstName?: string | null
  lastName?: string | null
  dateOfBirth?: string | null
  placeOfBirth?: string | null
  documentNumber?: string | null
  documentImagePath?: string | null
  company?: string | null
  gender?: string | null
  fatherName?: string | null
  motherName?: string | null
  nationality?: string | null
  cnapsNumber?: string | null
  ominoNumber?: string | null
  address?: string | null
  phone?: string | null
  email?: string | null
  employeePhotoPath?: string | null
  notes?: string | null
  ostieNumber?: string | null
  numberOfDependents?: number | null
  openingLeaveBalance?: number | null
  }) {
  // Posodobi samo polja, ki so podana (undefined = pusti pri miru)
  const fields: (keyof typeof data)[] = [
    'firstName', 'lastName', 'dateOfBirth', 'placeOfBirth', 'documentNumber',
    'documentImagePath', 'company', 'gender', 'fatherName', 'motherName',
    'nationality', 'cnapsNumber', 'ominoNumber', 'address', 'phone', 'email',
    'employeePhotoPath', 'notes', 'ostieNumber', 'numberOfDependents', 'openingLeaveBalance',
  ]
  for (const field of fields) {
    const value = data[field]
    if (value === undefined) continue
    const safe = value || null
    // ime stolpca je iz fiksnega seznama (varno), vrednost je parametrizirana
    await db.execute(sql`UPDATE staff_members SET ${sql.identifier(field)} = ${safe} WHERE id = ${id}`)
  }
  revalidatePath('/statistika')
}
