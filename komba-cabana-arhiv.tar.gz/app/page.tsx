"use client";

import React from "react";
import Link from "next/link";
import useSWR, { mutate } from "swr";
import { Home, LogIn, LogOut, UserRound, ReceiptText, Truck, Settings, RefreshCw, Leaf, Heart, Ship, Plus, Database, Car, Mail, ExternalLink, Calendar, ChevronDown, FileText, Printer, X, Wine, Archive, BarChart3, Sparkles, CreditCard, Sofa, Users, Link2, Unlink, HelpCircle, Palmtree, Check, Landmark } from "lucide-react";
import { bungalowLabel } from "@/lib/bungalow";
import {
  getDashboardData,
  createReservation,
  updateReservation,
  deleteReservation,
  updateTransfer,
  deleteTransfer,
  addOrderItem,
  deleteOrderItem,
  updateExchangeRate,
  checkOverlap,
  addExcursionBooking,
  updateExcursionBooking,
  deleteExcursionBooking,
  createReservationGroup,
  linkReservationToGroup,
  unlinkReservationFromGroup,
} from "./actions/komba";
import { closeAllDeliveryNotesForReservation } from "./actions/delivery";
import { addExcursion, deleteExcursion } from "./actions/pricing";
import { TaxesPanel } from "@/components/taxes-panel";

const DEFAULT_RATE = 4800;
const BUNGALOWS = ["Ocean Bungalow I", "Ocean Bungalow II", "Garden Bungalow III", "Ocean Bungalow IV", "Jungle Glamp Village"];
const STATUSES = ["ARRIVING_TODAY", "RESERVED", "IN_HOUSE", "DEPARTING_TODAY", "CHECKED_OUT", "CANCELLED"];
const BOOKING_SOURCES = ["Booking.com", "Airbnb", "Direct Website", "Agency", "Other"];
const CATEGORIES = ["Pijaca", "Hrana", "Transfer", "Izlet", "Razno"];

const today = () => new Date().toISOString().slice(0, 10);
const num = (value: unknown) => (Number.isFinite(Number(value)) ? Number(value) : 0);
const eur = (value: unknown) => `${num(value).toFixed(2)} EUR`;
const ar = (value: unknown) => `${Math.round(num(value)).toLocaleString("fr-FR")} Ar`;
const arToEur = (arValue: unknown, rate: number) => num(arValue) / rate;
const eurToAr = (eurValue: unknown, rate: number) => Math.round(num(eurValue) * rate);

interface OrderItem {
  id: string;
  name: string;
  category: string;
  qty: number;
  priceAr: number;
  paymentStatus?: string | null;
}

interface TransferData {
  route: string;
  time: string;
  flightNumber?: string;
  flightTime?: string;
  pickupDate?: string;
  pax?: number;
  notes?: string;
  boatId?: string;
  boatPortTime?: string;
  hermanAirportTime?: string;
  dilipOrderedAt?: string | null;
  hermanOrderedAt?: string | null;
  guestPrice: number;
  paymentStatus: string; // 'PREPAID', 'UNPAID', 'PAID'
  executed?: boolean; // Whether the transfer was actually executed
  executedAt?: string | null; // When it was marked as executed
}

interface ExcursionBooking {
  id: string;
  excursionId: string;
  boatId: string;
  date: string;
  pax: number;
  notes: string;
  guestPrice: number;
  lunchProviderId: string;
  lunchPrice: number;
  entranceFee: number;
  paymentStatus: string;
  dilipOrderedAt: string | null;
  executed: boolean;
}

interface Reservation {
  id: string;
  guestName: string;
  secondGuestName?: string | null; // Ime drugega gosta
  bungalow: string;
  pax: number;
  arrival: string;
  departure: string;
  status: string;
  bookingSource?: string | null;
  agencyName?: string | null;
  nationality?: string | null;
  passport?: string | null;
  dateOfBirth?: string | null;
  placeOfBirth?: string | null;
  fatherName?: string | null;
  motherName?: string | null;
  profession?: string | null;
  domicile?: string | null;
  passportDate?: string | null;
  passportLieu?: string | null;
  venantDe?: string | null;
  validiteVisa?: string | null;
  allantA?: string | null;
  secondNationality?: string | null;
  secondPassport?: string | null;
  secondDateOfBirth?: string | null;
  secondPlaceOfBirth?: string | null;
  secondFatherName?: string | null;
  secondMotherName?: string | null;
  secondProfession?: string | null;
  secondDomicile?: string | null;
  secondPassportDate?: string | null;
  secondPassportLieu?: string | null;
  secondVenantDe?: string | null;
  secondValiditeVisa?: string | null;
  secondAllantA?: string | null;
  email?: string | null;
  phone?: string | null;
  allergies?: string | null;
  honeymoon?: boolean | null;
  notes?: string | null;
  mealPlan?: string | null; // B = Breakfast, HB = Half Board, FB = Full Board
  mealPlanPaymentStatus?: string | null; // PAID, UNPAID
  checkedInAt?: string | null; // When guest checked in
  checkedOutAt?: string | null; // When guest checked out
  totalAmount?: number | null; // Cena nocitev (EUR) - iz Bentrala ali rocno
  amountPaid?: number | null; // Placano (EUR)
  agencyCommission?: number | null; // Provizija agenciji (EUR)
  currency?: string | null; // Valuta (EUR)
  transfers: {
    arrival: TransferData;
    departure: TransferData;
  };
  excursions: ExcursionBooking[];
  orderItems: OrderItem[];
}

// ============ LUXURY UI COMPONENTS ============

// Glassmorphism card with luxury styling
function GlassCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-[2rem] border border-white/[0.08] bg-[rgba(15,23,36,0.82)] p-8 shadow-[0_8px_32px_rgba(0,0,0,0.4)] backdrop-blur-xl ${className}`}>
      {children}
    </div>
  );
}

function SectionHeader({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }) {
  return (
    <div>
      {eyebrow && <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.22em] text-[#94a3b8]">{eyebrow}</p>}
      <h2 className="font-[family-name:var(--font-manrope)] text-[1.4rem] font-light tracking-wide text-[#f8fafc]">{title}</h2>
      {subtitle && <p className="mt-2 text-sm font-light text-[#94a3b8]">{subtitle}</p>}
    </div>
  );
}

function LuxuryBadge({ children, variant = "default" }: { children: React.ReactNode; variant?: "default" | "petrol" | "ocean" | "danger" | "gold" }) {
  const styles = {
    default: "bg-white/5 border-white/10 text-[#cbd5e1]",
    petrol: "bg-[#6fc8a3]/15 border-[#6fc8a3]/25 text-[#6fc8a3]",
    ocean: "bg-[#78b7ff]/15 border-[#78b7ff]/25 text-[#78b7ff]",
    danger: "bg-[#d94a63]/15 border-[#d94a63]/25 text-[#d94a63]",
    gold: "bg-[#f1d07a]/15 border-[#f1d07a]/25 text-[#f1d07a]",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] ${styles[variant]}`}>
      {children}
    </span>
  );
}

function LuxuryButton({ children, variant = "gold", className = "", ...props }: { children: React.ReactNode; variant?: "gold" | "petrol" | "ocean" | "ghost" | "danger"; className?: string } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const styles = {
    gold: "bg-gradient-to-r from-[#fff4cc] via-[#f1d07a] to-[#b8892f] text-[#0a0f1a] shadow-[0_4px_20px_rgba(241,208,122,0.25)] hover:shadow-[0_6px_28px_rgba(241,208,122,0.35)]",
    petrol: "bg-gradient-to-r from-[#6fc8a3] to-[#4fa987] text-[#0a0f1a] shadow-[0_4px_20px_rgba(111,200,163,0.25)] hover:shadow-[0_6px_28px_rgba(111,200,163,0.35)]",
    ocean: "bg-gradient-to-r from-[#78b7ff] to-[#5c8fd8] text-[#0a0f1a] shadow-[0_4px_20px_rgba(120,183,255,0.25)] hover:shadow-[0_6px_28px_rgba(120,183,255,0.35)]",
    ghost: "bg-white/[0.03] border border-white/10 text-[#cbd5e1] hover:bg-white/[0.06] hover:border-white/15",
    danger: "bg-gradient-to-r from-[#d94a63] to-[#a83248] text-white shadow-[0_4px_20px_rgba(217,74,99,0.25)] hover:shadow-[0_6px_28px_rgba(217,74,99,0.35)]",
  };
  return (
    <button className={`rounded-[1.2rem] px-6 py-3 text-[11px] font-semibold uppercase tracking-[0.18em] transition-all duration-300 ${styles[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}

function LuxuryInput({ label, value, onChange, type = "text", placeholder }: { label: string; value: string | number; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  return (
    <div>
      <label className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.2em] text-[#94a3b8]">{label}</label>
      <input
        type={type}
        className="w-full rounded-[1.1rem] border border-white/10 bg-white/[0.03] px-5 py-3.5 text-[#f8fafc] placeholder:text-[#475569] transition-all duration-300 focus:border-[#f1d07a]/40 focus:outline-none focus:ring-2 focus:ring-[#f1d07a]/10"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </div>
  );
}

function LuxurySelect({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: (string | { value: string; label: string })[] }) {
  return (
    <div>
      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">{label}</label>
      <select
        className="w-full rounded-[1.1rem] border border-white/10 bg-white/5 px-5 py-3 text-white transition-all duration-300 focus:border-[#f1d07a]/50 focus:outline-none focus:ring-2 focus:ring-[#f1d07a]/20 cursor-pointer"
        value={value}
        onChange={e => onChange(e.target.value)}
      >
        {options.map(opt => typeof opt === "string" ? <option key={opt} value={opt} className="bg-[#0a0f1a] text-white">{opt || "—"}</option> : <option key={opt.value} value={opt.value} className="bg-[#0a0f1a] text-white">{opt.label}</option>)}
      </select>
    </div>
  );
}

function LuxuryCheckbox({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center gap-3 text-sm text-white/70 transition-colors hover:text-white">
      <div className={`flex h-5 w-5 items-center justify-center rounded-lg border transition-all ${checked ? "border-[#f1d07a] bg-[#f1d07a]" : "border-white/20 bg-white/5"}`}>
        {checked && <span className="text-[#0a0f1a] text-xs">✓</span>}
      </div>
      <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)} className="sr-only" />
      {label}
    </label>
  );
}

// Reliable controlled text field for transfer fields (notes, times, etc.)
// Syncs with the saved value and shows a brief "Shranjeno" confirmation.
// Fixes the issue where notes added after a re-render (e.g. after marking
// departure executed) appeared to not be accepted with defaultValue inputs.
function TransferTextField({
  label,
  value,
  placeholder,
  onSave,
}: {
  label: string;
  value: string;
  placeholder?: string;
  onSave: (v: string) => Promise<void> | void;
}) {
  const [local, setLocal] = React.useState(value || "");
  const [saved, setSaved] = React.useState(false);
  const lastSavedRef = React.useRef(value || "");

  // Keep local input in sync when the saved value changes from outside (e.g. refresh)
  React.useEffect(() => {
    if ((value || "") !== lastSavedRef.current) {
      setLocal(value || "");
      lastSavedRef.current = value || "";
    }
  }, [value]);

  const commit = async () => {
    if (local === lastSavedRef.current) return;
    lastSavedRef.current = local;
    await onSave(local);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  return (
    <div>
      <label className="block text-xs text-white/40 mb-1">
        {label}
        {saved && <span className="ml-2 text-emerald-400">Shranjeno ✓</span>}
      </label>
      <input
        type="text"
        placeholder={placeholder}
        className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#78b7ff]/50 focus:outline-none"
        value={local}
        onChange={e => setLocal(e.target.value)}
        onBlur={commit}
        onKeyDown={e => { if (e.key === 'Enter') { (e.target as HTMLInputElement).blur(); } }}
      />
    </div>
  );
}

// Notes section with add functionality
function NotesSection({ notes, onAddNote }: { notes: string; onAddNote: (note: string) => void }) {
  const [newNote, setNewNote] = React.useState("");
  
  const handleAdd = () => {
    if (!newNote.trim()) return;
    onAddNote(newNote.trim());
    setNewNote("");
  };
  
  // Parse notes into array (split by ---)
  const notesList = notes ? notes.split('\n---\n').filter(Boolean) : [];
  
  return (
    <div className="space-y-4">
      <label className="block text-[10px] font-semibold uppercase tracking-[0.2em] text-[#94a3b8]">Opombe / Korespondenca</label>
      
      {/* Add new note */}
      <div className="flex gap-3">
        <textarea 
          className="flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-[#f1d07a]/50 focus:outline-none focus:ring-1 focus:ring-[#f1d07a]/50 min-h-[80px] resize-y"
          placeholder="Dodaj novo opombo..."
          value={newNote}
          onChange={e => setNewNote(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && e.metaKey) handleAdd(); }}
        />
      </div>
      <LuxuryButton variant="ghost" onClick={handleAdd} disabled={!newNote.trim()}>
        Dodaj opombo
      </LuxuryButton>
      
      {/* Existing notes */}
      {notesList.length > 0 && (
        <div className="mt-4 space-y-3 max-h-[300px] overflow-y-auto">
          {notesList.map((note, i) => (
            <div key={i} className="rounded-xl border border-white/5 bg-white/[0.02] p-4">
              <p className="text-sm text-white/70 whitespace-pre-wrap">{note}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Gmail email search section
interface GmailEmail {
  id: string;
  threadId: string;
  subject: string;
  from: string;
  date: string;
  snippet: string;
}

function GmailSection({ guestName, guestEmail }: { guestName: string; guestEmail?: string }) {
  const [emails, setEmails] = React.useState<GmailEmail[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [connected, setConnected] = React.useState<boolean | null>(null);
  const [expanded, setExpanded] = React.useState(false);

  // Check Gmail connection status
  React.useEffect(() => {
    fetch('/api/gmail/status')
      .then(res => res.json())
      .then(data => setConnected(data.connected))
      .catch(() => setConnected(false));
  }, []);

  const searchEmails = async () => {
    setLoading(true);
    setError(null);
    try {
      // Build search query from name parts and email
      const nameParts = guestName.split(' ').filter(p => p.length > 2);
      const searchTerms = guestEmail ? [...nameParts, guestEmail] : nameParts;
      
      const res = await fetch('/api/gmail/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchTerms.join(' OR ') })
      });
      
      if (!res.ok) {
        const data = await res.json();
        if (data.needsAuth) {
          window.location.href = '/api/auth/google';
          return;
        }
        throw new Error(data.error || 'Napaka pri iskanju');
      }
      
      const data = await res.json();
      setEmails(data.emails || []);
      setExpanded(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Napaka pri iskanju');
    } finally {
      setLoading(false);
    }
  };

  const connectGmail = () => {
    window.location.href = '/api/auth/google';
  };

  return (
    <div className="space-y-4 pt-4 border-t border-white/10">
      <div className="flex items-center justify-between">
        <label className="block text-[10px] font-semibold uppercase tracking-[0.2em] text-[#94a3b8]">
          <Mail className="inline h-3 w-3 mr-1" />
          Email korespondenca
        </label>
        {connected === false ? (
          <button
            onClick={connectGmail}
            className="text-xs text-[#78b7ff] hover:underline"
          >
            Povezi Gmail
          </button>
        ) : (
          <button
            onClick={searchEmails}
            disabled={loading}
            className="text-xs text-[#78b7ff] hover:underline disabled:opacity-50"
          >
            {loading ? 'Iscem...' : 'Poisci emails'}
          </button>
        )}
      </div>

      {error && (
        <p className="text-xs text-red-400">{error}</p>
      )}

      {expanded && emails.length === 0 && !loading && (
        <p className="text-xs text-white/40">Ni najdenih emailov za tega gosta.</p>
      )}

      {emails.length > 0 && (
        <div className="space-y-2 max-h-[300px] overflow-y-auto">
          {emails.map((email) => (
            <a
              key={email.id}
              href={`https://mail.google.com/mail/u/0/#inbox/${email.threadId}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block rounded-xl border border-white/5 bg-white/[0.02] p-3 hover:bg-white/[0.05] transition-colors"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white font-medium truncate">{email.subject || '(brez zadeve)'}</p>
                  <p className="text-xs text-white/50 truncate">{email.from}</p>
                  <p className="text-xs text-white/30 mt-1 line-clamp-2">{email.snippet}</p>
                </div>
                <div className="flex-shrink-0 flex items-center gap-2">
                  <span className="text-[10px] text-white/30">{email.date}</span>
                  <ExternalLink className="h-3 w-3 text-white/30" />
                </div>
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

// Payment methods
const PAYMENT_METHODS = [
  { value: 'card', label: 'Kreditna kartica' },
  { value: 'transfer', label: 'Bancni transfer' },
  { value: 'orange_money', label: 'Orange Money' },
  { value: 'cash', label: 'Gotovina' },
  ];
  
  // Police Registration Form Modal
  function PoliceFormModal({ reservation, isOpen, onClose }: { 
    reservation: { 
      guestName: string; 
      secondGuestName?: string | null;
      nationality?: string | null; 
      passport?: string | null; 
      dateOfBirth?: string | null;
      placeOfBirth?: string | null;
      fatherName?: string | null;
      motherName?: string | null;
      profession?: string | null;
      domicile?: string | null;
      passportDate?: string | null;
      passportLieu?: string | null;
      venantDe?: string | null;
      validiteVisa?: string | null;
      allantA?: string | null;
      secondNationality?: string | null;
      secondPassport?: string | null;
      secondDateOfBirth?: string | null;
      secondPlaceOfBirth?: string | null;
      secondFatherName?: string | null;
      secondMotherName?: string | null;
      secondProfession?: string | null;
      secondDomicile?: string | null;
      secondPassportDate?: string | null;
      secondPassportLieu?: string | null;
      secondVenantDe?: string | null;
      secondValiditeVisa?: string | null;
      secondAllantA?: string | null;
      arrival: string; 
      departure: string;
    }; 
    isOpen: boolean; 
    onClose: () => void; 
  }) {
    const [slot, setSlot] = React.useState<'first' | 'second'>('first');
    const [formData, setFormData] = React.useState({
      nom: '',
      prenom: '',
      dateNaissance: '',
      lieuNaissance: '',
      pere: '',
      mere: '',
      profession: '',
      domicile: '',
      nationalite: '',
      pieceIdentite: 'Passport',
      passportNo: '',
      passportDate: '',
      passportLieu: '',
      dateArrivee: '',
      venantDe: '',
      validiteVisa: '',
      dateDepart: '',
      aliantA: '',
      modeTransport: 'Avion'
    });
    
    React.useEffect(() => {
      if (isOpen) {
        // Pick the correct guest's data based on the selected slot
        const isSecond = slot === 'second';
        const guestName = isSecond ? (reservation.secondGuestName || '') : reservation.guestName;
        const nameParts = guestName.trim().split(' ');
        setFormData(prev => ({
          ...prev,
          nom: nameParts.slice(1).join(' ') || '',
          prenom: nameParts[0] || '',
          nationalite: (isSecond ? reservation.secondNationality : reservation.nationality) || '',
          passportNo: (isSecond ? reservation.secondPassport : reservation.passport) || '',
          dateNaissance: (isSecond ? reservation.secondDateOfBirth : reservation.dateOfBirth) || '',
          lieuNaissance: (isSecond ? reservation.secondPlaceOfBirth : reservation.placeOfBirth) || '',
          pere: (isSecond ? reservation.secondFatherName : reservation.fatherName) || '',
          mere: (isSecond ? reservation.secondMotherName : reservation.motherName) || '',
          profession: (isSecond ? reservation.secondProfession : reservation.profession) || '',
          domicile: (isSecond ? reservation.secondDomicile : reservation.domicile) || '',
          passportDate: (isSecond ? reservation.secondPassportDate : reservation.passportDate) || '',
          passportLieu: (isSecond ? reservation.secondPassportLieu : reservation.passportLieu) || '',
          venantDe: (isSecond ? reservation.secondVenantDe : reservation.venantDe) || '',
          validiteVisa: (isSecond ? reservation.secondValiditeVisa : reservation.validiteVisa) || '',
          aliantA: (isSecond ? reservation.secondAllantA : reservation.allantA) || '',
          dateArrivee: reservation.arrival,
          dateDepart: reservation.departure,
        }));
      }
    }, [isOpen, reservation, slot]);

    // Reset to first guest whenever the modal is opened
    React.useEffect(() => {
      if (isOpen) setSlot('first');
    }, [isOpen]);
    
    const handlePrint = () => {
      const printContent = document.getElementById('police-form-content');
      if (!printContent) return;
      
      const printWindow = window.open('', '_blank');
      if (!printWindow) return;
      
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Fiche de Police - ${formData.nom} ${formData.prenom}</title>
          <style>
            @page { size: A4; margin: 15mm; }
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { font-family: 'Times New Roman', Times, serif; font-size: 10pt; line-height: 1.3; }
            .form-container { max-width: 180mm; margin: 0 auto; }
            .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #000; padding-bottom: 3mm; margin-bottom: 4mm; }
            .header-left h1 { font-size: 14pt; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5mm; }
            .header-left p { font-size: 8pt; color: #555; margin-top: 1mm; }
            .header-right { text-align: right; }
            .header-right img { height: 8mm; }
            .form-row { display: flex; gap: 4mm; margin-bottom: 3mm; }
            .form-field { flex: 1; }
            .form-field.col-3 { flex: 0.33; }
            .form-label { font-size: 8pt; color: #333; text-transform: uppercase; letter-spacing: 0.3mm; margin-bottom: 1mm; display: block; }
            .form-value { border-bottom: 1px solid #000; min-height: 6mm; padding: 1mm 0; font-size: 10pt; font-weight: bold; text-transform: uppercase; }
            .transport-options { display: flex; gap: 3mm; margin-top: 1mm; }
            .transport-option { padding: 1.5mm 3mm; border: 1px solid #999; font-size: 9pt; }
            .transport-option.selected { background: #ddd; border-color: #000; font-weight: bold; }
            .signature-section { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 8mm; padding-top: 5mm; border-top: 1px solid #ccc; }
            .signature-line { width: 50mm; border-bottom: 1px solid #000; }
            .signature-label { font-size: 8pt; margin-bottom: 2mm; }
          </style>
        </head>
        <body>
          <div class="form-container">
            <div class="header">
              <div class="header-left">
                <h1>Fiche de Police</h1>
                <p>PRIERE D'ECRIRE TRES LISIBLEMENT / PLEASE WRITE PLAINLY</p>
              </div>
              <div class="header-right">
                <img src="/images/komba-logo.png" alt="Komba Cabana" />
              </div>
            </div>
            
            <div class="form-row">
              <div class="form-field"><span class="form-label">Nom / Name</span><div class="form-value">${formData.nom}</div></div>
              <div class="form-field"><span class="form-label">Prenom / First name</span><div class="form-value">${formData.prenom}</div></div>
            </div>
            
            <div class="form-row">
              <div class="form-field"><span class="form-label">Date de naissance</span><div class="form-value">${formData.dateNaissance}</div></div>
              <div class="form-field"><span class="form-label">Lieu de naissance</span><div class="form-value">${formData.lieuNaissance}</div></div>
            </div>
            
            <div class="form-row">
              <div class="form-field"><span class="form-label">Pere / Father</span><div class="form-value">${formData.pere}</div></div>
              <div class="form-field"><span class="form-label">Mere / Mother</span><div class="form-value">${formData.mere}</div></div>
            </div>
            
            <div class="form-row">
              <div class="form-field"><span class="form-label">Profession</span><div class="form-value">${formData.profession}</div></div>
              <div class="form-field"><span class="form-label">Domicile habituel</span><div class="form-value">${formData.domicile}</div></div>
            </div>
            
            <div class="form-row">
              <div class="form-field"><span class="form-label">Nationalite</span><div class="form-value">${formData.nationalite}</div></div>
              <div class="form-field"><span class="form-label">Piece d'identite</span><div class="form-value">${formData.pieceIdentite}</div></div>
            </div>
            
            <div class="form-row">
              <div class="form-field col-3"><span class="form-label">N° document</span><div class="form-value">${formData.passportNo}</div></div>
              <div class="form-field col-3"><span class="form-label">Date delivrance</span><div class="form-value">${formData.passportDate}</div></div>
              <div class="form-field col-3"><span class="form-label">Lieu delivrance</span><div class="form-value">${formData.passportLieu}</div></div>
            </div>
            
            <div class="form-row">
              <div class="form-field"><span class="form-label">Date d'arrivee</span><div class="form-value">${formData.dateArrivee}</div></div>
              <div class="form-field"><span class="form-label">Venant de / Coming from</span><div class="form-value">${formData.venantDe}</div></div>
            </div>
            
            <div class="form-row">
              <div class="form-field"><span class="form-label">Validite du Visa</span><div class="form-value">${formData.validiteVisa || '30 dni / 90 dni'}</div></div>
            </div>
            
            <div class="form-row">
              <div class="form-field"><span class="form-label">Date de depart</span><div class="form-value">${formData.dateDepart}</div></div>
              <div class="form-field"><span class="form-label">Aliant a / Going to</span><div class="form-value">${formData.aliantA}</div></div>
            </div>
            
            <div class="form-row">
              <div class="form-field">
                <span class="form-label">Mode de transport</span>
                <div class="transport-options">
                  ${['Avion', 'Voiture', 'Moto', 'Bateau'].map(t => `<span class="transport-option ${formData.modeTransport === t ? 'selected' : ''}">${t}</span>`).join('')}
                </div>
              </div>
            </div>
            
            <div class="signature-section">
              <div>Le _______________</div>
              <div style="text-align: right;">
                <div class="signature-label">Signature du responsable</div>
                <div class="signature-line"></div>
              </div>
            </div>
          </div>
        </body>
        </html>
      `);
      
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => { printWindow.print(); }, 250);
    };
    
    if (!isOpen) return null;
    
    const inputClass = "w-full border-b border-white/20 bg-transparent px-1 py-2 text-sm text-white focus:border-[#78b7ff] focus:outline-none";
    const labelClass = "block text-[10px] font-medium uppercase tracking-wider text-white/50 mb-0.5";
    
    return (
      <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/80 backdrop-blur-sm p-4 pt-8">
        <div className="relative w-full max-w-lg bg-[#0d1117] rounded-xl border border-white/10 shadow-2xl my-4">
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
            <div>
              <h2 className="text-base font-semibold text-white">Fiche de Police</h2>
              <p className="text-[10px] text-white/40 uppercase tracking-wider">Obrazec za policijo</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handlePrint}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#78b7ff]/10 text-[#78b7ff] hover:bg-[#78b7ff]/20 transition-all text-xs font-medium"
              >
                <Printer className="w-3.5 h-3.5" />
                Natisni
              </button>
              <button onClick={onClose} className="p-1.5 rounded-lg bg-white/5 text-white/40 hover:bg-white/10 hover:text-white transition-all">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          {/* Tabs for two guests */}
          {reservation.secondGuestName ? (
            <div className="flex gap-2 px-5 pt-4">
              <button
                type="button"
                onClick={() => setSlot('first')}
                className={`flex-1 rounded-lg border px-3 py-2 text-xs font-medium transition-all ${
                  slot === 'first'
                    ? 'border-[#78b7ff] bg-[#78b7ff]/10 text-[#78b7ff]'
                    : 'border-white/10 text-white/40 hover:border-white/20 hover:text-white/60'
                }`}
              >
                {reservation.guestName || 'Oseba 1'}
              </button>
              <button
                type="button"
                onClick={() => setSlot('second')}
                className={`flex-1 rounded-lg border px-3 py-2 text-xs font-medium transition-all ${
                  slot === 'second'
                    ? 'border-[#f9a8d4] bg-[#f9a8d4]/10 text-[#f9a8d4]'
                    : 'border-white/10 text-white/40 hover:border-white/20 hover:text-white/60'
                }`}
              >
                {reservation.secondGuestName}
              </button>
            </div>
          ) : null}

          {/* Form Content */}
          <div className="p-5 space-y-4" id="police-form-content">
            {/* Row 1: Name */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Nom / Name</label>
                <input type="text" value={formData.nom} onChange={e => setFormData(p => ({...p, nom: e.target.value}))} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Prenom / First name</label>
                <input type="text" value={formData.prenom} onChange={e => setFormData(p => ({...p, prenom: e.target.value}))} className={inputClass} />
              </div>
            </div>
            
            {/* Row 2: Birth */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Date de naissance</label>
                <input type="date" value={formData.dateNaissance} onChange={e => setFormData(p => ({...p, dateNaissance: e.target.value}))} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Lieu de naissance</label>
                <input type="text" value={formData.lieuNaissance} onChange={e => setFormData(p => ({...p, lieuNaissance: e.target.value}))} className={inputClass} />
              </div>
            </div>
            
            {/* Row 3: Parents */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Pere / Father</label>
                <input type="text" value={formData.pere} onChange={e => setFormData(p => ({...p, pere: e.target.value}))} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Mere / Mother</label>
                <input type="text" value={formData.mere} onChange={e => setFormData(p => ({...p, mere: e.target.value}))} className={inputClass} />
              </div>
            </div>
            
            {/* Row 4: Profession & Address */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Profession</label>
                <input type="text" value={formData.profession} onChange={e => setFormData(p => ({...p, profession: e.target.value}))} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Domicile habituel</label>
                <input type="text" value={formData.domicile} onChange={e => setFormData(p => ({...p, domicile: e.target.value}))} className={inputClass} />
              </div>
            </div>
            
            {/* Row 5: Nationality & ID type */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Nationalite</label>
                <input type="text" value={formData.nationalite} onChange={e => setFormData(p => ({...p, nationalite: e.target.value}))} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Piece d&apos;identite</label>
                <input type="text" value={formData.pieceIdentite} onChange={e => setFormData(p => ({...p, pieceIdentite: e.target.value}))} className={inputClass} />
              </div>
            </div>
            
            {/* Row 6: Passport details */}
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className={labelClass}>N° document</label>
                <input type="text" value={formData.passportNo} onChange={e => setFormData(p => ({...p, passportNo: e.target.value}))} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Date delivrance</label>
                <input type="date" value={formData.passportDate} onChange={e => setFormData(p => ({...p, passportDate: e.target.value}))} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Lieu delivrance</label>
                <input type="text" value={formData.passportLieu} onChange={e => setFormData(p => ({...p, passportLieu: e.target.value}))} className={inputClass} />
              </div>
            </div>
            
            {/* Row 7: Arrival */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Date d&apos;arrivee</label>
                <input type="date" value={formData.dateArrivee} onChange={e => setFormData(p => ({...p, dateArrivee: e.target.value}))} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Venant de / Coming from</label>
                <input type="text" value={formData.venantDe} onChange={e => setFormData(p => ({...p, venantDe: e.target.value}))} className={inputClass} />
              </div>
            </div>
            
            {/* Row 8: Visa */}
            <div>
              <label className={labelClass}>Validite du Visa</label>
              <input type="text" value={formData.validiteVisa} onChange={e => setFormData(p => ({...p, validiteVisa: e.target.value}))} placeholder="30 dni / 90 dni" className={`${inputClass} placeholder:text-white/20`} />
            </div>
            
            {/* Row 9: Departure */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Date de depart</label>
                <input type="date" value={formData.dateDepart} onChange={e => setFormData(p => ({...p, dateDepart: e.target.value}))} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Aliant a / Going to</label>
                <input type="text" value={formData.aliantA} onChange={e => setFormData(p => ({...p, aliantA: e.target.value}))} className={inputClass} />
              </div>
            </div>
            
            {/* Row 10: Transport */}
            <div>
              <label className={labelClass}>Mode de transport</label>
              <div className="flex gap-2 mt-2">
                {['Avion', 'Voiture', 'Moto', 'Bateau'].map(t => (
                  <button key={t} type="button" onClick={() => setFormData(p => ({...p, modeTransport: t}))}
                    className={`px-3 py-1.5 rounded border text-xs transition-all ${formData.modeTransport === t ? 'border-[#78b7ff] bg-[#78b7ff]/10 text-[#78b7ff]' : 'border-white/10 text-white/40 hover:border-white/20 hover:text-white/60'}`}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // Payment section with multiple payments tracking
function PaymentSection({ reservationId, totalAmount, currency, onPaymentChange }: { 
  reservationId: string; totalAmount: string; currency: string; onPaymentChange?: () => void;
}) {
  const [paymentsData, setPaymentsData] = React.useState<{
    id: string; amount: string; method: string; paidAt: string; notes: string | null;
  }[]>([]);
  const [showAddForm, setShowAddForm] = React.useState(false);
  const [newPayment, setNewPayment] = React.useState({ amount: '', method: 'card', paidAt: new Date().toISOString().split('T')[0], notes: '' });
  const [saving, setSaving] = React.useState(false);
  
  async function loadPayments() {
    const { getPayments } = await import("@/app/actions/komba");
    const data = await getPayments(reservationId);
    setPaymentsData(data as typeof paymentsData);
  }
  
  React.useEffect(() => { loadPayments(); }, [reservationId]);
  
  const totalPaid = paymentsData.reduce((sum, p) => sum + Number(p.amount), 0);
  const remaining = Number(totalAmount) - totalPaid;
  
  async function handleAddPayment() {
    if (!newPayment.amount || Number(newPayment.amount) <= 0) return;
    setSaving(true);
    const { addPayment } = await import("@/app/actions/komba");
  await addPayment({ reservationId, ...newPayment });
  setNewPayment({ amount: '', method: 'card', paidAt: new Date().toISOString().split('T')[0], notes: '' });
  setShowAddForm(false);
  loadPayments();
  onPaymentChange?.();
  setSaving(false);
  }
  
  async function handleDeletePayment(id: string) {
  if (!confirm("Izbrisi to placilo?")) return;
  const { deletePayment } = await import("@/app/actions/komba");
  await deletePayment(id);
  loadPayments();
  onPaymentChange?.();
  }
  
  const getMethodLabel = (method: string) => PAYMENT_METHODS.find(m => m.value === method)?.label || method;
  
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5 space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#94a3b8]">Placila</p>
        <LuxuryButton variant="ghost" onClick={() => setShowAddForm(!showAddForm)}>
          {showAddForm ? 'Preklici' : '+ Dodaj placilo'}
        </LuxuryButton>
      </div>
      
      {/* Summary */}
      <div className="grid grid-cols-3 gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/5">
        <div>
          <p className="text-xs text-white/40">Skupaj</p>
          <p className="text-lg font-light text-[#f1d07a]">{totalAmount} {currency}</p>
        </div>
        <div>
          <p className="text-xs text-white/40">Placano</p>
          <p className="text-lg font-light text-[#6fc8a3]">{totalPaid.toFixed(2)} {currency}</p>
        </div>
        <div>
          <p className="text-xs text-white/40">Preostanek</p>
          <p className={`text-lg font-light ${remaining <= 0 ? 'text-[#6fc8a3]' : 'text-[#ff6b6b]'}`}>
            {remaining.toFixed(2)} {currency}
          </p>
        </div>
      </div>
      
      {/* Add Payment Form */}
      {showAddForm && (
        <div className="p-4 rounded-xl border border-[#f1d07a]/30 bg-[#f1d07a]/5 space-y-3">
          <p className="text-xs font-medium text-[#f1d07a]">Novo placilo</p>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-white/40 mb-1">Znesek</label>
              <input 
                type="number" step="0.01" autoFocus
                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#f1d07a]/50 focus:outline-none"
                value={newPayment.amount}
                onChange={e => setNewPayment(p => ({ ...p, amount: e.target.value }))}
              />
            </div>
            <div>
              <label className="block text-xs text-white/40 mb-1">Nacin placila</label>
              <select 
                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#f1d07a]/50 focus:outline-none"
                value={newPayment.method}
                onChange={e => setNewPayment(p => ({ ...p, method: e.target.value }))}
              >
                {PAYMENT_METHODS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-white/40 mb-1">Datum placila</label>
              <input 
                type="date"
                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#f1d07a]/50 focus:outline-none"
                value={newPayment.paidAt}
                onChange={e => setNewPayment(p => ({ ...p, paidAt: e.target.value }))}
              />
            </div>
            <div>
              <label className="block text-xs text-white/40 mb-1">Opomba</label>
              <input 
                type="text"
                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#f1d07a]/50 focus:outline-none"
                placeholder="npr. depozit, koncno placilo..."
                value={newPayment.notes}
                onChange={e => setNewPayment(p => ({ ...p, notes: e.target.value }))}
              />
            </div>
          </div>
          <LuxuryButton variant="gold" onClick={handleAddPayment} disabled={saving || !newPayment.amount}>
            {saving ? 'Shranjujem...' : 'Shrani placilo'}
          </LuxuryButton>
        </div>
      )}
      
      {/* Payments List */}
      {paymentsData.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs text-white/40">Zgodovino placil</p>
          {paymentsData.map(p => (
            <div key={p.id} className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/5 group">
              <div className="flex items-center gap-4">
                <div>
                  <p className="text-sm font-medium text-[#6fc8a3]">{p.amount} {currency}</p>
                  <p className="text-xs text-white/40">{p.paidAt}</p>
                </div>
                <LuxuryBadge variant={p.method === 'card' ? 'ocean' : p.method === 'transfer' ? 'petrol' : p.method === 'orange_money' ? 'gold' : 'default'}>
                  {getMethodLabel(p.method)}
                </LuxuryBadge>
                {p.notes && <span className="text-xs text-white/50">{p.notes}</span>}
              </div>
              <button 
                onClick={() => handleDeletePayment(p.id)}
                className="opacity-0 group-hover:opacity-100 text-xs text-[#ff6b6b] hover:text-[#ff8b8b] transition-all"
              >
                Izbrisi
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============ MAIN APP ============
export default function KombaCabanaApp() {
  // ALL HOOKS MUST BE AT THE TOP - before any conditional returns
  const { data, error, isLoading } = useSWR("dashboard", getDashboardData, {
    refreshInterval: 0,
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
  });

  const [tab, setTab] = React.useState("bungalows");
  const [selectedReservationId, setSelectedReservationId] = React.useState("");
  const [showNewBookingForm, setShowNewBookingForm] = React.useState(false);
  const [showPricingModal, setShowPricingModal] = React.useState(false);
  const [showPendingTransfers, setShowPendingTransfers] = React.useState(false);
  const [showPendingExcursions, setShowPendingExcursions] = React.useState(false);
  const [showTaxes, setShowTaxes] = React.useState(false);
  const [pricingCalc, setPricingCalc] = React.useState({
    excursionId: "",
    boatId: "",
    pax: 2,
    includeEntrance: true,
    lunchProviderId: "",
    routeId: "",
    transferBoatId: "",
    transferPax: 2,
  });
  const [pricingTab, setPricingTab] = React.useState<'calculator' | 'schedule'>('calculator');
  const [message, setMessage] = React.useState("");
  const [reservationDraft, setReservationDraft] = React.useState({ guestName: "", bungalow: "Bungalow I", pax: 2, arrival: today(), departure: "", bookingSource: "Booking.com", agencyName: "" });
  const [orderDraft, setOrderDraft] = React.useState({ name: "", category: "Razno", qty: 1, priceAr: 0, eventDate: today() });
  const [transferDraft, setTransferDraft] = React.useState({ type: "arrival" as "arrival" | "departure", date: today(), routeId: "", boatId: "", paymentStatus: "UNPAID" as "PAID" | "UNPAID" });
  const [excursionDraft, setExcursionDraft] = React.useState({ excursionId: "", date: today(), boatId: "", paymentStatus: "UNPAID" as "PAID" | "UNPAID" });
  
  // Collapsible states for GuestCard (outside to prevent reset on refresh)
  const [showDates, setShowDates] = React.useState(false);
  const [showTransfers, setShowTransfers] = React.useState(false);
  const [showExcursions, setShowExcursions] = React.useState(false);
  const [expandedExcursionId, setExpandedExcursionId] = React.useState<string | null>(null);
  const [showPoliceForm, setShowPoliceForm] = React.useState(false);
  const [showSecondGuestData, setShowSecondGuestData] = React.useState(false);
  const [copiedLink, setCopiedLink] = React.useState<null | 'first' | 'second'>(null);
  const [generatingLink, setGeneratingLink] = React.useState<null | 'first' | 'second'>(null);
  const [newRate, setNewRate] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  
  // PIN Protection State
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);
  const [pin, setPin] = React.useState('');
  const [pinError, setPinError] = React.useState('');
  
  const ADMIN_PIN = '2580';
  
  // Check localStorage on mount for auth
  React.useEffect(() => {
    const saved = localStorage.getItem('kc_admin_auth');
    if (saved === 'true') {
      setIsAuthenticated(true);
    }
  }, []);
  
  const handlePinKey = (key: string) => {
    if (key === 'C') {
      setPin('');
      setPinError('');
    } else if (key === '←') {
      setPin(p => p.slice(0, -1));
      setPinError('');
    } else if (pin.length < 4) {
      const newPin = pin + key;
      setPin(newPin);
      setPinError('');
      if (newPin.length === 4) {
        if (newPin === ADMIN_PIN) {
          setIsAuthenticated(true);
          localStorage.setItem('kc_admin_auth', 'true');
        } else {
          setPinError('Napačna koda');
          setTimeout(() => setPin(''), 500);
        }
      }
    }
  };
  
  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('kc_admin_auth');
    setPin('');
  };

  const reservations: Reservation[] = data?.reservations || [];
  const exchangeRate = data?.exchangeRate || DEFAULT_RATE;
  const dbRoutes = data?.routes || [];
  const dbSellingPricing = data?.sellingPricing || [];
  const dbBoats = data?.boats || [];
  const dbExcursions = data?.excursions || [];
  const dbExcursionSellingPricing = data?.excursionSellingPricing || [];
  const dbLunchProviders = data?.lunchProviders || [];
  const dbMealProducts = data?.mealProducts || [];
  const dbAllProducts = data?.allProducts || [] as { id: string; name: string; category: string; priceAr: number }[];
  const dbScheduledExcursions = data?.scheduledExcursions || [] as { id: string; date: string; excursionType: string; isOption: boolean; notes: string | null; guests: { reservationId: string; guestName: string; bungalow: string; pax: number }[] }[];
  
  // Helper to get meal plan price per day from products (isce po ID iz Admin cenika - kategorija "Prehrana")
  const getMealPlanPrice = (mealPlan: string): number => {
    const productId = mealPlan === 'B' ? 'meal-breakfast' : mealPlan === 'HB' ? 'meal-hb' : mealPlan === 'FB' ? 'meal-fb' : '';
    const product = dbMealProducts.find((p: { id: string; priceAr: number }) => p.id === productId);
    return product ? product.priceAr / exchangeRate : 0;
  };
  
  // Helper to get meal plan price in Ariary (for order items)
  const getMealPlanPriceAr = (mealPlan: string): number => {
    const productId = mealPlan === 'B' ? 'meal-breakfast' : mealPlan === 'HB' ? 'meal-hb' : mealPlan === 'FB' ? 'meal-fb' : '';
    const product = dbMealProducts.find((p: { id: string; priceAr: number }) => p.id === productId);
    return product ? product.priceAr : 0;
  };
  
  // Helper to get meal plan name for order items
  const getMealPlanName = (mealPlan: string): string => {
    const productId = mealPlan === 'B' ? 'meal-breakfast' : mealPlan === 'HB' ? 'meal-hb' : mealPlan === 'FB' ? 'meal-fb' : '';
    const product = dbMealProducts.find((p: { id: string; name: string }) => p.id === productId);
    return product ? product.name : mealPlan;
  };
  
  // Handle check-in with meal plan and transfer logic
  const handleCheckIn = async (res: Reservation) => {
    // Helper to format date string (YYYY-MM-DD)
    const formatDateStr = (dateVal: string | Date | null | undefined): string => {
      if (!dateVal) return '';
      const d = typeof dateVal === 'string' ? dateVal : new Date(dateVal).toISOString();
      return d.split('T')[0];
    };
    
    // 0. Add ACCOMMODATION (remaining balance for stay) to order
    // Include payment history info
    const totalAmount = res.totalAmount ? Number(res.totalAmount) : 0;
    const amountPaid = res.amountPaid ? Number(res.amountPaid) : 0;
    const remainingEur = totalAmount - amountPaid;
    
    // Build payment info text from payments array
    const payments = res.payments || [];
    const paymentInfoParts = payments.map((p: { amount: number | string; method: string; paidAt: string }) => {
      const amt = Number(p.amount);
      const method = p.method === 'card' ? 'kartica' : p.method === 'cash' ? 'gotovina' : p.method === 'transfer' ? 'nakazilo' : p.method;
      const date = new Date(p.paidAt).toLocaleDateString('sl-SI');
      return `${amt.toFixed(2)} EUR (${method}, ${date})`;
    });
    const paymentInfo = paymentInfoParts.length > 0 ? ` | Placano: ${paymentInfoParts.join(', ')}` : '';
    
    const arr = res.arrival ? new Date(res.arrival) : null;
    const dep = res.departure ? new Date(res.departure) : null;
    const nights = arr && dep ? Math.ceil((dep.getTime() - arr.getTime()) / (1000 * 60 * 60 * 24)) : 0;
    const remainingAr = Math.round(remainingEur * exchangeRate);
    
    // Always add accommodation info (even if fully paid, for record)
    // Use arrival date for eventDate so statistics count it in correct month
    const arrivalDateStr = formatDateStr(res.arrival);
    await addOrderItem(res.id, {
      name: `Bivanje ${res.bungalow} (${nights} noci, ${res.pax} oseb) | Skupaj: ${totalAmount.toFixed(2)} EUR${paymentInfo}`,
      category: 'Bivanje',
      qty: 1,
      priceAr: remainingAr,
      paymentStatus: remainingEur > 0 ? 'UNPAID' : 'PAID',
      eventDate: arrivalDateStr
    });
    
    // 1. Add MEAL PLAN to order ONLY if PAID (prepaid)
    // If UNPAID - staff will add meals daily via Bar app
    if (res.mealPlan && res.mealPlanPaymentStatus === 'PAID') {
      const arr = res.arrival ? new Date(res.arrival) : null;
      const dep = res.departure ? new Date(res.departure) : null;
      const days = arr && dep ? Math.ceil((dep.getTime() - arr.getTime()) / (1000 * 60 * 60 * 24)) : 0;
      const totalQty = res.pax * days;
      const pricePerUnitAr = getMealPlanPriceAr(res.mealPlan);
      const mealName = getMealPlanName(res.mealPlan);
      
      if (totalQty > 0 && pricePerUnitAr > 0) {
        await addOrderItem(res.id, {
          name: `${mealName} (${res.pax} oseb × ${days} dni)`,
          category: 'Prehrana',
          qty: 1,
          priceAr: pricePerUnitAr * totalQty,
          paymentStatus: 'PAID',
          eventDate: arrivalDateStr
        });
      }
    }
    
    // 2. Add ARRIVAL transfer to order (if exists)
    // Note: Transfer data is in res.transfers.arrival (mapped from transfers table)
    const arrivalTransfer = res.transfers?.arrival;
    if (arrivalTransfer && arrivalTransfer.route && arrivalTransfer.route !== '') {
      const routeId = arrivalTransfer.route;
      const boatId = arrivalTransfer.boatId || '';
      const pax = res.pax || 1;
      const isPaid = arrivalTransfer.paymentStatus === 'PAID';
      const totalPriceEur = arrivalTransfer.guestPrice || getTransferGuestPrice(routeId, boatId, pax);
      const totalPriceAr = Math.round(totalPriceEur * exchangeRate); // Convert EUR to Ariary
      const routeName = dbRoutes.find((r: { id: string; name: string }) => r.id === routeId)?.name || routeId;
      const boatName = dbBoats.find((b: { id: string; name: string }) => b.id === boatId)?.name || '';
      // Get arrival date as string for eventDate (YYYY-MM-DD format)
      const arrivalDateStr = formatDateStr(res.arrival);
      
      await addOrderItem(res.id, {
        name: `Transfer ARRIVAL: ${routeName}${boatName ? ` (${boatName})` : ''} - ${pax} pax`,
        category: 'Transfer',
        qty: 1,
        priceAr: isPaid ? 0 : totalPriceAr, // If paid, add with 0 price (evidence only)
        paymentStatus: isPaid ? 'PAID' : 'UNPAID',
        eventDate: arrivalDateStr // Transfer happens on arrival date
      });
    }
    
    // 3. Add DEPARTURE transfer to order (if exists)
    const departureTransfer = res.transfers?.departure;
    if (departureTransfer && departureTransfer.route && departureTransfer.route !== '') {
      const routeId = departureTransfer.route;
      const boatId = departureTransfer.boatId || '';
      const pax = res.pax || 1;
      const isPaid = departureTransfer.paymentStatus === 'PAID';
      const totalPriceEur = departureTransfer.guestPrice || getTransferGuestPrice(routeId, boatId, pax);
      const totalPriceAr = Math.round(totalPriceEur * exchangeRate); // Convert EUR to Ariary
      const routeName = dbRoutes.find((r: { id: string; name: string }) => r.id === routeId)?.name || routeId;
      const boatName = dbBoats.find((b: { id: string; name: string }) => b.id === boatId)?.name || '';
      // Get departure date as string for eventDate (YYYY-MM-DD format)
      const departureDateStr = formatDateStr(res.departure);
      
      await addOrderItem(res.id, {
        name: `Transfer DEPARTURE: ${routeName}${boatName ? ` (${boatName})` : ''} - ${pax} pax`,
        category: 'Transfer',
        qty: 1,
        priceAr: isPaid ? 0 : totalPriceAr, // If paid, add with 0 price (evidence only)
        paymentStatus: isPaid ? 'PAID' : 'UNPAID',
        eventDate: departureDateStr // Transfer happens on departure date
      });
    }
    
    // 4. Add EXCURSIONS to order
    // UNPAID excursions ��� add with price now (needs to be paid)
    // PAID excursions → add as evidence only (0 Ar) - will be noted for the excursion date
    if (res.excursions && res.excursions.length > 0) {
      for (const exc of res.excursions) {
        const excursion = dbExcursions.find((e: { id: string; name: string }) => e.id === exc.excursionId);
        const excursionName = excursion?.name || 'Izlet';
        const excDate = formatDateStr(exc.date);
        const isPaid = exc.paymentStatus === 'PAID';
        const boatName = dbBoats.find((b: { id: string; name: string }) => b.id === exc.boatId)?.name || '';
        const lunchProvider = dbLunchProviders.find((lp: { id: string; name: string }) => lp.id === exc.lunchProviderId);
        
        // Build included items list
        const included: string[] = [];
        if (boatName) included.push(boatName);
        if (exc.entranceFee && exc.entranceFee > 0) included.push('vstopnina');
        if (lunchProvider) included.push(`kosilo: ${lunchProvider.name}`);
        const includedText = included.length > 0 ? ` | Vklj: ${included.join(', ')}` : '';
        
        // Total price = guest price + entrance fee + lunch price (all in EUR, convert to Ariary)
        const totalPriceEur = (exc.guestPrice || 0) + (exc.entranceFee || 0) + (exc.lunchPrice || 0);
        const totalPriceAr = Math.round(totalPriceEur * exchangeRate); // Convert EUR to Ariary
        
        await addOrderItem(res.id, {
          name: `Izlet: ${excursionName} - ${exc.pax} pax${includedText}`,
          category: 'Izlet',
          qty: 1,
          priceAr: isPaid ? 0 : totalPriceAr, // If paid, add with 0 price (evidence only)
          paymentStatus: isPaid ? 'PAID' : 'UNPAID',
          eventDate: excDate // Excursion happens on specific date
        });
      }
    }
    
    // 5. Create first delivery note for today (so transfers/excursions show under the day)
    const { getOrCreateDeliveryNote } = await import('@/app/actions/delivery');
    await getOrCreateDeliveryNote(res.id, res.bungalow, res.guestName);
    
    // Update check-in timestamp
    await handleUpdateReservation(res.id, { checkedInAt: new Date().toISOString() });
    showMsg("Check-in uspesen!");
  };
  
  // Build TRANSFER_ROUTES from database
  const TRANSFER_ROUTES = ["", ...dbRoutes.filter((r: { id: string }) => r.id !== 'route-airport-port').map((r: { name: string }) => r.name)];
  
  // Build EXCURSION options from database
  const EXCURSION_OPTIONS = ["", ...dbExcursions.map((e: { name: string }) => e.name)];
  
  // Helper to get TOTAL guest price for transfer (price per person * pax)
  // routeId is the route ID (e.g. "route-nosy-be"), not the route name
  const getTransferGuestPrice = (routeId: string, boatId: string, pax: number): number => {
    if (!routeId || !boatId) return 0;
    const pricing = dbSellingPricing.find((sp: { routeId: string; boatId: string }) => 
      sp.routeId === routeId && sp.boatId === boatId
    );
    if (!pricing) return 0;
    const paxKey = `pricePax${Math.min(Math.max(pax, 1), 6)}` as keyof typeof pricing;
    const pricePerPerson = Number(pricing[paxKey]) || 0;
    return pricePerPerson * pax; // Total price = price per person * number of guests
  };
  
  // Helper to get TOTAL guest price for excursion (price per person * pax)
  const getExcursionGuestPrice = (excursionId: string, boatId: string, pax: number): number => {
    if (!excursionId || !boatId) return 0;
    const pricing = dbExcursionSellingPricing.find((esp: { excursionId: string; boatId: string }) => 
      esp.excursionId === excursionId && esp.boatId === boatId
    );
    if (!pricing) return 0;
    const paxKey = `pricePax${Math.min(Math.max(pax, 1), 6)}` as keyof typeof pricing;
    const pricePerPerson = Number(pricing[paxKey]) || 0;
    return pricePerPerson * pax; // Total price = price per person * number of guests
  };
  
  const activeReservation = () => reservations.find(r => r.id === selectedReservationId);

  const showMsg = (text: string) => {
    setMessage(text);
    setTimeout(() => setMessage(""), 3000);
  };

  const refresh = () => mutate("dashboard");

  // ============ ACTIONS ============
async function handleCreateReservation() {
  const guestName = guestNameRef.current?.value || '';
  const agencyName = agencyNameRef.current?.value || '';
  const agencyCommission = agencyCommissionRef.current?.value ? Number(agencyCommissionRef.current.value) : 0;
  if (!guestName.trim() || !reservationDraft.departure) {
  showMsg("Izpolni vsa polja!");
  return;
  }
  setSaving(true);
  const hasOverlap = await checkOverlap(reservationDraft.bungalow, reservationDraft.arrival, reservationDraft.departure);
  if (hasOverlap) {
  showMsg("Prekrivanje z obstojecim gostom!");
  setSaving(false);
  return;
  }
  const id = await createReservation({ ...reservationDraft, guestName, agencyName, agencyCommission });
  setReservationDraft({ guestName: "", bungalow: "Bungalow I", pax: 2, arrival: today(), departure: "", bookingSource: "Booking.com", agencyName: "" });
  if (guestNameRef.current) guestNameRef.current.value = '';
  if (agencyNameRef.current) agencyNameRef.current.value = '';
  if (agencyCommissionRef.current) agencyCommissionRef.current.value = '';
  setSelectedReservationId(id);
  refresh();
  showMsg("Rezervacija ustvarjena!");
  setSaving(false);
  }

  async function handleUpdateReservation(id: string, updates: Parameters<typeof updateReservation>[1]) {
    setSaving(true);
    await updateReservation(id, updates);
    refresh();
    setSaving(false);
  }

  async function handleUpdateTransfer(reservationId: string, type: 'arrival' | 'departure', data: Parameters<typeof updateTransfer>[2]) {
    setSaving(true);
    await updateTransfer(reservationId, type, data);
    refresh();
    setSaving(false);
  }

  async function handleDeleteReservation(id: string) {
    if (!confirm("Ali res zelis izbrisati to rezervacijo in kartico gosta?")) return;
    setSaving(true);
    try {
      const { deleteReservationAndGuest } = await import("@/app/actions/komba");
      await deleteReservationAndGuest(id, true);
      setSelectedReservationId("");
      refresh();
      showMsg("Rezervacija in kartica gosta izbrisana!");
      setTab("reservations");
    } catch (err) {
      console.error("[v0] Error deleting reservation:", err);
      showMsg("Napaka pri brisanju rezervacije: " + (err instanceof Error ? err.message : "Neznana napaka"));
    } finally {
      setSaving(false);
    }
  }

  async function handleAddOrder() {
    const reservation = activeReservation();
    if (!reservation || !orderDraft.name.trim()) return;
    setSaving(true);
  await addOrderItem(reservation.id, orderDraft);
  setOrderDraft(prev => ({ name: "", category: prev.category, qty: 1, priceAr: 0, eventDate: prev.eventDate }));
    refresh();
    setSaving(false);
  }

  async function handleDeleteOrder(id: string) {
    setSaving(true);
    await deleteOrderItem(id);
    refresh();
    setSaving(false);
  }

  async function handleSaveExchangeRate() {
    const rate = Number(newRate);
    if (rate > 0) {
      setSaving(true);
      await updateExchangeRate(rate);
      setNewRate("");
      refresh();
      showMsg("Tecaj shranjen!");
      setSaving(false);
    }
  }

  // ============ STATUS HELPERS ============
  function getStatusBadge(status: string) {
    const variants: Record<string, "petrol" | "gold" | "danger" | "ocean" | "default"> = {
      ARRIVING_TODAY: "ocean",
      RESERVED: "gold",
      IN_HOUSE: "petrol",
      DEPARTING_TODAY: "danger",
      CHECKED_OUT: "default",
      CANCELLED: "danger",
    };
    return <LuxuryBadge variant={variants[status] || "default"}>{status.replace(/_/g, " ")}</LuxuryBadge>;
  }

  function getBungalowGuest(bungalow: string, when: "now" | "next"): Reservation | undefined {
    const todayStr = today();
    // Normalize so the "Bungalov"/"Bungalow" spelling difference (and casing) in stored
    // reservations doesn't break matching. Match as a word boundary to avoid
    // "Ocean Bungalow I" matching "Ocean Bungalow II".
    const normalize = (s: string) => s.toLowerCase().replace(/bungalov\b/g, "bungalow");
    const bungalowRegex = new RegExp(`\\b${normalize(bungalow)}\\b`);
    const active = reservations.filter(r => 
      bungalowRegex.test(normalize(r.bungalow || "")) && 
      r.status !== "CANCELLED" && 
      r.status !== "CHECKED_OUT"
    );
    if (when === "now") return active.find(r => r.arrival <= todayStr && r.departure >= todayStr);
    return active.filter(r => r.arrival > todayStr).sort((a, b) => a.arrival.localeCompare(b.arrival))[0];
  }

  // ============ SECTIONS ============
  function Bungalows() {
    const [expandedBungalow, setExpandedBungalow] = React.useState<string | null>(null);
    
    return (
      <section className="space-y-3">
        {BUNGALOWS.map(bungalow => {
          const now = getBungalowGuest(bungalow, "now");
          const next = getBungalowGuest(bungalow, "next");
          const isExpanded = expandedBungalow === bungalow;
          const status = now ? now.status.replace(/_/g, " ") : "AVAILABLE";
          
          // Status colors
          const statusColors: Record<string, string> = {
            "ARRIVING TODAY": "border-[#78b7ff]/40 bg-[#78b7ff]/10",
            "RESERVED": "border-[#f1d07a]/40 bg-[#f1d07a]/10",
            "IN HOUSE": "border-[#6fc8a3]/40 bg-[#6fc8a3]/10",
            "DEPARTING TODAY": "border-[#ef4444]/40 bg-[#ef4444]/10",
            "AVAILABLE": "border-white/10 bg-white/[0.02]",
          };
          const statusTextColors: Record<string, string> = {
  "ARRIVING TODAY": "text-[#78b7ff]",
  "RESERVED": "text-[#f1d07a]",
            "IN HOUSE": "text-[#6fc8a3]",
            "DEPARTING TODAY": "text-[#ef4444]",
            "AVAILABLE": "text-white/40",
          };
          
          // Check if guest is checked in (In house)
          const isInHouse = now?.checkedInAt && !now?.checkedOutAt;
          
          return (
            <div key={bungalow} className={`overflow-hidden rounded-2xl border bg-[rgba(15,23,42,0.5)] backdrop-blur-lg ${isInHouse ? 'border-[#f1d07a] border-2 shadow-[0_0_15px_rgba(241,208,122,0.3)]' : 'border-[#f1d07a]/30'}`}>
              {/* Collapsed Button View */}
              <button
                onClick={() => setExpandedBungalow(isExpanded ? null : bungalow)}
                className={`w-full flex items-center justify-between p-4 transition-all ${statusColors[status] || statusColors["AVAILABLE"]}`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${now ? (status === "IN HOUSE" ? "bg-[#6fc8a3]" : status === "ARRIVING TODAY" ? "bg-[#78b7ff]" : status === "DEPARTING TODAY" ? "bg-[#ef4444]" : "bg-[#f1d07a]") : "bg-white/20"}`} />
                  <div className="text-left">
                    <h3 className="font-[family-name:var(--font-manrope)] bg-gradient-to-r from-white via-[#f1d07a] to-[#d4a84b] bg-clip-text text-sm sm:text-base font-medium tracking-wide text-transparent whitespace-nowrap">{bungalow}</h3>
                    {now ? (
                      <p className="text-xs text-white/80 mt-0.5">
                        {now.guestName}
                        {now.checkedInAt ? (
                          <span className="ml-2 text-[#6fc8a3] font-medium">In house</span>
                        ) : now.arrival === today() ? (
                          <span className="ml-2 text-[#78b7ff] font-medium">Arriving</span>
                        ) : null}
                      </p>
                    ) : next ? (
                      <p className="text-xs text-white/60 mt-0.5">
                        <span className="text-[#78b7ff]">Naslednji:</span> <span className="text-white/80">{next.guestName}</span>
                        <span className="ml-1 text-white/50">({new Date(next.arrival).toLocaleDateString('sl-SI', { day: 'numeric', month: 'short' })})</span>
                      </p>
                    ) : null}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {/* Show unpaid balance on collapsed row — matches the invoice (services + bar).
                      Excursions are already included in orderItems, so we must NOT add them again
                      from the excursions list, otherwise the total would be double-counted. */}
                  {now && (() => {
                    const unpaidServicesAr = (now.orderItems || [])
                      .filter((item: { paymentStatus: string }) => item.paymentStatus === 'UNPAID')
                      .reduce((sum: number, item: { priceAr: number }) => sum + Number(item.priceAr || 0), 0);
                    const barAr = now.deliveryNotesTotal || 0;
                    const totalUnpaidAr = unpaidServicesAr + barAr;
                    const totalUnpaidEur = totalUnpaidAr / exchangeRate;
                    return totalUnpaidEur > 0 ? (
                      <span className="text-sm font-semibold text-[#78b7ff]">{totalUnpaidEur.toLocaleString('sl-SI', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} EUR</span>
                    ) : null;
                  })()}
                  <span className={`text-[10px] font-medium uppercase tracking-wider ${statusTextColors[status] || statusTextColors["AVAILABLE"]}`}>
                    {status}
                  </span>
                  <ChevronDown className={`w-5 h-5 text-[#f1d07a]/60 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                </div>
              </button>
              
              {/* Expanded Content */}
              {isExpanded && (
                <div className="p-4 pt-0 space-y-4 border-t border-white/[0.06]">
                  {/* NOW Card */}
                  <div className="mt-4 rounded-xl border border-[#6fc8a3]/20 bg-[#6fc8a3]/5 p-4">
                    <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-[#6fc8a3]">NOW</p>
                    {now ? (
                      <>
                        <button className="mt-2 text-left text-sm font-light text-[#f8fafc] transition-colors hover:text-[#f1d07a]" onClick={() => { setSelectedReservationId(now.id); setTab("guest"); }}>
                          {now.guestName}
                          <span className="mt-1 block text-xs font-normal text-[#94a3b8]">{now.arrival} → {now.departure}</span>
                        </button>
                        <div className="mt-2 flex flex-wrap gap-1">
                          {now.mealPlan && <LuxuryBadge variant="gold">{now.mealPlan}</LuxuryBadge>}
                          {now.bookingSource && (
                            <LuxuryBadge variant={now.bookingSource === 'Booking.com' ? 'ocean' : now.bookingSource === 'Airbnb' ? 'danger' : 'gold'}>
                              {now.bookingSource === 'Booking.com' ? 'Booking' : now.bookingSource}
                            </LuxuryBadge>
                          )}
                          {now.honeymoon && <LuxuryBadge variant="gold"><Heart className="h-3 w-3" /></LuxuryBadge>}
                          {now.allergies && <LuxuryBadge variant="danger"><Leaf className="h-3 w-3" /></LuxuryBadge>}
                        </div>
                        {/* Remaining balance to pay — matches the invoice: unpaid services + bar.
                            Excursions are already part of orderItems, so they are NOT added separately. */}
                        {(() => {
                          // Sum all UNPAID order items (in Ariary)
                          const unpaidOrderItemsAr = (now.orderItems || [])
                            .filter((item: { paymentStatus: string }) => item.paymentStatus === 'UNPAID')
                            .reduce((sum: number, item: { priceAr: number }) => sum + Number(item.priceAr || 0), 0);
                          const barAr = now.deliveryNotesTotal || 0;
                          const unpaidEur = (unpaidOrderItemsAr + barAr) / exchangeRate;
                          
                          return unpaidEur > 0 ? (
                            <div className="mt-3 flex items-center justify-between rounded-lg bg-[#f1d07a]/10 px-3 py-2">
                              <span className="text-[10px] uppercase tracking-wider text-[#f1d07a]/70">Za placilo</span>
                              <span className="text-sm font-semibold text-[#f1d07a]">{unpaidEur.toFixed(2)} EUR</span>
                            </div>
                          ) : null;
                        })()}
                        {/* Delivery Note Button - only if checked in */}
                        {now.checkedInAt && (
                          <Link
                            href={(() => {
                              // If shared invoice, link to main reservation's dobavnica
                              if (now.groupId) {
                                const mainRes = reservations.find(r => r.groupId === now.groupId && r.isMainReservation);
                                if (mainRes?.sharedInvoice) {
                                  return `/dobavnice/${mainRes.id}`;
                                }
                              }
                              return `/dobavnice/${now.id}`;
                            })()}
                            className="mt-3 flex items-center justify-center gap-2 w-full rounded-lg border border-[#6fc8a3]/30 bg-[#6fc8a3]/10 px-3 py-2 text-xs font-medium text-[#6fc8a3] transition-all hover:bg-[#6fc8a3]/20"
                          >
                            <ReceiptText className="h-3.5 w-3.5" />
                            {(() => {
                              if (now.groupId) {
                                const mainRes = reservations.find(r => r.groupId === now.groupId && r.isMainReservation);
                                if (mainRes?.sharedInvoice) {
                                  return "Skupna dobavnica";
                                }
                              }
                              return "Dobavnica danes";
                            })()}
                          </Link>
                        )}
                      </>
                    ) : <p className="mt-2 text-sm font-light text-[#94a3b8]">Bungalov trenutno prazen.</p>}
                  </div>
                  
                  {/* NEXT Card */}
                  <div className="rounded-xl border border-[#78b7ff]/20 bg-[#78b7ff]/5 p-4">
                    <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-[#78b7ff]">NEXT</p>
                    {next ? (
                      <>
                        <button 
                          className="mt-2 w-full text-left rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 transition-all hover:border-[#f1d07a]/40 hover:bg-[#f1d07a]/10 group" 
                          onClick={() => { setSelectedReservationId(next.id); setTab("guest"); }}
                        >
                          <span className="font-medium text-white group-hover:text-[#f1d07a]">{next.guestName}</span>
                          <span className="mt-0.5 block text-xs text-white/50">{next.arrival}</span>
                        </button>
                        <div className="mt-2 flex flex-wrap gap-1">
                          {next.mealPlan && <LuxuryBadge variant="gold">{next.mealPlan}</LuxuryBadge>}
                          {next.bookingSource && (
                            <LuxuryBadge variant={next.bookingSource === 'Booking.com' ? 'ocean' : next.bookingSource === 'Airbnb' ? 'danger' : 'gold'}>
                              {next.bookingSource === 'Booking.com' ? 'Booking' : next.bookingSource}
                            </LuxuryBadge>
                          )}
                          {next.honeymoon && <LuxuryBadge variant="gold"><Heart className="h-3 w-3" /></LuxuryBadge>}
                          {next.allergies && <LuxuryBadge variant="danger"><Leaf className="h-3 w-3" /></LuxuryBadge>}
                        </div>
                      </>
                    ) : <p className="mt-2 text-sm text-white/40">Ni naslednje rezervacije.</p>}
                  </div>
                  
                  {/* Action buttons */}
                  <div className="flex gap-3">
                    {now && now.status === "ARRIVING_TODAY" && <LuxuryButton variant="petrol" onClick={() => handleUpdateReservation(now.id, { status: "IN_HOUSE" })}>Check In</LuxuryButton>}
                    {now && now.status === "IN_HOUSE" && <LuxuryButton variant="danger" onClick={() => handleUpdateReservation(now.id, { status: "CHECKED_OUT" })}>Check Out</LuxuryButton>}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </section>
    );
  }

  const guestNameRef = React.useRef<HTMLInputElement>(null);
  const agencyNameRef = React.useRef<HTMLInputElement>(null);
  const agencyCommissionRef = React.useRef<HTMLInputElement>(null);

  // Memoized text inputs - NEVER re-render these
  const GuestNameInput = React.useMemo(() => (
    <div>
      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Ime gosta</label>
      <input
        ref={guestNameRef}
        type="text"
        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-[#78b7ff]/40 focus:outline-none"
        placeholder="John Doe"
      />
    </div>
  ), []);

  const AgencyNameInput = React.useMemo(() => (
    <div>
      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Ime agencije</label>
      <input
        ref={agencyNameRef}
        type="text"
        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-[#78b7ff]/40 focus:outline-none"
      />
    </div>
  ), []);

const AgencyCommissionInput = React.useMemo(() => (
  <div>
  <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Provizija (EUR)</label>
  <input
        ref={agencyCommissionRef}
        type="number"
        step="0.01"
        min="0"
        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-[#78b7ff]/40 focus:outline-none"
        placeholder="0.00"
      />
    </div>
  ), []);

  function GuestCard() {
  const reservation = activeReservation();
  
  if (!reservation) return <GlassCard className="p-4"><p className="text-white/40 text-center py-8">Izberi gosta iz seznama rezervacij.</p></GlassCard>;

    return (
      <section className="space-y-4">
        <GlassCard className="p-4 sm:p-6">
<div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
  <div>
    <p className="text-[10px] uppercase tracking-wider text-[#f1d07a]">Guest Profile</p>
    <h2 className="text-lg font-semibold text-white">{reservation.guestName}</h2>
  </div>
  <div className="flex items-center gap-2 flex-wrap">
  {reservation.mealPlan && (
  <LuxuryBadge variant="gold">{reservation.mealPlan}</LuxuryBadge>
  )}
  {reservation.bookingSource && (
  <LuxuryBadge variant={reservation.bookingSource === 'Booking.com' ? 'ocean' : reservation.bookingSource === 'Airbnb' ? 'danger' : 'gold'}>
  {reservation.bookingSource === 'Booking.com' ? 'Booking' : reservation.bookingSource}
  </LuxuryBadge>
  )}
  {/* Group indicator */}
  {reservation.groupId && (
    <span className="flex items-center gap-1 px-2 py-1 rounded-lg bg-purple-500/20 border border-purple-500/30 text-purple-300 text-xs">
      <Users className="h-3 w-3" />
      Skupina
    </span>
  )}
  <button
    onClick={() => setTab("orders")}
    className="flex items-center gap-1.5 rounded-lg border border-[#f1d07a]/30 bg-[#f1d07a]/10 px-3 py-1.5 text-xs font-medium text-[#f1d07a] hover:bg-[#f1d07a]/20 transition-all"
  >
    <ReceiptText className="h-3.5 w-3.5" />
    Dobavnica
  </button>
  </div>
  </div>

          {/* Check-in / Check-out Section */}
  <div className="mt-4 grid grid-cols-2 sm:flex gap-2 sm:gap-3">
  {!reservation.checkedInAt ? (
  <button
  onClick={() => handleCheckIn(reservation)}
  className="col-span-1 sm:flex-1 rounded-xl bg-gradient-to-r from-[#78b7ff]/20 to-[#5c8fd8]/20 border border-[#78b7ff]/30 py-2.5 sm:py-3 px-3 sm:px-4 text-xs sm:text-sm font-medium text-[#78b7ff] hover:from-[#78b7ff]/30 hover:to-[#5c8fd8]/30 transition-all"
  >
  Check-in
  </button>
  ) : (
  <div className="col-span-1 sm:flex-1 rounded-xl bg-[#78b7ff]/10 border border-[#78b7ff]/20 py-2.5 sm:py-3 px-3 sm:px-4 text-center">
  <p className="text-[10px] sm:text-xs text-[#78b7ff]/70">Checked in</p>
  <p className="text-xs sm:text-sm text-[#78b7ff]">{new Date(reservation.checkedInAt).toLocaleDateString('sl-SI')}</p>
  </div>
  )}
  <button
    onClick={() => setShowPoliceForm(true)}
    className="col-span-1 sm:flex-none flex items-center justify-center gap-1.5 sm:gap-2 rounded-xl bg-gradient-to-r from-[#f9a8d4]/20 to-[#f472b6]/20 border border-[#f9a8d4]/30 py-2.5 sm:py-3 px-3 sm:px-4 text-xs sm:text-sm font-medium text-[#f9a8d4] hover:from-[#f9a8d4]/30 hover:to-[#f472b6]/30 transition-all"
  >
    <FileText className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
    Policija
  </button>
  <button
    onClick={async () => {
      setGeneratingLink('first');
      try {
        const { getOrCreateCheckinToken } = await import("@/app/actions/checkin");
        const token = await getOrCreateCheckinToken(reservation.id, 'first');
        const url = `${window.location.origin}/checkin/${token}`;
        await navigator.clipboard.writeText(url);
        setCopiedLink('first');
        setTimeout(() => setCopiedLink(null), 2500);
      } catch {
        showMsg("Napaka pri kopiranju linka.");
      } finally {
        setGeneratingLink(null);
      }
    }}
    disabled={generatingLink !== null}
    className="col-span-1 sm:flex-none flex items-center justify-center gap-1.5 sm:gap-2 rounded-xl bg-gradient-to-r from-[#6fc8a3]/20 to-[#3a9d7a]/20 border border-[#6fc8a3]/30 py-2.5 sm:py-3 px-3 sm:px-4 text-xs sm:text-sm font-medium text-[#6fc8a3] hover:from-[#6fc8a3]/30 hover:to-[#3a9d7a]/30 transition-all disabled:opacity-50"
  >
    {copiedLink === 'first' ? <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Link2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
    {copiedLink === 'first' ? "Kopirano!" : (reservation.secondGuestName ? "Link gost 1" : "Link za gosta")}
  </button>
  {reservation.secondGuestName ? (
    <button
      onClick={async () => {
        setGeneratingLink('second');
        try {
          const { getOrCreateCheckinToken } = await import("@/app/actions/checkin");
          const token = await getOrCreateCheckinToken(reservation.id, 'second');
          const url = `${window.location.origin}/checkin/${token}`;
          await navigator.clipboard.writeText(url);
          setCopiedLink('second');
          setTimeout(() => setCopiedLink(null), 2500);
        } catch {
          showMsg("Napaka pri kopiranju linka.");
        } finally {
          setGeneratingLink(null);
        }
      }}
      disabled={generatingLink !== null}
      className="col-span-1 sm:flex-none flex items-center justify-center gap-1.5 sm:gap-2 rounded-xl bg-gradient-to-r from-[#6fc8a3]/20 to-[#3a9d7a]/20 border border-[#6fc8a3]/30 py-2.5 sm:py-3 px-3 sm:px-4 text-xs sm:text-sm font-medium text-[#6fc8a3] hover:from-[#6fc8a3]/30 hover:to-[#3a9d7a]/30 transition-all disabled:opacity-50"
    >
      {copiedLink === 'second' ? <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Link2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
      {copiedLink === 'second' ? "Kopirano!" : "Link gost 2"}
    </button>
  ) : null}
            
            {reservation.checkedInAt && !reservation.checkedOutAt ? (
              <button
                onClick={async () => {
                  await closeAllDeliveryNotesForReservation(reservation.id);
                  await handleUpdateReservation(reservation.id, { checkedOutAt: new Date().toISOString() });
                  showMsg("Check-out opravljen, dobavnice zaprte.");
                }}
                className="col-span-2 sm:col-span-1 sm:flex-1 rounded-xl bg-gradient-to-r from-[#f1d07a]/20 to-[#b8892f]/20 border border-[#f1d07a]/30 py-2.5 sm:py-3 px-3 sm:px-4 text-xs sm:text-sm font-medium text-[#f1d07a] hover:from-[#f1d07a]/30 hover:to-[#b8892f]/30 transition-all"
              >
                Check-out
              </button>
            ) : reservation.checkedOutAt ? (
              <div className="col-span-2 sm:col-span-1 sm:flex-1 rounded-xl bg-[#f1d07a]/10 border border-[#f1d07a]/20 py-2.5 sm:py-3 px-3 sm:px-4 text-center">
                <p className="text-[10px] sm:text-xs text-[#f1d07a]/70">Checked out</p>
                <p className="text-xs sm:text-sm text-[#f1d07a]">{new Date(reservation.checkedOutAt).toLocaleDateString('sl-SI')}</p>
              </div>
            ) : null}
          </div>
          
          {/* Undo check-in button */}
          {reservation.checkedInAt && !reservation.checkedOutAt && (
            <button
              onClick={async () => {
                await handleUpdateReservation(reservation.id, { checkedInAt: null });
                showMsg("Check-in razveljavljen.");
              }}
              className="mt-2 w-full rounded-xl bg-white/5 border border-white/10 py-2 px-4 text-xs font-medium text-white/40 hover:bg-white/10 hover:text-white/60 transition-all"
            >
              Razveljavi check-in
            </button>
          )}

          {/* Skupina / Povezane rezervacije */}
          <div className="mt-4 p-3 rounded-xl border border-purple-500/20 bg-purple-500/5">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-purple-400" />
                <span className="text-xs font-medium text-purple-300">Povezane rezervacije</span>
              </div>
              {!reservation.groupId ? (
                <button
                  onClick={async () => {
                    await createReservationGroup(reservation.id);
                    refresh();
                    showMsg("Skupina ustvarjena - ta rezervacija je glavna.");
                  }}
                  className="flex items-center gap-1 px-2 py-1 rounded-lg bg-purple-500/20 text-purple-300 text-[10px] hover:bg-purple-500/30 transition-colors"
                >
                  <Plus className="h-3 w-3" />
                  Ustvari skupino
                </button>
              ) : (
                <button
                  onClick={async () => {
                    await unlinkReservationFromGroup(reservation.id);
                    refresh();
                    showMsg("Rezervacija odstranjena iz skupine.");
                  }}
                  className="flex items-center gap-1 px-2 py-1 rounded-lg bg-red-500/20 text-red-300 text-[10px] hover:bg-red-500/30 transition-colors"
                >
                  <Unlink className="h-3 w-3" />
                  Odstrani iz skupine
                </button>
              )}
            </div>
            
            {reservation.groupId ? (
              <>
                {/* Show other reservations in this group */}
                {(() => {
                  const groupReservations = reservations.filter(r => r.groupId === reservation.groupId && r.id !== reservation.id);
                  if (groupReservations.length === 0) {
                    return <p className="text-[10px] text-white/40">Ni drugih rezervacij v skupini. Povezi drugo rezervacijo spodaj.</p>;
                  }
                  return (
                    <div className="space-y-1.5">
                      {groupReservations.map(gr => {
                        const shortBungalow = gr.bungalow?.split(';')[0]?.split('/')[0]?.trim() || gr.bungalow;
                        return (
                          <div 
                            key={gr.id} 
                            className="flex items-center justify-between p-2 rounded-lg bg-white/5 cursor-pointer hover:bg-white/10 transition-colors"
                            onClick={() => setSelectedReservationId(gr.id)}
                          >
                            <div className="flex items-center gap-2">
                              {gr.isMainReservation && <span className="text-[9px] px-1.5 py-0.5 rounded bg-purple-500/30 text-purple-200">GLAVNA</span>}
                              <span className="text-xs text-white">{shortBungalow}</span>
                              <span className="text-xs text-white/60">- {gr.guestName}</span>
                              <span className="text-[10px] text-white/40">({gr.pax} os)</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
                
                {/* Link another reservation */}
                <div className="mt-3 pt-3 border-t border-purple-500/20">
                  <label className="block text-[10px] text-white/40 mb-1.5">Povezi drugo rezervacijo</label>
                  <select
                    className="w-full rounded-lg border border-white/10 bg-[#1a1a2e] px-3 py-2 text-xs text-white focus:border-purple-500/50 focus:outline-none [&>option]:bg-[#1a1a2e] [&>option]:text-white"
                    value=""
                    onChange={async e => {
                      if (e.target.value) {
                        await linkReservationToGroup(e.target.value, reservation.groupId!);
                        refresh();
                        showMsg("Rezervacija povezana v skupino.");
                      }
                    }}
                  >
                    <option value="" className="bg-[#1a1a2e] text-white/60">Izberi rezervacijo...</option>
                    {reservations
                      .filter(r => !r.groupId && r.id !== reservation.id && r.status !== 'CHECKED_OUT' && r.status !== 'CANCELLED')
                      .map(r => {
                        const shortBungalow = r.bungalow?.split(';')[0]?.split('/')[0]?.trim() || r.bungalow;
                        return (
                          <option key={r.id} value={r.id} className="bg-[#1a1a2e] text-white">{shortBungalow} - {r.guestName} ({r.pax} os)</option>
                        );
                      })}
                  </select>
                </div>
                
                {/* Shared invoice checkbox */}
                <div className="mt-3 pt-3 border-t border-purple-500/20">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={(() => {
                        // Check main reservation's sharedInvoice setting
                        const mainRes = reservations.find(r => r.groupId === reservation.groupId && r.isMainReservation);
                        return mainRes?.sharedInvoice || reservation.sharedInvoice || false;
                      })()}
                      onChange={async e => {
                        // Update the MAIN reservation's sharedInvoice setting
                        const mainRes = reservations.find(r => r.groupId === reservation.groupId && r.isMainReservation);
                        const targetId = mainRes?.id || reservation.id;
                        const newValue = e.target.checked;
                        showMsg(newValue ? "Dobavnica bo skupna za vse bungalove." : "Dobavnice bodo ločene po bungalovih.");
                        await updateReservation(targetId, { sharedInvoice: newValue });
                        refresh();
                      }}
                      className="w-4 h-4 rounded border-purple-500/50 bg-white/5 text-purple-500 focus:ring-purple-500/50"
                    />
                    <div>
                      <span className="text-xs text-white">Skupna dobavnica</span>
                      <p className="text-[10px] text-white/40">Vsi artikli iz vseh bungalovov skupine gredo na eno dobavnico</p>
                    </div>
                  </label>
                </div>
              </>
            ) : (
              <p className="text-[10px] text-white/40">Ta rezervacija ni del skupine. Klikni "Ustvari skupino" za povezovanje več bungalovov.</p>
            )}
          </div>

            <div className="mt-6 space-y-4">
            <div>
              <label className="mb-1.5 block text-[10px] sm:text-[11px] font-medium uppercase tracking-wider text-white/40">Ime</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 sm:px-4 py-2.5 sm:py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.guestName}
                onBlur={async e => { await updateReservation(reservation.id, { guestName: e.target.value }); }}
              />
            </div>
            <LuxurySelect label="Bungalow" value={reservation.bungalow} onChange={v => handleUpdateReservation(reservation.id, { bungalow: v })} options={BUNGALOWS} />
            <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1.5 block text-[10px] sm:text-[11px] font-medium uppercase tracking-wider text-white/40">Pax</label>
              <input
                type="number"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 sm:px-4 py-2.5 sm:py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
  defaultValue={reservation.pax}
  onBlur={async e => { await updateReservation(reservation.id, { pax: Number(e.target.value) }); }}
  />
  </div>
  
  {/* Ime drugega gosta */}
  <div>
  <label className="mb-1.5 block text-[10px] sm:text-[11px] font-medium uppercase tracking-wider text-white/40">Drugi gost</label>
  <input
  key={`second-guest-${reservation.id}`}
  type="text"
  className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 sm:px-4 py-2.5 sm:py-3 text-sm text-white placeholder:text-white/30 focus:border-[#78b7ff]/40 focus:outline-none"
  defaultValue={reservation.secondGuestName || ""}
  placeholder="Ime"
  onBlur={async e => { await updateReservation(reservation.id, { secondGuestName: e.target.value }); }}
  />
  </div>
  </div>
  
  {/* Collapsible Dates Section */}
            <div>
              <button
                onClick={() => setShowDates(!showDates)}
                className="w-full flex items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 py-2.5 text-sm text-white hover:bg-white/[0.04] transition-colors"
              >
                <span className="flex items-center gap-2 min-w-0">
                  <Calendar className="h-4 w-4 flex-shrink-0 text-[#78b7ff]" />
                  <span className="truncate text-xs sm:text-sm">
                    <span className="text-white/60">Bivanje: </span>
                    <span className="font-medium">{reservation.arrival || '?'} → {reservation.departure || '?'}</span>
                  </span>
                </span>
                <ChevronDown className={`h-4 w-4 flex-shrink-0 text-white/40 transition-transform ${showDates ? 'rotate-180' : ''}`} />
              </button>
              {showDates && (
                <div className="mt-2 grid grid-cols-2 gap-2 p-3 rounded-xl border border-white/[0.06] bg-white/[0.02]">
                  <div>
                    <label className="mb-1 block text-[10px] font-medium uppercase tracking-wider text-white/40">Prihod</label>
                    <input
                      type="date"
                      className="w-full rounded-lg border border-white/[0.06] bg-white/[0.02] px-2 sm:px-3 py-2 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                      defaultValue={reservation.arrival || ''}
                      onBlur={e => {
                        if (e.target.value !== reservation.arrival) {
                          handleUpdateReservation(reservation.id, { arrival: e.target.value });
                        }
                      }}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-medium uppercase tracking-wider text-white/40">Odhod</label>
                    <input
                      type="date"
                      className="w-full rounded-lg border border-white/[0.06] bg-white/[0.02] px-2 sm:px-3 py-2 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                      defaultValue={reservation.departure || ''}
                      onBlur={e => {
                        if (e.target.value !== reservation.departure) {
                          handleUpdateReservation(reservation.id, { departure: e.target.value });
                        }
                      }}
                    />
                  </div>
                </div>
              )}
            </div>
            
            {/* Collapsible Transfers Section */}
            <div>
              <button
                onClick={() => setShowTransfers(!showTransfers)}
                className="w-full flex items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 py-2.5 text-sm text-white hover:bg-white/[0.04] transition-colors"
              >
                <span className="flex items-center gap-2 min-w-0">
                  <Car className="h-4 w-4 flex-shrink-0 text-[#5c8fd8]" />
                  <span className="truncate text-xs sm:text-sm">
                    <span className="text-white/60">Transferji: </span>
                    <span className="font-medium">
                      {reservation.transfers?.arrival?.route ? 'Prihod' : ''} 
                      {reservation.transfers?.arrival?.route && reservation.transfers?.departure?.route ? ' + ' : ''}
                      {reservation.transfers?.departure?.route ? 'Odhod' : ''}
                      {!reservation.transfers?.arrival?.route && !reservation.transfers?.departure?.route ? 'Ni' : ''}
                    </span>
                  </span>
                </span>
                <ChevronDown className={`h-4 w-4 flex-shrink-0 text-white/40 transition-transform ${showTransfers ? 'rotate-180' : ''}`} />
              </button>
              
              {showTransfers && (
                <div className="mt-3 space-y-3 p-3 rounded-xl border border-white/[0.06] bg-white/[0.02]">
                  {/* Arrival Transfer */}
                  <div className="p-3 rounded-xl border border-[#22c55e]/20 bg-[#22c55e]/5">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <LogIn className="h-4 w-4 text-[#22c55e]" />
                        <span className="text-sm font-medium text-[#22c55e]">Prihod</span>
                        <span className="text-xs text-white/40">({reservation.arrival})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {reservation.transfers?.arrival?.route && (
                          <>
                            <button
                              onClick={async () => {
                                if (confirm('Ali res želiš izbrisati ta transfer?')) {
                                  await deleteTransfer(reservation.id, 'arrival');
                                  refresh();
                                }
                              }}
                              className="text-xs text-red-400 hover:text-red-300"
                            >
                              Izbriši
                            </button>
                            <LuxuryBadge variant={reservation.transfers.arrival.paymentStatus === 'PREPAID' ? 'petrol' : reservation.transfers.arrival.paymentStatus === 'PAID' ? 'ocean' : 'danger'}>
                              {reservation.transfers.arrival.paymentStatus === 'PREPAID' ? 'Vkljuceno' : reservation.transfers.arrival.paymentStatus === 'PAID' ? 'Placano' : 'Za placilo'}
                            </LuxuryBadge>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs text-white/40 mb-1">Relacija</label>
                        <select
                          className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#22c55e]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                          value={reservation.transfers?.arrival?.route || ''}
                          onChange={async e => {
                            const route = e.target.value;
                            // Price will be calculated when boat is selected
                            await updateTransfer(reservation.id, 'arrival', { route, guestPrice: 0, date: reservation.arrival });
                            refresh();
                          }}
                        >
                          <option value="">-- Ni transferja --</option>
                          {dbRoutes.map((r: { id: string; name: string }) => (
                            <option key={r.id} value={r.id}>{r.name}</option>
                          ))}
                        </select>
                      </div>
                      {reservation.transfers?.arrival?.route && (
                        <>
                          {/* Flight Info */}
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                            <TransferTextField
                              label="St. leta"
                              placeholder="ET837"
                              value={reservation.transfers?.arrival?.flightNumber || ''}
                              onSave={async v => { await updateTransfer(reservation.id, 'arrival', { flightNumber: v }); refresh(); }}
                            />
                            <TransferTextField
                              label="Ura prihoda"
                              placeholder="14:45"
                              value={reservation.transfers?.arrival?.flightTime || ''}
                              onSave={async v => { await updateTransfer(reservation.id, 'arrival', { flightTime: v }); refresh(); }}
                            />
                            <div>
                              <label className="block text-xs text-white/40 mb-1">Datum</label>
                              <input
                                type="date"
                                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#22c55e]/50 focus:outline-none"
                                defaultValue={reservation.transfers?.arrival?.pickupDate || reservation.arrival}
                                onBlur={async e => {
                                  await updateTransfer(reservation.id, 'arrival', { pickupDate: e.target.value });
                                }}
                              />
                            </div>
                          </div>

                          {/* Price and Payment */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <label className="block text-xs text-white/40 mb-1">Cena (EUR)</label>
                              <input
                                type="number"
                                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#22c55e]/50 focus:outline-none"
                                defaultValue={reservation.transfers.arrival.guestPrice || 0}
                                onBlur={async e => { await updateTransfer(reservation.id, "arrival", { guestPrice: Number(e.target.value) }); }}
                              />
                            </div>
                            <LuxurySelect 
                              label="Status placila" 
                              value={reservation.transfers.arrival.paymentStatus || 'UNPAID'} 
                              onChange={async v => { await updateTransfer(reservation.id, "arrival", { paymentStatus: v }); refresh(); }} 
                              options={[
                                { value: 'PREPAID', label: 'Vkljuceno' },
                                { value: 'PAID', label: 'Placano' },
                                { value: 'UNPAID', label: 'Za placilo' },
                              ]} 
                            />
                          </div>

                          {/* Boat Selection */}
                          <div>
                            <label className="block text-xs text-white/40 mb-1">Coln</label>
                            <select 
                              className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#22c55e]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                              value={reservation.transfers.arrival.boatId || ''}
                              onChange={async e => { 
                                const boatId = e.target.value; 
                                const price = getTransferGuestPrice(reservation.transfers.arrival.route, boatId, reservation.pax); 
                                await updateTransfer(reservation.id, "arrival", { boatId, guestPrice: price }); 
                                refresh();
                              }}
                            >
                              <option value="">-- Izberi coln --</option>
                              {dbBoats.map((b: { id: string; name: string; engine: string; maxPax: number }) => <option key={b.id} value={b.id}>{b.name} ({b.engine})</option>)}
                            </select>
                          </div>

                          {/* Port & Herman Times */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <TransferTextField
                              label="Coln v Portu"
                              placeholder="15:30"
                              value={reservation.transfers?.arrival?.boatPortTime || ''}
                              onSave={async v => { await updateTransfer(reservation.id, "arrival", { boatPortTime: v }); refresh(); }}
                            />
                            <TransferTextField
                              label="Herman na letaliscu"
                              placeholder="14:30"
                              value={reservation.transfers?.arrival?.hermanAirportTime || ''}
                              onSave={async v => { await updateTransfer(reservation.id, "arrival", { hermanAirportTime: v }); refresh(); }}
                            />
                          </div>

                          {/* Notes */}
                          <TransferTextField
                            label="Opombe"
                            placeholder="npr. otroški sedež..."
                            value={reservation.transfers?.arrival?.notes || ''}
                            onSave={async v => { await updateTransfer(reservation.id, "arrival", { notes: v }); refresh(); }}
                          />

                          {/* Executed */}
                          <div className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 p-2">
                            <span className="text-xs text-white">Izveden</span>
                            <label className="relative inline-flex items-center cursor-pointer">
                              <input
                                type="checkbox"
                                checked={reservation.transfers.arrival.executed || false}
                                onChange={async e => { 
                                  await updateTransfer(reservation.id, "arrival", { 
                                    executed: e.target.checked,
                                    executedAt: e.target.checked ? new Date().toISOString() : null
                                  }); 
                                  refresh();
                                }}
                                className="sr-only peer"
                              />
                              <div className="w-9 h-5 bg-white/10 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#22c55e]"></div>
                            </label>
                          </div>

                          {/* WhatsApp Buttons */}
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <a
                                href={`https://wa.me/261326801412?text=${encodeURIComponent(
                                  `PRIHOD:\n` +
                                  `Datum: ${reservation.transfers.arrival.pickupDate || reservation.arrival}\n` +
                                  `Let: ${reservation.transfers.arrival.flightNumber || '?'} ob ${reservation.transfers.arrival.flightTime || '?'}\n` +
                                  `Coln v Portu: ${reservation.transfers.arrival.boatPortTime || '?'}\n` +
                                  `Coln: ${dbBoats.find((b: {id: string}) => b.id === reservation.transfers.arrival.boatId)?.name || '?'}\n` +
                                  `Pax: ${reservation.pax}\n` +
                                  `Gost: ${reservation.guestName}`
                                )}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center gap-1 w-full rounded-lg bg-[#25D366]/20 border border-[#25D366]/30 px-2 py-2 text-xs text-[#25D366] hover:bg-[#25D366]/30"
                              >
                                <Ship className="h-3 w-3" />
                                Dilip
                              </a>
                              {reservation.transfers.arrival.dilipOrderedAt && (
                                <p className="text-[9px] text-green-400 text-center mt-1">
                                  {new Date(reservation.transfers.arrival.dilipOrderedAt).toLocaleDateString('sl-SI')}
                                </p>
                              )}
                            </div>
                            <div>
                              <a
                                href={`https://wa.me/261326801412?text=${encodeURIComponent(
                                  `TAXI PRIHOD:\n` +
                                  `Datum: ${reservation.transfers.arrival.pickupDate || reservation.arrival}\n` +
                                  `Let: ${reservation.transfers.arrival.flightNumber || '?'} ob ${reservation.transfers.arrival.flightTime || '?'}\n` +
                                  `Taxi ob: ${reservation.transfers.arrival.hermanAirportTime || '?'}\n` +
                                  `Pax: ${reservation.pax}\n` +
                                  `Gost: ${reservation.guestName}`
                                )}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center gap-1 w-full rounded-lg bg-[#25D366]/20 border border-[#25D366]/30 px-2 py-2 text-xs text-[#25D366] hover:bg-[#25D366]/30"
                              >
                                <Car className="h-3 w-3" />
                                Herman
                              </a>
                              {reservation.transfers.arrival.hermanOrderedAt && (
                                <p className="text-[9px] text-green-400 text-center mt-1">
                                  {new Date(reservation.transfers.arrival.hermanOrderedAt).toLocaleDateString('sl-SI')}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              onClick={async () => { await updateTransfer(reservation.id, "arrival", { dilipOrderedAt: new Date().toISOString() }); refresh(); }}
                              className="text-[9px] text-white/40 hover:text-white/60 underline"
                            >
                              Potrdi Dilipa
                            </button>
                            <button
                              onClick={async () => { await updateTransfer(reservation.id, "arrival", { hermanOrderedAt: new Date().toISOString() }); refresh(); }}
                              className="text-[9px] text-white/40 hover:text-white/60 underline"
                            >
                              Potrdi Hermana
                            </button>
                          </div>
                          
                          {/* Voucher Buttons */}
                          <div className="flex gap-2 mt-2">
                            <button
                              onClick={() => {
                                const routeName = dbRoutes.find((r: {id: string; name: string}) => r.id === reservation.transfers.arrival.route)?.name || '';
                                const voucherWindow = window.open('', '_blank', 'width=550,height=850,scrollbars=yes');
                                if (!voucherWindow) return;
                                
                                voucherWindow.document.write(`
<!DOCTYPE html>
<html>
<head>
  <title>Transfer Voucher - ${reservation.guestName}</title>
  <meta charset="utf-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    body { font-family: 'Segoe UI', system-ui, sans-serif; background: #0f1724; display: flex; justify-content: center; padding: 16px; }
    .voucher { width: 100%; max-width: 500px; background: white; border-radius: 16px; overflow: hidden; }
    .header { background: linear-gradient(to right, #0f1724, #1a2744) !important; padding: 16px 20px; display: flex; align-items: center; justify-content: space-between; }
    .header-logo { height: 60px; }
    .header-icon { width: 44px; height: 44px; border: 2px solid #f1d07a; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: transparent; }
    .header-icon svg { width: 22px; height: 22px; fill: #f1d07a; }
    .content { padding: 24px; }
    .guest-section { margin-bottom: 20px; }
    .guest-label { font-size: 10px; letter-spacing: 1px; text-transform: uppercase; color: #94a3b8; margin-bottom: 4px; }
    .guest-name { font-size: 22px; font-weight: 700; color: #0f1724; }
    .guest-bungalow { font-size: 14px; color: #22c55e; margin-top: 4px; }
    .transfer-badge { display: inline-block; background: #22c55e20; border: 1px solid #22c55e; color: #22c55e; font-size: 11px; font-weight: 600; padding: 4px 12px; border-radius: 20px; margin-bottom: 16px; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
    .info-item { }
    .info-label { font-size: 10px; letter-spacing: 1px; text-transform: uppercase; color: #94a3b8; margin-bottom: 2px; }
    .info-value { font-size: 15px; font-weight: 600; color: #0f1724; }
    .route-section { background: #f8fafc; border-radius: 12px; padding: 16px; margin-bottom: 20px; }
    .route-label { font-size: 10px; letter-spacing: 1px; text-transform: uppercase; color: #94a3b8; margin-bottom: 4px; }
    .route-value { font-size: 16px; font-weight: 600; color: #0f1724; }
    .logo-section { background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; text-align: center; margin-bottom: 20px; }
    .logo-text { font-size: 10px; letter-spacing: 2px; color: #6b7280; text-transform: uppercase; margin-bottom: 12px; }
    .logo-img { height: 60px; }
    .instructions { background: #0f1724; color: white; padding: 20px; font-size: 13px; line-height: 1.6; }
    .instructions p { margin-bottom: 12px; }
    .instructions .note { font-size: 11px; color: rgba(255,255,255,0.6); }
    .payment-note { background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 12px; margin: 16px 20px; text-align: center; font-size: 12px; color: #92400e; font-weight: 500; }
    .footer { padding: 16px 24px; text-align: center; font-size: 11px; color: #94a3b8; }
    @media print { body { background: white; padding: 0; } .header { background: linear-gradient(to right, #0f1724, #1a2744) !important; } }
  </style>
</head>
<body>
  <div class="voucher">
    <div class="header">
      <img src="${window.location.origin}/images/komba-logo-gold.png" alt="Komba Cabana" class="header-logo" />
      <div class="header-icon">
        <svg viewBox="0 0 24 24"><path d="M20 21c-1.39 0-2.78-.47-4-1.32-2.44 1.71-5.56 1.71-8 0C6.78 20.53 5.39 21 4 21H2v2h2c1.38 0 2.74-.35 4-.99 2.52 1.29 5.48 1.29 8 0 1.26.65 2.62.99 4 .99h2v-2h-2zM3.95 19H4c1.6 0 3.02-.88 4-2 .98 1.12 2.4 2 4 2s3.02-.88 4-2c.98 1.12 2.4 2 4 2h.05l1.89-6.68c.08-.26.06-.54-.06-.78s-.34-.42-.6-.5L20 10.62V6c0-1.1-.9-2-2-2h-3V1H9v3H6c-1.1 0-2 .9-2 2v4.62l-1.29.42c-.26.08-.48.26-.6.5s-.15.52-.06.78L3.95 19zM6 6h12v3.97L12 8 6 9.97V6z"/></svg>
      </div>
    </div>
    
    <div class="content">
      <div class="guest-section">
        <div class="guest-label">Guest</div>
        <div class="guest-name">${reservation.guestName}${reservation.secondGuestName ? '<br>' + reservation.secondGuestName : ''}</div>
        <div class="guest-bungalow">${reservation.bungalow || ''}</div>
      </div>
      
      <div class="transfer-badge">ARRIVAL TRANSFER</div>
      
      <div class="info-grid">
        <div class="info-item">
          <div class="info-label">Date</div>
          <div class="info-value">${reservation.transfers.arrival.pickupDate ? new Date(reservation.transfers.arrival.pickupDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) : reservation.arrival}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Time</div>
          <div class="info-value">${reservation.transfers.arrival.flightTime || 'TBA'}</div>
        </div>
      </div>
      
      <div class="route-section">
        <div class="route-label">Route</div>
        <div class="route-value">${routeName}</div>
      </div>
      
      <div class="info-grid">
        <div class="info-item">
          <div class="info-label">Passengers</div>
          <div class="info-value">${reservation.pax} ${reservation.pax === 1 ? 'person' : 'persons'}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Flight</div>
          <div class="info-value">${reservation.transfers.arrival.flightNumber || 'N/A'}</div>
        </div>
      </div>
      
      <div class="logo-section">
        <div class="logo-text">Look for our logo at the airport:</div>
        <img src="${window.location.origin}/images/komba-logo-color.png" alt="Komba Cabana" class="logo-img" />
      </div>
    </div>
    
    <div class="instructions">
      <p><strong>Our driver will meet you at the airport with the Komba Cabana Lodge logo.</strong> You will be driven to the port of Hell-Ville (Andoany), where a boat will be waiting to take you directly to Komba Cabana Lodge beach.</p>
      <p class="note">Please present this voucher upon arrival.</p>
    </div>
    
    ${reservation.transfers.arrival.paymentStatus !== 'PAID' && reservation.transfers.arrival.paymentStatus !== 'PREPAID' ? '<div class="payment-note">Transfer is payable at checkout during your final bill settlement.</div>' : ''}
    
    <div class="footer">For questions: info@kombacabana.com</div>
  </div>
</body>
</html>
                                `);
                                
                                voucherWindow.document.close();
                                voucherWindow.focus();
                                setTimeout(() => { voucherWindow.print(); }, 800);
                              }}
                              className="flex items-center justify-center gap-1 flex-1 rounded-lg bg-[#f1d07a]/20 border border-[#f1d07a]/30 px-2 py-1.5 text-xs text-[#f1d07a] hover:bg-[#f1d07a]/30"
                            >
                              <Printer className="h-3 w-3" />
                              Natisni
                            </button>
                            <button
                              onClick={() => {
                                const url = `${window.location.origin}/voucher/transfer/${reservation.id}/arrival`;
                                const textarea = document.createElement('textarea');
                                textarea.value = url;
                                textarea.style.position = 'fixed';
                                textarea.style.opacity = '0';
                                document.body.appendChild(textarea);
                                textarea.select();
                                document.execCommand('copy');
                                document.body.removeChild(textarea);
                                alert('Komba Cabana transfer voucher link kopiran!');
                              }}
                              className="flex items-center justify-center gap-1 flex-1 rounded-lg bg-[#78b7ff]/20 border border-[#78b7ff]/30 px-2 py-1.5 text-xs text-[#78b7ff] hover:bg-[#78b7ff]/30"
                            >
                              <ExternalLink className="h-3 w-3" />
                              Kopiraj Link
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                  
                  {/* Departure Transfer */}
                  <div className="p-3 rounded-xl border border-[#ef4444]/20 bg-[#ef4444]/5">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <LogIn className="h-4 w-4 text-[#ef4444] rotate-180" />
                        <span className="text-sm font-medium text-[#ef4444]">Odhod</span>
                        <span className="text-xs text-white/40">({reservation.departure})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {reservation.transfers?.departure?.route && (
                          <>
                            <button
                              onClick={async () => {
                                if (confirm('Ali res želiš izbrisati ta transfer?')) {
                                  await deleteTransfer(reservation.id, 'departure');
                                  refresh();
                                }
                              }}
                              className="text-xs text-red-400 hover:text-red-300"
                            >
                              Izbriši
                            </button>
                            <LuxuryBadge variant={reservation.transfers.departure.paymentStatus === 'PREPAID' ? 'petrol' : reservation.transfers.departure.paymentStatus === 'PAID' ? 'ocean' : 'danger'}>
                              {reservation.transfers.departure.paymentStatus === 'PREPAID' ? 'Vkljuceno' : reservation.transfers.departure.paymentStatus === 'PAID' ? 'Placano' : 'Za placilo'}
                            </LuxuryBadge>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs text-white/40 mb-1">Relacija</label>
                        <select
                          className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#ef4444]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                          value={reservation.transfers?.departure?.route || ''}
                          onChange={async e => {
                            const route = e.target.value;
                            // Price will be calculated when boat is selected
                            await updateTransfer(reservation.id, 'departure', { route, guestPrice: 0, date: reservation.departure });
                            refresh();
                          }}
                        >
                          <option value="">-- Ni transferja --</option>
                          {dbRoutes.map((r: { id: string; name: string }) => (
                            <option key={r.id} value={r.id}>{r.name}</option>
                          ))}
                        </select>
                      </div>
                      {reservation.transfers?.departure?.route && (
                        <>
                          {/* Departure Time */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <TransferTextField
                              label="Odhod iz Kombe"
                              placeholder="08:00"
                              value={reservation.transfers?.departure?.time || ''}
                              onSave={async v => { await updateTransfer(reservation.id, "departure", { time: v }); refresh(); }}
                            />
                            <div>
                              <label className="block text-xs text-white/40 mb-1">Datum</label>
                              <input 
                                type="date"
                                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#ef4444]/50 focus:outline-none"
                                defaultValue={reservation.transfers?.departure?.pickupDate || reservation.departure}
                                onBlur={async e => { await updateTransfer(reservation.id, "departure", { pickupDate: e.target.value }); }}
                              />
                            </div>
                          </div>

                          {/* Price and Payment */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <label className="block text-xs text-white/40 mb-1">Cena (EUR)</label>
                              <input
                                type="number"
                                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#ef4444]/50 focus:outline-none"
                                defaultValue={reservation.transfers.departure.guestPrice || 0}
                                onBlur={async e => { await updateTransfer(reservation.id, "departure", { guestPrice: Number(e.target.value) }); }}
                              />
                            </div>
                            <LuxurySelect 
                              label="Status placila" 
                              value={reservation.transfers.departure.paymentStatus || 'UNPAID'} 
                              onChange={async v => { await updateTransfer(reservation.id, "departure", { paymentStatus: v }); refresh(); }} 
                              options={[
                                { value: 'PREPAID', label: 'Vkljuceno' },
                                { value: 'PAID', label: 'Placano' },
                                { value: 'UNPAID', label: 'Za placilo' },
                              ]} 
                            />
                          </div>

                          {/* Boat Selection */}
                          <div>
                            <label className="block text-xs text-white/40 mb-1">Coln</label>
                            <select 
                              className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#ef4444]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                              value={reservation.transfers.departure.boatId || ''}
                              onChange={async e => { 
                                const boatId = e.target.value; 
                                const price = getTransferGuestPrice(reservation.transfers.departure.route, boatId, reservation.pax); 
                                await updateTransfer(reservation.id, "departure", { boatId, guestPrice: price }); 
                                refresh();
                              }}
                            >
                              <option value="">-- Izberi coln --</option>
                              {dbBoats.map((b: { id: string; name: string; engine: string; maxPax: number }) => <option key={b.id} value={b.id}>{b.name} ({b.engine})</option>)}
                            </select>
                          </div>

                          {/* Port & Herman Times */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <TransferTextField
                              label="Coln v Portu"
                              placeholder="09:00"
                              value={reservation.transfers?.departure?.boatPortTime || ''}
                              onSave={async v => { await updateTransfer(reservation.id, "departure", { boatPortTime: v }); refresh(); }}
                            />
                            <TransferTextField
                              label="Herman na letaliscu"
                              placeholder="13:00"
                              value={reservation.transfers?.departure?.hermanAirportTime || ''}
                              onSave={async v => { await updateTransfer(reservation.id, "departure", { hermanAirportTime: v }); refresh(); }}
                            />
                          </div>

                          {/* Notes */}
                          <TransferTextField
                            label="Opombe"
                            placeholder="npr. let ob 15:30..."
                            value={reservation.transfers?.departure?.notes || ''}
                            onSave={async v => { await updateTransfer(reservation.id, "departure", { notes: v }); refresh(); }}
                          />

                          {/* Executed */}
                          <div className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 p-2">
                            <span className="text-xs text-white">Izveden</span>
                            <label className="relative inline-flex items-center cursor-pointer">
                              <input
                                type="checkbox"
                                checked={reservation.transfers.departure.executed || false}
                                onChange={async e => { 
                                  await updateTransfer(reservation.id, "departure", { 
                                    executed: e.target.checked,
                                    executedAt: e.target.checked ? new Date().toISOString() : null
                                  }); 
                                  refresh();
                                }}
                                className="sr-only peer"
                              />
                              <div className="w-9 h-5 bg-white/10 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#ef4444]"></div>
                            </label>
                          </div>

                          {/* WhatsApp Buttons */}
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <a
                                href={`https://wa.me/261326801412?text=${encodeURIComponent(
                                  `ODHOD:\n` +
                                  `Datum: ${reservation.transfers.departure.pickupDate || reservation.departure}\n` +
                                  `Iz Kombe: ${reservation.transfers.departure.time || '?'}\n` +
                                  `Coln v Portu: ${reservation.transfers.departure.boatPortTime || '?'}\n` +
                                  `Coln: ${dbBoats.find((b: {id: string}) => b.id === reservation.transfers.departure.boatId)?.name || '?'}\n` +
                                  `Pax: ${reservation.pax}\n` +
                                  `Gost: ${reservation.guestName}`
                                )}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center gap-1 w-full rounded-lg bg-[#25D366]/20 border border-[#25D366]/30 px-2 py-2 text-xs text-[#25D366] hover:bg-[#25D366]/30"
                              >
                                <Ship className="h-3 w-3" />
                                Dilip
                              </a>
                              {reservation.transfers.departure.dilipOrderedAt && (
                                <p className="text-[9px] text-green-400 text-center mt-1">
                                  {new Date(reservation.transfers.departure.dilipOrderedAt).toLocaleDateString('sl-SI')}
                                </p>
                              )}
                            </div>
                            <div>
                              <a
                                href={`https://wa.me/261326801412?text=${encodeURIComponent(
                                  `TAXI ODHOD:\n` +
                                  `Datum: ${reservation.transfers.departure.pickupDate || reservation.departure}\n` +
                                  `Coln v Portu: ${reservation.transfers.departure.boatPortTime || '?'}\n` +
                                  `Taxi ob: ${reservation.transfers.departure.hermanAirportTime || '?'}\n` +
                                  `Pax: ${reservation.pax}\n` +
                                  `Gost: ${reservation.guestName}`
                                )}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center gap-1 w-full rounded-lg bg-[#25D366]/20 border border-[#25D366]/30 px-2 py-2 text-xs text-[#25D366] hover:bg-[#25D366]/30"
                              >
                                <Car className="h-3 w-3" />
                                Herman
                              </a>
                              {reservation.transfers.departure.hermanOrderedAt && (
                                <p className="text-[9px] text-green-400 text-center mt-1">
                                  {new Date(reservation.transfers.departure.hermanOrderedAt).toLocaleDateString('sl-SI')}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              onClick={async () => { await updateTransfer(reservation.id, "departure", { dilipOrderedAt: new Date().toISOString() }); refresh(); }}
                              className="text-[9px] text-white/40 hover:text-white/60 underline"
                            >
                              Potrdi Dilipa
                            </button>
                            <button
                              onClick={async () => { await updateTransfer(reservation.id, "departure", { hermanOrderedAt: new Date().toISOString() }); refresh(); }}
                              className="text-[9px] text-white/40 hover:text-white/60 underline"
                            >
                              Potrdi Hermana
                            </button>
                          </div>
                          
                          {/* Voucher Buttons */}
                          <div className="flex gap-2 mt-2">
                            <button
                              onClick={() => {
                                const routeName = dbRoutes.find((r: {id: string; name: string}) => r.id === reservation.transfers.departure.route)?.name || '';
                                const voucherWindow = window.open('', '_blank', 'width=550,height=850,scrollbars=yes');
                                if (!voucherWindow) return;
                                
                                voucherWindow.document.write(`
<!DOCTYPE html>
<html>
<head>
  <title>Transfer Voucher - ${reservation.guestName}</title>
  <meta charset="utf-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    body { font-family: 'Segoe UI', system-ui, sans-serif; background: #0f1724; display: flex; justify-content: center; padding: 16px; }
    .voucher { width: 100%; max-width: 500px; background: white; border-radius: 16px; overflow: hidden; }
    .header { background: linear-gradient(to right, #0f1724, #1a2744) !important; padding: 16px 20px; display: flex; align-items: center; justify-content: space-between; }
    .header-logo { height: 60px; }
    .header-icon { width: 44px; height: 44px; border: 2px solid #f1d07a; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: transparent; }
    .header-icon svg { width: 22px; height: 22px; fill: #f1d07a; }
    .content { padding: 24px; }
    .guest-section { margin-bottom: 20px; }
    .guest-label { font-size: 10px; letter-spacing: 1px; text-transform: uppercase; color: #94a3b8; margin-bottom: 4px; }
    .guest-name { font-size: 22px; font-weight: 700; color: #0f1724; }
    .guest-bungalow { font-size: 14px; color: #ef4444; margin-top: 4px; }
    .transfer-badge { display: inline-block; background: #ef444420; border: 1px solid #ef4444; color: #ef4444; font-size: 11px; font-weight: 600; padding: 4px 12px; border-radius: 20px; margin-bottom: 16px; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
    .info-item { }
    .info-label { font-size: 10px; letter-spacing: 1px; text-transform: uppercase; color: #94a3b8; margin-bottom: 2px; }
    .info-value { font-size: 15px; font-weight: 600; color: #0f1724; }
    .route-section { background: #f8fafc; border-radius: 12px; padding: 16px; margin-bottom: 20px; }
    .route-label { font-size: 10px; letter-spacing: 1px; text-transform: uppercase; color: #94a3b8; margin-bottom: 4px; }
    .route-value { font-size: 16px; font-weight: 600; color: #0f1724; }
    .logo-section { background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; text-align: center; margin-bottom: 20px; }
    .logo-text { font-size: 10px; letter-spacing: 2px; color: #6b7280; text-transform: uppercase; margin-bottom: 12px; }
    .logo-img { height: 60px; }
    .instructions { background: #0f1724; color: white; padding: 20px; font-size: 13px; line-height: 1.6; }
    .instructions p { margin-bottom: 12px; }
    .instructions .note { font-size: 11px; color: rgba(255,255,255,0.6); }
    .payment-note { background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 12px; margin: 16px 20px; text-align: center; font-size: 12px; color: #92400e; font-weight: 500; }
    .footer { padding: 16px 24px; text-align: center; font-size: 11px; color: #94a3b8; }
    @media print { body { background: white; padding: 0; } .header { background: linear-gradient(to right, #0f1724, #1a2744) !important; } }
  </style>
</head>
<body>
  <div class="voucher">
    <div class="header">
      <img src="${window.location.origin}/images/komba-logo-gold.png" alt="Komba Cabana" class="header-logo" />
      <div class="header-icon">
        <svg viewBox="0 0 24 24"><path d="M20 21c-1.39 0-2.78-.47-4-1.32-2.44 1.71-5.56 1.71-8 0C6.78 20.53 5.39 21 4 21H2v2h2c1.38 0 2.74-.35 4-.99 2.52 1.29 5.48 1.29 8 0 1.26.65 2.62.99 4 .99h2v-2h-2zM3.95 19H4c1.6 0 3.02-.88 4-2 .98 1.12 2.4 2 4 2s3.02-.88 4-2c.98 1.12 2.4 2 4 2h.05l1.89-6.68c.08-.26.06-.54-.06-.78s-.34-.42-.6-.5L20 10.62V6c0-1.1-.9-2-2-2h-3V1H9v3H6c-1.1 0-2 .9-2 2v4.62l-1.29.42c-.26.08-.48.26-.6.5s-.15.52-.06.78L3.95 19zM6 6h12v3.97L12 8 6 9.97V6z"/></svg>
      </div>
    </div>
    
    <div class="content">
      <div class="guest-section">
        <div class="guest-label">Guest</div>
        <div class="guest-name">${reservation.guestName}${reservation.secondGuestName ? '<br>' + reservation.secondGuestName : ''}</div>
        <div class="guest-bungalow">${reservation.bungalow || ''}</div>
      </div>
      
      <div class="transfer-badge">DEPARTURE TRANSFER</div>
      
      <div class="info-grid">
        <div class="info-item">
          <div class="info-label">Date</div>
          <div class="info-value">${reservation.transfers.departure.pickupDate ? new Date(reservation.transfers.departure.pickupDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) : reservation.departure}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Pickup Time</div>
          <div class="info-value">${reservation.transfers.departure.pickupTime || 'TBA'}</div>
        </div>
      </div>
      
      <div class="route-section">
        <div class="route-label">Route</div>
        <div class="route-value">${routeName}</div>
      </div>
      
      <div class="info-grid">
        <div class="info-item">
          <div class="info-label">Passengers</div>
          <div class="info-value">${reservation.pax} ${reservation.pax === 1 ? 'person' : 'persons'}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Flight</div>
          <div class="info-value">${reservation.transfers.departure.flightNumber || 'N/A'}</div>
        </div>
      </div>
      
      <div class="logo-section">
        <img src="${window.location.origin}/images/komba-logo-gold.png" alt="Komba Cabana" class="logo-img" />
      </div>
    </div>
    
    <div class="instructions">
      <p><strong>Our team will pick you up from Komba Cabana Lodge beach.</strong> You will be taken by boat to Hell-Ville (Andoany) port, then by car to Nosy Be Airport.</p>
      <p class="note">Please be ready at the reception at the scheduled pickup time.</p>
    </div>
    
    ${reservation.transfers.departure.paymentStatus !== 'PAID' && reservation.transfers.departure.paymentStatus !== 'PREPAID' ? '<div class="payment-note">Transfer is payable at checkout during your final bill settlement.</div>' : ''}
    
    <div class="footer">For questions: info@kombacabana.com</div>
  </div>
</body>
</html>
                                `);
                                
                                voucherWindow.document.close();
                                voucherWindow.focus();
                                setTimeout(() => { voucherWindow.print(); }, 800);
                              }}
                              className="flex items-center justify-center gap-1 flex-1 rounded-lg bg-[#f1d07a]/20 border border-[#f1d07a]/30 px-2 py-1.5 text-xs text-[#f1d07a] hover:bg-[#f1d07a]/30"
                            >
                              <Printer className="h-3 w-3" />
                              Natisni
                            </button>
                            <button
                              onClick={() => {
                                const url = `${window.location.origin}/voucher/transfer/${reservation.id}/departure`;
                                const textarea = document.createElement('textarea');
                                textarea.value = url;
                                textarea.style.position = 'fixed';
                                textarea.style.opacity = '0';
                                document.body.appendChild(textarea);
                                textarea.select();
                                document.execCommand('copy');
                                document.body.removeChild(textarea);
                                alert('Komba Cabana transfer voucher link kopiran!');
                              }}
                              className="flex items-center justify-center gap-1 flex-1 rounded-lg bg-[#78b7ff]/20 border border-[#78b7ff]/30 px-2 py-1.5 text-xs text-[#78b7ff] hover:bg-[#78b7ff]/30"
                            >
                              <ExternalLink className="h-3 w-3" />
                              Kopiraj Link
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <LuxurySelect label="Status" value={reservation.status} onChange={v => handleUpdateReservation(reservation.id, { status: v })} options={STATUSES} />
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Nacionalnost</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.nationality || ""}
                onBlur={async e => { await updateReservation(reservation.id, { nationality: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Potni list</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.passport || ""}
                onBlur={async e => { await updateReservation(reservation.id, { passport: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Datum rojstva</label>
              <input
                type="date"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none [color-scheme:dark]"
                defaultValue={reservation.dateOfBirth || ""}
                onChange={async e => { await updateReservation(reservation.id, { dateOfBirth: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Kraj rojstva</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.placeOfBirth || ""}
                onBlur={async e => { await updateReservation(reservation.id, { placeOfBirth: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Ime očeta</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.fatherName || ""}
                onBlur={async e => { await updateReservation(reservation.id, { fatherName: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Ime matere</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.motherName || ""}
                onBlur={async e => { await updateReservation(reservation.id, { motherName: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Poklic</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.profession || ""}
                onBlur={async e => { await updateReservation(reservation.id, { profession: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Stalno prebivališče</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.domicile || ""}
                onBlur={async e => { await updateReservation(reservation.id, { domicile: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Datum izdaje potnega lista</label>
              <input
                type="date"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none [color-scheme:dark]"
                defaultValue={reservation.passportDate || ""}
                onChange={async e => { await updateReservation(reservation.id, { passportDate: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Kraj izdaje potnega lista</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.passportLieu || ""}
                onBlur={async e => { await updateReservation(reservation.id, { passportLieu: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Prihaja iz</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.venantDe || ""}
                onBlur={async e => { await updateReservation(reservation.id, { venantDe: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Veljavnost vize</label>
              <input
                type="date"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none [color-scheme:dark]"
                defaultValue={reservation.validiteVisa || ""}
                onChange={async e => { await updateReservation(reservation.id, { validiteVisa: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Potuje v</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.allantA || ""}
                onBlur={async e => { await updateReservation(reservation.id, { allantA: e.target.value }); }}
              />
            </div>

            {/* Osebni podatki drugega gosta (za policijski zapisnik) */}
            {reservation.secondGuestName ? (
              <div className="rounded-xl border border-[#f9a8d4]/20 bg-[#f9a8d4]/[0.04]">
                <button
                  type="button"
                  onClick={() => setShowSecondGuestData(!showSecondGuestData)}
                  className="w-full flex items-center justify-between px-4 py-3 text-sm text-white hover:bg-white/[0.02] transition-colors"
                >
                  <span className="flex items-center gap-2 min-w-0">
                    <FileText className="h-4 w-4 flex-shrink-0 text-[#f9a8d4]" />
                    <span className="truncate">
                      <span className="text-white/60">Podatki 2. gosta: </span>
                      <span className="font-medium text-[#f9a8d4]">{reservation.secondGuestName}</span>
                    </span>
                  </span>
                  <ChevronDown className={`h-4 w-4 flex-shrink-0 text-white/40 transition-transform ${showSecondGuestData ? 'rotate-180' : ''}`} />
                </button>
                {showSecondGuestData ? (
                  <div className="px-4 pb-4 pt-1 space-y-3 border-t border-[#f9a8d4]/10">
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Ime in priimek</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondGuestName || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondGuestName: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Nacionalnost</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondNationality || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondNationality: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Potni list</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondPassport || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondPassport: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Datum rojstva</label>
                      <input
                        type="date"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none [color-scheme:dark]"
                        defaultValue={reservation.secondDateOfBirth || ""}
                        onChange={async e => { await updateReservation(reservation.id, { secondDateOfBirth: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Kraj rojstva</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondPlaceOfBirth || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondPlaceOfBirth: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Ime očeta</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondFatherName || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondFatherName: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Ime matere</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondMotherName || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondMotherName: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Poklic</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondProfession || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondProfession: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Stalno prebivališče</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondDomicile || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondDomicile: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Datum izdaje potnega lista</label>
                      <input
                        type="date"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none [color-scheme:dark]"
                        defaultValue={reservation.secondPassportDate || ""}
                        onChange={async e => { await updateReservation(reservation.id, { secondPassportDate: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Kraj izdaje potnega lista</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondPassportLieu || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondPassportLieu: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Prihaja iz</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondVenantDe || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondVenantDe: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Veljavnost vize</label>
                      <input
                        type="date"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none [color-scheme:dark]"
                        defaultValue={reservation.secondValiditeVisa || ""}
                        onChange={async e => { await updateReservation(reservation.id, { secondValiditeVisa: e.target.value }); }}
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Potuje v</label>
                      <input
                        type="text"
                        className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#f9a8d4]/40 focus:outline-none"
                        defaultValue={reservation.secondAllantA || ""}
                        onBlur={async e => { await updateReservation(reservation.id, { secondAllantA: e.target.value }); }}
                      />
                    </div>
                  </div>
                ) : null}
              </div>
            ) : null}
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Email</label>
              <input
                type="email"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.email || ""}
                onBlur={async e => { await updateReservation(reservation.id, { email: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Telefon</label>
              <input
                type="tel"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.phone || ""}
                onBlur={async e => { await updateReservation(reservation.id, { phone: e.target.value }); }}
              />
            </div>
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Alergije</label>
              <input
                type="text"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={reservation.allergies || ""}
                onBlur={async e => { await updateReservation(reservation.id, { allergies: e.target.value }); }}
              />
            </div>
            
              <LuxuryCheckbox label="Honeymoon" checked={reservation.honeymoon || false} onChange={v => handleUpdateReservation(reservation.id, { honeymoon: v })} />
              <LuxuryCheckbox label="Ne potrebuje prevoza" checked={(reservation as { noTransferNeeded?: boolean }).noTransferNeeded || false} onChange={v => handleUpdateReservation(reservation.id, { noTransferNeeded: v })} />
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Penzion</label>
              <div className="flex gap-2">
                {[
                  { value: "B", label: "B" },
                  { value: "HB", label: "HB" },
                  { value: "FB", label: "FB" }
                ].map(opt => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => handleUpdateReservation(reservation.id, { mealPlan: reservation.mealPlan === opt.value ? "" : opt.value })}
                    className={`flex-1 rounded-xl border py-3 px-4 text-sm font-medium transition-all ${
                      reservation.mealPlan === opt.value
                        ? "border-[#6fc8a3] bg-[#6fc8a3]/20 text-[#6fc8a3]"
                        : "border-white/10 bg-white/5 text-white/60 hover:border-white/20 hover:bg-white/10"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              
              {/* Meal Plan Price and Payment Status */}
              {reservation.mealPlan && (
                <div className="mt-3 p-3 rounded-xl border border-[#6fc8a3]/20 bg-[#6fc8a3]/5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-white/40">Cena na dan / osebo</p>
                      <p className="text-sm font-medium text-[#6fc8a3]">{eur(getMealPlanPrice(reservation.mealPlan))}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-white/40">{reservation.pax} oseb × {(() => {
                        const arr = reservation.arrival ? new Date(reservation.arrival) : null;
                        const dep = reservation.departure ? new Date(reservation.departure) : null;
                        return arr && dep ? Math.ceil((dep.getTime() - arr.getTime()) / (1000 * 60 * 60 * 24)) : 0;
                      })()} dni</p>
                      <p className="text-lg font-bold text-[#6fc8a3]">{eur(getMealPlanPrice(reservation.mealPlan) * reservation.pax * (() => {
                        const arr = reservation.arrival ? new Date(reservation.arrival) : null;
                        const dep = reservation.departure ? new Date(reservation.departure) : null;
                        return arr && dep ? Math.ceil((dep.getTime() - arr.getTime()) / (1000 * 60 * 60 * 24)) : 0;
                      })())}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {[
                      { value: 'PAID', label: 'Placano', color: 'ocean' },
                      { value: 'UNPAID', label: 'Za placilo', color: 'danger' }
                    ].map(opt => (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => handleUpdateReservation(reservation.id, { mealPlanPaymentStatus: opt.value })}
                        className={`flex-1 rounded-lg border py-2 px-2 text-xs font-medium transition-all ${
                          (reservation.mealPlanPaymentStatus || 'UNPAID') === opt.value
                            ? opt.value === 'PAID' ? "border-[#78b7ff] bg-[#78b7ff]/20 text-[#78b7ff]"
                              : "border-[#ef4444] bg-[#ef4444]/20 text-[#ef4444]"
                            : "border-white/10 bg-white/5 text-white/40 hover:border-white/20"
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            {/* Cena nocitev - nad placili */}
            <div className="p-4 rounded-xl border border-[#78b7ff]/20 bg-[#78b7ff]/5">
              <label className="mb-3 block text-[11px] font-medium uppercase tracking-wider text-white/40">Cena nocitev (EUR)</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-white/40 mb-1">Skupaj</label>
                  <input
                    key={`total-${reservation.id}`}
                    type="text"
                    inputMode="decimal"
                    className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                    defaultValue={reservation.totalAmount || ""}
                    placeholder="0.00"
                    onBlur={async e => { 
                      const val = e.target.value.replace(',', '.');
                      await handleUpdateReservation(reservation.id, { totalAmount: val ? Number(val) : null }); 
                    }}
                  />
                </div>
                <div>
                  <label className="block text-xs text-white/40 mb-1">Placano</label>
                  <input
                    key={`paid-${reservation.id}`}
                    type="text"
                    inputMode="decimal"
                    className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                    defaultValue={reservation.amountPaid || ""}
                    placeholder="0.00"
                    onBlur={async e => { 
                      const val = e.target.value.replace(',', '.');
                      await handleUpdateReservation(reservation.id, { amountPaid: val ? Number(val) : null }); 
                    }}
                  />
                </div>
              </div>
              {reservation.totalAmount && reservation.totalAmount > 0 && (
                <div className="mt-3 flex items-center justify-between text-sm">
                  <span className="text-white/40">Ostalo za placilo:</span>
                  <span className={`font-bold ${(reservation.totalAmount - (reservation.amountPaid || 0)) > 0 ? 'text-[#ef4444]' : 'text-[#22c55e]'}`}>
                    {eur((reservation.totalAmount || 0) - (reservation.amountPaid || 0))}
                  </span>
                </div>
              )}
              {/* Commission - show for Agency, Booking.com, Airbnb */}
              {(reservation.bookingSource === 'Agency' || reservation.bookingSource === 'Booking.com' || reservation.bookingSource === 'Airbnb') && (
                <div className="mt-3 pt-3 border-t border-white/10">
                  <div className="flex items-center justify-between">
                    <label className="text-xs text-white/40">Provizija (EUR)</label>
                    <input
                      key={`commission-${reservation.id}`}
                      type="text"
                      inputMode="decimal"
                      className="w-24 rounded-lg border border-white/[0.06] bg-white/[0.02] px-3 py-1.5 text-sm text-right text-[#f1d07a] focus:border-[#f1d07a]/40 focus:outline-none"
                      defaultValue={reservation.agencyCommission || ""}
                      placeholder="0.00"
                      onBlur={async e => { 
                        const val = e.target.value.replace(',', '.');
                        await handleUpdateReservation(reservation.id, { agencyCommission: val ? Number(val) : 0 }); 
                      }}
                    />
                  </div>
                  {reservation.agencyName && (
                    <p className="text-xs text-white/30 mt-1">Agencija: {reservation.agencyName}</p>
                  )}
                </div>
              )}
            </div>
          
  {/* Payment Section */}
  <PaymentSection
    reservationId={reservation.id}
    totalAmount={reservation.totalAmount || '0'}
    currency={reservation.currency || 'EUR'}
    onPaymentChange={refresh}
  />

            <NotesSection 
              notes={reservation.notes || ""} 
              onAddNote={(note) => {
                const timestamp = new Date().toLocaleDateString('sl-SI') + ' ' + new Date().toLocaleTimeString('sl-SI', { hour: '2-digit', minute: '2-digit' });
                const newNote = `[${timestamp}] ${note}`;
                const updatedNotes = reservation.notes ? `${newNote}\n---\n${reservation.notes}` : newNote;
                handleUpdateReservation(reservation.id, { notes: updatedNotes });
              }} 
            />

            {/* Gmail Section */}
            <GmailSection 
              guestName={reservation.guestName}
              guestEmail={reservation.email}
            />
          </div>
          
          {/* Collapsible Excursions Section */}
          <div className="mt-4 pt-4 border-t border-white/10">
            <button
              onClick={() => setShowExcursions(!showExcursions)}
              className="w-full flex items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 py-2.5 text-sm text-white hover:bg-white/[0.04] transition-colors"
            >
              <span className="flex items-center gap-2 min-w-0">
                <Truck className="h-4 w-4 flex-shrink-0 text-[#78b7ff]" />
                <span className="truncate text-xs sm:text-sm">
                  <span className="text-white/60">Izleti: </span>
                  <span className="font-medium">{reservation.excursions?.length || 0} rezerviranih</span>
                </span>
              </span>
              <ChevronDown className={`h-4 w-4 flex-shrink-0 text-white/40 transition-transform ${showExcursions ? 'rotate-180' : ''}`} />
            </button>
            
            {showExcursions && (
              <div className="mt-2 space-y-2">
                <div className="flex justify-end">
                  <button
                    onClick={async () => {
                      if (dbExcursions.length > 0) {
                        await addExcursionBooking(reservation.id, { 
                          excursionId: dbExcursions[0].id, 
                          pax: reservation.pax 
                        });
                        refresh();
                      }
                    }}
                    className="flex items-center gap-2 rounded-lg bg-[#78b7ff]/20 border border-[#78b7ff]/30 px-3 py-1.5 text-xs text-[#78b7ff] hover:bg-[#78b7ff]/30 transition-colors"
                  >
                    <Plus className="h-3 w-3" />
                    Dodaj izlet
                  </button>
                </div>
                
                {(!reservation.excursions || reservation.excursions.length === 0) ? (
                  <p className="text-white/40 text-sm">Ni rezerviranih izletov.</p>
                ) : (
                  <div className="space-y-2">
                    {reservation.excursions.map((exc, idx) => {
                      const excursionData = dbExcursions.find((e: { id: string; name: string; description?: string | null; imageUrl?: string | null }) => e.id === exc.excursionId);
                      const boatData = dbBoats.find((b: { id: string }) => b.id === exc.boatId);
                      const isExpanded = expandedExcursionId === exc.id;
                      return (
                        <div key={exc.id} className="rounded-xl border border-[#78b7ff]/20 bg-[#78b7ff]/5 overflow-hidden">
                          {/* Collapsed header - always visible */}
                          <button
                            onClick={() => setExpandedExcursionId(isExpanded ? null : exc.id)}
                            className="w-full flex items-center justify-between p-3 text-left hover:bg-white/[0.02] transition-colors"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <span className="text-xs font-medium text-[#78b7ff]">#{idx + 1}</span>
                              <span className="text-sm text-white truncate">{excursionData?.name || 'Izlet'}</span>
                              {exc.date && <span className="text-xs text-white/40">{exc.date}</span>}
                            </div>
                            <ChevronDown className={`h-4 w-4 flex-shrink-0 text-white/40 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                          </button>
                          
                          {/* Expanded content */}
                          {isExpanded && (
                            <div className="px-3 pb-3 space-y-3 border-t border-white/10">
                              {/* Delete button */}
                              <div className="flex justify-end pt-2">
                                <button
                                  onClick={async () => {
                                    await deleteExcursionBooking(exc.id);
                                    refresh();
                                  }}
                                  className="text-red-400 hover:text-red-300 text-xs"
                                >
                                  Odstrani
                                </button>
                              </div>
                              
                              {/* Excursion image and description */}
                              {excursionData && (excursionData.imageUrl || excursionData.description) && (
                                <div className="flex gap-3 p-2 rounded-lg bg-white/[0.03] border border-white/[0.06]">
                                  {excursionData.imageUrl && (
                                    <img 
                                      src={excursionData.imageUrl} 
                                      alt={excursionData.name} 
                                      className="w-16 h-16 rounded-lg object-cover flex-shrink-0"
                                    />
                                  )}
                                  <div className="flex-1 min-w-0">
                                    <h4 className="text-sm font-medium text-[#f1d07a]">{excursionData.name}</h4>
                                    {excursionData.description && (
                                      <p className="text-xs text-white/60 mt-1 line-clamp-3">{excursionData.description}</p>
                                    )}
                                  </div>
                                </div>
                              )}
                              
                              <div className="grid grid-cols-2 gap-2">
                                <div>
                                  <label className="block text-[10px] text-white/40 mb-1">Izlet</label>
                                  <select
                                    className="w-full rounded-lg border border-white/10 bg-white/5 px-2 py-1.5 text-xs text-white focus:border-[#78b7ff]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                                    value={exc.excursionId}
                                    onChange={async e => {
                                      await updateExcursionBooking(exc.id, { excursionId: e.target.value });
                                      refresh();
                                    }}
                                  >
                                    {dbExcursions.map((e: { id: string; name: string }) => (
                                      <option key={e.id} value={e.id}>{e.name}</option>
                                    ))}
                                  </select>
                                </div>
                                
                                <div>
                                  <label className="block text-[10px] text-white/40 mb-1">Datum</label>
                                  <input
                                    type="date"
                                    className="w-full rounded-lg border border-white/10 bg-white/5 px-2 py-1.5 text-xs text-white focus:border-[#78b7ff]/50 focus:outline-none"
                                    defaultValue={exc.date || ''}
                                    onBlur={async e => {
                                      if (e.target.value !== exc.date) {
                                        await updateExcursionBooking(exc.id, { date: e.target.value });
                                        refresh();
                                      }
                                    }}
                                  />
                                </div>
                              </div>
                              
                              <div className="grid grid-cols-2 gap-2">
                                <div>
                                  <label className="block text-[10px] text-white/40 mb-1">Coln</label>
                                  <select
                                    className="w-full rounded-lg border border-white/10 bg-white/5 px-2 py-1.5 text-xs text-white focus:border-[#f1d07a]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                                    value={exc.boatId || ''}
                                    onChange={async e => {
                                      const boatId = e.target.value;
                                      const price = getExcursionGuestPrice(exc.excursionId, boatId, reservation.pax);
                                      await updateExcursionBooking(exc.id, { boatId, guestPrice: price });
                                      refresh();
                                    }}
                                  >
                                    <option value="">-- Izberi --</option>
                                    {dbBoats.map((b: { id: string; name: string; engine: string }) => (
                                      <option key={b.id} value={b.id}>{b.name}</option>
                                    ))}
                                  </select>
                                </div>
                                
                                <div>
                                  <label className="block text-[10px] text-white/40 mb-1">Oseb</label>
                                  <input
                                    type="number"
                                    className="w-full rounded-lg border border-white/10 bg-white/5 px-2 py-1.5 text-xs text-white focus:border-[#78b7ff]/50 focus:outline-none"
                                    value={exc.pax || reservation.pax}
                                    onChange={async e => {
                                      const pax = Number(e.target.value);
                                      const price = getExcursionGuestPrice(exc.excursionId, exc.boatId, pax);
                                      await updateExcursionBooking(exc.id, { pax, guestPrice: price });
                                      refresh();
                                    }}
                                  />
                                </div>
                              </div>
                          
                          {/* Entrance Fee */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <label className="block text-xs text-white/40 mb-1">Vstopnina (EUR)</label>
                              <div className="flex items-center gap-2">
                                <input
                                  type="number"
                                  className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#78b7ff]/50 focus:outline-none"
                                  value={exc.entranceFee || 0}
                                  onChange={async e => {
                                    await updateExcursionBooking(exc.id, { entranceFee: Number(e.target.value) });
                                    refresh();
                                  }}
                                />
                                <button
                                  onClick={async () => {
                                    const entrancePerPerson = excursionData?.entranceFeeAr ? arToEur(excursionData.entranceFeeAr, exchangeRate) : 0;
                                    const totalEntrance = entrancePerPerson * (exc.pax || reservation.pax);
                                    await updateExcursionBooking(exc.id, { entranceFee: Math.round(totalEntrance * 100) / 100 });
                                    refresh();
                                  }}
                                  className="px-2 py-2 rounded-lg bg-white/5 text-xs text-white/60 hover:bg-white/10 whitespace-nowrap"
                                  title="Izracunaj iz cenika"
                                >
                                  Auto
                                </button>
                              </div>
                            </div>
                            
                            {/* Lunch Provider */}
                            <div>
                              <label className="block text-xs text-white/40 mb-1">Ponudnik kosila</label>
                              <select
                                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#fb923c]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                                value={exc.lunchProviderId || ''}
                                onChange={async e => {
                                  const providerId = e.target.value;
                                  const provider = dbLunchProviders.find((lp: { id: string }) => lp.id === providerId);
                                  const lunchPricePerPerson = provider ? arToEur(provider.pricePerPersonAr, exchangeRate) : 0;
                                  const totalLunch = lunchPricePerPerson * (exc.pax || reservation.pax);
                                  await updateExcursionBooking(exc.id, { 
                                    lunchProviderId: providerId, 
                                    lunchPrice: Math.round(totalLunch * 100) / 100 
                                  });
                                  refresh();
                                }}
                              >
                                <option value="">-- Brez kosila --</option>
                                {dbLunchProviders.map((lp: { id: string; name: string; location: string | null; pricePerPersonAr: number }) => (
                                  <option key={lp.id} value={lp.id}>
                                    {lp.name} {lp.location ? `(${lp.location})` : ''} - {eur(arToEur(lp.pricePerPersonAr, exchangeRate))}/os
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>
                          
                          {/* Lunch Price - only if provider selected */}
                          {exc.lunchProviderId && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              <div>
                                <label className="block text-xs text-white/40 mb-1">Cena kosila (EUR)</label>
                                <input
                                  type="number"
                                  className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#fb923c]/50 focus:outline-none"
                                  value={exc.lunchPrice || 0}
                                  onChange={async e => {
                                    await updateExcursionBooking(exc.id, { lunchPrice: Number(e.target.value) });
                                    refresh();
                                  }}
                                />
                              </div>
                              <div className="flex items-end pb-2">
                                <p className="text-xs text-white/40">Skupaj kosilo: {eur(exc.lunchPrice || 0)}</p>
                              </div>
                            </div>
                          )}
                          
                          {/* Transport Price and Payment */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <LuxuryInput 
                              label="Cena transporta (EUR)" 
                              type="number" 
                              value={exc.guestPrice} 
                              onChange={async v => {
                                await updateExcursionBooking(exc.id, { guestPrice: Number(v) });
                                refresh();
                              }} 
                            />
                            <LuxurySelect
                              label="Status placila"
                              value={exc.paymentStatus || 'UNPAID'}
                              onChange={async v => {
                                await updateExcursionBooking(exc.id, { paymentStatus: v });
                                refresh();
                              }}
                              options={[
                                { value: 'PREPAID', label: 'Vkljuceno v rezervacijo' },
                                { value: 'PAID', label: 'Placano' },
                                { value: 'UNPAID', label: 'Se ni placano' },
                              ]}
                            />
                          </div>
                          
                          {/* Total Summary */}
                          <div className="p-3 rounded-lg bg-[#78b7ff]/10 border border-[#78b7ff]/20">
                            <div className="flex justify-between text-xs text-white/60">
                              <span>Transport:</span>
                              <span>{eur(exc.guestPrice || 0)}</span>
                            </div>
                            <div className="flex justify-between text-xs text-white/60">
                              <span>Vstopnina:</span>
                              <span>{eur(exc.entranceFee || 0)}</span>
                            </div>
                            {exc.lunchProviderId && (
                              <div className="flex justify-between text-xs text-white/60">
                                <span>Kosilo:</span>
                                <span>{eur(exc.lunchPrice || 0)}</span>
                              </div>
                            )}
                            <div className="flex justify-between text-sm font-medium text-[#78b7ff] pt-2 mt-2 border-t border-[#78b7ff]/20">
                              <span>SKUPAJ:</span>
                              <span>{eur((exc.guestPrice || 0) + (exc.entranceFee || 0) + (exc.lunchPrice || 0))}</span>
                            </div>
                          </div>
                          
                          {/* Notes */}
                          <div>
                            <label className="block text-xs text-white/40 mb-1">Opombe</label>
                            <input
                              type="text"
                              placeholder="npr. potrebuje vegetarijansko kosilo..."
                              className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#78b7ff]/50 focus:outline-none"
                              defaultValue={exc.notes || ''}
                              onBlur={async e => {
                                await updateExcursionBooking(exc.id, { notes: e.target.value });
                                refresh();
                              }}
                            />
                          </div>
                          
                          {/* Order Dilip */}
                          <div className="pt-2 border-t border-white/10">
                            <a
                              href={`https://wa.me/261326801412?text=${encodeURIComponent(
                                `Pozdravljeni, narocam izlet:\n` +
                                `- Izlet: ${excursionData?.name || 'ni izbran'}\n` +
                                `- Datum: ${exc.date || 'ni izbran'}\n` +
                                `- Coln: ${boatData?.name || 'ni izbran'}\n` +
                                `- Stevilo oseb: ${exc.pax || reservation.pax}\n` +
                                `- Gost: ${reservation.guestName}\n` +
                                `${exc.notes ? `- Opombe: ${exc.notes}\n` : ''}` +
                                `Hvala!`
                              )}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center justify-center gap-2 w-full rounded-lg bg-[#25D366]/20 border border-[#25D366]/30 px-3 py-2 text-sm text-[#25D366] hover:bg-[#25D366]/30 transition-colors"
                            >
                              <Ship className="h-4 w-4" />
                              Naroci Dilipa
                            </a>
                            {exc.dilipOrderedAt ? (
                              <div className="text-[10px] text-green-400 text-center mt-1">
                                Naroceno: {new Date(exc.dilipOrderedAt).toLocaleString('sl-SI')}
                              </div>
                            ) : (
                              <button
                                onClick={async () => {
                                  await updateExcursionBooking(exc.id, { dilipOrderedAt: new Date().toISOString() });
                                  refresh();
                                }}
                                className="w-full text-[10px] text-white/40 hover:text-white/60 underline mt-1"
                              >
                                Potrdi narocilo
                              </button>
                            )}
                          </div>
                          
                          {/* Voucher Buttons */}
                          <div className="flex gap-2 mt-3">
                          <button
                            onClick={() => {
                              const lunchProvider = dbLunchProviders.find((lp: { id: string; name: string; location: string | null }) => lp.id === exc.lunchProviderId);
                              const voucherWindow = window.open('', '_blank', 'width=550,height=850,scrollbars=yes');
                              if (!voucherWindow) return;
                              
                              voucherWindow.document.write(`
<!DOCTYPE html>
<html>
<head>
  <title>Voucher - ${excursionData?.name || 'Izlet'}</title>
  <meta charset="utf-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    @page { size: A4; margin: 0; }
    body { 
      font-family: 'Segoe UI', system-ui, sans-serif; 
      background: #0f1724;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      padding: 16px;
    }
    .voucher {
      width: 100%;
      max-width: 500px;
      background: white;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
    }
    .header {
      background: linear-gradient(to right, #0f1724, #1a2744);
      padding: 16px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .logo-img {
      height: 50px;
      width: auto;
    }
    .subtitle {
      font-size: 10px;
      letter-spacing: 3px;
      color: rgba(255,255,255,0.6);
      text-transform: uppercase;
    }
    .image-section {
      width: 100%;
      height: 160px;
    }
    .image-section img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .content {
      padding: 20px;
    }
    .excursion-name {
      font-size: 20px;
      font-weight: 700;
      color: #0f1724;
      margin-bottom: 8px;
    }
    .description {
      font-size: 12px;
      color: #64748b;
      line-height: 1.6;
      margin-bottom: 16px;
      padding-bottom: 16px;
      border-bottom: 1px solid #e2e8f0;
    }
    .guest-section {
      background: linear-gradient(135deg, rgba(120,183,255,0.1), rgba(120,183,255,0.05));
      border: 1px solid rgba(120,183,255,0.3);
      border-radius: 12px;
      padding: 12px;
      margin-bottom: 12px;
    }
    .guest-label {
      font-size: 9px;
      letter-spacing: 1px;
      text-transform: uppercase;
      color: #78b7ff;
      margin-bottom: 4px;
    }
    .guest-name {
      font-size: 16px;
      font-weight: 700;
      color: #0f1724;
      line-height: 1.4;
    }
    .honeymoon-badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      background: linear-gradient(135deg, #fef3c7, #fde68a);
      border: 1px solid #f59e0b;
      border-radius: 12px;
      padding: 4px 10px;
      margin-top: 8px;
      color: #92400e;
      font-size: 10px;
      font-weight: 600;
    }
    .honeymoon-badge svg {
      width: 12px;
      height: 12px;
      fill: #dc2626;
    }
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
      margin-bottom: 12px;
    }
    .info-item {
      padding: 10px;
      background: #f8fafc;
      border-radius: 8px;
    }
    .info-label {
      font-size: 8px;
      letter-spacing: 1px;
      text-transform: uppercase;
      color: #94a3b8;
      margin-bottom: 2px;
    }
    .info-value {
      font-size: 13px;
      font-weight: 600;
      color: #0f1724;
    }
    .footer {
      background: #f8fafc;
      padding: 12px 20px;
      text-align: center;
      border-top: 1px solid #e2e8f0;
    }
    .footer-text {
      font-size: 10px;
      color: #94a3b8;
    }
    * {
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
      color-adjust: exact !important;
    }
    @media print {
      body { background: white; padding: 0; }
      .voucher { box-shadow: none; }
      .header {
        background: linear-gradient(to right, #0f1724, #1a2744) !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
    }
  </style>
</head>
<body>
  <div class="voucher">
    <div class="header">
      <img src="${window.location.origin}/images/komba-logo-gold.png" alt="Komba Cabana" class="logo-img" />
      <div class="subtitle">Excursion Voucher</div>
    </div>
    
    ${excursionData?.imageUrl ? `<div class="image-section"><img src="${excursionData.imageUrl}" alt="${excursionData?.name || ''}" /></div>` : ''}
    
    <div class="content">
      <h1 class="excursion-name">${excursionData?.name || 'Izlet'}</h1>
      ${excursionData?.description ? `<p class="description">${excursionData.description.replace(/\n/g, '<br>')}</p>` : ''}
      
      <div class="guest-section">
        <div class="guest-label">${reservation.secondGuestName ? 'Guests' : 'Guest'}</div>
        <div class="guest-name">${reservation.guestName}${reservation.secondGuestName ? '<br>' + reservation.secondGuestName : ''}</div>
        ${reservation.honeymoon ? '<div class="honeymoon-badge"><svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg> Honeymoon</div>' : ''}
      </div>
      
      <div class="info-grid">
        <div class="info-item">
          <div class="info-label">Date</div>
          <div class="info-value">${exc.date ? new Date(exc.date).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }) : 'TBC'}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Number of Guests</div>
          <div class="info-value">${exc.pax || reservation.pax} ${(exc.pax || reservation.pax) === 1 ? 'person' : 'people'}</div>
        </div>
      </div>
    </div>
    
    <div class="footer">
      <div class="footer-text">Thank you for choosing Komba Cabana. Enjoy your adventure!</div>
    </div>
  </div>
</body>
</html>
                              `);
                              
                              voucherWindow.document.close();
                              voucherWindow.focus();
                              setTimeout(() => { voucherWindow.print(); }, 800);
                            }}
                            className="flex items-center justify-center gap-2 flex-1 rounded-lg bg-[#f1d07a]/20 border border-[#f1d07a]/30 px-3 py-2 text-sm text-[#f1d07a] hover:bg-[#f1d07a]/30 transition-colors"
                          >
                            <Printer className="h-4 w-4" />
                            Natisni
                          </button>
                          <button
                            onClick={() => {
                              const url = `${window.location.origin}/voucher/${exc.id}`;
                              const textarea = document.createElement('textarea');
                              textarea.value = url;
                              textarea.style.position = 'fixed';
                              textarea.style.opacity = '0';
                              document.body.appendChild(textarea);
                              textarea.select();
                              document.execCommand('copy');
                              document.body.removeChild(textarea);
                              alert('Komba Cabana voucher link kopiran!');
                            }}
                            className="flex items-center justify-center gap-2 flex-1 rounded-lg bg-[#78b7ff]/20 border border-[#78b7ff]/30 px-3 py-2 text-sm text-[#78b7ff] hover:bg-[#78b7ff]/30 transition-colors"
                          >
                            <ExternalLink className="h-4 w-4" />
                            Kopiraj Link
                          </button>
                          </div>
                          </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
          
          <div className="mt-6 pt-4 border-t border-white/10">
            <LuxuryButton variant="danger" className="w-full sm:w-auto" onClick={() => handleDeleteReservation(reservation.id)}>
              Izbrisi rezervacijo
            </LuxuryButton>
          </div>
          
          {/* Police Form Modal */}
          <PoliceFormModal 
            reservation={reservation} 
            isOpen={showPoliceForm} 
            onClose={() => setShowPoliceForm(false)} 
          />
        </GlassCard>
      </section>
    );
  }

  function Orders() {
    const reservation = activeReservation();

    // ===== Invoice discounts (popusti) — hooks must run unconditionally =====
    const reservationId = reservation?.id || '';
    const [discounts, setDiscounts] = React.useState<{ id: string; kind: string; label: string; amountAr: number }[]>([]);
    const [discountKind, setDiscountKind] = React.useState<'stay' | 'item'>('stay');
    const [discountLabel, setDiscountLabel] = React.useState('');
    const [discountAmount, setDiscountAmount] = React.useState('');
    const [addingDiscount, setAddingDiscount] = React.useState(false);

    async function loadDiscounts() {
      if (!reservationId) { setDiscounts([]); return; }
      const { getInvoiceDiscounts } = await import("@/app/actions/komba");
      const data = await getInvoiceDiscounts(reservationId);
      setDiscounts(data as typeof discounts);
    }
    React.useEffect(() => { loadDiscounts(); }, [reservationId]);

    async function handleAddDiscount() {
      const eur = parseFloat(discountAmount);
      if (isNaN(eur) || eur <= 0 || !reservationId) return;
      setAddingDiscount(true);
      const { addInvoiceDiscount } = await import("@/app/actions/komba");
      await addInvoiceDiscount(reservationId, discountKind, discountLabel, Math.round(eur * exchangeRate));
      setDiscountLabel('');
      setDiscountAmount('');
      await loadDiscounts();
      setAddingDiscount(false);
    }

    async function handleDeleteDiscount(id: string) {
      const { deleteInvoiceDiscount } = await import("@/app/actions/komba");
      await deleteInvoiceDiscount(id, reservationId);
      await loadDiscounts();
    }

    if (!reservation) return <GlassCard><p className="text-white/40">Ni izbranega gosta.</p></GlassCard>;

    const orderItems = reservation.orderItems || [];
    const barItems = reservation.barItems || [];
    
    // Create items with service dates and executed status
    interface OrderItemWithDate extends OrderItem {
      serviceDate: string;
      executed?: boolean;
      isTransfer?: boolean;
      isBarItem?: boolean;
    }
    
    const itemsWithDates: OrderItemWithDate[] = [];
    
    // Arrival transfer - only include if executed (or always show but mark differently)
    if (reservation.transfers.arrival.route) {
      itemsWithDates.push({ 
        id: "arrival-transfer", 
        name: "Arrival Transfer", 
        category: "Transfer", 
        qty: 1, 
        priceAr: eurToAr(reservation.transfers.arrival.guestPrice, exchangeRate), 
        paymentStatus: reservation.transfers.arrival.paymentStatus,
        serviceDate: reservation.arrival,
        executed: reservation.transfers.arrival.executed,
        isTransfer: true
      });
    }
    
    // Departure transfer - only include if executed (or always show but mark differently)
    if (reservation.transfers.departure.route) {
      itemsWithDates.push({ 
        id: "departure-transfer", 
        name: "Departure Transfer", 
        category: "Transfer", 
        qty: 1, 
        priceAr: eurToAr(reservation.transfers.departure.guestPrice, exchangeRate), 
        paymentStatus: reservation.transfers.departure.paymentStatus,
        serviceDate: reservation.departure,
        executed: reservation.transfers.departure.executed,
        isTransfer: true
      });
    }
    
  // Other order items - use eventDate (user-specified) or createdAt as fallback.
  // Skip "Bivanje" (accommodation) items: accommodation is accounted for separately
  // via reservation.totalAmount in the PaymentSection, so including it here would double count.
  orderItems.forEach(item => {
    if ((item as any).category === 'Bivanje') return;
    const itemWithMeta = item as OrderItemWithDate & { eventDate?: string; createdAt?: string };
    itemsWithDates.push({
      ...item,
      serviceDate: itemWithMeta.eventDate || itemWithMeta.createdAt?.split('T')[0] || new Date().toISOString().split('T')[0],
      executed: true // Bar items are always "executed"
    });
  });
  
  // Bar items from delivery notes
  barItems.forEach((item: any) => {
    itemsWithDates.push({
      id: item.id,
      name: item.productName,
      category: item.category || 'Bar',
      qty: item.quantity,
      priceAr: item.priceAr,
      paymentStatus: 'UNPAID', // Bar items are always unpaid until checkout
      serviceDate: item.noteDate || new Date().toISOString().split('T')[0],
      executed: true,
      isBarItem: true
    });
  });
    
    // Separate items for display
    const executedUnpaid = itemsWithDates.filter(item => (item.executed || !item.isTransfer) && item.paymentStatus !== "PAID" && item.paymentStatus !== "PREPAID");
    const paidItems = itemsWithDates.filter(item => item.paymentStatus === "PAID" || item.paymentStatus === "PREPAID");
    const notExecutedTransfers = itemsWithDates.filter(item => item.isTransfer && !item.executed);
    
    // Group executed unpaid items by service date
    const groupedByDate = executedUnpaid.reduce((groups, item) => {
      const date = item.serviceDate;
      if (!groups[date]) groups[date] = [];
      groups[date].push(item);
      return groups;
    }, {} as Record<string, OrderItemWithDate[]>);
    
    // Sort dates chronologically
    const sortedDates = Object.keys(groupedByDate).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
    
    // Total only from executed unpaid items.
    // Bar items (from delivery notes) store priceAr PER UNIT, so multiply by qty.
    // Order items / transfers store priceAr as the TOTAL line price already, so do NOT multiply.
    const totalAr = executedUnpaid.reduce((sum, item) => sum + num(item.priceAr) * (item.isBarItem ? num(item.qty || 1) : 1), 0);
    const discountTotalAr = discounts.reduce((sum, d) => sum + (d.amountAr || 0), 0);
    const netTotalAr = Math.max(0, totalAr - discountTotalAr);

    const formatDateSlo = (dateStr: string) => {
      const date = new Date(dateStr);
      return date.toLocaleDateString('sl-SI', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    };

    return (
      <section className="grid gap-8 xl:grid-cols-[440px_1fr]">
        <GlassCard>
          <SectionHeader eyebrow="Delivery Note" title="Rocni vnos dobavnice" />
          
          {/* Check-out reminder */}
          {!reservation.checkedOutAt && (
            <div className="mt-4 rounded-xl border border-[#f1d07a]/30 bg-[#f1d07a]/10 p-3">
              <p className="text-xs text-[#f1d07a]">Dobavnica se zakljuci ob Check-out gosta</p>
            </div>
          )}
          
          {/* Shared Invoice Link */}
          {reservation.groupId && (() => {
            const mainRes = reservations.find(r => r.groupId === reservation.groupId && r.isMainReservation);
            if (mainRes?.sharedInvoice) {
              return (
                <Link
                  href={`/dobavnice/${mainRes.id}`}
                  className="mt-4 flex items-center justify-center gap-2 w-full rounded-xl border border-purple-500/30 bg-purple-500/10 py-3 px-4 text-sm font-medium text-purple-300 hover:bg-purple-500/20 transition-all"
                >
                  <Users className="h-4 w-4" />
                  Odpri skupno dobavnico
                </Link>
              );
            }
            return null;
          })()}
          
  <div className="mt-4 rounded-2xl bg-gradient-to-r from-[#f1d07a]/10 to-[#b8892f]/10 p-4">
  <p className="text-sm text-white/50">Skupaj za placilo:</p>
  {discountTotalAr > 0 && (
    <>
      <p className="mt-1 text-sm text-white/40 line-through">{ar(totalAr)}</p>
      <p className="text-xs text-[#6fc8a3]">Popust: -{ar(discountTotalAr)} ({eur(arToEur(discountTotalAr, exchangeRate))})</p>
    </>
  )}
  <p className="mt-1 bg-gradient-to-r from-[#fff4cc] to-[#f1d07a] bg-clip-text text-2xl font-light text-transparent">{ar(netTotalAr)}</p>
  <p className="text-lg text-white font-medium">{eur(arToEur(netTotalAr, exchangeRate))}</p>
  </div>

  {/* Popusti (discounts) - only before checkout */}
  {reservation.checkedInAt && !reservation.checkedOutAt && (
  <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.02] p-5 space-y-4">
    <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#94a3b8]">Popusti</p>

    {/* Existing discounts */}
    {discounts.length > 0 && (
      <div className="space-y-2">
        {discounts.map(d => (
          <div key={d.id} className="flex items-center justify-between rounded-xl bg-white/[0.03] border border-white/10 px-3 py-2">
            <div>
              <p className="text-sm font-medium text-white">{d.label}</p>
              <p className="text-xs text-white/40">{d.kind === 'item' ? 'Brezplacna postavka' : 'Popust na bivanje'}</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm font-medium text-[#6fc8a3]">-{eur(arToEur(d.amountAr, exchangeRate))}</span>
              <button onClick={() => handleDeleteDiscount(d.id)} className="rounded-lg p-1.5 text-white/40 hover:bg-white/10 hover:text-[#ff6b6b] transition-colors">
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    )}

    {/* Kind toggle */}
    <div className="grid grid-cols-2 gap-2">
      <button
        onClick={() => setDiscountKind('stay')}
        className={`rounded-xl border px-3 py-2.5 text-center text-sm transition-all ${discountKind === 'stay' ? 'border-white/30 bg-white/10 text-white' : 'border-white/10 bg-white/[0.02] text-white/50 hover:bg-white/[0.05]'}`}
      >
        Popust na bivanje
      </button>
      <button
        onClick={() => setDiscountKind('item')}
        className={`rounded-xl border px-3 py-2.5 text-center text-sm transition-all ${discountKind === 'item' ? 'border-white/30 bg-white/10 text-white' : 'border-white/10 bg-white/[0.02] text-white/50 hover:bg-white/[0.05]'}`}
      >
        Brezplacna postavka
      </button>
    </div>

    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      <input
        type="text"
        value={discountLabel}
        onChange={e => setDiscountLabel(e.target.value)}
        placeholder={discountKind === 'item' ? 'Npr. Brezplacna vecerja' : 'Npr. Popust na bivanje'}
        className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-white/30 focus:border-[#6fc8a3]/50 focus:outline-none"
      />
      <div className="relative">
        <input
          type="number" step="0.01"
          value={discountAmount}
          onChange={e => setDiscountAmount(e.target.value)}
          placeholder="Znesek"
          className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-white/30 focus:border-[#6fc8a3]/50 focus:outline-none"
        />
        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-white/40">EUR</span>
      </div>
    </div>

    <button
      onClick={handleAddDiscount}
      disabled={addingDiscount || !discountAmount || parseFloat(discountAmount) <= 0}
      className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#6fc8a3]/30 bg-[#6fc8a3]/15 py-3 text-sm font-medium text-[#6fc8a3] transition-all hover:bg-[#6fc8a3]/25 disabled:cursor-not-allowed disabled:opacity-50"
    >
      {addingDiscount ? 'Dodajam...' : '+ Dodaj popust'}
    </button>
  </div>
  )}
  
  {/* Payments Section for manual entry */}
  <div className="mt-6">
  <PaymentSection 
    reservationId={reservation.id} 
    totalAmount={(Number(reservation.totalAmount || 0) + arToEur(netTotalAr, exchangeRate)).toFixed(2)} 
    currency="EUR" 
    onPaymentChange={refresh} 
  />
  </div>
  
  {/* Predogled računa (odpre stran računa v novem zavihku - NE zaključi ničesar) */}
  {reservation.checkedInAt && !reservation.checkedOutAt && (
  <div className="mt-6">
  <button
    onClick={() => window.open(`/racun/${reservation.id}?view=true`, "_blank")}
    className="w-full flex items-center justify-center gap-2 rounded-xl bg-[#78b7ff]/10 border border-[#78b7ff]/30 py-4 px-4 text-sm font-medium text-[#78b7ff] hover:bg-[#78b7ff]/20 transition-all"
  >
    <FileText className="h-4 w-4" />
    Predogled računa
  </button>
  </div>
  )}

  {/* Issue Invoice & Checkout Button */}
  {reservation.checkedInAt && !reservation.checkedOutAt && (
  <div className="mt-6">
  <button
    onClick={async () => {
      if (!confirm("Izdaj racun in opravi check-out?")) return;
      setSaving(true);
      // Close all open delivery notes
      await closeAllDeliveryNotesForReservation(reservation.id);
      // Set check-out timestamp
      await handleUpdateReservation(reservation.id, { checkedOutAt: new Date().toISOString() });
      showMsg("Racun izdan, check-out opravljen!");
      setSaving(false);
    }}
    disabled={saving}
    className="w-full rounded-xl bg-gradient-to-r from-[#6fc8a3]/20 to-[#4a9f7e]/20 border border-[#6fc8a3]/30 py-4 px-4 text-sm font-medium text-[#6fc8a3] hover:from-[#6fc8a3]/30 hover:to-[#4a9f7e]/30 transition-all"
  >
    {saving ? "Izdajam..." : "Izdaj racun in Check-out"}
  </button>
  </div>
  )}
          
          <div className="mt-6 space-y-4">
            {/* Datum - use uncontrolled input with key to prevent focus loss */}
            <div>
              <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Datum</label>
              <input
                key="manual-date-input"
                type="date"
                className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                defaultValue={orderDraft.eventDate}
                onBlur={e => {
                  if (e.target.value && e.target.value !== orderDraft.eventDate) {
                    setOrderDraft(p => ({ ...p, eventDate: e.target.value }))
                  }
                }}
              />
            </div>
            
            {/* Kategorija - najprej izberi kategorijo */}
            <LuxurySelect 
              label="Kategorija" 
              value={orderDraft.category} 
              onChange={v => setOrderDraft(p => ({ ...p, category: v, name: "", priceAr: 0 }))} 
              options={[
                { value: "", label: "Izberi kategorijo" },
                ...Array.from(new Set(dbAllProducts.map(p => p.category))).map(cat => ({ value: cat, label: cat }))
              ]} 
            />
            
            {/* Produkt - filtrirano po kategoriji */}
            {orderDraft.category && (
              <LuxurySelect 
                label="Produkt" 
                value="" 
                onChange={v => { 
                  const item = dbAllProducts.find(x => x.id === v); 
                  if (item) setOrderDraft(p => ({ ...p, name: item.name, priceAr: item.priceAr })); 
                }} 
                options={[
                  { value: "", label: "Izberi produkt" }, 
                  ...dbAllProducts
                    .filter(p => p.category === orderDraft.category)
                    .map(item => ({ value: item.id, label: `${item.name} - ${ar(item.priceAr)}` }))
                ]} 
              />
            )}
            
            <LuxuryInput label="Naziv" value={orderDraft.name} onChange={v => setOrderDraft(p => ({ ...p, name: v }))} />
            <LuxuryInput label="Kolicina" type="number" value={orderDraft.qty} onChange={v => setOrderDraft(p => ({ ...p, qty: Number(v) }))} />
            <LuxuryInput label="Cena Ar" type="number" value={orderDraft.priceAr} onChange={v => setOrderDraft(p => ({ ...p, priceAr: Number(v) }))} />
            <p className="text-xs text-white/40">= {eur(arToEur(orderDraft.priceAr, exchangeRate))}</p>
            <LuxuryButton variant="gold" className="w-full" onClick={handleAddOrder} disabled={saving}>{saving ? "Dodajam..." : "Dodaj postavko"}</LuxuryButton>
            
            {/* Divider */}
            <div className="my-6 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
            
            {/* Transfer Entry - with route and boat selection */}
            <div className="space-y-3">
              <p className="text-[11px] font-medium uppercase tracking-wider text-white/40">Dodaj prevoz</p>
              <LuxurySelect 
                label="Tip prevoza" 
                value={transferDraft.type} 
                onChange={v => setTransferDraft(p => ({ ...p, type: v as "arrival" | "departure" }))} 
                options={[
                  { value: "arrival", label: "Prihod (Arrival)" },
                  { value: "departure", label: "Odhod (Departure)" }
                ]} 
              />
              <div>
                <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Datum</label>
                <input
                  type="date"
                  className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                  defaultValue={transferDraft.date}
                  onBlur={e => setTransferDraft(p => ({ ...p, date: e.target.value }))}
                />
              </div>
              <LuxurySelect 
                label="Relacija" 
                value={transferDraft.routeId} 
                onChange={v => setTransferDraft(p => ({ ...p, routeId: v }))} 
                options={[
                  { value: "", label: "-- Izberi relacijo --" },
                  ...dbRoutes.map((r: { id: string; name: string }) => ({ value: r.id, label: r.name }))
                ]} 
              />
              {transferDraft.routeId && (
                <LuxurySelect 
                  label="Coln" 
                  value={transferDraft.boatId} 
                  onChange={v => setTransferDraft(p => ({ ...p, boatId: v }))} 
                  options={[
                    { value: "", label: "-- Izberi coln --" },
                    ...dbBoats.map((b: { id: string; name: string }) => ({ value: b.id, label: b.name }))
                  ]} 
                />
              )}
              {transferDraft.routeId && transferDraft.boatId && (
                <p className="text-sm text-[#f1d07a]">
                  Cena: {eur(getTransferGuestPrice(transferDraft.routeId, transferDraft.boatId, reservation.pax))} ({reservation.pax} oseb)
                </p>
              )}
              <LuxurySelect 
                label="Status placila" 
                value={transferDraft.paymentStatus} 
                onChange={v => setTransferDraft(p => ({ ...p, paymentStatus: v as "PAID" | "UNPAID" }))} 
                options={[
                  { value: "UNPAID", label: "Za placilo" },
                  { value: "PAID", label: "Placano" }
                ]} 
              />
              <LuxuryButton variant="gold" className="w-full" onClick={async () => {
                if (!transferDraft.routeId) { showMsg("Izberi relacijo"); return; }
                if (!transferDraft.boatId) { showMsg("Izberi coln"); return; }
                setSaving(true);
                const routeName = dbRoutes.find((r: { id: string; name: string }) => r.id === transferDraft.routeId)?.name || transferDraft.routeId;
                const boatName = dbBoats.find((b: { id: string; name: string }) => b.id === transferDraft.boatId)?.name || '';
                const priceEur = getTransferGuestPrice(transferDraft.routeId, transferDraft.boatId, reservation.pax);
                const priceAr = Math.round(priceEur * exchangeRate);
                await addOrderItem(reservation.id, {
                  name: `Transfer ${transferDraft.type === "arrival" ? "ARRIVAL" : "DEPARTURE"}: ${routeName}${boatName ? ` (${boatName})` : ''} - ${reservation.pax} pax`,
                  category: "Transfer",
                  qty: 1,
                  priceAr: transferDraft.paymentStatus === 'PAID' ? 0 : priceAr,
                  paymentStatus: transferDraft.paymentStatus,
                  eventDate: transferDraft.date
                });
                setTransferDraft({ type: "arrival", date: today(), routeId: "", boatId: "", paymentStatus: "UNPAID" });
                refresh();
                setSaving(false);
              }} disabled={saving || !transferDraft.routeId || !transferDraft.boatId}>{saving ? "Dodajam..." : "Dodaj prevoz"}</LuxuryButton>
            </div>
            
            {/* Divider */}
            <div className="my-6 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
            
            {/* Excursion Entry - with excursion and boat selection */}
            <div className="space-y-3">
              <p className="text-[11px] font-medium uppercase tracking-wider text-white/40">Dodaj izlet</p>
              <LuxurySelect 
                label="Izlet" 
                value={excursionDraft.excursionId} 
                onChange={v => setExcursionDraft(p => ({ ...p, excursionId: v }))} 
                options={[
                  { value: "", label: "-- Izberi izlet --" },
                  ...dbExcursions.map((e: { id: string; name: string }) => ({ value: e.id, label: e.name }))
                ]} 
              />
              <div>
                <label className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-white/40">Datum</label>
                <input
                  type="date"
                  className="w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
                  defaultValue={excursionDraft.date}
                  onBlur={e => setExcursionDraft(p => ({ ...p, date: e.target.value }))}
                />
              </div>
              {excursionDraft.excursionId && (
                <LuxurySelect 
                  label="Coln" 
                  value={excursionDraft.boatId} 
                  onChange={v => setExcursionDraft(p => ({ ...p, boatId: v }))} 
                  options={[
                    { value: "", label: "-- Izberi coln --" },
                    ...dbBoats.map((b: { id: string; name: string }) => ({ value: b.id, label: b.name }))
                  ]} 
                />
              )}
              {excursionDraft.excursionId && excursionDraft.boatId && (
                <p className="text-sm text-[#f1d07a]">
                  Cena: {eur(getExcursionGuestPrice(excursionDraft.excursionId, excursionDraft.boatId, reservation.pax))} ({reservation.pax} oseb)
                </p>
              )}
              <LuxurySelect 
                label="Status placila" 
                value={excursionDraft.paymentStatus} 
                onChange={v => setExcursionDraft(p => ({ ...p, paymentStatus: v as "PAID" | "UNPAID" }))} 
                options={[
                  { value: "UNPAID", label: "Za placilo" },
                  { value: "PAID", label: "Placano" }
                ]} 
              />
              <LuxuryButton variant="gold" className="w-full" onClick={async () => {
                if (!excursionDraft.excursionId) { showMsg("Izberi izlet"); return; }
                if (!excursionDraft.boatId) { showMsg("Izberi coln"); return; }
                setSaving(true);
                const excursionName = dbExcursions.find((e: { id: string; name: string }) => e.id === excursionDraft.excursionId)?.name || excursionDraft.excursionId;
                const boatName = dbBoats.find((b: { id: string; name: string }) => b.id === excursionDraft.boatId)?.name || '';
                const priceEur = getExcursionGuestPrice(excursionDraft.excursionId, excursionDraft.boatId, reservation.pax);
                const priceAr = Math.round(priceEur * exchangeRate);
                await addOrderItem(reservation.id, {
                  name: `${excursionName}${boatName ? ` (${boatName})` : ''} - ${reservation.pax} pax`,
                  category: "Izlet",
                  qty: 1,
                  priceAr: excursionDraft.paymentStatus === 'PAID' ? 0 : priceAr,
                  paymentStatus: excursionDraft.paymentStatus,
                  eventDate: excursionDraft.date
                });
                setExcursionDraft({ excursionId: "", date: today(), boatId: "", paymentStatus: "UNPAID" });
                refresh();
                setSaving(false);
              }} disabled={saving || !excursionDraft.excursionId || !excursionDraft.boatId}>{saving ? "Dodajam..." : "Dodaj izlet"}</LuxuryButton>
            </div>
          </div>
        </GlassCard>
        <GlassCard>
          <SectionHeader eyebrow={reservation.guestName} title="Postavke za placilo" />
          <div className="mt-6 space-y-6 max-h-[500px] overflow-y-auto pr-2">
            {sortedDates.length === 0 && paidItems.length === 0 && notExecutedTransfers.length === 0 ? <p className="text-white/40">Ni postavk.</p> : null}
            
            {/* Executed Unpaid Items - grouped by date */}
            {sortedDates.map(date => (
              <div key={date} className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="h-px flex-1 bg-gradient-to-r from-[#f1d07a]/30 to-transparent" />
                  <span className="text-sm font-medium text-[#f1d07a]">{formatDateSlo(date)}</span>
                  <div className="h-px flex-1 bg-gradient-to-l from-[#f1d07a]/30 to-transparent" />
                </div>
                {groupedByDate[date].map(item => (
                  <div key={item.id} className="flex items-center justify-between rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4">
                    <div>
                      <p className="text-white">{item.name}</p>
                      <p className="mt-1 text-xs text-white/40">{item.category} | Qty {item.qty} | {ar(item.priceAr)}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <LuxuryBadge variant="danger">Za placilo</LuxuryBadge>
                      <button className="text-[#d94a63] transition-colors hover:text-[#d94a63]/70" onClick={() => handleDeleteOrder(item.id)}>Odstrani</button>
                    </div>
                  </div>
                ))}
              </div>
            ))}
            
            {/* Not Executed Transfers - shown but not on invoice */}
            {notExecutedTransfers.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="h-px flex-1 bg-gradient-to-r from-white/10 to-transparent" />
                  <span className="text-sm font-medium text-white/40">Neizveden transfer (ni na dobavnici)</span>
                  <div className="h-px flex-1 bg-gradient-to-l from-white/10 to-transparent" />
                </div>
                {notExecutedTransfers.map(item => (
                  <div key={item.id} className="flex items-center justify-between rounded-2xl border border-white/[0.05] bg-white/[0.01] p-4 opacity-50">
                    <div>
                      <p className="text-white/60 line-through">{item.name}</p>
                      <p className="mt-1 text-xs text-white/30">{item.category} | Qty {item.qty} | {ar(item.priceAr)}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <LuxuryBadge variant="default">Ni izveden</LuxuryBadge>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Paid Items - shown as evidence */}
            {paidItems.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="h-px flex-1 bg-gradient-to-r from-[#0eb39a]/30 to-transparent" />
                  <span className="text-sm font-medium text-[#0eb39a]">Ze placano (evidenca)</span>
                  <div className="h-px flex-1 bg-gradient-to-l from-[#0eb39a]/30 to-transparent" />
                </div>
                {paidItems.map(item => (
                  <div key={item.id} className="flex items-center justify-between rounded-2xl border border-[#0eb39a]/10 bg-[#0eb39a]/5 p-4">
                    <div>
                      <p className="text-white/60">{item.name}</p>
                      <p className="mt-1 text-xs text-white/30">{item.category} | Qty {item.qty} | {ar(item.priceAr)}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <LuxuryBadge variant="petrol">{item.paymentStatus === "PREPAID" ? "Predplacano" : "Placano"}</LuxuryBadge>
                      <button className="text-[#d94a63] transition-colors hover:text-[#d94a63]/70" onClick={() => handleDeleteOrder(item.id)}>Odstrani</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </GlassCard>
      </section>
    );
  }

  
  // ============ EXCURSIONS MANAGER ============
  function ExcursionsManager() {
    const [selectedReservationId, setSelectedReservationId] = React.useState<string>("");
    const [newBooking, setNewBooking] = React.useState({ excursionId: "", date: today(), pax: 2, boatId: "", lunchProviderId: "", paymentStatus: "UNPAID" });
    const [saving, setSaving] = React.useState(false);
    const [showAddExcursionType, setShowAddExcursionType] = React.useState(false);
    const [newExcursionType, setNewExcursionType] = React.useState({ name: "", guidePriceAr: 0, entranceFeeAr: 0, lunchPriceAr: 0 });
    
    // Get all excursions from all reservations
    const allExcursions = reservations.flatMap(r => 
      (r.excursions || []).map(exc => ({
        ...exc,
        guestName: r.guestName,
        bungalow: r.bungalow,
        reservationId: r.id,
        arrival: r.arrival,
        departure: r.departure
      }))
    ).sort((a, b) => (a.date || '').localeCompare(b.date || ''));
    
    // Active guests (checked in, not checked out)
    const activeGuests = reservations.filter(r => r.checkedInAt && !r.checkedOutAt);
    
    async function handleAddBooking() {
      if (!selectedReservationId || !newBooking.excursionId) {
        showMsg("Izberi gosta in izlet!");
        return;
      }
      setSaving(true);
      await addExcursionBooking(selectedReservationId, {
        excursionId: newBooking.excursionId,
        date: newBooking.date,
        pax: newBooking.pax,
        boatId: newBooking.boatId || undefined,
        lunchProviderId: newBooking.lunchProviderId || undefined,
        paymentStatus: newBooking.paymentStatus
      });
      setNewBooking({ excursionId: "", date: today(), pax: 2, boatId: "", lunchProviderId: "", paymentStatus: "UNPAID" });
      refresh();
      setSaving(false);
      showMsg("Izlet dodan!");
    }
    
    async function handleAddExcursionType() {
      if (!newExcursionType.name.trim()) {
        showMsg("Vnesi ime izleta!");
        return;
      }
      setSaving(true);
      await addExcursion(newExcursionType);
      setNewExcursionType({ name: "", guidePriceAr: 0, entranceFeeAr: 0, lunchPriceAr: 0 });
      setShowAddExcursionType(false);
      refresh();
      setSaving(false);
      showMsg("Izlet dodan v cenik!");
    }
    
    async function handleDeleteExcursionType(id: string, name: string) {
      if (!confirm(`Izbrisi izlet "${name}" iz cenika?`)) return;
      await deleteExcursion(id);
      refresh();
      showMsg("Izlet izbrisan iz cenika.");
    }
    
    return (
      <div className="grid gap-8 lg:grid-cols-[400px_1fr]">
        {/* Left Column - Forms */}
        <div className="space-y-6">
          {/* Add Excursion Booking Form */}
          <GlassCard className="h-fit">
            <SectionHeader eyebrow="Nova rezervacija" title="Dodaj izlet gostu" />
            
            <div className="mt-6 space-y-4">
              <LuxurySelect 
                label="Gost" 
                value={selectedReservationId} 
                onChange={v => {
                  setSelectedReservationId(v);
                  const guest = reservations.find(r => r.id === v);
                  if (guest) setNewBooking(p => ({ ...p, pax: guest.pax }));
                }} 
                options={[
                  { value: "", label: "Izberi gosta" },
                  ...activeGuests.map(r => ({ value: r.id, label: `${r.guestName} (${bungalowLabel(r.bungalow)})` }))
                ]} 
              />
              
              <LuxurySelect 
                label="Izlet" 
                value={newBooking.excursionId} 
                onChange={v => setNewBooking(p => ({ ...p, excursionId: v }))} 
                options={[
                  { value: "", label: "Izberi izlet" },
                  ...dbExcursions.map((e: { id: string; name: string }) => ({ value: e.id, label: e.name }))
                ]} 
              />
              
              <LuxuryInput 
                label="Datum" 
                type="date" 
                value={newBooking.date} 
                onChange={v => setNewBooking(p => ({ ...p, date: v }))} 
              />
              
              <LuxuryInput 
                label="Stevilo oseb" 
                type="number" 
                value={newBooking.pax} 
                onChange={v => setNewBooking(p => ({ ...p, pax: Number(v) }))} 
              />
              
              <LuxurySelect 
                label="Coln" 
                value={newBooking.boatId} 
                onChange={v => setNewBooking(p => ({ ...p, boatId: v }))} 
                options={[
                  { value: "", label: "Ni izbrano" },
                  ...dbBoats.map((b: { id: string; name: string }) => ({ value: b.id, label: b.name }))
                ]} 
              />
              
              <LuxurySelect 
                label="Kosilo" 
                value={newBooking.lunchProviderId} 
                onChange={v => setNewBooking(p => ({ ...p, lunchProviderId: v }))} 
                options={[
                  { value: "", label: "Ni izbrano" },
                  ...dbLunchProviders.map((l: { id: string; name: string }) => ({ value: l.id, label: l.name }))
                ]} 
              />
              
              <LuxurySelect 
                label="Status placila" 
                value={newBooking.paymentStatus} 
                onChange={v => setNewBooking(p => ({ ...p, paymentStatus: v }))} 
                options={[
                  { value: "UNPAID", label: "Za placilo" },
                  { value: "PAID", label: "Placano" }
                ]} 
              />
              
              <LuxuryButton variant="gold" className="w-full" onClick={handleAddBooking} disabled={saving}>
                {saving ? "Dodajam..." : "Dodaj izlet gostu"}
              </LuxuryButton>
            </div>
          </GlassCard>
          
          {/* Manage Excursion Types */}
          <GlassCard className="h-fit">
            <SectionHeader eyebrow="Cenik" title="Vrste izletov" />
            
            <div className="mt-4">
              <button
                onClick={() => setShowAddExcursionType(!showAddExcursionType)}
                className="w-full px-4 py-2 rounded-xl bg-gradient-to-r from-[#78b7ff]/20 to-[#78b7ff]/10 border border-[#78b7ff]/30 text-[#78b7ff] text-sm font-medium hover:bg-[#78b7ff]/20 transition-colors"
              >
                {showAddExcursionType ? "Preklici" : "+ Dodaj nov izlet"}
              </button>
            </div>
            
            {showAddExcursionType && (
              <div className="mt-4 p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-3">
                <LuxuryInput label="Ime izleta" value={newExcursionType.name} onChange={v => setNewExcursionType(p => ({ ...p, name: v }))} placeholder="Npr. Lokobe" />
                <LuxuryInput label="Vodic (Ar)" type="number" value={newExcursionType.guidePriceAr} onChange={v => setNewExcursionType(p => ({ ...p, guidePriceAr: Number(v) }))} />
                <LuxuryInput label="Vstopnina (Ar)" type="number" value={newExcursionType.entranceFeeAr} onChange={v => setNewExcursionType(p => ({ ...p, entranceFeeAr: Number(v) }))} />
                <LuxuryInput label="Kosilo (Ar)" type="number" value={newExcursionType.lunchPriceAr} onChange={v => setNewExcursionType(p => ({ ...p, lunchPriceAr: Number(v) }))} />
                <LuxuryButton variant="ocean" className="w-full" onClick={handleAddExcursionType} disabled={saving}>
                  {saving ? "Shranjujem..." : "Shrani izlet"}
                </LuxuryButton>
              </div>
            )}
            
            {/* List of excursion types */}
            <div className="mt-4 space-y-2">
              {dbExcursions.map((exc: { id: string; name: string; guidePriceAr?: number; entranceFeeAr?: number; lunchPriceAr?: number }) => (
                <div key={exc.id} className="flex items-center justify-between p-3 rounded-xl border border-white/[0.06] bg-white/[0.02]">
                  <div>
                    <p className="text-sm text-white font-medium">{exc.name}</p>
                    <p className="text-xs text-white/40 mt-0.5">
                      Vodic: {ar(exc.guidePriceAr || 0)} | Vstop: {ar(exc.entranceFeeAr || 0)} | Kosilo: {ar(exc.lunchPriceAr || 0)}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteExcursionType(exc.id, exc.name)}
                    className="p-2 rounded-lg hover:bg-red-500/10 text-white/40 hover:text-red-400 transition-colors"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>
        
        {/* Right Column - Excursions List */}
        <GlassCard>
          <SectionHeader eyebrow="Pregled" title="Vsi izleti gostov" subtitle={`${allExcursions.length} rezerviranih izletov`} />
          
          {allExcursions.length === 0 ? (
            <p className="mt-8 text-center text-white/50">Ni rezerviranih izletov.</p>
          ) : (
            <div className="mt-6 space-y-4">
              {allExcursions.map(exc => {
                const excursionData = dbExcursions.find((e: { id: string }) => e.id === exc.excursionId);
                const boatData = dbBoats.find((b: { id: string }) => b.id === exc.boatId);
                const lunchData = dbLunchProviders.find((l: { id: string }) => l.id === exc.lunchProviderId);
                return (
                  <div key={exc.id} className="p-4 rounded-xl border border-[#78b7ff]/20 bg-[#78b7ff]/5">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium text-white">{excursionData?.name || "Neznani izlet"}</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full ${exc.paymentStatus === 'PAID' ? 'bg-[#6fc8a3]/20 text-[#6fc8a3]' : 'bg-red-500/20 text-red-400'}`}>
                            {exc.paymentStatus === 'PAID' ? 'PLACANO' : 'ZA PLACILO'}
                          </span>
                        </div>
                        <p className="text-sm text-white/60 mt-1">{exc.guestName} ({bungalowLabel(exc.bungalow)})</p>
                        <div className="flex flex-wrap gap-3 mt-2 text-xs text-white/40">
                          <span>Datum: {exc.date || 'Ni nastavljen'}</span>
                          <span>Oseb: {exc.pax}</span>
                          {boatData && <span>Coln: {boatData.name}</span>}
                          {lunchData && <span>Kosilo: {lunchData.name}</span>}
                        </div>
                      </div>
                      <button
                        onClick={async () => {
                          await deleteExcursionBooking(exc.id);
                          refresh();
                        }}
                        className="text-red-400/60 hover:text-red-400 text-xs"
                      >
                        Odstrani
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </GlassCard>
      </div>
    );
  }

  // ============ BENTRAL MANAGER ============
  function BentralManager() {
    const [bentralData, setBentralData] = React.useState<{
      id: string; externalId: string; status: string; source: string | null; guestName: string;
      country: string | null; checkIn: string; checkOut: string; nights: number; adults: number;
      children: number; childrenAges: string | null; units: string | null; currency: string | null;
      amount: string; guestNotes: string | null; ownNotes: string | null;
      transferred: boolean | null; reservationId: string | null;
    }[] | null>(null);
    const [importing, setImporting] = React.useState(false);
    const [transferring, setTransferring] = React.useState<string | null>(null);
    const [importResult, setImportResult] = React.useState<{ imported: number; updated: number; skipped: number } | null>(null);
    const [statusFilter, setStatusFilter] = React.useState("all");
    const [showTransferred, setShowTransferred] = React.useState(false);
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    async function loadBentralData() {
      const { getBentralReservations } = await import("@/app/actions/komba");
      const data = await getBentralReservations({ status: statusFilter });
      setBentralData(data as typeof bentralData);
    }

    React.useEffect(() => { loadBentralData(); }, [statusFilter]);

    async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
      const file = e.target.files?.[0];
      if (!file) return;
      
      setImporting(true);
      setImportResult(null);
      
      try {
        const text = await file.text();
        const { importBentralCSV } = await import("@/app/actions/komba");
        const result = await importBentralCSV(text);
        setImportResult(result);
        loadBentralData();
        showMsg(`Import uspesen: ${result.imported} novih, ${result.updated} posodobljenih`);
      } catch (err) {
        showMsg("Napaka pri importu!");
      }
      
      setImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }

    async function handleTransfer(id: string) {
      setTransferring(id);
      try {
        const { transferBentralReservation } = await import("@/app/actions/komba");
        await transferBentralReservation(id);
        showMsg("Rezervacija prenesena v sistem!");
        loadBentralData();
      } catch (err) {
        showMsg("Napaka pri prenosu!");
      }
      setTransferring(null);
    }

    const statusOptions = [
      { value: "all", label: "Vsi statusi" },
      { value: "Potrjeno", label: "Potrjeno" },
      { value: "Plačano (1. del)", label: "Placano (1. del)" },
      { value: "Ponudba", label: "Ponudba" },
      { value: "Preklicano", label: "Preklicano" },
      { value: "Ni odziva", label: "Ni odziva" },
    ];

    const getStatusVariant = (status: string): "petrol" | "gold" | "ocean" | "danger" | "default" => {
      if (status === "Potrjeno") return "petrol";
      if (status === "Plačano (1. del)") return "ocean";
      if (status === "Ponudba") return "gold";
      if (status === "Preklicano") return "danger";
      return "default";
    };

    const getSourceBadge = (source: string | null) => {
      if (!source) return <LuxuryBadge variant="gold">Direct</LuxuryBadge>;
      if (source === "Booking.com") return <LuxuryBadge variant="ocean">Booking</LuxuryBadge>;
      if (source === "Airbnb") return <LuxuryBadge variant="danger">Airbnb</LuxuryBadge>;
      return <LuxuryBadge>{source}</LuxuryBadge>;
    };

    return (
      <section className="space-y-8">
        <GlassCard>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <SectionHeader eyebrow="Channel Manager" title="Bentral Rezervacije" subtitle="Uvozi rezervacije iz Bentral sistema" />
            <div className="flex gap-3">
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
              />
              <LuxuryButton variant="petrol" onClick={() => fileInputRef.current?.click()} disabled={importing}>
                {importing ? "Uvazam..." : "Uvozi CSV"}
              </LuxuryButton>
            </div>
          </div>

          {importResult && (
            <div className="mt-4 rounded-2xl border border-[#6fc8a3]/30 bg-[#6fc8a3]/10 p-4">
              <p className="text-sm text-[#6fc8a3]">
                Import zakljucen: <strong>{importResult.imported}</strong> novih rezervacij, <strong>{importResult.updated}</strong> posodobljenih, <strong>{importResult.skipped}</strong> preskocenih
              </p>
            </div>
          )}

          <div className="mt-6 flex gap-4">
            <div className="w-48">
              <LuxurySelect label="Filter po statusu" value={statusFilter} onChange={setStatusFilter} options={statusOptions} />
            </div>
          </div>
        </GlassCard>

        {/* Reservations List */}
        <GlassCard>
          <div className="flex items-center justify-between">
            <SectionHeader eyebrow="Reservations" title="Seznam rezervacij" subtitle={bentralData ? `${bentralData.filter(r => showTransferred || !r.transferred).length} rezervacij` : "Nalagam..."} />
            <label className="flex items-center gap-2 text-sm text-white/50">
              <input type="checkbox" checked={showTransferred} onChange={e => setShowTransferred(e.target.checked)} className="rounded" />
              Prikazi prenesene
            </label>
          </div>
          
          {!bentralData ? (
            <div className="mt-8 flex justify-center">
              <RefreshCw className="h-6 w-6 animate-spin text-[#f1d07a]" />
            </div>
          ) : bentralData.filter(r => showTransferred || !r.transferred).length === 0 ? (
            <p className="mt-8 text-center text-white/50">Ni rezervacij. Uvozi CSV iz Bentral.</p>
          ) : (
            <div className="mt-6 space-y-4">
              {bentralData.filter(r => showTransferred || !r.transferred).map(res => (
                <div key={res.id} className={`rounded-2xl border p-5 ${res.transferred ? 'border-[#6fc8a3]/30 bg-[#6fc8a3]/5' : 'border-white/[0.08] bg-white/[0.02]'}`}>
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="font-medium text-white">{res.guestName}</h4>
                        <LuxuryBadge variant={getStatusVariant(res.status)}>{res.status}</LuxuryBadge>
                        {getSourceBadge(res.source)}
                        {res.transferred && <LuxuryBadge variant="petrol">Preneseno</LuxuryBadge>}
                      </div>
                      <p className="mt-2 text-sm text-white/60">
                        <span className="text-[#78b7ff]">{res.checkIn}</span> → <span className="text-[#78b7ff]">{res.checkOut}</span>
                        <span className="ml-2 text-white/40">({res.nights} noci)</span>
                      </p>
                      <p className="mt-1 text-sm text-white/50">
                        {res.adults} odrasli{res.children > 0 && `, ${res.children} otroci`}
                        {res.country && <span className="ml-2">• {res.country}</span>}
                      </p>
                      {res.units && <p className="mt-1 text-xs text-white/40 line-clamp-1">{res.units}</p>}
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <p className="text-lg font-light text-[#f1d07a]">{res.amount} {res.currency}</p>
                      <p className="text-xs text-white/40">#{res.externalId}</p>
                      {!res.transferred && res.status !== "Preklicano" ? (
                        <LuxuryButton 
                          variant="ocean" 
                          onClick={() => handleTransfer(res.id)}
                          disabled={transferring === res.id}
                        >
                          {transferring === res.id ? "Prenasam..." : "Prenesi v sistem"}
                        </LuxuryButton>
                      ) : res.transferred ? (
                        <LuxuryButton variant="ghost" onClick={() => setTab("reservations")}>
                          Odpri rezervacijo
                        </LuxuryButton>
                      ) : (
                        <span className="text-xs text-white/30">Preklicano</span>
                      )}
                    </div>
                  </div>
                  {(res.guestNotes || res.ownNotes) && (
                    <div className="mt-4 border-t border-white/5 pt-4">
                      {res.guestNotes && <p className="text-xs text-white/50"><span className="text-white/30">Gost:</span> {res.guestNotes.slice(0, 200)}{res.guestNotes.length > 200 && "..."}</p>}
                      {res.ownNotes && <p className="mt-1 text-xs text-[#6fc8a3]/70"><span className="text-[#6fc8a3]/50">Opombe:</span> {res.ownNotes}</p>}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </GlassCard>
      </section>
    );
  }

  // Navigation config with module-specific colors
  const nav: [string, string, typeof Home, "gold" | "petrol" | "ocean"][] = [
    ["bungalows", "Bungalovi", Home, "gold"],
    ["reservations", "Rezervacije", LogIn, "gold"],
  ];

  // Count pending transfers:
  // - Arrivals: only for guests NOT yet checked in
  // - Departures: only for guests who ARE checked in but not checked out
  const pendingCount = reservations.reduce((count, r) => {
    let transfers = 0;
    // Arrival transfer: show only if guest is NOT checked in yet
    if (r.transfers.arrival.route && !r.checkedInAt && !r.checkedOutAt) transfers++;
    // Departure transfer: show only if guest IS checked in (but not checked out)
    if (r.transfers.departure.route && r.checkedInAt && !r.checkedOutAt) transfers++;
    return count + transfers;
  }, 0);

  // Build list of all pending transfers
  const pendingTransfersList = reservations
    .filter(r => !r.checkedOutAt)
    .flatMap(r => {
      const list: { type: 'arrival' | 'departure'; reservation: typeof r; transfer: typeof r.transfers.arrival }[] = [];
      // Arrival: only if NOT checked in yet
      if (r.transfers.arrival.route && !r.checkedInAt) {
        list.push({ type: 'arrival', reservation: r, transfer: r.transfers.arrival });
      }
      // Departure: only if already checked in
      if (r.transfers.departure.route && r.checkedInAt) {
        list.push({ type: 'departure', reservation: r, transfer: r.transfers.departure });
      }
      return list;
    })
    .sort((a, b) => {
      const dateA = a.type === 'arrival' ? a.reservation.arrival : a.reservation.departure;
      const dateB = b.type === 'arrival' ? b.reservation.arrival : b.reservation.departure;
      return new Date(dateA).getTime() - new Date(dateB).getTime();
    });
  
  const pendingArrivals = pendingTransfersList.filter(t => t.type === 'arrival');
  const pendingDepartures = pendingTransfersList.filter(t => t.type === 'departure');
  
  // Build list of all excursions - hide only after the day has passed
  const todayDate = new Date();
  todayDate.setHours(0, 0, 0, 0);
  
  const rawExcursionItems = reservations
    .filter(r => r.status !== "CHECKED_OUT")
    .flatMap(r => {
      return (r.excursions || []).map(exc => ({
        reservation: r,
        excursion: exc,
        excursionName: data?.excursions?.find((e: { id: string; name: string }) => e.id === exc.excursionId)?.name || 'Izlet',
        isOrdered: !!exc.dilipOrderedAt
      }));
    })
    .filter(item => {
      // Hide excursions only after the date has passed (next day)
      if (!item.excursion.date) return true;
      const excDate = new Date(item.excursion.date);
      excDate.setHours(0, 0, 0, 0);
      return excDate >= todayDate;
    });

  // Skupinske izlete (isti groupId) združimo v ENO vrstico, ker je čoln pri Dilipu
  // naročen enkrat za celo skupino (sicer bi se plačilo Dilipu podvojilo).
  type ExcItem = (typeof rawExcursionItems)[number];
  const groupedMap = new Map<string, ExcItem[]>();
  const singleItems: ExcItem[] = [];
  for (const item of rawExcursionItems) {
    const gid = item.excursion.groupId;
    if (gid) {
      const arr = groupedMap.get(gid) || [];
      arr.push(item);
      groupedMap.set(gid, arr);
    } else {
      singleItems.push(item);
    }
  }

  const allExcursionsList = [
    ...singleItems.map(item => ({ ...item, members: [item] as ExcItem[] })),
    ...Array.from(groupedMap.values()).map(members => ({
      ...members[0],
      members,
      isOrdered: members.every(m => m.isOrdered),
    })),
  ]
    .sort((a, b) => {
      const dateA = a.excursion.date || a.reservation.arrival;
      const dateB = b.excursion.date || b.reservation.arrival;
      return new Date(dateA).getTime() - new Date(dateB).getTime();
    });
  
  const pendingExcursionsList = allExcursionsList.filter(item => !item.isOrdered);
  const pendingExcursionsCount = pendingExcursionsList.length;
  
  // Show PIN screen if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0a0f1a] flex items-center justify-center p-4">
        <div className="bg-[#0d1420] rounded-3xl p-8 w-full max-w-sm border border-white/10">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-[#f1d07a]/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Home className="w-8 h-8 text-[#f1d07a]" />
            </div>
            <h1 className="text-xl font-bold text-white">Komba Cabana</h1>
            <p className="text-white/40 text-sm mt-1">Vnesite PIN za dostop</p>
          </div>
          
          {/* PIN Display */}
          <div className="flex justify-center gap-3 mb-6">
            {[0, 1, 2, 3].map(i => (
              <div
                key={i}
                className={`w-14 h-14 rounded-xl border-2 flex items-center justify-center text-xl font-bold transition-colors ${
                  pin.length > i 
                    ? 'border-[#f1d07a] bg-[#f1d07a]/20 text-[#f1d07a]' 
                    : 'border-white/20 bg-white/5'
                }`}
              >
                {pin.length > i ? '•' : ''}
              </div>
            ))}
          </div>
          
          {pinError && (
            <p className="text-red-400 text-sm text-center mb-4">{pinError}</p>
          )}
          
          {/* Keypad */}
          <div className="grid grid-cols-3 gap-3">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '←'].map(key => (
              <button
                key={key}
                onClick={() => handlePinKey(key)}
                className={`h-16 rounded-xl text-xl font-medium transition-colors ${
                  key === 'C' 
                    ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' 
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                {key}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }
  
  if (isLoading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#040812]">
        <div className="text-center">
          <RefreshCw className="mx-auto h-8 w-8 animate-spin text-[#f1d07a]" />
          <p className="mt-4 text-white/50">Nalagam podatke...</p>
        </div>
      </main>
    );
  }

  if (error) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#040812]">
        <div className="text-center">
          <p className="text-[#d94a63]">Napaka pri nalaganju podatkov</p>
          <LuxuryButton variant="gold" className="mt-4" onClick={refresh}>Poskusi znova</LuxuryButton>
        </div>
      </main>
    );
  }

  const activeNavItem = nav.find(([id]) => id === tab);
  const activeColor = activeNavItem ? activeNavItem[3] : "gold";

  return (
    <main className="min-h-screen bg-[#040812] text-white">
      {/* Ambient lighting effect */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -left-40 -top-40 h-96 w-96 rounded-full bg-[#f1d07a]/5 blur-[120px]" />
        <div className="absolute -right-40 top-1/3 h-96 w-96 rounded-full bg-[#5c8fd8]/5 blur-[120px]" />
      </div>

      {/* Header */}
      <header className="relative z-[60] border-b border-white/[0.06] bg-[rgba(15,23,36,0.6)] backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 sm:px-8 py-4">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
            <div className="flex flex-col items-center sm:items-start">
              <img 
                src="/images/komba-logo-gold.png" 
                alt="Komba Cabana" 
                className="h-20 sm:h-28 w-auto max-w-[280px] sm:max-w-none object-contain drop-shadow-[0_0_30px_rgba(241,208,122,0.3)]"
              />
              <p className="mt-2 text-[9px] sm:text-[10px] font-semibold uppercase tracking-[0.2em] sm:tracking-[0.28em] text-[#94a3b8]">Private Island Operating System</p>
            </div>
            <div className="flex items-center justify-center sm:justify-end gap-2 sm:gap-3">
              <Link href="/statistika" className="flex items-center gap-1.5 sm:gap-2 rounded-xl border border-[#f1d07a]/30 bg-[#f1d07a]/10 px-3 sm:px-4 py-2 sm:py-2.5 text-xs sm:text-sm font-medium text-[#f1d07a] transition-all hover:bg-[#f1d07a]/20">
                <BarChart3 className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                Statistika
              </Link>
              <details className="relative">
                <summary className="list-none flex items-center gap-1.5 sm:gap-2 rounded-xl border border-[#78b7ff]/30 bg-[#78b7ff]/10 px-3 sm:px-4 py-2 sm:py-2.5 text-xs sm:text-sm font-medium text-[#78b7ff] transition-all hover:bg-[#78b7ff]/20 cursor-pointer">
                  <Database className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                  Baza
                  <ChevronDown className="h-3 w-3" />
                </summary>
                <div className="absolute right-0 top-full mt-2 z-[100] rounded-xl border border-white/10 bg-[#0d1420] p-2 shadow-xl min-w-[160px]">
                  <Link href="/bentral" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/[0.06] hover:text-white transition-all">
                    <Database className="h-4 w-4" />
                    Bentral
                  </Link>
                  <Link href="/arhiv" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/[0.06] hover:text-white transition-all">
                    <Archive className="h-4 w-4" />
                    Arhiv
                  </Link>
                  <Link href="/admin" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/[0.06] hover:text-white transition-all">
                    <Settings className="h-4 w-4" />
                    Ceniki
                  </Link>
                </div>
              </details>
              <details className="relative">
                <summary className="list-none flex items-center gap-1.5 sm:gap-2 rounded-xl border border-[#6fc8a3]/30 bg-[#6fc8a3]/10 px-3 sm:px-4 py-2 sm:py-2.5 text-xs sm:text-sm font-medium text-[#6fc8a3] transition-all hover:bg-[#6fc8a3]/20 cursor-pointer">
                  <CreditCard className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                  Blagajna
                  <ChevronDown className="h-3 w-3" />
                </summary>
                <div className="absolute right-0 top-full mt-2 z-[100] rounded-xl border border-white/10 bg-[#0d1420] p-2 shadow-xl min-w-[160px]">
                  <Link href="/staff" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/[0.06] hover:text-white transition-all">
                    <Wine className="h-4 w-4" />
                    Bar
                  </Link>
                  <Link href="/recepcija" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/[0.06] hover:text-white transition-all">
                    <Sofa className="h-4 w-4" />
                    Recepcija
                  </Link>
                  <div className="border-t border-white/10 my-1"></div>
                  <button 
                    onClick={handleLogout}
                    className="w-full flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-red-400 hover:bg-red-500/10 transition-all"
                  >
                    <LogOut className="h-4 w-4" />
                    Odjava
                  </button>
                </div>
              </details>
            </div>
          </div>
        </div>
      </header>

      {/* Message Toast */}
      {message && (
        <div className="fixed top-24 left-1/2 z-50 -translate-x-1/2 rounded-full bg-gradient-to-r from-[#fff4cc] via-[#f1d07a] to-[#b8892f] px-8 py-3 text-sm font-medium text-[#0a0f1a] shadow-[0_8px_32px_rgba(241,208,122,0.4)]">
          {message}
        </div>
      )}

      {/* Navigation */}
      <nav className="sticky top-0 z-40 border-b border-white/[0.06] bg-[rgba(15,23,36,0.8)] backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-8 py-4">
          {nav.map(([id, label, Icon, color]) => {
            const isActive = tab === id;
            const colorStyles = {
              gold: isActive ? "bg-gradient-to-r from-[#fff4cc] via-[#f1d07a] to-[#b8892f] text-[#0a0f1a]" : "",
              petrol: isActive ? "bg-gradient-to-r from-[#6fc8a3] to-[#4fa987] text-[#0a0f1a]" : "",
              ocean: isActive ? "bg-gradient-to-r from-[#78b7ff] to-[#5c8fd8] text-[#0a0f1a]" : "",
            };
            return (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={`flex items-center gap-2 whitespace-nowrap rounded-full px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] transition-all duration-300 ${
                  isActive ? colorStyles[color] : "bg-white/[0.03] text-[#94a3b8] hover:bg-white/[0.06] hover:text-[#f8fafc]"
                }`}
              >
                <Icon className="h-4 w-4" /> {label}
              </button>
            );
  })}
  
          {/* Ceniki button */}
          <button
            onClick={() => setShowPricingModal(true)}
            className="ml-auto flex items-center gap-2 whitespace-nowrap rounded-full px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] transition-all duration-300 bg-white/[0.03] text-[#94a3b8] hover:bg-white/[0.06] hover:text-[#f8fafc]"
          >
            <Settings className="h-4 w-4" /> Ceniki
          </button>
  </div>
  </nav>

      {/* Pending Transfers & Excursions & Taxes Badges */}
      {(
        <div className="mx-auto max-w-7xl px-8 pt-6">
          <div className="flex flex-wrap gap-3">
            {/* Pending Transfers Button */}
            {pendingCount > 0 && (
              <button 
                onClick={() => { setShowPendingTransfers(!showPendingTransfers); setShowPendingExcursions(false); }}
                className="inline-flex items-center gap-2 rounded-full bg-[#78b7ff]/10 border border-[#78b7ff]/20 px-5 py-2.5 text-[#78b7ff] hover:bg-[#78b7ff]/20 transition-colors"
              >
                <Ship className="h-4 w-4" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.2em]">Pending Transferji</span>
                <span className="text-sm font-medium">· {pendingCount}</span>
                <ChevronDown className={`h-4 w-4 transition-transform ${showPendingTransfers ? 'rotate-180' : ''}`} />
              </button>
            )}
            
            {/* Excursions Button - shows if any excursions exist */}
            {allExcursionsList.length > 0 && (
              <button 
                onClick={() => { setShowPendingExcursions(!showPendingExcursions); setShowPendingTransfers(false); }}
                className={`inline-flex items-center gap-2 rounded-full px-5 py-2.5 transition-colors ${
                  pendingExcursionsCount > 0 
                    ? 'bg-[#6fc8a3]/10 border border-[#6fc8a3]/20 text-[#6fc8a3] hover:bg-[#6fc8a3]/20'
                    : 'bg-[#6fc8a3]/20 border border-[#6fc8a3]/40 text-[#6fc8a3] hover:bg-[#6fc8a3]/30'
                }`}
              >
                <Palmtree className="h-4 w-4" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.2em]">Izleti</span>
                {pendingExcursionsCount > 0 ? (
                  <span className="text-sm font-medium">· {pendingExcursionsCount} za naročiti</span>
                ) : (
                  <span className="text-sm font-medium">· vsi naročeni</span>
                )}
                <ChevronDown className={`h-4 w-4 transition-transform ${showPendingExcursions ? 'rotate-180' : ''}`} />
              </button>
            )}

            {/* Takse Button */}
            <button
              onClick={() => { setShowTaxes(!showTaxes); setShowPendingTransfers(false); setShowPendingExcursions(false); }}
              className="inline-flex items-center gap-2 rounded-full bg-[#f9a8d4]/10 border border-[#f9a8d4]/25 px-5 py-2.5 text-[#f9a8d4] hover:bg-[#f9a8d4]/20 transition-colors"
            >
              <Landmark className="h-4 w-4" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em]">Takse</span>
              <ChevronDown className={`h-4 w-4 transition-transform ${showTaxes ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Expanded Taxes Panel */}
          {showTaxes && <TaxesPanel />}
          
          {/* Expanded Transfers Panel */}
          {showPendingTransfers && (
            <div className="mt-4 rounded-2xl border border-[#78b7ff]/20 bg-[#0a1628]/90 backdrop-blur-xl p-5">
              <div className="grid md:grid-cols-2 gap-6">
                {/* PRIHODI */}
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-3 flex items-center gap-2">
                    <LogIn className="h-4 w-4" />
                    Prihodi ({pendingArrivals.length})
                  </h4>
                  <div className="space-y-2">
                    {pendingArrivals.length === 0 ? (
                      <p className="text-white/30 text-xs">Ni prihodov</p>
                    ) : (
                      pendingArrivals.map((item, idx) => {
                        const r = item.reservation;
                        const t = item.transfer;
                        const isOrdered = !!t.dilipOrderedAt;
                        const shortBungalow = r.bungalow?.split(';')[0]?.split('/')[0]?.trim() || r.bungalow;
                        const boatName = dbBoats.find((b: { id: string }) => b.id === t.boatId)?.name;
                        return (
                          <div key={`arr-${idx}`} className={`p-3 rounded-xl border ${isOrdered ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-red-500/30 bg-red-500/5'}`}>
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  {!isOrdered && <span className="text-red-400 text-xs">⚠</span>}
                                  {isOrdered && <span className="text-emerald-400 text-xs">✓</span>}
                                  <span className="text-white text-sm font-medium">
                                    {new Date(t.pickupDate || r.arrival).toLocaleDateString('sl-SI', { day: 'numeric', month: 'short' })}
                                    {t.time && ` · ${t.time}`}
                                  </span>
                                </div>
                                <p className="text-white/70 text-xs truncate">{shortBungalow} - {r.guestName}</p>
                                <p className="text-white/40 text-[10px]">{t.route} · {r.pax} os</p>
                                <div className="mt-1.5 space-y-0.5 text-[10px] text-white/50">
                                  {(t.flightNumber || t.flightTime) && (
                                    <p><span className="text-white/30">Let:</span> {t.flightNumber || '?'}{t.flightTime ? ` ob ${t.flightTime}` : ''}</p>
                                  )}
                                  {(boatName || t.boatPortTime) && (
                                    <p><span className="text-white/30">Čoln:</span> {boatName || '?'}{t.boatPortTime ? ` · port ${t.boatPortTime}` : ''}</p>
                                  )}
                                  {t.hermanAirportTime && (
                                    <p><span className="text-white/30">Herman na letališču:</span> {t.hermanAirportTime}</p>
                                  )}
                                  {t.notes && (
                                    <p className="text-amber-300/80"><span className="text-white/30">Opomba:</span> {t.notes}</p>
                                  )}
                                </div>
                              </div>
                              {!isOrdered ? (
                                <button
                                  onClick={async () => {
                                    await updateTransfer(r.id, 'arrival', { dilipOrderedAt: new Date() });
                                    refresh();
                                  }}
                                  className="px-2 py-1 text-[10px] font-medium rounded-lg bg-[#78b7ff]/20 text-[#78b7ff] hover:bg-[#78b7ff]/30 transition-colors whitespace-nowrap"
                                >
                                  Pokliči Dilipa
                                </button>
                              ) : (
                                <span className="text-[10px] text-emerald-400/70">Naročeno</span>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
                
                {/* ODHODI */}
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-orange-400 mb-3 flex items-center gap-2">
                    <LogOut className="h-4 w-4" />
                    Odhodi ({pendingDepartures.length})
                  </h4>
                  <div className="space-y-2">
                    {pendingDepartures.length === 0 ? (
                      <p className="text-white/30 text-xs">Ni odhodov</p>
                    ) : (
                      pendingDepartures.map((item, idx) => {
                        const r = item.reservation;
                        const t = item.transfer;
                        const isOrdered = !!t.dilipOrderedAt;
                        const shortBungalow = r.bungalow?.split(';')[0]?.split('/')[0]?.trim() || r.bungalow;
                        const boatName = dbBoats.find((b: { id: string }) => b.id === t.boatId)?.name;
                        return (
                          <div key={`dep-${idx}`} className={`p-3 rounded-xl border ${isOrdered ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-red-500/30 bg-red-500/5'}`}>
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  {!isOrdered && <span className="text-red-400 text-xs">⚠</span>}
                                  {isOrdered && <span className="text-emerald-400 text-xs">✓</span>}
                                  <span className="text-white text-sm font-medium">
                                    {new Date(t.pickupDate || r.departure).toLocaleDateString('sl-SI', { day: 'numeric', month: 'short' })}
                                    {t.time && ` · Odhod iz Kombe ${t.time}`}
                                  </span>
                                </div>
                                <p className="text-white/70 text-xs truncate">{shortBungalow} - {r.guestName}</p>
                                <p className="text-white/40 text-[10px]">{t.route} · {r.pax} os</p>
                                <div className="mt-1.5 space-y-0.5 text-[10px] text-white/50">
                                  {t.time && (
                                    <p><span className="text-white/30">Odhod iz Kombe:</span> {t.time}</p>
                                  )}
                                  {(boatName || t.boatPortTime) && (
                                    <p><span className="text-white/30">Čoln:</span> {boatName || '?'}{t.boatPortTime ? ` · port ${t.boatPortTime}` : ''}</p>
                                  )}
                                  {t.hermanAirportTime && (
                                    <p><span className="text-white/30">Herman na letališču:</span> {t.hermanAirportTime}</p>
                                  )}
                                  {(t.flightNumber || t.flightTime) && (
                                    <p><span className="text-white/30">Let:</span> {t.flightNumber || '?'}{t.flightTime ? ` ob ${t.flightTime}` : ''}</p>
                                  )}
                                  {t.notes && (
                                    <p className="text-amber-300/80"><span className="text-white/30">Opomba:</span> {t.notes}</p>
                                  )}
                                </div>
                              </div>
                              {!isOrdered ? (
                                <button
                                  onClick={async () => {
                                    await updateTransfer(r.id, 'departure', { dilipOrderedAt: new Date() });
                                    refresh();
                                  }}
                                  className="px-2 py-1 text-[10px] font-medium rounded-lg bg-[#78b7ff]/20 text-[#78b7ff] hover:bg-[#78b7ff]/30 transition-colors whitespace-nowrap"
                                >
                                  Pokliči Dilipa
                                </button>
                              ) : (
                                <span className="text-[10px] text-emerald-400/70">Naročeno</span>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Expanded Excursions Panel */}
          {showPendingExcursions && (
            <div className="mt-4 rounded-2xl border border-[#6fc8a3]/20 bg-[#0a1628]/90 backdrop-blur-xl p-5">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-[#6fc8a3] mb-3 flex items-center gap-2">
                <Palmtree className="h-4 w-4" />
                Izleti - {pendingExcursionsCount} za naročiti
              </h4>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                {allExcursionsList.map((item, idx) => {
                  const r = item.reservation;
                  const exc = item.excursion;
                  const members = item.members;
                  const isGroup = !!exc.groupId && members.length > 1;
                  const shortBungalow = r.bungalow?.split(';')[0]?.split('/')[0]?.trim() || r.bungalow;
                  const isOrdered = item.isOrdered;
                  // Skupno število oseb (skupinski: vsota članov)
                  const totalPax = members.reduce((sum, m) => sum + (m.excursion.pax || 0), 0);

                  // --- Izračun zneskov za Dilipa in vodiča (kosilo) ---
                  // Nabavna cena čolna iz cenika "Izleti - Nabavne" (excursionPricing)
                  const boatPriceRow = data?.excursionPricing?.find(
                    (ep: { excursionId: string; boatId: string; priceAr: number }) =>
                      ep.excursionId === exc.excursionId && ep.boatId === exc.boatId
                  );
                  const boatCompletePrice = boatPriceRow?.priceAr || 0;
                  // Cena vodiča iz tipa izleta
                  const excType = data?.excursions?.find(
                    (e: { id: string; guidePriceAr?: number; entranceFeeAr?: number }) => e.id === exc.excursionId
                  );
                  const guidePrice = excType?.guidePriceAr || 0;
                  // Dilip = (kompletna cena čolna − vodič) × 0,90 + vodič — ČOLN je en sam za skupino
                  const boatNet = Math.max(0, boatCompletePrice - guidePrice);
                  const dilipPayment = boatNet > 0 ? Math.round(boatNet * 0.9) + guidePrice : 0;
                  // Vstopnina (skiper jo plača na licu mesta) = vstopnina/os × SKUPNO število oseb
                  const entranceTotalAr = Math.round((excType?.entranceFeeAr || 0) * totalPax);
                  // Kosilo vodiču = vsota cen kosila vseh članov (EUR) → pretvorjeno v Ariarje
                  const excRate = data?.exchangeRate || DEFAULT_RATE;
                  const lunchTotal = Math.round(members.reduce((sum, m) => sum + (m.excursion.lunchPrice || 0), 0) * excRate);

                  return (
                    <div key={`exc-${idx}`} className={`p-3 rounded-xl border ${isOrdered ? 'border-[#6fc8a3]/30 bg-[#6fc8a3]/5' : 'border-amber-500/30 bg-amber-500/5'}`}>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            {isOrdered ? (
                              <span className="text-[#6fc8a3] text-xs">✓</span>
                            ) : (
                              <span className="text-amber-400 text-xs">⚠</span>
                            )}
                            <span className="text-white text-sm font-medium">
                              {exc.date ? new Date(exc.date).toLocaleDateString('sl-SI', { day: 'numeric', month: 'short' }) : 'Ni datuma'}
                            </span>
                          </div>
                          <p className="text-[#6fc8a3] text-xs font-medium truncate">
                            {item.excursionName}
                            {isGroup && <span className="ml-1 px-1.5 py-0.5 rounded bg-[#78b7ff]/20 text-[#78b7ff] text-[9px] align-middle">SKUPINA</span>}
                          </p>
                          {isGroup ? (
                            <div className="text-white/70 text-xs">
                              {members.map((m, mi) => {
                                const mb = m.reservation.bungalow?.split(';')[0]?.split('/')[0]?.trim() || m.reservation.bungalow;
                                return (
                                  <p key={mi} className="truncate">{mb} - {m.reservation.guestName} <span className="text-white/40">({m.excursion.pax} os)</span></p>
                                );
                              })}
                            </div>
                          ) : (
                            <p className="text-white/70 text-xs truncate">{shortBungalow} - {r.guestName}</p>
                          )}
                          <p className="text-white/40 text-[10px]">{totalPax} os{isGroup ? ' skupaj' : ''}</p>
                          {/* Zneski za plačilo */}
                          <div className="mt-2 space-y-1 border-t border-white/10 pt-2">
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-[10px] text-white/50">Dilipu (čoln + vodič)</span>
                              <span className="text-[11px] font-semibold text-[#78b7ff] whitespace-nowrap">
                                {dilipPayment > 0 ? ar(dilipPayment) : '—'}
                              </span>
                            </div>
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-[10px] text-white/50">Vodiču za kosilo</span>
                              <span className="text-[11px] font-semibold text-[#f1d07a] whitespace-nowrap">
                                {lunchTotal > 0 ? ar(lunchTotal) : '—'}
                              </span>
                            </div>
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-[10px] text-white/50">Skiperju za vstopnino ({totalPax} os)</span>
                              <span className="text-[11px] font-semibold text-[#e8915b] whitespace-nowrap">
                                {entranceTotalAr > 0 ? ar(entranceTotalAr) : '—'}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          {isOrdered ? (
                            <span className="px-2 py-1 text-[10px] font-medium rounded-lg bg-[#6fc8a3]/20 text-[#6fc8a3]">
                              Naročeno
                            </span>
                          ) : (
                            <button
                              onClick={async () => {
                                await Promise.all(members.map(m =>
                                  updateExcursionBooking(m.excursion.id, { dilipOrderedAt: new Date().toISOString() })
                                ));
                                refresh();
                              }}
                              className="px-2 py-1 text-[10px] font-medium rounded-lg bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 transition-colors whitespace-nowrap"
                            >
                              Naroči
                            </button>
                          )}
                          <button
                            onClick={async () => {
                              const msg = isGroup
                                ? `Želite pobrisati SKUPINSKI izlet "${item.excursionName}" za vse bungalove (${members.length})?`
                                : `Želite pobrisati izlet "${item.excursionName}" za ${r.guestName}?`;
                              if (confirm(msg)) {
                                await Promise.all(members.map(m => deleteExcursionBooking(m.excursion.id)));
                                refresh();
                              }
                            }}
                            className="p-1 text-red-400/60 hover:text-red-400 hover:bg-red-500/20 rounded-lg transition-colors"
                            title="Pobriši izlet"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

  {/* Content */}
  <div className="relative mx-auto max-w-7xl px-8 py-10">
  {tab === "bungalows" && <Bungalows />}
  {tab === "reservations" && (
    <section>
      <GlassCard className="p-4 sm:p-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <SectionHeader eyebrow="Bookings" title="Rezervacije" />
          <LuxuryButton variant="gold" className="w-full sm:w-auto" onClick={() => setShowNewBookingForm(true)}>
            <Plus className="h-4 w-4" /> Nova Rezervacija
          </LuxuryButton>
        </div>
        <div className="mt-6 space-y-3 max-h-[70vh] overflow-y-auto">
          {reservations.length === 0 && <p className="text-white/40 text-center py-8">Ni rezervacij.</p>}
          {[...reservations].sort((a, b) => new Date(a.arrival).getTime() - new Date(b.arrival).getTime()).map(res => {
            const shortBungalow = res.bungalow.includes(';') 
              ? res.bungalow.split(';')[0].split('/')[0].trim()
              : res.bungalow.split('/')[0].trim();
            const sourceVariant = res.bookingSource === 'Booking.com' ? 'ocean' 
              : res.bookingSource === 'Airbnb' ? 'danger' 
              : 'gold';
            return (
            <button 
              key={res.id} 
              className="w-full text-left rounded-xl border border-white/[0.08] bg-white/[0.02] p-4 transition-all duration-200 hover:border-[#f1d07a]/30 hover:bg-white/[0.04] active:scale-[0.98]"
              onClick={() => { setSelectedReservationId(res.id); setTab("guest"); }}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-white truncate">{res.guestName}</p>
                    {res.bookingSource && (
                      <LuxuryBadge variant={sourceVariant as "ocean" | "danger" | "gold"}>
                        {res.bookingSource === 'Booking.com' ? 'Booking' : res.bookingSource}
                      </LuxuryBadge>
                    )}
                  </div>
                  <p className="mt-1 text-sm text-white/50">{shortBungalow}</p>
                  <p className="text-xs text-white/40">{res.arrival} → {res.departure}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  {res.honeymoon && (
                    <Heart className="h-4 w-4 text-[#f1d07a]" />
                  )}
                  {res.allergies && (
                    <Leaf className="h-4 w-4 text-[#6fc8a3]" />
                  )}
                  {/* Transfer status indicator */}
                  {(() => {
                    const hasArrivalTransfer = res.transfers?.arrival?.route;
                    const hasDepartureTransfer = res.transfers?.departure?.route;
                    const noTransferNeeded = (res as { noTransferNeeded?: boolean }).noTransferNeeded;
                    
                    if (noTransferNeeded) {
                      // Ne potrebuje prevoza - prečrtan čoln
                      return (
                        <div className="relative">
                          <Ship className="h-4 w-4 text-white/30" />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-5 h-0.5 bg-white/50 rotate-[-45deg]" />
                          </div>
                        </div>
                      );
                    } else if (hasArrivalTransfer || hasDepartureTransfer) {
                      // Ima naročen prevoz - zelen čoln
                      return <Ship className="h-4 w-4 text-[#6fc8a3]" />;
                    } else {
                      // Ni prevoza in ni označeno da ne potrebuje - opozorilo
                      return (
                        <div className="relative">
                          <Ship className="h-4 w-4 text-[#d94a63]" />
                          <HelpCircle className="absolute -top-1 -right-1 h-2.5 w-2.5 text-[#d94a63]" />
                        </div>
                      );
                    }
                  })()}
                </div>
              </div>
            </button>
          )})}
        </div>
      </GlassCard>
      
      {/* New Booking Modal */}
      {showNewBookingForm && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm" onClick={() => setShowNewBookingForm(false)}>
          <div 
            className="relative w-full sm:max-w-md sm:mx-4 bg-[#0f1724] border-t sm:border border-white/10 sm:rounded-2xl overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            {/* Drag handle for mobile */}
            <div className="flex justify-center pt-3 pb-1 sm:hidden">
              <div className="w-10 h-1 rounded-full bg-white/20" />
            </div>
            
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-3 border-b border-white/10">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-[#f1d07a]">New Booking</p>
                <h3 className="text-lg font-semibold text-white">Nova Rezervacija</h3>
              </div>
              <button 
                onClick={() => setShowNewBookingForm(false)} 
                className="p-2 rounded-full bg-white/5 text-white/60 hover:bg-white/10 hover:text-white transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            {/* Form */}
            <div className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              {GuestNameInput}
              <LuxurySelect label="Bungalow" value={reservationDraft.bungalow} onChange={v => setReservationDraft(p => ({ ...p, bungalow: v }))} options={BUNGALOWS} />
              <LuxuryInput label="Pax" type="number" value={reservationDraft.pax} onChange={v => setReservationDraft(p => ({ ...p, pax: Number(v) }))} />
              <div className="grid grid-cols-2 gap-3">
                <LuxuryInput label="Prihod" type="date" value={reservationDraft.arrival} onChange={v => setReservationDraft(p => ({ ...p, arrival: v }))} />
                <LuxuryInput label="Odhod" type="date" value={reservationDraft.departure} onChange={v => setReservationDraft(p => ({ ...p, departure: v }))} />
              </div>
              <LuxurySelect label="Booking Source" value={reservationDraft.bookingSource} onChange={v => setReservationDraft(p => ({ ...p, bookingSource: v }))} options={BOOKING_SOURCES} />
              {reservationDraft.bookingSource === "Agency" && AgencyNameInput}
              {(reservationDraft.bookingSource === "Agency" || reservationDraft.bookingSource === "Booking.com" || reservationDraft.bookingSource === "Airbnb") && AgencyCommissionInput}
            </div>
            
            {/* Footer with button */}
            <div className="px-5 py-4 border-t border-white/10 bg-white/[0.02]">
              <LuxuryButton variant="gold" className="w-full" onClick={async () => { await handleCreateReservation(); setShowNewBookingForm(false); }} disabled={saving}>
                {saving ? "Shranjujem..." : "Ustvari rezervacijo"}
              </LuxuryButton>
            </div>
          </div>
        </div>
      )}
    </section>
  )}
                {tab === "guest" && <GuestCard />}
                {tab === "orders" && <Orders />}
                {tab === "excursions" && <ExcursionsManager />}
              </div>
              
      {/* Pricing Calculator Modal */}
      {showPricingModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm" onClick={() => setShowPricingModal(false)}>
          <div 
            className="relative w-full sm:max-w-xl sm:mx-4 bg-[#0f1724] border-t sm:border border-white/10 sm:rounded-2xl overflow-hidden max-h-[90vh] flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            {/* Drag handle for mobile */}
            <div className="flex justify-center pt-3 pb-1 sm:hidden">
              <div className="w-10 h-1 rounded-full bg-white/20" />
            </div>
            
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-3 border-b border-white/10 flex-shrink-0">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-[#f1d07a]">Kalkulator</p>
                <h3 className="text-lg font-semibold text-white">Ceniki</h3>
              </div>
              <button 
                onClick={() => setShowPricingModal(false)} 
                className="p-2 rounded-full bg-white/5 text-white/60 hover:bg-white/10 hover:text-white transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            {/* Tabs */}
            <div className="flex border-b border-white/10">
              <button
                onClick={() => setPricingTab('calculator')}
                className={`flex-1 px-4 py-2 text-xs font-medium transition-colors ${pricingTab === 'calculator' ? 'text-[#f1d07a] border-b-2 border-[#f1d07a]' : 'text-white/50 hover:text-white/80'}`}
              >
                Kalkulator
              </button>
              <button
                onClick={() => setPricingTab('schedule')}
                className={`flex-1 px-4 py-2 text-xs font-medium transition-colors ${pricingTab === 'schedule' ? 'text-[#f1d07a] border-b-2 border-[#f1d07a]' : 'text-white/50 hover:text-white/80'}`}
              >
                Fanjin Urnik
              </button>
            </div>
            
            {/* Content */}
            <div className="px-5 py-4 space-y-6 overflow-y-auto flex-1">
              
              {pricingTab === 'calculator' && (
              <>
              {/* IZLETI CALCULATOR */}
              <div className="p-4 rounded-xl border border-[#78b7ff]/20 bg-[#78b7ff]/5">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-[#78b7ff] mb-4 flex items-center gap-2">
                  <Truck className="h-4 w-4" />
                  Izlet - Kalkulator
                </h4>
                
                {/* Selected excursion info */}
                {pricingCalc.excursionId && (() => {
                  const exc = dbExcursions.find((e: { id: string }) => e.id === pricingCalc.excursionId) as { id: string; name: string; description?: string | null; imageUrl?: string | null; entranceFeeAr?: number } | undefined;
                  if (!exc) return null;
                  return (
                    <div className="mb-4 p-3 rounded-lg bg-white/[0.03] border border-white/[0.06]">
                      <div className="flex gap-3">
                        {exc.imageUrl && (
                          <img src={exc.imageUrl} alt={exc.name} className="w-16 h-16 rounded-lg object-cover flex-shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-medium text-[#f1d07a]">{exc.name}</h4>
                          {exc.description && (
                            <p className="text-xs text-white/60 mt-1 line-clamp-3">{exc.description}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()}
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Izlet</label>
                    <select
                      className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#78b7ff]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                      value={pricingCalc.excursionId}
                      onChange={e => setPricingCalc(p => ({ ...p, excursionId: e.target.value }))}
                    >
                      <option value="">-- Izberi izlet --</option>
                      {dbExcursions.map((e: { id: string; name: string }) => (
                        <option key={e.id} value={e.id}>{e.name}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Coln</label>
                    <select
                      className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#78b7ff]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                      value={pricingCalc.boatId}
                      onChange={e => setPricingCalc(p => ({ ...p, boatId: e.target.value }))}
                    >
                      <option value="">-- Izberi coln --</option>
                      {dbBoats.map((b: { id: string; name: string; engine: string }) => (
                        <option key={b.id} value={b.id}>{b.name} ({b.engine})</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Stevilo oseb</label>
                    <input
                      type="number"
                      min="1"
                      inputMode="numeric"
                      className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#78b7ff]/50 focus:outline-none"
                      value={pricingCalc.pax === 0 ? '' : pricingCalc.pax}
                      onChange={e => setPricingCalc(p => ({ ...p, pax: e.target.value === '' ? 0 : Number(e.target.value) }))}
                      onBlur={e => { if (e.target.value === '' || Number(e.target.value) < 1) setPricingCalc(p => ({ ...p, pax: 1 })) }}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Cena transporta/os</label>
                    <div className="rounded-lg border border-[#f1d07a]/30 bg-[#f1d07a]/10 px-3 py-2 text-sm font-medium text-[#f1d07a]">
                      {pricingCalc.excursionId && pricingCalc.boatId ? (
                        (() => {
                          const pricing = dbExcursionSellingPricing.find((p: { excursionId: string; boatId: string }) => 
                            p.excursionId === pricingCalc.excursionId && p.boatId === pricingCalc.boatId
                          ) as { pricePax1?: string; pricePax2?: string; pricePax3?: string; pricePax4?: string; pricePax5?: string; pricePax6?: string } | undefined;
                          if (!pricing) return "Ni cene";
                          const paxKey = `pricePax${Math.min(pricingCalc.pax, 6)}` as keyof typeof pricing;
                          const pricePerPerson = Number(pricing[paxKey]) || 0;
                          return eur(pricePerPerson);
                        })()
                      ) : "—"}
                    </div>
                  </div>
                </div>
                
                {/* Vstopnina */}
                <div className="mt-3 grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Vstopnina</label>
                    <label className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 cursor-pointer hover:bg-white/10 transition-colors">
                      <input
                        type="checkbox"
                        checked={pricingCalc.includeEntrance}
                        onChange={e => setPricingCalc(p => ({ ...p, includeEntrance: e.target.checked }))}
                        className="rounded border-white/20"
                      />
                      <span className="text-sm text-white">
                        {pricingCalc.excursionId ? (() => {
                          const exc = dbExcursions.find((e: { id: string }) => e.id === pricingCalc.excursionId) as { entranceFeeAr?: number } | undefined;
                          return exc?.entranceFeeAr ? `${eur(arToEur(exc.entranceFeeAr, exchangeRate))}/os` : "Brez vstopnine";
                        })() : "Vkljuci"}
                      </span>
                    </label>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Ponudnik kosila</label>
                    <select
                      className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#fb923c]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                      value={pricingCalc.lunchProviderId}
                      onChange={e => setPricingCalc(p => ({ ...p, lunchProviderId: e.target.value }))}
                    >
                      <option value="">-- Brez kosila --</option>
                      {dbLunchProviders.map((lp: { id: string; name: string; pricePerPersonAr: number }) => (
                        <option key={lp.id} value={lp.id}>{lp.name} ({eur(arToEur(lp.pricePerPersonAr, exchangeRate))}/os)</option>
                      ))}
                    </select>
                  </div>
                </div>
                
                {/* Total for excursion */}
                {pricingCalc.excursionId && pricingCalc.boatId && (
                  <div className="mt-4 p-3 rounded-lg border border-[#f1d07a]/30 bg-[#f1d07a]/10">
                    {(() => {
                      const exc = dbExcursions.find((e: { id: string }) => e.id === pricingCalc.excursionId) as { entranceFeeAr?: number } | undefined;
                      const pricing = dbExcursionSellingPricing.find((p: { excursionId: string; boatId: string }) => 
                        p.excursionId === pricingCalc.excursionId && p.boatId === pricingCalc.boatId
                      ) as { pricePax1?: string; pricePax2?: string; pricePax3?: string; pricePax4?: string; pricePax5?: string; pricePax6?: string } | undefined;
                      const lunchProvider = dbLunchProviders.find((lp: { id: string }) => lp.id === pricingCalc.lunchProviderId) as { pricePerPersonAr: number } | undefined;
                      
                      // Transport: cena na osebo glede na število oseb (že v EUR)
                      const paxKey = `pricePax${Math.min(pricingCalc.pax, 6)}` as keyof NonNullable<typeof pricing>;
                      const transportPerPerson = pricing ? (Number(pricing[paxKey]) || 0) : 0;
                      const entrancePerPerson = (pricingCalc.includeEntrance && exc?.entranceFeeAr) ? arToEur(exc.entranceFeeAr, exchangeRate) : 0;
                      const lunchPerPerson = lunchProvider ? arToEur(lunchProvider.pricePerPersonAr, exchangeRate) : 0;
                      
                      const transportTotal = transportPerPerson * pricingCalc.pax;
                      const entranceTotal = entrancePerPerson * pricingCalc.pax;
                      const lunchTotal = lunchPerPerson * pricingCalc.pax;
                      const grandTotal = transportTotal + entranceTotal + lunchTotal;
                      
                      return (
                        <>
                          <div className="flex justify-between items-center text-xs text-white/60">
                            <span>Transport ({pricingCalc.pax} oseb × {eur(transportPerPerson)}):</span>
                            <span>{eur(transportTotal)}</span>
                          </div>
                          {pricingCalc.includeEntrance && entrancePerPerson > 0 && (
                            <div className="flex justify-between items-center text-xs text-white/60 mt-1">
                              <span>Vstopnina ({pricingCalc.pax} oseb × {eur(entrancePerPerson)}):</span>
                              <span>{eur(entranceTotal)}</span>
                            </div>
                          )}
                          {lunchPerPerson > 0 && (
                            <div className="flex justify-between items-center text-xs text-white/60 mt-1">
                              <span>Kosilo ({pricingCalc.pax} oseb × {eur(lunchPerPerson)}):</span>
                              <span>{eur(lunchTotal)}</span>
                            </div>
                          )}
                          <div className="flex justify-between items-center mt-2 pt-2 border-t border-[#f1d07a]/20">
                            <span className="text-sm font-semibold text-[#f1d07a]">SKUPAJ:</span>
                            <span className="text-lg font-bold text-[#f1d07a]">{eur(grandTotal)}</span>
                          </div>
                        </>
                      );
                    })()}
                  </div>
                )}
              </div>
              
              {/* TRANSFER CALCULATOR */}
              <div className="p-4 rounded-xl border border-[#5c8fd8]/20 bg-[#5c8fd8]/5">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-[#5c8fd8] mb-4 flex items-center gap-2">
                  <Car className="h-4 w-4" />
                  Transfer - Kalkulator
                </h4>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Ruta</label>
                    <select
                      className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#5c8fd8]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                      value={pricingCalc.routeId}
                      onChange={e => setPricingCalc(p => ({ ...p, routeId: e.target.value }))}
                    >
                      <option value="">-- Izberi ruto --</option>
                      {dbRoutes
                        .filter((r: { id: string }) => r.id !== 'route-airport-port')
                        .map((r: { id: string; name: string }) => (
                        <option key={r.id} value={r.id}>{r.name}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Coln</label>
                    <select
                      className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#5c8fd8]/50 focus:outline-none [&>option]:bg-[#0f1724] [&>option]:text-white"
                      value={pricingCalc.transferBoatId}
                      onChange={e => setPricingCalc(p => ({ ...p, transferBoatId: e.target.value }))}
                    >
                      <option value="">-- Izberi coln --</option>
                      {dbBoats.map((b: { id: string; name: string; engine: string }) => (
                        <option key={b.id} value={b.id}>{b.name} ({b.engine})</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Stevilo oseb</label>
                    <input
                      type="number"
                      min="1"
                      inputMode="numeric"
                      className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white focus:border-[#5c8fd8]/50 focus:outline-none"
                      value={pricingCalc.transferPax === 0 ? '' : pricingCalc.transferPax}
                      onChange={e => setPricingCalc(p => ({ ...p, transferPax: e.target.value === '' ? 0 : Number(e.target.value) }))}
                      onBlur={e => { if (e.target.value === '' || Number(e.target.value) < 1) setPricingCalc(p => ({ ...p, transferPax: 1 })) }}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Cena na osebo</label>
                    <div className="rounded-lg border border-[#78b7ff]/30 bg-[#78b7ff]/10 px-3 py-2 text-sm font-medium text-[#78b7ff]">
                      {pricingCalc.routeId && pricingCalc.transferBoatId ? (
                        (() => {
                          const pricing = dbSellingPricing.find((p: { routeId: string; boatId: string }) => 
                            p.routeId === pricingCalc.routeId && p.boatId === pricingCalc.transferBoatId
                          ) as { pricePax1?: string; pricePax2?: string; pricePax3?: string; pricePax4?: string; pricePax5?: string; pricePax6?: string } | undefined;
                          if (!pricing) return "Ni cene";
                          const paxKey = `pricePax${Math.min(pricingCalc.transferPax, 6)}` as keyof typeof pricing;
                          const pricePerPerson = Number(pricing[paxKey]) || 0;
                          return eur(pricePerPerson);
                        })()
                      ) : "—"}
                    </div>
                  </div>
                </div>
                
                {/* Total for transfer */}
                {pricingCalc.routeId && pricingCalc.transferBoatId && (
                  <div className="mt-4 p-3 rounded-lg border border-[#78b7ff]/30 bg-[#78b7ff]/10">
                    {(() => {
                      const pricing = dbSellingPricing.find((p: { routeId: string; boatId: string }) => 
                        p.routeId === pricingCalc.routeId && p.boatId === pricingCalc.transferBoatId
                      ) as { pricePax1?: string; pricePax2?: string; pricePax3?: string; pricePax4?: string; pricePax5?: string; pricePax6?: string } | undefined;
                      
                      const paxKey = `pricePax${Math.min(pricingCalc.transferPax, 6)}` as keyof NonNullable<typeof pricing>;
                      const pricePerPerson = pricing ? (Number(pricing[paxKey]) || 0) : 0;
                      const total = pricePerPerson * pricingCalc.transferPax;
                      
                      return (
                        <>
                          <div className="flex justify-between items-center">
                            <span className="text-xs text-white/60">Transfer ({pricingCalc.transferPax} oseb × {eur(pricePerPerson)}):</span>
                            <span className="text-sm font-medium text-[#78b7ff]">{eur(total)}</span>
                          </div>
                          <div className="flex justify-between items-center mt-2 pt-2 border-t border-[#78b7ff]/20">
                            <span className="text-sm font-semibold text-[#78b7ff]">SKUPAJ:</span>
                            <span className="text-lg font-bold text-[#78b7ff]">{eur(total)}</span>
                          </div>
                        </>
                      );
                    })()}
                  </div>
                )}
              </div>
              
              {/* Colni info */}
              <div className="p-4 rounded-xl border border-white/[0.08] bg-white/[0.02]">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-[#f1d07a] mb-3 flex items-center gap-2">
                  <Ship className="h-4 w-4" />
                  Colni
                </h4>
                <div className="flex flex-wrap gap-2">
                  {dbBoats.map((boat: { id: string; name: string; engine: string; capacity: number }) => (
                    <div key={boat.id} className="px-3 py-2 rounded-lg border border-white/[0.08] bg-white/[0.02]">
                      <p className="text-sm font-medium text-white">{boat.name}</p>
                      <p className="text-[10px] text-white/40">{boat.engine} · {boat.capacity} oseb</p>
                    </div>
                  ))}
                </div>
              </div>
              </>
              )}
              
              {/* FANJIN URNIK TAB */}
              {pricingTab === 'schedule' && (
              <div className="space-y-3">
                <p className="text-xs text-white/50 mb-4">Fanjini planirani izleti - vidi�� kdo od gostov je že prijavljen na kateri datum.</p>
                
                {dbScheduledExcursions.length === 0 ? (
                  <p className="text-white/40 text-sm text-center py-8">Ni planiranih izletov.</p>
                ) : (
                  dbScheduledExcursions.map((sched) => {
                    const typeColors: Record<string, string> = {
                      'bivouac': 'border-emerald-500/30 bg-emerald-500/10',
                      'tanikely-sakatia': 'border-cyan-500/30 bg-cyan-500/10',
                      'mitsio': 'border-[#f1d07a]/30 bg-[#f1d07a]/10',
                      'safari-iranja': 'border-sky-400/30 bg-sky-400/10',
                    };
                    const typeLabels: Record<string, string> = {
                      'bivouac': 'Bivouac',
                      'tanikely-sakatia': 'Tanikely & Sakatia',
                      'mitsio': 'Mitsio',
                      'safari-iranja': 'Safari Iranja',
                    };
                    const colorClass = typeColors[sched.excursionType] || 'border-white/10 bg-white/5';
                    const isPast = new Date(sched.date) < new Date(today());
                    
                    return (
                      <div 
                        key={sched.id} 
                        className={`p-3 rounded-xl border ${colorClass} ${isPast ? 'opacity-50' : ''}`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-white">
                              {new Date(sched.date).toLocaleDateString('sl-SI', { weekday: 'short', day: 'numeric', month: 'short' })}
                            </span>
                            {sched.isOption && (
                              <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/10 text-white/50">OPTION</span>
                            )}
                          </div>
                          <span className="text-xs font-medium text-white/70">{typeLabels[sched.excursionType] || sched.excursionType}</span>
                        </div>
                        
                        {sched.notes && (
                          <p className="text-[10px] text-white/40 mb-2">{sched.notes}</p>
                        )}
                        
                        {/* Guests booked on this date */}
                        {sched.guests && sched.guests.length > 0 ? (
                          <div className="flex flex-wrap gap-1.5 mt-2">
                            {sched.guests.map((g, idx) => {
                              // Extract first bungalow name (before any ';' or '/')
                              const bungalowShort = g.bungalow?.split(';')[0]?.split('/')[0]?.trim() || g.bungalow
                              return (
                                <span 
                                  key={idx}
                                  className="text-[10px] px-2 py-1 rounded-full bg-[#f1d07a]/20 text-[#f1d07a] border border-[#f1d07a]/30"
                                >
                                  {bungalowShort} - {g.guestName?.trim()} ({g.pax} os)
                                </span>
                              )
                            })}
                          </div>
                        ) : (
                          <p className="text-[10px] text-white/30 mt-2">Ni prijavljenih gostov</p>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
              )}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
