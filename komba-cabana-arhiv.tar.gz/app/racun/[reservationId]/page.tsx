'use client'

import React, { useState, useRef } from 'react'
import { useParams, useRouter, useSearchParams } from 'next/navigation'
import useSWR from 'swr'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowLeft, CreditCard, Banknote, Smartphone, HelpCircle, Plus, X, Check, Printer, Users, FileText, FileDown, Tag, Gift } from 'lucide-react'
import { getReservationById, getOrderItems, completeCheckout, getDashboardData, getInvoiceDiscounts, addInvoiceDiscount, deleteInvoiceDiscount } from '@/app/actions/komba'
import { getDeliveryNotesForReservation } from '@/app/actions/delivery'

type PaymentMethod = 'CARD' | 'CASH' | 'ORANGE_MONEY' | 'OTHER'

interface PendingPayment {
  id: string
  amount: number
  method: PaymentMethod
  notes: string
}

interface InvoiceDiscount {
  id: string
  reservationId: string
  kind: string
  label: string
  amountAr: number
  createdAt: string | Date
}

interface OrderItem {
  id: string
  name: string
  category: string
  priceAr: number
  paymentStatus: string
  eventDate?: string
  createdAt?: string
}

interface DeliveryNote {
  id: string
  date: string
  status: string
  totalAr: number
  items: Array<{
    id: string
    productName: string
    quantity: number
    priceAr: number
  }>
}

const fetcher = async (reservationId: string) => {
  const [notes, reservation, orderItems, dashboard, discounts] = await Promise.all([
    getDeliveryNotesForReservation(reservationId),
    getReservationById(reservationId),
    getOrderItems(reservationId),
    getDashboardData(),
    getInvoiceDiscounts(reservationId),
  ])
  
  // Check if this reservation is part of a group with sharedInvoice enabled
  let allNotes = notes
  let allOrderItems = orderItems
  let groupReservations: typeof dashboard.reservations = []
  let isSharedInvoice = false
  
  if (reservation?.groupId) {
    // Find the main reservation in the group to check sharedInvoice
    const mainReservation = dashboard.reservations.find(r => r.groupId === reservation.groupId && r.isMainReservation)
    isSharedInvoice = mainReservation?.sharedInvoice || reservation?.sharedInvoice || false
    
    if (isSharedInvoice) {
      // Get all reservations in the group
      groupReservations = dashboard.reservations.filter(r => r.groupId === reservation.groupId && r.id !== reservationId)
      
      // Fetch notes and orderItems for all group reservations
      const groupData = await Promise.all(
        groupReservations.map(async (r) => {
          const [groupNotes, groupOrderItems] = await Promise.all([
            getDeliveryNotesForReservation(r.id),
            getOrderItems(r.id)
          ])
          return { 
            notes: groupNotes, 
            orderItems: groupOrderItems.map(item => ({ ...item, fromBungalow: r.bungalow?.split(';')[0]?.split('/')[0]?.trim() }))
          }
        })
      )
      
      // Combine all notes and orderItems
      allNotes = [...notes, ...groupData.flatMap(d => d.notes)]
      allOrderItems = [
        ...orderItems,
        ...groupData.flatMap(d => d.orderItems)
      ]
    }
  }
  
  return { 
    notes: allNotes, 
    reservation, 
    orderItems: allOrderItems, 
    exchangeRate: reservation?.exchangeRate || 4800,
    groupReservations,
    isSharedInvoice,
    discounts,
  }
}

const methodConfig: Record<PaymentMethod, { label: string; icon: typeof CreditCard; color: string }> = {
  CARD: { label: 'Kartica', icon: CreditCard, color: '#78b7ff' },
  CASH: { label: 'Gotovina', icon: Banknote, color: '#6fc8a3' },
  ORANGE_MONEY: { label: 'Orange Money', icon: Smartphone, color: '#f97316' },
  OTHER: { label: 'Ostalo', icon: HelpCircle, color: '#f1d07a' }
}

// Invoice language (only EN or FR - Slovenian stays in the app only)
type InvoiceLang = 'en' | 'fr'

const invoiceText: Record<InvoiceLang, Record<string, string>> = {
  en: {
    invoice: 'INVOICE',
    guest: 'Guest',
    accommodation: 'Accommodation',
    persons: 'persons',
    nights: 'nights',
    services: 'Services',
    description: 'Description',
    amount: 'Amount',
    servicesTotal: 'Services total',
    bar: 'Bar',
    date: 'Date',
    item: 'Item',
    qty: 'Qty',
    items: 'items',
    barTotal: 'Bar total',
    subtotal: 'Subtotal',
    total: 'TOTAL',
    exchangeRate: 'Exchange rate',
    payments: 'Payments',
    prepayment: 'Prepayment',
    totalPaid: 'Total paid',
    balanceDue: 'Balance due',
    paid: 'Paid',
    thankYou: 'Thank you for your visit!',
    tagline: 'Komba Cabana — Pure nature.',
    includedBungalows: 'Included bungalows',
    sharedInvoice: 'Shared invoice',
  },
  fr: {
    invoice: 'FACTURE',
    guest: 'Client',
    accommodation: 'Hébergement',
    persons: 'personnes',
    nights: 'nuits',
    services: 'Services',
    description: 'Description',
    amount: 'Montant',
    servicesTotal: 'Total services',
    bar: 'Bar',
    date: 'Date',
    item: 'Article',
    qty: 'Qté',
    items: 'articles',
    barTotal: 'Total bar',
    subtotal: 'Sous-total',
    total: 'TOTAL',
    exchangeRate: 'Taux de change',
    payments: 'Paiements',
    prepayment: 'Acompte',
    totalPaid: 'Total payé',
    balanceDue: 'Solde dû',
    paid: 'Payé',
    thankYou: 'Merci de votre visite !',
    tagline: 'Komba Cabana — Pure nature.',
    includedBungalows: 'Bungalows inclus',
    sharedInvoice: 'Facture commune',
  },
}

const methodLabelByLang: Record<InvoiceLang, Record<PaymentMethod, string>> = {
  en: { CARD: 'Card', CASH: 'Cash', ORANGE_MONEY: 'Orange Money', OTHER: 'Other' },
  fr: { CARD: 'Carte', CASH: 'Espèces', ORANGE_MONEY: 'Orange Money', OTHER: 'Autre' },
}

// Word-level translation for stored order item names (saved in Slovenian in the DB).
// We only translate at display time on the invoice; the stored name is never changed.
const itemWordMap: Record<InvoiceLang, Record<string, string>> = {
  en: {
    'Bivanje': 'Accommodation',
    'noci': 'nights',
    'noči': 'nights',
    'oseb': 'persons',
    'dni': 'days',
    'Skupaj': 'Total',
    'Placano': 'Paid',
    'Plačano': 'Paid',
    'kartica': 'card',
    'gotovina': 'cash',
    'nakazilo': 'transfer',
    'Zajtrk': 'Breakfast',
    'Polpenzion': 'Half Board',
    'Polni penzion': 'Full Board',
    'Kosilo': 'Lunch',
    'Vecerja': 'Dinner',
    'Večerja': 'Dinner',
  },
  fr: {
    'Bivanje': 'Hébergement',
    'noci': 'nuits',
    'noči': 'nuits',
    'oseb': 'personnes',
    'dni': 'jours',
    'Skupaj': 'Total',
    'Placano': 'Payé',
    'Plačano': 'Payé',
    'kartica': 'carte',
    'gotovina': 'espèces',
    'nakazilo': 'virement',
    'Zajtrk': 'Petit-déjeuner',
    'Polpenzion': 'Demi-pension',
    'Polni penzion': 'Pension complète',
    'Kosilo': 'Déjeuner',
    'Vecerja': 'Dîner',
    'Večerja': 'Dîner',
  },
}

function translateItemName(name: string, lang: InvoiceLang): string {
  let out = name
  // Strip "Slovensko / English" dual-language meal names down to a single translated word
  // (handled below by word replacement). Replace whole words only.
  for (const [sl, tr] of Object.entries(itemWordMap[lang])) {
    out = out.replace(new RegExp(`\\b${sl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'g'), tr)
  }
  // Collapse "Breakfast / Breakfast" style duplicates that can appear after translating
  // dual-language meal names like "Zajtrk / Breakfast"
  out = out.replace(/\b([A-Za-zÀ-ÿ-]+)\s*\/\s*\1\b/g, '$1')
  return out
}

export default function RacunPage() {
  const params = useParams()
  const router = useRouter()
  const searchParams = useSearchParams()
  const reservationId = params.reservationId as string
  const viewOnly = searchParams.get('view') === 'true'
  const printRef = useRef<HTMLDivElement>(null)
  
  const { data, error, isLoading, mutate } = useSWR(
    reservationId ? `racun-${reservationId}` : null,
    () => fetcher(reservationId)
  )
  
  const [pendingPayments, setPendingPayments] = useState<PendingPayment[]>([])
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('CARD')
  const [amount, setAmount] = useState('')
  const [notes, setNotes] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [showPrintPreview, setShowPrintPreview] = useState(viewOnly)
  const [invoiceLang, setInvoiceLang] = useState<InvoiceLang>('en')
  const [generatingPdf, setGeneratingPdf] = useState(false)
  // Discount form state
  const [discountKind, setDiscountKind] = useState<'stay' | 'item'>('stay')
  const [discountLabel, setDiscountLabel] = useState('')
  const [discountAmount, setDiscountAmount] = useState('')
  const [addingDiscount, setAddingDiscount] = useState(false)
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0a0f1a] flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#f1d07a]"></div>
      </div>
    )
  }
  
  if (error || !data?.reservation) {
    return (
      <div className="min-h-screen bg-[#0a0f1a] flex items-center justify-center">
        <p className="text-white/50">Rezervacija ni najdena</p>
      </div>
    )
  }
  
  const { reservation, orderItems, notes: deliveryNotes, exchangeRate, groupReservations, isSharedInvoice, discounts } = data
  const invoiceDiscounts = (discounts || []) as InvoiceDiscount[]
  
  // The invoice shows ALL services, including those scheduled for a future date
  // (e.g. tomorrow's excursion or departure transfer), so the guest sees their full bill.
  // Accommodation is shown in its own dedicated section (from reservation.totalAmount),
  // so exclude any "Bivanje" order items here to avoid double counting.
  const isAccommodation = (item: OrderItem) => item.category === 'Bivanje'
  const isOnInvoice = (item: OrderItem) => !isAccommodation(item)
  const invoiceOrderItems = (orderItems as OrderItem[]).filter(isOnInvoice)
  
  // Calculate totals
  const servicesTotal = invoiceOrderItems
    .filter((item) => item.paymentStatus === 'UNPAID')
    .reduce((sum, item) => sum + Number(item.priceAr || 0), 0)
  
  const barTotal = (deliveryNotes as DeliveryNote[]).reduce((sum, note) => sum + (note.totalAr || 0), 0)
  // Accommodation (price of stay) — stored in EUR on the reservation
  const accommodationEur = Number(reservation.totalAmount || 0)
  const accommodationAr = Math.round(accommodationEur * exchangeRate)
  const subtotalAr = accommodationAr + servicesTotal + barTotal
  const discountTotalAr = invoiceDiscounts.reduce((sum, d) => sum + (d.amountAr || 0), 0)
  const grandTotalAr = Math.max(0, subtotalAr - discountTotalAr)
  const grandTotalEur = grandTotalAr / exchangeRate
  
  // Already paid (from previous payments)
  const alreadyPaidEur = Number(reservation.amountPaid) || 0
  
  // Pending payments total
  const pendingTotalEur = pendingPayments.reduce((sum, p) => sum + p.amount, 0)
  
  // Remaining to pay
  const remainingEur = Math.max(0, grandTotalEur - alreadyPaidEur - pendingTotalEur)
  
  const formatEur = (val: number) => val.toLocaleString('sl-SI', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  const formatAr = (val: number) => val.toLocaleString('sl-SI', { maximumFractionDigits: 0 })
  
  const handleAddPayment = () => {
    const numAmount = parseFloat(amount)
    if (isNaN(numAmount) || numAmount <= 0) return
    
    const newPayment: PendingPayment = {
      id: `pending-${Date.now()}`,
      amount: numAmount,
      method: selectedMethod,
      notes: notes
    }
    
    setPendingPayments([...pendingPayments, newPayment])
    setAmount('')
    setNotes('')
  }
  
  const handleRemovePayment = (id: string) => {
    setPendingPayments(pendingPayments.filter(p => p.id !== id))
  }
  
  const handleFillRemaining = () => {
    setAmount(remainingEur.toFixed(2))
  }
  
  const handleAddDiscount = async () => {
    const eur = parseFloat(discountAmount)
    if (isNaN(eur) || eur <= 0) return
    const amountAr = Math.round(eur * exchangeRate)
    setAddingDiscount(true)
    try {
      await addInvoiceDiscount(reservationId, discountKind, discountLabel, amountAr)
      setDiscountLabel('')
      setDiscountAmount('')
      await mutate()
    } catch (err) {
      console.error('Add discount error:', err)
      alert('Napaka pri dodajanju popusta')
    } finally {
      setAddingDiscount(false)
    }
  }
  
  const handleDeleteDiscount = async (id: string) => {
    try {
      await deleteInvoiceDiscount(id, reservationId)
      await mutate()
    } catch (err) {
      console.error('Delete discount error:', err)
    }
  }
  
  const handlePrint = () => {
    setShowPrintPreview(true)
    setTimeout(() => {
      window.print()
    }, 100)
  }
  
  const handleCompleteCheckout = async () => {
    if (pendingPayments.length === 0 && remainingEur > 0) {
      alert('Dodajte vsaj eno placilo')
      return
    }
    
    setSubmitting(true)
    try {
      await completeCheckout(reservationId, pendingPayments.map(p => ({
        amount: p.amount,
        currency: 'EUR',
        method: p.method,
        notes: p.notes || undefined
      })))
      // Show print preview - user will manually print and close
      setShowPrintPreview(true)
      setSubmitting(false)
    } catch (err) {
      console.error('Checkout error:', err)
      alert('Napaka pri zakljucevanju')
      setSubmitting(false)
    }
  }
  
  const t = invoiceText[invoiceLang]
  const dateLocale = invoiceLang === 'fr' ? 'fr-FR' : 'en-GB'
  const fmtDate = (d: string | Date) => new Date(d).toLocaleDateString(dateLocale, { day: '2-digit', month: 'short', year: 'numeric' })
  const today = new Date().toLocaleDateString(dateLocale, { day: 'numeric', month: 'long', year: 'numeric' })
  const invoiceNumber = `KC-${new Date().getFullYear()}-${reservation.id.slice(-6).toUpperCase()}`
  const nightsCount = Math.max(1, Math.round((new Date(reservation.departure).getTime() - new Date(reservation.arrival).getTime()) / (1000 * 60 * 60 * 24)))

  const handleDownloadPdf = async () => {
    if (!printRef.current) return
    setGeneratingPdf(true)
    // Track logo swap so we can always restore it (declared outside try)
    let logoEls: HTMLImageElement[] = []
    let originalLogoSrcs: string[] = []
    try {
      const [{ default: html2canvas }, { jsPDF }] = await Promise.all([
        import('html2canvas-pro'),
        import('jspdf'),
      ])
      // Capture the elegant DARK invoice exactly as shown on screen (gold logo).
      // We intentionally do NOT add the light 'pdf-export' class here.
      const DARK = { r: 10, g: 15, b: 26 } // #0a0f1a
      const darkHex = '#0a0f1a'

      // The on-screen logo is the dark-brown version which is nearly invisible
      // on the dark background, so swap in the gold logo just for the capture.
      logoEls = Array.from(
        printRef.current.querySelectorAll<HTMLImageElement>('img.inv-logo'),
      )
      originalLogoSrcs = logoEls.map((el) => el.src)
      await Promise.all(
        logoEls.map(
          (el) =>
            new Promise<void>((resolve) => {
              el.src = '/images/komba-logo-gold.png'
              if (el.complete) {
                resolve()
              } else {
                el.onload = () => resolve()
                el.onerror = () => resolve()
              }
            }),
        ),
      )

      const canvas = await html2canvas(printRef.current, {
        scale: 2,
        backgroundColor: darkHex,
        useCORS: true,
      })

      const pdf = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' })
      const pageW = pdf.internal.pageSize.getWidth()
      const pageH = pdf.internal.pageSize.getHeight()
      const imgW = pageW
      const usableH = pageH

      const cw = canvas.width
      // Max canvas pixels that fit on one printed page (keeps aspect ratio)
      const pagePxH = Math.floor((usableH * cw) / imgW)

      // Detect which canvas rows are "empty" (pure dark background) so we can
      // break there instead of slicing through a card. Sample columns densely
      // so thin card borders / rounded corners are not mistaken for background.
      const ctx = canvas.getContext('2d', { willReadFrequently: true })!
      const sampleStep = Math.max(1, Math.floor(cw / 600))
      const tol = 8
      const isRowEmpty = (y: number): boolean => {
        const data = ctx.getImageData(0, y, cw, 1).data
        for (let x = 0; x < cw; x += sampleStep) {
          const i = x * 4
          // Any pixel not matching the dark background means content on this row
          if (
            Math.abs(data[i] - DARK.r) > tol ||
            Math.abs(data[i + 1] - DARK.g) > tol ||
            Math.abs(data[i + 2] - DARK.b) > tol
          )
            return false
        }
        return true
      }

      // A real gap between cards must be a band of consecutive blank rows.
      const minGap = Math.max(6, Math.round(8 * 2)) // ~8px at scale 2

      const positions: { start: number; height: number }[] = []
      let start = 0
      while (start < canvas.height) {
        let end = Math.min(start + pagePxH, canvas.height)
        if (end < canvas.height) {
          // Search upward from the ideal cut (max 35% back) for a whitespace
          // band, then cut in the MIDDLE of that band.
          const minEnd = start + Math.floor(pagePxH * 0.65)
          let y = end
          let cut = -1
          while (y > minEnd) {
            if (isRowEmpty(y)) {
              // Found the bottom of a blank band; find its top
              let top = y
              while (top > minEnd && isRowEmpty(top - 1)) top--
              if (y - top >= minGap) {
                cut = Math.floor((top + y) / 2)
                break
              }
              y = top - 1 // skip past this too-thin band and keep looking
            } else {
              y--
            }
          }
          if (cut > minEnd) end = cut
        }
        positions.push({ start, height: end - start })
        start = end
      }

      positions.forEach((seg, idx) => {
        const pageCanvas = document.createElement('canvas')
        pageCanvas.width = cw
        pageCanvas.height = pagePxH
        const pctx = pageCanvas.getContext('2d')!
        // Fill the whole A4 page with the dark background so trailing space
        // on the last page stays on-theme (no white gap).
        pctx.fillStyle = darkHex
        pctx.fillRect(0, 0, cw, pagePxH)
        pctx.drawImage(canvas, 0, seg.start, cw, seg.height, 0, 0, cw, seg.height)
        if (idx > 0) pdf.addPage()
        pdf.addImage(pageCanvas.toDataURL('image/jpeg', 0.98), 'JPEG', 0, 0, imgW, usableH)
      })

      pdf.save(`${invoiceNumber}-${reservation.guestName?.replace(/[^\w-]+/g, '_') || 'racun'}.pdf`)
    } catch (err) {
      console.error('[v0] PDF generation error:', err)
      alert('Napaka pri ustvarjanju PDF')
    } finally {
      // Restore the original (on-screen) logo source
      logoEls.forEach((el, i) => {
        el.onload = null
        el.onerror = null
        if (originalLogoSrcs[i]) el.src = originalLogoSrcs[i]
      })
      setGeneratingPdf(false)
    }
  }
  
  // Print Preview / Invoice
  if (showPrintPreview) {
    return (
      <>
        <style jsx global>{`
          @media screen {
            .invoice-doc {
              background: #0a0f1a;
              color: #fff;
            }
            .inv-card { background: rgba(255,255,255,0.02); border-color: rgba(255,255,255,0.08); }
            .inv-head { border-color: rgba(255,255,255,0.1); }
            .inv-muted { color: rgba(255,255,255,0.45); }
            .inv-sub { color: rgba(255,255,255,0.6); }
            .inv-gold { color: #f1d07a; }
            .inv-green { color: #6fc8a3; }
            .inv-rowline { border-color: rgba(255,255,255,0.06); }
            .inv-section-title { color: #6fc8a3; }
            .inv-total-bar { border-color: rgba(255,255,255,0.2); }
            .inv-pay-box { background: rgba(111,200,163,0.06); border-color: rgba(111,200,163,0.2); }
            .inv-note-icon { background: rgba(111,200,163,0.1); }
          }
          @media print {
            @page { margin: 12mm; }
            html, body { background: #fff !important; }
            .no-print { display: none !important; }
            .invoice-doc {
              background: #fff !important;
              color: #111 !important;
              min-height: 0 !important;
              padding: 0 !important;
            }
            .inv-card { background: #f8f8f8 !important; border-color: #e5e5e5 !important; }
            .inv-head { border-color: #ddd !important; }
            .inv-muted { color: #777 !important; }
            .inv-sub { color: #444 !important; }
            .inv-gold { color: #111 !important; }
            .inv-green { color: #111 !important; }
            .inv-rowline { border-color: #eee !important; }
            .inv-section-title { color: #111 !important; border-color: #ddd !important; }
            .inv-total-bar { border-color: #111 !important; }
            .inv-pay-box { background: #f3f8f5 !important; border-color: #cde6da !important; }
            .inv-note-icon { background: #f0f0f0 !important; }
            .inv-logo { filter: none !important; opacity: 1 !important; }
            /* Keep blocks from being split across pages */
            .inv-card,
            .inv-pay-box,
            .inv-total-bar,
            .inv-no-break { break-inside: avoid; page-break-inside: avoid; }
            table { break-inside: auto; }
            tr, td, th { break-inside: avoid; page-break-inside: avoid; }
            h2, h3 { break-after: avoid; page-break-after: avoid; }
            /* Trim large screen-only spacing so it stays compact on paper */
            .inv-footer { margin-top: 1.5rem !important; }
            /* COMPACT print mode: fit more on each page */
            .invoice-doc { font-size: 12px !important; }
            .inv-bar-list { gap: 0.4rem !important; }
            .inv-card { border-radius: 8px !important; }
            .inv-card .inv-note-icon { height: 1.5rem !important; width: 1.5rem !important; }
            .inv-card > div:first-child { padding: 0.4rem 0.75rem !important; }
            .inv-card > div:last-child { padding-top: 0.1rem !important; padding-bottom: 0.1rem !important; }
            .inv-card > div:last-child > div { padding-top: 0.2rem !important; padding-bottom: 0.2rem !important; }
            /* Smaller, more elegant item text on bar delivery notes */
            .inv-bar-item { font-size: 10px !important; line-height: 1.25 !important; }
            /* Match the smaller, elegant text in the Services table rows */
            .inv-services-table tbody td { font-size: 10px !important; line-height: 1.25 !important; }
            .inv-services-table tbody .inv-green { font-size: 9px !important; }
            /* Smaller TOTAL and PAYMENTS blocks so they don't look oversized */
            .inv-total-bar { padding-top: 0.6rem !important; margin-bottom: 1rem !important; }
            .inv-total-bar > div:first-child { font-size: 14px !important; margin-bottom: 0.1rem !important; }
            .inv-total-bar > div:last-child { font-size: 10px !important; }
            .inv-pay-box { font-size: 10px !important; }
            .inv-pay-box h3 { font-size: 10px !important; margin-bottom: 0.4rem !important; }
            .inv-pay-box > div { font-size: 10px !important; margin-bottom: 0.25rem !important; }
            /* Tighten the guest / accommodation card */
            .inv-doc-header { margin-bottom: 0.75rem !important; padding-bottom: 0.75rem !important; }
            .inv-guest-card { padding: 0.6rem 0.9rem !important; margin-bottom: 0.75rem !important; }
            .inv-guest-card .grid { gap: 0.75rem !important; }
            .inv-guest-card p { font-size: 11px !important; line-height: 1.3 !important; }
            .inv-guest-card p.text-lg { font-size: 17px !important; }
            /* Thinner divider above the Bar total so it doesn't stand out */
            .inv-bar-list + .inv-rowline { border-top-width: 0.5px !important; border-color: #ddd !important; }
            /* Tighten section spacing */
            .inv-doc-section { margin-bottom: 1rem !important; }
            h2.inv-section-title { margin-bottom: 0.5rem !important; padding-bottom: 0.3rem !important; }
            table td, table th { padding-top: 0.2rem !important; padding-bottom: 0.2rem !important; }
            .inv-pay-box { padding: 0.75rem 1rem !important; }
          }
          /* Same light styling applied when exporting to PDF (html2pdf) */
          .pdf-export, .pdf-export.invoice-doc {
            background: #fff !important;
            color: #111 !important;
          }
          .pdf-export .inv-card { background: #f8f8f8 !important; border-color: #e5e5e5 !important; }
          .pdf-export .inv-head { border-color: #ddd !important; }
          .pdf-export .inv-muted { color: #777 !important; }
          .pdf-export .inv-sub { color: #444 !important; }
          .pdf-export .inv-gold { color: #111 !important; }
          .pdf-export .inv-green { color: #111 !important; }
          .pdf-export .inv-rowline { border-color: #eee !important; }
          .pdf-export .inv-section-title { color: #111 !important; border-color: #ddd !important; }
          .pdf-export .inv-total-bar { border-color: #111 !important; }
          .pdf-export .inv-pay-box { background: #f3f8f5 !important; border-color: #cde6da !important; }
          .pdf-export .inv-note-icon { background: #f0f0f0 !important; }
          .pdf-export .inv-logo { filter: none !important; opacity: 1 !important; }
          .pdf-export .no-print { display: none !important; }
        `}</style>

        <div ref={printRef} className="invoice-doc min-h-screen p-5 sm:p-10 print:p-0">
          <div className="max-w-3xl mx-auto">
            {/* Header with Logo */}
            <div className="inv-doc-header inv-head flex items-start justify-between mb-8 border-b pb-6">
              <div>
                <Image
                  src="/images/komba-logo.png"
                  alt="Komba Cabana"
                  width={190}
                  height={76}
                  className="inv-logo mb-2"
                />
                <p className="inv-muted text-sm">Nosy Komba, Madagascar</p>
                <p className="inv-muted text-sm">info@kombacabana.com</p>
              </div>
              <div className="text-right">
                <h1 className="text-2xl font-bold tracking-wide">{t.invoice}</h1>
                <p className="inv-sub">#{invoiceNumber}</p>
                <p className="inv-muted text-sm mt-2">{today}</p>
              </div>
            </div>

            {/* Guest Info */}
            <div className="inv-guest-card inv-card mb-8 p-5 rounded-2xl border">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="inv-muted text-[11px] uppercase tracking-wider mb-1">{t.guest}</p>
                  <p className="font-semibold text-lg">{reservation.guestName}</p>
                  {reservation.email && <p className="inv-sub text-sm">{reservation.email}</p>}
                </div>
                <div>
                  <p className="inv-muted text-[11px] uppercase tracking-wider mb-1">{t.accommodation}</p>
                  <p className="inv-gold font-semibold">{reservation.bungalow}</p>
                  <p className="inv-sub text-sm">
                    {fmtDate(reservation.arrival)} — {fmtDate(reservation.departure)}
                  </p>
                  <p className="inv-sub text-sm">{nightsCount} {t.nights} · {reservation.pax} {t.persons}</p>
                </div>
              </div>
              {isSharedInvoice && groupReservations.length > 0 && (
                <div className="inv-head mt-4 pt-4 border-t">
                  <p className="inv-muted text-[11px] uppercase tracking-wider mb-1">{t.includedBungalows}</p>
                  <p className="inv-sub text-sm">
                    {reservation.bungalow?.split(';')[0]?.split('/')[0]?.trim()} + {groupReservations.map(r => r.bungalow?.split(';')[0]?.split('/')[0]?.trim()).join(' + ')}
                  </p>
                </div>
              )}
            </div>

            {/* Accommodation */}
            {accommodationEur > 0 && (
              <div className="inv-doc-section mb-7">
                <h2 className="inv-section-title inv-head font-semibold mb-3 pb-2 border-b text-sm uppercase tracking-wider">{t.accommodation}</h2>
                <table className="inv-services-table w-full text-sm">
                  <tbody>
                    <tr className="inv-rowline border-b">
                      <td className="py-2">
                        <span>{reservation.bungalow}</span>
                        <span className="inv-muted ml-2 text-xs">{nightsCount} {t.nights}</span>
                      </td>
                      <td className="text-right py-2 tabular-nums">{formatEur(accommodationEur)} EUR</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {/* Services */}
            <div className="inv-doc-section mb-7">
              <h2 className="inv-section-title inv-head font-semibold mb-3 pb-2 border-b text-sm uppercase tracking-wider">{t.services}</h2>
              <table className="inv-services-table w-full text-sm">
                <thead>
                  <tr className="inv-muted text-[11px] uppercase">
                    <th className="text-left py-2 font-medium">{t.description}</th>
                    <th className="text-right py-2 font-medium">{t.amount}</th>
                  </tr>
                </thead>
                <tbody>
                  {invoiceOrderItems.map((item) => (
                    <tr key={item.id} className="inv-rowline border-b">
                      <td className="py-2">
                        <span className={item.paymentStatus === 'PAID' ? 'inv-muted' : ''}>{translateItemName(item.name, invoiceLang)}</span>
                        {(item.eventDate || item.createdAt) && (
                          <span className="inv-muted ml-2 text-xs">
                            {new Date(item.eventDate || item.createdAt!).toLocaleDateString(invoiceLang === 'fr' ? 'fr-FR' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                          </span>
                        )}
                        {item.paymentStatus === 'PAID' && <span className="inv-green ml-2 text-xs">({t.paid})</span>}
                      </td>
                      <td className="text-right py-2 tabular-nums">
                        {item.paymentStatus === 'PAID' ? (
                          <span className="inv-muted">0.00 EUR</span>
                        ) : (
                          <span>{formatEur(item.priceAr / exchangeRate)} EUR</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="font-semibold">
                    <td className="pt-3">{t.servicesTotal}</td>
                    <td className="text-right pt-3 tabular-nums">{formatEur(servicesTotal / exchangeRate)} EUR</td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Bar Items - grouped per daily delivery note */}
            {(deliveryNotes as DeliveryNote[]).length > 0 && (deliveryNotes as DeliveryNote[]).some(n => n.items.length > 0) && (
              <div className="inv-doc-section mb-7">
                <h2 className="inv-section-title inv-head font-semibold mb-3 pb-2 border-b text-sm uppercase tracking-wider">{t.bar}</h2>
                <div className="inv-bar-list flex flex-col gap-4">
                  {(deliveryNotes as DeliveryNote[])
                    .filter((note) => note.items.length > 0)
                    .map((note) => {
                      const noteTotalAr = note.items.reduce((s, it) => s + it.priceAr * it.quantity, 0)
                      return (
                        <div key={note.id} className="inv-card rounded-2xl border overflow-hidden">
                          {/* Note header */}
                          <div className="inv-rowline flex items-center justify-between border-b px-4 py-3">
                            <div className="flex items-center gap-3">
                              <div className="inv-note-icon flex h-9 w-9 items-center justify-center rounded-lg">
                                <FileText className="inv-green h-4 w-4" />
                              </div>
                              <div>
                                <p className="font-semibold capitalize">{fmtDate(note.date)}</p>
                                <p className="inv-muted text-xs">{note.items.length} {t.items}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="inv-green font-semibold tabular-nums">{formatEur(noteTotalAr / exchangeRate)} EUR</p>
                              <p className="inv-muted text-xs tabular-nums">{formatAr(noteTotalAr)} Ar</p>
                            </div>
                          </div>
                          {/* Note items */}
                          <div className="px-4 py-1">
                            {note.items.map((item) => (
                              <div key={item.id} className="inv-bar-item inv-rowline flex items-center justify-between border-b py-2 last:border-b-0 text-sm">
                                <span><span className="inv-muted">{item.quantity}x</span> {translateItemName(item.productName, invoiceLang)}</span>
                                <span className="tabular-nums">{formatEur((item.priceAr * item.quantity) / exchangeRate)} EUR</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )
                    })}
                </div>
                {/* Bar total */}
                <div className="inv-rowline flex justify-between border-t mt-3 pt-3 font-semibold text-sm">
                  <span>{t.barTotal}</span>
                  <span className="tabular-nums">{formatEur(barTotal / exchangeRate)} EUR</span>
                </div>
              </div>
            )}

            {/* Totals */}
            <div className="inv-total-bar border-t-2 pt-4 mb-6">
              {invoiceDiscounts.length > 0 && (
                <div className="mb-2">
                  <div className="inv-muted flex justify-between text-sm mb-1">
                    <span>{t.subtotal}</span>
                    <span className="tabular-nums">{formatEur(subtotalAr / exchangeRate)} EUR</span>
                  </div>
                  {invoiceDiscounts.map((d) => (
                    <div key={d.id} className="inv-discount-row flex justify-between text-sm mb-1">
                      <span>{d.label}</span>
                      <span className="tabular-nums">-{formatEur(d.amountAr / exchangeRate)} EUR</span>
                    </div>
                  ))}
                </div>
              )}
              <div className="flex justify-between text-xl font-bold mb-1">
                <span>{t.total}</span>
                <span className="tabular-nums">{formatEur(grandTotalEur)} EUR</span>
              </div>
              <div className="inv-muted flex justify-between text-sm">
                <span className="tabular-nums">{formatAr(grandTotalAr)} Ar</span>
                <span>{t.exchangeRate}: 1 EUR = {formatAr(exchangeRate)} Ar</span>
              </div>
            </div>

            {/* Payments */}
            <div className="inv-pay-box mb-8 p-5 rounded-2xl border">
              <h3 className="inv-green font-semibold mb-3 text-sm uppercase tracking-wider">{t.payments}</h3>
              {alreadyPaidEur > 0 && (
                <div className="flex justify-between text-sm mb-2">
                  <span className="inv-sub">{t.prepayment}</span>
                  <span className="tabular-nums">{formatEur(alreadyPaidEur)} EUR</span>
                </div>
              )}
              {pendingPayments.map((payment) => (
                <div key={payment.id} className="flex justify-between text-sm mb-2">
                  <span className="inv-sub">{methodLabelByLang[invoiceLang][payment.method]}{payment.notes ? ` (${payment.notes})` : ''}</span>
                  <span className="tabular-nums">{formatEur(payment.amount)} EUR</span>
                </div>
              ))}
              <div className="inv-pay-box flex justify-between font-bold pt-2 border-t mt-2" style={{ background: 'transparent' }}>
                <span>{t.totalPaid}</span>
                <span className="tabular-nums">{formatEur(alreadyPaidEur + pendingTotalEur)} EUR</span>
              </div>
              {remainingEur > 0 && (
                <div className="flex justify-between font-bold mt-2 text-base">
                  <span>{t.balanceDue}</span>
                  <span className="tabular-nums">{formatEur(remainingEur)} EUR</span>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="inv-footer inv-head inv-muted text-center text-sm mt-12 pt-6 border-t">
              <p>{t.thankYou} {t.tagline}</p>
            </div>
          </div>

          {/* Action buttons - no print */}
          <div className="no-print fixed top-4 right-4 flex items-center gap-2">
            {/* Language toggle EN / FR */}
            <div className="flex items-center rounded-lg overflow-hidden border border-white/15 bg-white/5">
              <button
                onClick={() => setInvoiceLang('en')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${invoiceLang === 'en' ? 'bg-[#f1d07a] text-gray-900' : 'text-white/60 hover:text-white'}`}
              >
                EN
              </button>
              <button
                onClick={() => setInvoiceLang('fr')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${invoiceLang === 'fr' ? 'bg-[#f1d07a] text-gray-900' : 'text-white/60 hover:text-white'}`}
              >
                FR
              </button>
            </div>
            <button
              onClick={handleDownloadPdf}
              disabled={generatingPdf}
              className="px-4 py-2 bg-[#78b7ff] text-gray-900 rounded-lg hover:bg-[#6aa8f0] font-medium flex items-center gap-2 disabled:opacity-60"
            >
              {generatingPdf ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-900"></div>
              ) : (
                <FileDown className="h-4 w-4" />
              )}
              PDF
            </button>
            <button
              onClick={() => window.print()}
              className="px-4 py-2 bg-[#f1d07a] text-gray-900 rounded-lg hover:bg-[#e5c46e] font-medium flex items-center gap-2"
            >
              <Printer className="h-4 w-4" />
              Natisni
            </button>
            {!viewOnly && (
              <button
                onClick={() => router.push('/arhiv')}
                className="px-4 py-2 bg-[#6fc8a3] text-gray-900 rounded-lg hover:bg-[#5db892] font-medium"
              >
                Končano
              </button>
            )}
            {viewOnly && (
              <button
                onClick={() => window.close()}
                className="px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20 font-medium"
              >
                Zapri
              </button>
            )}
          </div>
        </div>
      </>
    )
  }
  
  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-[#0a0f1a]/95 backdrop-blur-sm border-b border-white/10">
        <div className="px-4 py-4 flex items-center justify-between">
          <Link href={`/dobavnice/${reservationId}`} className="flex items-center gap-2 text-white/60 hover:text-white">
            <ArrowLeft className="h-5 w-5" />
            <span>Nazaj</span>
          </Link>
          <h1 className="text-lg font-semibold">Zaključi račun</h1>
          <button onClick={handlePrint} className="p-2 rounded-lg hover:bg-white/10">
            <Printer className="h-5 w-5 text-white/60" />
          </button>
        </div>
      </div>
      
      <div className="p-4 max-w-2xl mx-auto space-y-6">
        {/* Logo */}
        <div className="flex justify-center py-4">
          <Image 
            src="/images/komba-logo.png" 
            alt="Komba Cabana" 
            width={180} 
            height={72}
            className="opacity-80"
          />
        </div>
        
        {/* Guest Info */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[#f1d07a] font-bold text-lg">{reservation.bungalow}</p>
              <p className="text-white/60 text-sm">{reservation.guestName}</p>
              <p className="text-white/40 text-xs mt-1">
                {new Date(reservation.arrival).toLocaleDateString('sl-SI')} - {new Date(reservation.departure).toLocaleDateString('sl-SI')} | {reservation.pax} oseb
              </p>
            </div>
            {isSharedInvoice && groupReservations.length > 0 && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-purple-500/20 border border-purple-500/30">
                <Users className="h-3.5 w-3.5 text-purple-300" />
                <span className="text-xs font-medium text-purple-300">Skupna</span>
              </div>
            )}
          </div>
          {isSharedInvoice && groupReservations.length > 0 && (
            <div className="mt-3 pt-3 border-t border-white/10">
              <p className="text-[10px] text-white/40 mb-1">Vključeni bungalovi:</p>
              <p className="text-xs text-purple-300">
                {reservation.bungalow?.split(';')[0]?.split('/')[0]?.trim()} + {groupReservations.map(r => r.bungalow?.split(';')[0]?.split('/')[0]?.trim()).join(' + ')}
              </p>
            </div>
          )}
        </div>
        
        {/* Invoice Summary */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
          <div className="px-4 py-3 border-b border-white/10 bg-white/[0.02]">
            <p className="text-sm font-medium text-white/70 uppercase tracking-wider">Povzetek računa</p>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-white/60">Storitve (za plačilo)</span>
              <span className="text-white">{formatEur(servicesTotal / exchangeRate)} EUR</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-white/60">Bar</span>
              <span className="text-white">{formatEur(barTotal / exchangeRate)} EUR</span>
            </div>
            {invoiceDiscounts.map((d) => (
              <div key={d.id} className="flex justify-between text-sm text-[#6fc8a3]">
                <span className="flex items-center gap-1.5">
                  {d.kind === 'item' ? <Gift className="h-3.5 w-3.5" /> : <Tag className="h-3.5 w-3.5" />}
                  {d.label}
                </span>
                <span>-{formatEur(d.amountAr / exchangeRate)} EUR</span>
              </div>
            ))}
            <div className="border-t border-white/10 pt-3 flex justify-between">
              <span className="text-white font-medium">Skupaj</span>
              <div className="text-right">
                <p className="text-[#78b7ff] font-bold text-lg">{formatEur(grandTotalEur)} EUR</p>
                <p className="text-white/40 text-xs">{formatAr(grandTotalAr)} Ar</p>
              </div>
            </div>
            {alreadyPaidEur > 0 && (
              <div className="flex justify-between text-sm text-[#6fc8a3]">
                <span>Že plačano</span>
                <span>-{formatEur(alreadyPaidEur)} EUR</span>
              </div>
            )}
            {pendingTotalEur > 0 && (
              <div className="flex justify-between text-sm text-[#f1d07a]">
                <span>Dodano plačilo</span>
                <span>-{formatEur(pendingTotalEur)} EUR</span>
              </div>
            )}
            <div className="border-t border-white/10 pt-3 flex justify-between">
              <span className="text-white font-semibold">Za plačilo</span>
              <span className={`font-bold text-xl ${remainingEur <= 0 ? 'text-[#6fc8a3]' : 'text-red-400'}`}>
                {formatEur(remainingEur)} EUR
              </span>
            </div>
          </div>
        </div>
        
        {/* Discounts (editable, not in view-only) */}
        {!viewOnly && (
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
            <div className="px-4 py-3 border-b border-white/10 bg-white/[0.02]">
              <p className="text-sm font-medium text-white/70 uppercase tracking-wider">Popusti</p>
            </div>
            <div className="p-4 space-y-4">
              {/* Existing discounts */}
              {invoiceDiscounts.length > 0 && (
                <div className="space-y-2">
                  {invoiceDiscounts.map((d) => (
                    <div key={d.id} className="flex items-center justify-between rounded-xl bg-white/[0.03] border border-white/10 px-3 py-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-[#6fc8a3]/15">
                          {d.kind === 'item' ? <Gift className="h-4 w-4 text-[#6fc8a3]" /> : <Tag className="h-4 w-4 text-[#6fc8a3]" />}
                        </div>
                        <div>
                          <p className="text-white text-sm font-medium">{d.label}</p>
                          <p className="text-white/40 text-xs">{d.kind === 'item' ? 'Brezplačna postavka' : 'Popust na bivanje'}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[#6fc8a3] text-sm font-medium">-{formatEur(d.amountAr / exchangeRate)} EUR</span>
                        <button onClick={() => handleDeleteDiscount(d.id)} className="p-1.5 rounded-lg hover:bg-white/10 text-white/40 hover:text-red-400">
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Kind toggle */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setDiscountKind('stay')}
                  className={`p-3 rounded-xl border text-center transition-all flex items-center justify-center gap-2 ${discountKind === 'stay' ? 'border-white/30 bg-white/10 text-white' : 'border-white/10 bg-white/[0.02] text-white/50 hover:bg-white/[0.05]'}`}
                >
                  <Tag className="h-4 w-4" />
                  <span className="text-sm">Popust na bivanje</span>
                </button>
                <button
                  onClick={() => setDiscountKind('item')}
                  className={`p-3 rounded-xl border text-center transition-all flex items-center justify-center gap-2 ${discountKind === 'item' ? 'border-white/30 bg-white/10 text-white' : 'border-white/10 bg-white/[0.02] text-white/50 hover:bg-white/[0.05]'}`}
                >
                  <Gift className="h-4 w-4" />
                  <span className="text-sm">Brezplačna postavka</span>
                </button>
              </div>

              {/* Label */}
              <input
                type="text"
                value={discountLabel}
                onChange={(e) => setDiscountLabel(e.target.value)}
                placeholder={discountKind === 'item' ? 'Npr. Brezplačna večerja' : 'Npr. Popust na bivanje'}
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-white/30"
              />

              {/* Amount */}
              <div className="relative">
                <input
                  type="number"
                  value={discountAmount}
                  onChange={(e) => setDiscountAmount(e.target.value)}
                  placeholder="Znesek popusta"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-white/30"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-white/40">EUR</span>
              </div>

              <button
                onClick={handleAddDiscount}
                disabled={addingDiscount || !discountAmount || parseFloat(discountAmount) <= 0}
                className="w-full py-3 rounded-xl bg-[#6fc8a3]/20 text-[#6fc8a3] font-medium flex items-center justify-center gap-2 hover:bg-[#6fc8a3]/30 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Plus className="h-5 w-5" />
                Dodaj popust
              </button>
            </div>
          </div>
        )}
        
        {/* Payment Method Selection */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
          <div className="px-4 py-3 border-b border-white/10 bg-white/[0.02]">
            <p className="text-sm font-medium text-white/70 uppercase tracking-wider">Dodaj plačilo</p>
          </div>
          <div className="p-4 space-y-4">
            {/* Method buttons */}
            <div className="grid grid-cols-4 gap-2">
              {(Object.entries(methodConfig) as [PaymentMethod, typeof methodConfig[PaymentMethod]][]).map(([method, config]) => {
                const Icon = config.icon
                const isSelected = selectedMethod === method
                return (
                  <button
                    key={method}
                    onClick={() => setSelectedMethod(method)}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      isSelected 
                        ? 'border-white/30 bg-white/10' 
                        : 'border-white/10 bg-white/[0.02] hover:bg-white/[0.05]'
                    }`}
                  >
                    <Icon 
                      className="h-6 w-6 mx-auto mb-1" 
                      style={{ color: isSelected ? config.color : 'rgba(255,255,255,0.4)' }}
                    />
                    <p className={`text-xs ${isSelected ? 'text-white' : 'text-white/50'}`}>{config.label}</p>
                  </button>
                )
              })}
            </div>
            
            {/* Amount input */}
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Znesek"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-white/30"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-white/40">EUR</span>
              </div>
              <button
                onClick={handleFillRemaining}
                className="px-4 py-3 rounded-xl bg-[#78b7ff]/20 text-[#78b7ff] text-sm font-medium hover:bg-[#78b7ff]/30"
              >
                Preostanek
              </button>
            </div>
            
            {/* Notes (optional) */}
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Opomba (opcijsko)"
              className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-white/30"
            />
            
            {/* Add button */}
            <button
              onClick={handleAddPayment}
              disabled={!amount || parseFloat(amount) <= 0}
              className="w-full py-3 rounded-xl bg-[#6fc8a3]/20 text-[#6fc8a3] font-medium flex items-center justify-center gap-2 hover:bg-[#6fc8a3]/30 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus className="h-5 w-5" />
              Dodaj plačilo
            </button>
          </div>
        </div>
        
        {/* Pending Payments List */}
        {pendingPayments.length > 0 && (
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
            <div className="px-4 py-3 border-b border-white/10 bg-white/[0.02]">
              <p className="text-sm font-medium text-white/70 uppercase tracking-wider">Dodana pla��ila</p>
            </div>
            <div className="divide-y divide-white/5">
              {pendingPayments.map((payment) => {
                const config = methodConfig[payment.method]
                const Icon = config.icon
                return (
                  <div key={payment.id} className="px-4 py-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-10 h-10 rounded-xl flex items-center justify-center"
                        style={{ backgroundColor: config.color + '20' }}
                      >
                        <Icon className="h-5 w-5" style={{ color: config.color }} />
                      </div>
                      <div>
                        <p className="text-white font-medium">{formatEur(payment.amount)} EUR</p>
                        <p className="text-white/40 text-sm">{config.label}{payment.notes ? ` • ${payment.notes}` : ''}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleRemovePayment(payment.id)}
                      className="p-2 rounded-lg hover:bg-red-500/20 text-white/30 hover:text-red-400"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                )
              })}
            </div>
          </div>
        )}
        
        {/* Complete Button */}
        <button
          onClick={handleCompleteCheckout}
          disabled={submitting || (pendingPayments.length === 0 && remainingEur > 0)}
          className={`w-full py-4 rounded-2xl font-semibold text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
            remainingEur <= 0 || pendingPayments.length > 0
              ? 'bg-gradient-to-r from-[#6fc8a3] to-[#4a9a7c] text-white hover:opacity-90'
              : 'bg-white/10 text-white/30 cursor-not-allowed'
          }`}
        >
          {submitting ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
          ) : (
            <>
              <Check className="h-5 w-5" />
              Zaključi račun
            </>
          )}
        </button>
        
        {remainingEur > 0 && pendingPayments.length === 0 && (
          <p className="text-center text-white/40 text-sm">Dodajte plačilo za nadaljevanje</p>
        )}
      </div>
    </div>
  )
}
