'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import useSWR from 'swr'
import { ArrowLeft, TrendingUp, TrendingDown, Settings, Plus, Trash2, Users, Moon, Euro, BarChart3, UserCog, Edit2, Check, X, Printer, UserMinus, UserCheck, Calendar, AlertTriangle, FileText, Ship, Megaphone, Search } from 'lucide-react'
import { 
  getMonthlyStatistics, 
  getCostSettings, 
  updateCostSetting,
  getStaffSalaries,
  upsertStaffSalary,
  deleteStaffSalary,
  getAllStaffMembers,
  upsertStaffMember,
  deleteStaffMember,
  toggleStaffActive,
  updateStaffStartDate,
  setStaffRegularEmployee
} from '@/app/actions/statistics'
import RazporedTab from '@/components/razpored-tab'
import VrtnarjiTab from '@/components/vrtnarji-tab'
import KuhinjaTab from '@/components/kuhinja-tab'
import PlaceTab from '@/components/place-tab'
import PogodbeTab from '@/components/pogodbe-tab'
import StaffPersonalInfo from '@/components/staff-personal-info'
import GuestBreakdown from '@/components/guest-breakdown'
import PrevozinkiTab from '@/components/prevozniki-tab'
import MarketingTab from '@/components/marketing-tab'
import MarketingOverviewRow from '@/components/marketing-overview-row'
import LeaveDocument from '@/components/leave-document'
import PayrollSettingsPanel from '@/components/payroll-settings'
import { getUpcomingContributionAlerts } from '@/app/actions/payroll'
import { formatAr } from '@/lib/payroll'

const MONTHS = [
  'Januar', 'Februar', 'Marec', 'April', 'Maj', 'Junij',
  'Julij', 'Avgust', 'September', 'Oktober', 'November', 'December'
]

const STAFF_TYPES = [
  { value: 'gardener', label: 'Vrtnar', allocateTo: 'accommodation' },
  { value: 'housekeeper', label: 'Sobarica', allocateTo: 'accommodation' },
  { value: 'barman', label: 'Barman', allocateTo: 'bar' },
  { value: 'kitchen', label: 'Kuhinja', allocateTo: 'kuhinja' },
  { value: 'reception', label: 'Recepcija', allocateTo: 'management' },
  { value: 'maintenance', label: 'Vzdrževanje', allocateTo: 'management' },
  { value: 'other', label: 'Drugo', allocateTo: 'management' },
]

function formatEur(value: number) {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(value)
}

type Tab = 'kalkulacije' | 'kadri'
type KalkulacijeView = 'pregled' | 'nastavitve' | 'prevozniki' | 'marketing'
type KadriView = 'seznam' | 'place' | 'pogodbe' | 'razpored'

export default function StatistikaPage() {
  const currentDate = new Date()
  const [year, setYear] = useState(currentDate.getFullYear())
  const [month, setMonth] = useState(currentDate.getMonth() + 1)
  const [activeTab, setActiveTab] = useState<Tab>('kalkulacije')
  const [kalkulacijeView, setKalkulacijeView] = useState<KalkulacijeView>('pregled')
  const [razporedView, setRazporedView] = useState<'sobarice' | 'vrtnarji' | 'kuhinja' | 'bar'>('sobarice')
  const [kadriView, setKadriView] = useState<KadriView>('seznam')
  const [staffSearch, setStaffSearch] = useState('')
  const [editingStaff, setEditingStaff] = useState<string | null>(null)
  const [newStaff, setNewStaff] = useState({ 
    staffType: 'other', 
    staffName: '', 
    monthlySalary: '', 
    allocateTo: 'management',
    activeMonths: [1,2,3,4,5,6,7,8,9,10,11,12],
    startDate: ''
  })

  const { data: stats, mutate } = useSWR(
    ['statistics', year, month],
    () => getMonthlyStatistics(year, month),
    { refreshInterval: 0 }
  )

  const { data: allStaff, mutate: mutateStaff } = useSWR(
    'all-staff',
    () => getAllStaffMembers(),
    { refreshInterval: 0 }
  )

  const { data: contributionAlerts } = useSWR(
    'contribution-alerts',
    () => getUpcomingContributionAlerts(),
    { refreshInterval: 0 }
  )

  const handleCostUpdate = async (id: string, value: number) => {
    await updateCostSetting(id, value)
    mutate()
  }

  const handleAddStaff = async () => {
    if (!newStaff.staffName || !newStaff.monthlySalary) return
    await upsertStaffMember({
      staffType: newStaff.staffType,
      staffName: newStaff.staffName,
      monthlySalary: Number(newStaff.monthlySalary),
      allocateTo: newStaff.allocateTo,
      activeMonths: newStaff.activeMonths,
      startDate: newStaff.startDate || null
    })
    setNewStaff({ staffType: 'other', staffName: '', monthlySalary: '', allocateTo: 'management', activeMonths: [1,2,3,4,5,6,7,8,9,10,11,12], startDate: '' })
    mutateStaff()
    mutate()
  }

 const handleDeleteStaff = async (id: string) => {
  await deleteStaffMember(id)
  mutateStaff()
  mutate()
  }

  const handleToggleActive = async (id: string, currentActive: boolean) => {
    await toggleStaffActive(id, !currentActive)
    mutateStaff()
    mutate()
  }

  const handleUpdateStartDate = async (id: string, startDate: string) => {
    await updateStaffStartDate(id, startDate || null)
    mutateStaff()
  }

  const handleToggleRegular = async (id: string, current: boolean) => {
    await setStaffRegularEmployee(id, !current)
    mutateStaff()
  }
  
  const handleToggleMonth = (monthNum: number) => {
    setNewStaff(s => ({
      ...s,
      activeMonths: s.activeMonths.includes(monthNum) 
        ? s.activeMonths.filter(m => m !== monthNum)
        : [...s.activeMonths, monthNum].sort((a,b) => a-b)
    }))
  }

  if (!stats) {
    return (
      <div className="min-h-screen bg-[#0a0f1a] flex items-center justify-center">
        <div className="animate-pulse text-white/50">Nalagam statistiko...</div>
      </div>
    )
  }

  const profitColor = stats.profit >= 0 ? 'text-[#6fc8a3]' : 'text-[#ef4444]'
  const ProfitIcon = stats.profit >= 0 ? TrendingUp : TrendingDown

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white">
      {/* Header */}
      <div className="border-b border-white/10 bg-[#0d1420]">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-white/60 hover:text-white">
                <ArrowLeft className="h-4 w-4" />
                <span className="text-sm">Nazaj</span>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-[#f1d07a]">Statistika</h1>
                <p className="text-white/40 text-sm hidden sm:block">Mesečni pregled prihodkov in stroškov</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {/* Month/Year Selector */}
              <select
                value={month}
                onChange={(e) => setMonth(Number(e.target.value))}
                className="flex-1 sm:flex-none px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-sm"
              >
                {MONTHS.map((m, i) => (
                  <option key={i} value={i + 1} className="bg-[#0d1420]">{m}</option>
                ))}
              </select>
              <select
                value={year}
                onChange={(e) => setYear(Number(e.target.value))}
                className="px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-sm"
              >
                {[2024, 2025, 2026, 2027].map(y => (
                  <option key={y} value={y} className="bg-[#0d1420]">{y}</option>
                ))}
              </select>
            </div>
          </div>
          
          {/* Tabs */}
          <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
            <button
              onClick={() => setActiveTab('kalkulacije')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                activeTab === 'kalkulacije' 
                  ? 'bg-[#78b7ff]/20 text-[#78b7ff] border border-[#78b7ff]/30' 
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              <BarChart3 className="h-4 w-4" />
              Kalkulacije
            </button>
            <button
              onClick={() => setActiveTab('kadri')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                activeTab === 'kadri' 
                  ? 'bg-[#6fc8a3]/20 text-[#6fc8a3] border border-[#6fc8a3]/30' 
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              <UserCog className="h-4 w-4" />
              Kadrovski oddelek
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        
        {/* TAB: KALKULACIJE */}
        {activeTab === 'kalkulacije' && (
          <div className="space-y-6">
          {/* Sub-toggle: Pregled / Nastavitve */}
          <div className="flex gap-2 overflow-x-auto pb-1">
            <button
              onClick={() => setKalkulacijeView('pregled')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                kalkulacijeView === 'pregled'
                  ? 'bg-[#78b7ff]/20 text-[#78b7ff] border border-[#78b7ff]/30'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              <BarChart3 className="h-4 w-4" />
              Pregled
            </button>
            <button
              onClick={() => setKalkulacijeView('prevozniki')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                kalkulacijeView === 'prevozniki'
                  ? 'bg-[#6fc8a3]/20 text-[#6fc8a3] border border-[#6fc8a3]/30'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              <Ship className="h-4 w-4" />
              Prevozniki
            </button>
            <button
              onClick={() => setKalkulacijeView('marketing')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                kalkulacijeView === 'marketing'
                  ? 'bg-[#f1d07a]/20 text-[#f1d07a] border border-[#f1d07a]/30'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              <Megaphone className="h-4 w-4" />
              Stroški
            </button>
            <button
              onClick={() => setKalkulacijeView('nastavitve')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                kalkulacijeView === 'nastavitve'
                  ? 'bg-[#f1d07a]/20 text-[#f1d07a] border border-[#f1d07a]/30'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              <Settings className="h-4 w-4" />
              Nastavitve
            </button>
          </div>

          {kalkulacijeView === 'pregled' && (
          <>
            {/* Opozorila za rok placila prispevkov */}
            {contributionAlerts && contributionAlerts.length > 0 && (
              <div className="mb-6 space-y-3">
                {contributionAlerts.map((a) => {
                  const deadline = new Date(a.deadline)
                  const deadlineStr = deadline.toLocaleDateString('sl-SI', { day: 'numeric', month: 'long', year: 'numeric' })
                  return (
                    <div
                      key={`${a.year}-${a.quarter}`}
                      className="flex flex-wrap items-center gap-4 rounded-2xl border border-[#e08a8a]/30 bg-[#e08a8a]/10 p-4"
                    >
                      <div className="flex items-center gap-3">
                        <AlertTriangle className="h-5 w-5 shrink-0 text-[#e08a8a]" />
                        <div>
                          <p className="text-sm font-semibold text-[#e08a8a]">
                            Prispevki Q{a.quarter} {a.year} —{' '}
                            {a.daysLeft < 0
                              ? `rok potekel pred ${Math.abs(a.daysLeft)} dnevi!`
                              : `rok čez ${a.daysLeft} dni`}
                          </p>
                          <p className="text-xs text-white/50">Rok plačila: {deadlineStr}</p>
                        </div>
                      </div>
                      <div className="ml-auto flex flex-wrap gap-x-6 gap-y-1 text-xs text-white/60">
                        <span>CNAPS: <span className="text-white">{formatAr(a.cnaps)}</span></span>
                        <span>OMINO: <span className="text-white">{formatAr(a.omino)}</span></span>
                        <span>FMFP: <span className="text-white">{formatAr(a.fmfp)}</span></span>
                        <span className="font-semibold">Skupaj: <span className="text-[#e08a8a]">{formatAr(a.total)}</span></span>
                      </div>
                      <button
                        onClick={() => { setActiveTab('kadri'); setKadriView('place') }}
                        className="rounded-xl border border-white/[0.08] bg-white/[0.04] px-3 py-1.5 text-xs font-medium text-white transition hover:bg-white/[0.08]"
                      >
                        Odpri obračun
                      </button>
                    </div>
                  )
                })}
              </div>
            )}

            {/* Summary Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
              <div className="p-3 sm:p-4 rounded-2xl bg-white/[0.03] border border-white/10">
                <div className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-wider mb-1 sm:mb-2">
                  <Users className="h-3 w-3 sm:h-4 sm:w-4" />
                  Gostov
                </div>
                <p className="text-xl sm:text-2xl font-bold text-white">{stats.guests}</p>
              </div>
              <div className="p-3 sm:p-4 rounded-2xl bg-white/[0.03] border border-white/10">
                <div className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-wider mb-1 sm:mb-2">
                  <Moon className="h-3 w-3 sm:h-4 sm:w-4" />
                  Nočitev
                </div>
                <p className="text-xl sm:text-2xl font-bold text-white">{stats.nights}</p>
              </div>
              <div className="p-3 sm:p-4 rounded-2xl bg-white/[0.03] border border-white/10">
                <div className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-wider mb-1 sm:mb-2">
                  <Euro className="h-3 w-3 sm:h-4 sm:w-4" />
                  Prihodki
                </div>
                <p className="text-lg sm:text-2xl font-bold text-[#78b7ff]">{formatEur(stats.revenue.total)}</p>
              </div>
              <div className="p-3 sm:p-4 rounded-2xl bg-white/[0.03] border border-white/10">
                <div className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-wider mb-1 sm:mb-2">
                  <ProfitIcon className="h-3 w-3 sm:h-4 sm:w-4" />
                  Dobiček
                </div>
                <p className={`text-lg sm:text-2xl font-bold ${profitColor}`}>{formatEur(stats.profit)}</p>
              </div>
            </div>

            <div className="space-y-6">
              {/* NOČITVE */}
              <div className="p-4 sm:p-6 rounded-2xl bg-white/[0.03] border border-white/10">
                <h2 className="text-base sm:text-lg font-bold text-[#f1d07a] mb-4">NOČITVE</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-8">
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Prihodki</p>
                    <p className="text-xl sm:text-2xl font-bold text-[#78b7ff]">{formatEur(stats.revenue.accommodation)}</p>
                  </div>
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Stroški</p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-white/50">Plače (vrtnar, sobarica)</span>
                        <span className="text-white">{formatEur((stats.salaryBreakdown as { accommodation?: number })?.accommodation || 0)}</span>
                      </div>
                      <MarketingOverviewRow year={year} month={month} category="marketing" label="Marketing" amount={(stats.costs as { marketing?: number }).marketing || 0} />
                      {/* Provizija prodajnih platform: Booking + Optima plus */}
                      <div className="pt-1">
                        <p className="text-[11px] uppercase tracking-wider text-white/35 mb-1">Provizija prodajnih platform</p>
                        <div className="ml-1 space-y-2">
                          <MarketingOverviewRow year={year} month={month} category="booking" label="Booking" amount={(stats.costs as { booking?: number }).booking || 0} />
                          <MarketingOverviewRow year={year} month={month} category="optimaplus" label="Optima plus" amount={(stats.costs as { optimaplus?: number }).optimaplus || 0} />
                        </div>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-white/50">Starlink</span>
                        <span className="text-white">{formatEur((stats.costs as { starlink?: number }).starlink || 0)}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:justify-between gap-1">
                  <span className="text-white/70 font-medium">Dobiček nočitev</span>
                  <span className="text-[#6fc8a3] font-bold">{formatEur(stats.revenue.accommodation - ((stats.salaryBreakdown as { accommodation?: number })?.accommodation || 0) - ((stats.costs as { platformCommission?: number }).platformCommission || 0) - ((stats.costs as { marketing?: number }).marketing || 0) - ((stats.costs as { starlink?: number }).starlink || 0))}</span>
                </div>
              </div>

              {/* BAR (samo pijača) */}
              <div className="p-4 sm:p-6 rounded-2xl bg-white/[0.03] border border-white/10">
                <h2 className="text-base sm:text-lg font-bold text-[#f1d07a] mb-4">BAR</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-8">
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Prihodki</p>
                    <p className="text-xl sm:text-2xl font-bold text-[#78b7ff]">{formatEur(stats.revenue.bar.pijaca)}</p>
                  </div>
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Stroški</p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-white/50">Nabava pijača ({stats.costSettings?.find(c => c.category === 'bar_pijaca')?.value || 0}%)</span>
                        <span className="text-white">{formatEur(stats.costs.barPijaca)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-white/50">Plače (barman)</span>
                        <span className="text-white">{formatEur((stats.salaryBreakdown as { bar?: number })?.bar || 0)}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:justify-between gap-1">
                  <span className="text-white/70 font-medium">Dobiček bar</span>
                  <span className="text-[#6fc8a3] font-bold">{formatEur(stats.revenue.bar.pijaca - stats.costs.barPijaca - ((stats.salaryBreakdown as { bar?: number })?.bar || 0))}</span>
                </div>
              </div>

              {/* KUHINJA (prehrana iz bara + meal plan predplačilo) */}
              <div className="p-4 sm:p-6 rounded-2xl bg-white/[0.03] border border-white/10">
                <h2 className="text-base sm:text-lg font-bold text-[#f1d07a] mb-4">KUHINJA</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-8">
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Prihodki</p>
                    <p className="text-xl sm:text-2xl font-bold text-[#78b7ff]">{formatEur(stats.revenue.bar.prehrana + stats.revenue.mealPlan)}</p>
                    <div className="mt-2 space-y-1 text-sm">
                      <div className="flex justify-between text-white/50">
                        <span>- Prehrana (bar)</span>
                        <span>{formatEur(stats.revenue.bar.prehrana)}</span>
                      </div>
                      <div className="flex justify-between text-white/50">
                        <span>- Predplačilo (meal plan)</span>
                        <span>{formatEur(stats.revenue.mealPlan)}</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Stroški</p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-white/50">Nabava hrana ({stats.costSettings?.find(c => c.category === 'bar_prehrana')?.value || 0}%)</span>
                        <span className="text-white">{formatEur(stats.costs.barPrehrana + ((stats.costs as { mealPlan?: number }).mealPlan || 0))}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-white/50">Plače (kuhinja)</span>
                        <span className="text-white">{formatEur((stats.salaryBreakdown as { kuhinja?: number })?.kuhinja || 0)}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:justify-between gap-1">
                  <span className="text-white/70 font-medium">Dobiček kuhinja</span>
                  <span className="text-[#6fc8a3] font-bold">{formatEur(stats.revenue.bar.prehrana + stats.revenue.mealPlan - stats.costs.barPrehrana - ((stats.costs as { mealPlan?: number }).mealPlan || 0) - ((stats.salaryBreakdown as { kuhinja?: number })?.kuhinja || 0))}</span>
                </div>
              </div>

              {/* PREVOZI */}
              <div className="p-4 sm:p-6 rounded-2xl bg-white/[0.03] border border-white/10">
                <h2 className="text-base sm:text-lg font-bold text-[#f1d07a] mb-4">PREVOZI</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-8">
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Prihodki</p>
                    <p className="text-xl sm:text-2xl font-bold text-[#78b7ff]">{formatEur(stats.revenue.transfers)}</p>
                  </div>
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Stroški</p>
                    <div className="flex justify-between text-sm">
                      <span className="text-white/50">Dobavitelj prevozov</span>
                      <span className="text-white">{formatEur((stats.costs as { transfers?: number }).transfers || 0)}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:justify-between gap-1">
                  <span className="text-white/70 font-medium">Dobiček prevozi</span>
                  <span className="text-[#6fc8a3] font-bold">{formatEur(stats.revenue.transfers - ((stats.costs as { transfers?: number }).transfers || 0))}</span>
                </div>
              </div>

              {/* IZLETI */}
              <div className="p-4 sm:p-6 rounded-2xl bg-white/[0.03] border border-white/10">
                <h2 className="text-base sm:text-lg font-bold text-[#f1d07a] mb-4">IZLETI</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-8">
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Prihodki</p>
                    <p className="text-xl sm:text-2xl font-bold text-[#78b7ff]">{formatEur(stats.revenue.excursions)}</p>
                  </div>
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Stroški</p>
                    <div className="flex justify-between text-sm">
                      <span className="text-white/50">Najem čolnov + vodič + vstop + kosilo</span>
                      <span className="text-white">{formatEur((stats.costs as { excursions?: number }).excursions || 0)}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:justify-between gap-1">
                  <span className="text-white/70 font-medium">Dobiček izleti</span>
                  <span className="text-[#6fc8a3] font-bold">{formatEur(stats.revenue.excursions - ((stats.costs as { excursions?: number }).excursions || 0))}</span>
                </div>
              </div>

              {/* WELLNESS */}
              <div className="p-4 sm:p-6 rounded-2xl bg-white/[0.03] border border-white/10">
                <h2 className="text-base sm:text-lg font-bold text-[#f1d07a] mb-4">WELLNESS</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-8">
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Prihodki</p>
                    <p className="text-xl sm:text-2xl font-bold text-[#78b7ff]">{formatEur(stats.revenue.wellness)}</p>
                  </div>
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Stroški</p>
                    <div className="flex justify-between text-sm">
                      <span className="text-white/50">Maserke ({stats.costSettings?.find(c => c.category === 'wellness')?.value || 0} EUR/kos)</span>
                      <span className="text-white">{formatEur(stats.costs.wellness)}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:justify-between gap-1">
                  <span className="text-white/70 font-medium">Dobiček wellness</span>
                  <span className="text-[#6fc8a3] font-bold">{formatEur(stats.revenue.wellness - stats.costs.wellness)}</span>
                </div>
              </div>

              {/* OSTALO */}
              <div className="p-4 sm:p-6 rounded-2xl bg-white/[0.03] border border-white/10">
                <h2 className="text-base sm:text-lg font-bold text-[#f1d07a] mb-4">OSTALO (pranje)</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-8">
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Prihodki</p>
                    <p className="text-xl sm:text-2xl font-bold text-[#78b7ff]">{formatEur(stats.revenue.ostalo)}</p>
                  </div>
                  <div>
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Stroški</p>
                    <div className="flex justify-between text-sm">
                      <span className="text-white/50">Stroški ({stats.costSettings?.find(c => c.category === 'ostalo')?.value || 0}%)</span>
                      <span className="text-white">{formatEur(stats.costs.ostalo)}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:justify-between gap-1">
                  <span className="text-white/70 font-medium">Dobiček ostalo</span>
                  <span className="text-[#6fc8a3] font-bold">{formatEur(stats.revenue.ostalo - stats.costs.ostalo)}</span>
                </div>
              </div>

              {/* MANAGEMENT PLAČE */}
              {(stats.salaryBreakdown?.management || 0) > 0 && (
                <div className="p-4 sm:p-6 rounded-2xl bg-white/[0.03] border border-white/10">
                  <h2 className="text-base sm:text-lg font-bold text-[#ef4444] mb-4">MANAGEMENT PLAČE</h2>
                  <div className="flex flex-col sm:flex-row sm:justify-between gap-1">
                    <span className="text-white/50">Vodstvo (recepcija, vzdrževanje)</span>
                    <span className="text-white font-medium">{formatEur(stats.salaryBreakdown?.management || 0)}</span>
                  </div>
                </div>
              )}

              {/* SKUPAJ */}
              <div className="p-4 sm:p-6 rounded-2xl bg-gradient-to-r from-[#6fc8a3]/20 to-[#4a9f7e]/20 border border-[#6fc8a3]/30">
                <h2 className="text-base sm:text-lg font-bold text-white mb-4">SKUPAJ</h2>
                <div className="grid grid-cols-3 gap-2 sm:gap-8">
                  <div>
                    <p className="text-white/40 text-[10px] sm:text-xs uppercase tracking-wider mb-1 sm:mb-2">Prihodki</p>
                    <p className="text-base sm:text-2xl font-bold text-[#78b7ff]">{formatEur(stats.revenue.total)}</p>
                  </div>
                  <div>
                    <p className="text-white/40 text-[10px] sm:text-xs uppercase tracking-wider mb-1 sm:mb-2">Stroški</p>
                    <p className="text-base sm:text-2xl font-bold text-[#ef4444]">{formatEur(stats.costs.total)}</p>
                  </div>
                  <div>
                    <p className="text-white/40 text-[10px] sm:text-xs uppercase tracking-wider mb-1 sm:mb-2">Dobiček</p>
                    <p className={`text-base sm:text-2xl font-bold ${profitColor}`}>{formatEur(stats.profit)}</p>
                  </div>
                </div>
              </div>

              {/* REZULTAT PO GOSTIH */}
              <GuestBreakdown guests={(stats as { guestBreakdown?: React.ComponentProps<typeof GuestBreakdown>['guests'] }).guestBreakdown || []} />
            </div>
          </>
          )}

          {kalkulacijeView === 'prevozniki' && (
            <PrevozinkiTab year={year} month={month} />
          )}

          {kalkulacijeView === 'marketing' && (
            <MarketingTab year={year} month={month} />
          )}

          {kalkulacijeView === 'nastavitve' && (
            <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10">
              <h2 className="text-lg font-bold text-[#f1d07a] mb-4">Nastavitve stroškov</h2>
              <p className="text-white/50 text-sm mb-6">
                Nastavite nabavne procente in fiksne stroške za izračun dobička.
              </p>
              
              <div className="grid grid-cols-2 gap-8">
                {/* Cost Percentages */}
                <div>
                  <h3 className="text-sm font-medium text-white/60 uppercase tracking-wider mb-4">Nabavni procenti</h3>
                  <p className="text-white/40 text-xs mb-4">Koliko % prodajne cene predstavlja nabavna cena</p>
                  
                  <div className="space-y-4">
                    {stats?.costSettings?.filter(c => c.costType === 'percentage').map(cost => (
                      <div key={cost.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                        <label className="text-white/70">{cost.description}</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            defaultValue={Number(cost.value)}
                            onBlur={(e) => handleCostUpdate(cost.id, Number(e.target.value))}
                            className="w-20 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-right"
                          />
                          <span className="text-white/50 w-8">%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Fixed Costs */}
                <div>
                  <h3 className="text-sm font-medium text-white/60 uppercase tracking-wider mb-4">Fiksni stroški</h3>
                  <p className="text-white/40 text-xs mb-4">Fiksna cena na enoto (npr. cena maserke)</p>
                  
                  <div className="space-y-4">
                    {stats?.costSettings?.filter(c => c.costType === 'fixed').map(cost => (
                      <div key={cost.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                        <label className="text-white/70">{cost.description}</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            step="0.01"
                            defaultValue={Number(cost.value)}
                            onBlur={(e) => handleCostUpdate(cost.id, Number(e.target.value))}
                            className="w-20 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-right"
                          />
                          <span className="text-white/50 w-8">EUR</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <PayrollSettingsPanel />
            </div>
          )}
        </div>
        )}

        {/* TAB: KADROVSKI ODDELEK */}
      {activeTab === 'kadri' && (
        <div className="space-y-6">
        {/* Sub-toggle: Seznam osebja / Obračun plač / Pogodbe / Razpored */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => setKadriView('seznam')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
              kadriView === 'seznam'
                ? 'bg-[#6fc8a3]/20 text-[#6fc8a3] border border-[#6fc8a3]/30'
                : 'bg-white/5 text-white/60 hover:bg-white/10'
            }`}
          >
            <Users className="h-4 w-4" />
            Seznam osebja
          </button>
          <button
            onClick={() => setKadriView('place')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
              kadriView === 'place'
                ? 'bg-[#78b7ff]/20 text-[#78b7ff] border border-[#78b7ff]/30'
                : 'bg-white/5 text-white/60 hover:bg-white/10'
            }`}
          >
            <Euro className="h-4 w-4" />
            Obračun plač
          </button>
          <button
            onClick={() => setKadriView('pogodbe')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
              kadriView === 'pogodbe'
                ? 'bg-[#f1d07a]/20 text-[#f1d07a] border border-[#f1d07a]/30'
                : 'bg-white/5 text-white/60 hover:bg-white/10'
            }`}
          >
            <FileText className="h-4 w-4" />
            Pogodbe
          </button>
          <button
            onClick={() => setKadriView('razpored')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
              kadriView === 'razpored'
                ? 'bg-[#78b7ff]/20 text-[#78b7ff] border border-[#78b7ff]/30'
                : 'bg-white/5 text-white/60 hover:bg-white/10'
            }`}
          >
            <Calendar className="h-4 w-4" />
            Razpored
          </button>
        </div>

        {kadriView === 'place' && <PlaceTab year={year} month={month} />}

        {kadriView === 'pogodbe' && <PogodbeTab />}

        {kadriView === 'razpored' && (
          <div className="space-y-4">
            {/* Sub-toggle: Sobarice / Vrtnarji / Kuhinja */}
            <div className="no-print flex gap-2">
              <button
                onClick={() => setRazporedView('sobarice')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                  razporedView === 'sobarice'
                    ? 'bg-[#f1d07a]/20 text-[#f1d07a] border border-[#f1d07a]/30'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                Sobarice
              </button>
              <button
                onClick={() => setRazporedView('vrtnarji')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                  razporedView === 'vrtnarji'
                    ? 'bg-[#6fc8a3]/20 text-[#6fc8a3] border border-[#6fc8a3]/30'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                Vrtnarji
              </button>
              <button
                onClick={() => setRazporedView('kuhinja')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                  razporedView === 'kuhinja'
                    ? 'bg-[#f1d07a]/20 text-[#f1d07a] border border-[#f1d07a]/30'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                Kuhinja
              </button>
              <button
                onClick={() => setRazporedView('bar')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                  razporedView === 'bar'
                    ? 'bg-[#78b7ff]/20 text-[#78b7ff] border border-[#78b7ff]/30'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                Bar
              </button>
            </div>

            {razporedView === 'sobarice' ? (
              <div className="space-y-4">
                <LeaveDocument department="housekeeper" />
                <RazporedTab year={year} month={month} />
              </div>
            ) : razporedView === 'vrtnarji' ? (
              <div className="space-y-4">
                <LeaveDocument department="gardener" />
                <VrtnarjiTab year={year} month={month} />
              </div>
            ) : razporedView === 'kuhinja' ? (
              <div className="space-y-4">
                <LeaveDocument department="kitchen" />
                <KuhinjaTab year={year} month={month} />
              </div>
            ) : (
              <div className="space-y-4">
                <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
                  <h3 className="mb-1 text-sm font-medium text-white">Bar</h3>
                  <p className="text-xs text-white/50">
                    Bar ima ločeno aplikacijo za prijave in razporede. Tukaj lahko dodeliš dopust
                    barskemu osebju in pripraviš dokument za podpis.
                  </p>
                </div>
                <LeaveDocument department="barman" />
              </div>
            )}
          </div>
        )}

        {kadriView === 'seznam' && (
        <div className="space-y-6">
        <div className="p-4 sm:p-6 rounded-2xl bg-white/[0.03] border border-white/10">
          <div className="flex items-center justify-between mb-4">
          <h2 className="text-base sm:text-lg font-bold text-[#6fc8a3]">Seznam osebja</h2>
          <Link 
            href="/potrdila" 
            className="flex items-center gap-2 rounded-xl bg-[#6fc8a3]/10 border border-[#6fc8a3]/30 px-4 py-2 text-sm font-medium text-[#6fc8a3] hover:bg-[#6fc8a3]/20 transition-colors"
          >
            <Printer className="h-4 w-4" />
            Potrdila o plači
          </Link>
        </div>
        <p className="text-white/50 text-sm mb-6">
                Definirajte osebje in njihove mesečne plače. Plače se bodo avtomatsko upoštevale v statistiki glede na razporeditev (nočitve, bar, management).
              </p>

              {/* Search by name */}
              <div className="relative mb-6">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
                <input
                  type="text"
                  value={staffSearch}
                  onChange={(e) => setStaffSearch(e.target.value)}
                  placeholder="Išči po imenu..."
                  className="w-full rounded-xl bg-white/[0.03] border border-white/10 pl-10 pr-10 py-2.5 text-sm text-white placeholder-white/30 focus:border-[#6fc8a3]/40 focus:outline-none"
                />
                {staffSearch && (
                  <button
                    onClick={() => setStaffSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
                    aria-label="Počisti iskanje"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              
              {/* Staff List */}
              <div className="space-y-3 mb-6">
                {allStaff?.slice().filter(staff =>
                  staff.staffName.toLowerCase().includes(staffSearch.trim().toLowerCase())
                ).sort((a, b) => {
                  // Sort inactive to bottom, then by category, then by name
                  if ((a.active !== false) !== (b.active !== false)) return (a.active !== false) ? -1 : 1
                  const categoryOrder = { kuhinja: 0, bar: 1, accommodation: 2, management: 3 }
                  const catA = categoryOrder[a.allocateTo as keyof typeof categoryOrder] ?? 4
                  const catB = categoryOrder[b.allocateTo as keyof typeof categoryOrder] ?? 4
                  if (catA !== catB) return catA - catB
                  return a.staffName.localeCompare(b.staffName)
                }).map(staff => {
                  const typeInfo = STAFF_TYPES.find(t => t.value === staff.staffType) || STAFF_TYPES[6]
  const allocateLabel = staff.allocateTo === 'accommodation' ? 'Nočitve' : staff.allocateTo === 'bar' ? 'Bar' : staff.allocateTo === 'kuhinja' ? 'Kuhinja' : 'Management'
  const allocateColor = staff.allocateTo === 'accommodation' ? 'text-[#78b7ff]' : staff.allocateTo === 'bar' ? 'text-[#6fc8a3]' : staff.allocateTo === 'kuhinja' ? 'text-[#f1d07a]' : 'text-white/70'
                  const isActive = staff.active !== false
                  
                  return (
                    <div key={staff.id} className={`p-4 rounded-xl border ${isActive ? 'bg-white/5 border-white/10' : 'bg-red-500/5 border-red-500/20 opacity-60'}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive ? 'bg-[#6fc8a3]/20' : 'bg-red-500/20'}`}>
                          {isActive ? <UserCog className="h-5 w-5 text-[#6fc8a3]" /> : <UserMinus className="h-5 w-5 text-red-400" />}
  </div>
  <div>
  <p className={`font-medium ${isActive ? 'text-white' : 'text-white/50 line-through'}`}>{staff.staffName}</p>
  <p className="text-white/50 text-sm">{typeInfo.label}</p>
  <div className="flex items-center gap-2 mt-1">
    <Calendar className="h-3 w-3 text-[#78b7ff]" />
    <input
      type="date"
      value={staff.startDate ? staff.startDate.split('T')[0] : ''}
      onChange={(e) => handleUpdateStartDate(staff.id, e.target.value)}
      className="bg-transparent text-[#78b7ff] text-xs border-none p-0 focus:outline-none [color-scheme:dark] cursor-pointer"
      title="Datum vstopa"
    />
  </div>
  {!isActive && <span className="text-red-400 text-xs">Neaktiven</span>}
  </div>
  </div>
                      
                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <p className="text-[#f1d07a] font-bold">{formatEur(Number(staff.monthlySalary) / (stats?.exchangeRate || 4800))}</p>
                          <p className="text-white/30 text-xs">{Number(staff.monthlySalary).toLocaleString()} Ar</p>
                          <p className={`text-xs ${allocateColor}`}>Strošek: {allocateLabel}</p>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          {[1,2,3,4,5,6,7,8,9,10,11,12].map(m => (
                            <div 
                              key={m}
                              className={`w-5 h-5 rounded text-[10px] flex items-center justify-center ${
                                staff.activeMonths?.includes(m) 
                                  ? 'bg-[#6fc8a3]/30 text-[#6fc8a3]' 
                                  : 'bg-white/5 text-white/20'
                              }`}
                              title={MONTHS[m-1]}
                            >
                              {m}
                            </div>
                          ))}
                        </div>
                        
                        <button
                          onClick={() => handleToggleRegular(staff.id, staff.isRegularEmployee)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors ${
                            staff.isRegularEmployee
                              ? 'bg-[#78b7ff]/15 text-[#78b7ff] border-[#78b7ff]/30'
                              : 'bg-white/5 text-white/40 border-white/10 hover:bg-white/10'
                          }`}
                          title="Redno zaposlen (vključen v obračun plač)"
                        >
                          {staff.isRegularEmployee ? 'Redno zaposlen' : 'Pogodbeno'}
                        </button>

                        <button
                          onClick={() => handleToggleActive(staff.id, isActive)}
                          className={`p-2 rounded-lg transition-colors ${isActive ? 'text-amber-400 hover:bg-amber-500/20' : 'text-[#6fc8a3] hover:bg-[#6fc8a3]/20'}`}
                          title={isActive ? 'Označi kot neaktiven' : 'Označi kot aktiven'}
                        >
                          {isActive ? <UserMinus className="h-4 w-4" /> : <UserCheck className="h-4 w-4" />}
                        </button>
                        
                        <button
                          onClick={() => handleDeleteStaff(staff.id)}
                          className="p-2 rounded-lg text-red-400 hover:bg-red-500/20 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>

                    <StaffPersonalInfo
                      staffId={staff.id}
                      firstName={staff.firstName}
                      lastName={staff.lastName}
                      dateOfBirth={staff.dateOfBirth}
                      placeOfBirth={staff.placeOfBirth}
                      documentNumber={staff.documentNumber}
                      documentImagePath={staff.documentImagePath}
                      company={staff.company}
                      gender={staff.gender}
                      fatherName={staff.fatherName}
                      motherName={staff.motherName}
                      nationality={staff.nationality}
                      cnapsNumber={staff.cnapsNumber}
                      ominoNumber={staff.ominoNumber}
                      ostieNumber={staff.ostieNumber}
                      numberOfDependents={staff.numberOfDependents}
                      openingLeaveBalance={staff.openingLeaveBalance}
                      address={staff.address}
                      phone={staff.phone}
                      email={staff.email}
                      employeePhotoPath={staff.employeePhotoPath}
                      notes={staff.notes}
                      onImageChange={() => mutateStaff()}
                    />
                    </div>
                  )
                })}
                
                {(!allStaff || allStaff.length === 0) && (
                  <div className="text-center py-8 text-white/40">
                    Ni še dodanega osebja. Dodajte prvega delavca spodaj.
                  </div>
                )}

                {allStaff && allStaff.length > 0 && staffSearch.trim() &&
                  allStaff.filter(s => s.staffName.toLowerCase().includes(staffSearch.trim().toLowerCase())).length === 0 && (
                  <div className="text-center py-8 text-white/40">
                    Ni zadetkov za &quot;{staffSearch}&quot;.
                  </div>
                )}
              </div>
              
              {/* Add New Staff */}
              <div className="p-4 rounded-xl bg-[#0d1420] border border-[#6fc8a3]/30">
                <h3 className="text-sm font-medium text-[#6fc8a3] mb-4">Dodaj novega delavca</h3>
                
  <div className="grid grid-cols-5 gap-3 mb-3">
  <input
  type="text"
  placeholder="Ime in priimek"
  value={newStaff.staffName}
  onChange={(e) => setNewStaff(s => ({ ...s, staffName: e.target.value }))}
  className="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/30"
  />
  <select
  value={newStaff.staffType}
  onChange={(e) => {
  const type = STAFF_TYPES.find(t => t.value === e.target.value)
  setNewStaff(s => ({
  ...s,
  staffType: e.target.value,
  allocateTo: type?.allocateTo || 'management'
  }))
  }}
  className="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm"
  >
  {STAFF_TYPES.map(t => (
  <option key={t.value} value={t.value} className="bg-[#0d1420]">{t.label}</option>
  ))}
  </select>
  <input
  type="number"
  placeholder="Mesečna plača (Ar)"
  value={newStaff.monthlySalary}
  onChange={(e) => setNewStaff(s => ({ ...s, monthlySalary: e.target.value }))}
  className="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/30"
  />
  <input
  type="date"
  value={newStaff.startDate}
  onChange={(e) => setNewStaff(s => ({ ...s, startDate: e.target.value }))}
  className="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm [color-scheme:dark]"
  title="Datum vstopa"
  />
  <select
  value={newStaff.allocateTo}
  onChange={(e) => setNewStaff(s => ({ ...s, allocateTo: e.target.value }))}
  className="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm"
  >
  <option value="accommodation" className="bg-[#0d1420]">Strošek: Nočitve</option>
  <option value="bar" className="bg-[#0d1420]">Strošek: Bar</option>
  <option value="kuhinja" className="bg-[#0d1420]">Strošek: Kuhinja</option>
  <option value="management" className="bg-[#0d1420]">Strošek: Management</option>
  </select>
  </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-white/50 text-sm">Aktivni meseci:</span>
                    <div className="flex gap-1">
                      {[1,2,3,4,5,6,7,8,9,10,11,12].map(m => (
                        <button 
                          key={m}
                          onClick={() => handleToggleMonth(m)}
                          className={`w-7 h-7 rounded text-xs font-medium transition-colors ${
                            newStaff.activeMonths.includes(m) 
                              ? 'bg-[#6fc8a3] text-white' 
                              : 'bg-white/5 text-white/40 hover:bg-white/10'
                          }`}
                        >
                          {m}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <button
                    onClick={handleAddStaff}
                    disabled={!newStaff.staffName || !newStaff.monthlySalary}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#6fc8a3] text-white font-medium hover:bg-[#5eb892] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    <Plus className="h-4 w-4" />
                    Dodaj
                  </button>
                </div>
              </div>
            </div>
            
            {/* Salary Allocation Info */}
            <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10">
              <h3 className="text-sm font-medium text-white/60 uppercase tracking-wider mb-4">Kako se plače razporejajo</h3>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-[#78b7ff]/10 border border-[#78b7ff]/20">
                  <h4 className="text-[#78b7ff] font-medium mb-2">Nočitve (alikvotno)</h4>
                  <p className="text-white/50 text-sm">
                    Plača se deli glede na število nočitev v mesecu. Vrtnar in sobarica se razporedita sem.
                  </p>
                  <p className="text-white/30 text-xs mt-2">
                    Formula: plača / dni v mesecu * nočitev
                  </p>
                </div>
                
                <div className="p-4 rounded-xl bg-[#6fc8a3]/10 border border-[#6fc8a3]/20">
                  <h4 className="text-[#6fc8a3] font-medium mb-2">Bar (celotna)</h4>
                  <p className="text-white/50 text-sm">
                    Celotna mesečna plača se upošteva. Barman in kuhinja se razporedita sem.
                  </p>
                  <p className="text-white/30 text-xs mt-2">
                    Formula: celotna mesečna plača
                  </p>
                </div>
                
<div className="p-4 rounded-xl bg-[#f1d07a]/10 border border-[#f1d07a]/20">
<h4 className="text-[#f1d07a] font-medium mb-2">Management</h4>
<p className="text-white/50 text-sm">
Prikazano posebej, ne zmanjšuje dobička posamezne kategorije.
</p>
<p className="text-white/30 text-xs mt-2">
Recepcija, vzdrževanje...
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
        </div>
        )}

      </div>
    </div>
  )
}
