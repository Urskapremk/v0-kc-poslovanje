'use client'

import { useMemo, useState } from 'react'
import useSWR from 'swr'
import { Calendar, Printer, Info, FileText } from 'lucide-react'
import {
  KITCHEN_STAFF,
  SHIFT_LABELS,
  SHIFT_LABELS_FR,
  STAFF_ROLE,
  ROLE_LABELS,
  ROLE_LABELS_FR,
  generateKitchenSchedule,
  computeKitchenStats,
  type KitchenShift,
} from '@/lib/kitchen'
import { getLeaveRequests } from '@/app/actions/leave'
import { leaveDaysForStaff, LEAVE_TYPES, type LeaveType } from '@/lib/leave'

const MONTHS = [
  'Januar', 'Februar', 'Marec', 'April', 'Maj', 'Junij',
  'Julij', 'Avgust', 'September', 'Oktober', 'November', 'December',
]
const MONTHS_FR = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre',
]
const DAY_NAMES = ['Ned', 'Pon', 'Tor', 'Sre', 'Čet', 'Pet', 'Sob']
const DAY_NAMES_FR = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam']

// Color per shift (on-screen only)
function shiftClasses(shift: KitchenShift): string {
  switch (shift) {
    case 'MORNING':
      return 'bg-[#f1d07a]/15 text-[#f1d07a] border border-[#f1d07a]/25'
    case 'MIDDLE':
      return 'bg-[#78b7ff]/15 text-[#78b7ff] border border-[#78b7ff]/25'
    case 'EVENING':
      return 'bg-[#c79bff]/15 text-[#c79bff] border border-[#c79bff]/25'
    default:
      return 'text-white/25'
  }
}

export default function KuhinjaTab({ year, month }: { year: number; month: number }) {
  const [selected, setSelected] = useState<string | null>(null)

  const schedule = useMemo(() => generateKitchenSchedule(year, month), [year, month])
  const stats = useMemo(() => computeKitchenStats(schedule), [schedule])
  const lastDay = schedule.length

  const { data: leaves } = useSWR(['leave', 'kitchen'], () => getLeaveRequests('kitchen'))
  const leaveByStaff = useMemo(() => {
    const map: Record<string, ReturnType<typeof leaveDaysForStaff>> = {}
    for (const p of KITCHEN_STAFF) map[p] = leaveDaysForStaff(leaves ?? [], p, year, month)
    return map
  }, [leaves, year, month])

  const visibleStaff = KITCHEN_STAFF.filter((p) => !selected || p === selected)

  function printDoc(target: 'kitchen' | 'kitchen-attendance') {
    document.body.classList.add(`printing-${target}`)
    window.print()
    setTimeout(() => document.body.classList.remove(`printing-${target}`), 500)
  }

  return (
    <div className="space-y-4">
      <style>{`
        @media print {
          @page { size: portrait; margin: 12mm; }
          body.printing-kitchen .no-print,
          body.printing-kitchen .kitchen-screen,
          body.printing-kitchen-attendance .no-print,
          body.printing-kitchen-attendance .kitchen-screen { display: none !important; }
          body.printing-kitchen * { visibility: hidden; }
          body.printing-kitchen .kitchen-print,
          body.printing-kitchen .kitchen-print * { visibility: visible; }
          body.printing-kitchen .kitchen-print {
            display: flex !important; flex-direction: column;
            position: absolute; left: 0; top: 0; width: 100%;
            height: 248mm; box-sizing: border-box; overflow: hidden;
          }
          .kitchen-print .doc-header { text-align: center; border-bottom: 2px solid #111; padding-bottom: 6px; margin-bottom: 4px; flex: 0 0 auto; }
          .kitchen-print .doc-logo { display: block; margin: 0 auto; height: 48px; width: auto; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .kitchen-print .doc-location { font-size: 12px; font-style: italic; color: #333; margin: 2px 0 0; }
          .kitchen-print .doc-title-block { text-align: center; border-bottom: 1px solid #111; padding-bottom: 6px; margin-bottom: 6px; flex: 0 0 auto; }
          .kitchen-print .doc-title { font-size: 17px; font-weight: 700; letter-spacing: 1px; margin: 6px 0 0; }
          .kitchen-print .doc-subtitle { font-size: 12px; color: #777; margin: 2px 0 0; }
          .kitchen-print .doc-fields { font-size: 13px; line-height: 1.4; margin-bottom: 6px; flex: 0 0 auto; }
          .kitchen-print .doc-fields p { margin: 0; }
          .kitchen-print table { width: 100%; border-collapse: collapse; font-size: 11px; color: #111; font-family: Georgia, 'Times New Roman', serif; flex: 1 1 auto; height: 100%; }
          .kitchen-print th, .kitchen-print td { border: 1px solid #999; padding: 2px 5px; line-height: 1.2; text-align: center; vertical-align: middle; }
          .kitchen-print th { background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; font-size: 10px; }
          .kitchen-print .g-day { text-align: left; }
          .kitchen-print .g-total td { font-weight: 700; background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .kitchen-print .doc-legend { font-size: 11px; margin-top: 8px; flex: 0 0 auto; }

          /* ===== Attendance sheets (one page per person) ===== */
          body.printing-kitchen-attendance * { visibility: hidden; }
          body.printing-kitchen-attendance .kitchen-att-print,
          body.printing-kitchen-attendance .kitchen-att-print * { visibility: visible; }
          body.printing-kitchen-attendance .kitchen-att-print {
            display: block !important;
            position: absolute; left: 0; top: 0; width: 100%;
          }
          .kitchen-att-print .att-page { page-break-after: always; break-after: page; color: #111; font-family: Georgia, 'Times New Roman', serif; height: 248mm; box-sizing: border-box; display: flex; flex-direction: column; overflow: hidden; }
          .kitchen-att-print .att-page:last-child { page-break-after: auto; break-after: auto; }
          .kitchen-att-print .doc-header { text-align: center; border-bottom: 2px solid #111; padding-bottom: 4px; margin-bottom: 4px; flex: 0 0 auto; }
          .kitchen-att-print .doc-logo { display: block; margin: 0 auto; height: 40px; width: auto; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .kitchen-att-print .doc-location { font-size: 11px; font-style: italic; color: #333; margin: 1px 0 0; }
          .kitchen-att-print .doc-title-block { text-align: center; border-bottom: 1px solid #111; padding-bottom: 4px; margin-bottom: 5px; flex: 0 0 auto; }
          .kitchen-att-print .doc-title { font-size: 16px; font-weight: 700; letter-spacing: 1px; margin: 4px 0 0; }
          .kitchen-att-print .doc-subtitle { font-size: 11px; color: #777; margin: 2px 0 0; }
          .kitchen-att-print .doc-fields { font-size: 12px; line-height: 1.4; margin-bottom: 5px; flex: 0 0 auto; }
          .kitchen-att-print .doc-fields p { margin: 0; }
          .kitchen-att-print .doc-label { display: inline-block; min-width: 150px; }
          .kitchen-att-print table { width: 100%; border-collapse: collapse; font-size: 11px; color: #111; flex: 1 1 auto; }
          .kitchen-att-print th, .kitchen-att-print td { border: 1px solid #999; padding: 0 8px; line-height: 1.25; text-align: center; vertical-align: middle; }
          .kitchen-att-print th { background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; font-size: 10px; }
          .kitchen-att-print .att-col-day, .kitchen-att-print .att-col-date { text-align: left; }
          .kitchen-att-print .doc-legend { display: flex; justify-content: space-between; flex-wrap: wrap; gap: 12px; font-size: 11px; margin-top: 6px; flex: 0 0 auto; }
          .kitchen-att-print .doc-note { font-size: 10px; color: #333; margin: 3px 0 0; flex: 0 0 auto; }
        }
      `}</style>

      {/* Header */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#f1d07a] flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Razpored kuhinje
          </h2>
          <p className="text-white/40 text-sm">{MONTHS[month - 1]} {year} · {KITCHEN_STAFF.join(', ')}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => printDoc('kitchen')}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#78b7ff]/20 text-[#78b7ff] border border-[#78b7ff]/30 hover:bg-[#78b7ff]/30 transition-colors text-sm font-medium"
          >
            <Printer className="h-4 w-4" />
            Natisni razpored (FR)
          </button>
          <button
            onClick={() => printDoc('kitchen-attendance')}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#f1d07a]/20 text-[#f1d07a] border border-[#f1d07a]/30 hover:bg-[#f1d07a]/30 transition-colors text-sm font-medium"
          >
            <FileText className="h-4 w-4" />
            Natisni evidenco prisotnosti (FR)
          </button>
        </div>
      </div>

      {/* Notice */}
      <div className="no-print flex items-start gap-2 rounded-xl border border-[#f1d07a]/30 bg-[#f1d07a]/10 px-3 py-2 text-xs text-[#f1d07a]">
        <Info className="h-4 w-4 shrink-0 mt-0.5" />
        <span>
          Razpored se samodejno izračuna po pravilih (3 smene × 2 osebi, fiksne smene, 6 dni delo / 1 prost).
          Anifa kot rezerva pokriva tisto, ki je prosta — tako sta v vsaki smeni vedno 2 osebi.
        </span>
      </div>

      {/* Legend / filter */}
      <div className="no-print flex flex-wrap items-center gap-2 text-xs">
        {KITCHEN_STAFF.map((p) => {
          const active = selected === p
          return (
            <button
              key={p}
              type="button"
              onClick={() => setSelected(active ? null : p)}
              className={`px-3 py-1.5 rounded-lg border transition-all ${
                active
                  ? 'bg-[#f1d07a]/20 text-[#f1d07a] border-[#f1d07a]/40'
                  : 'bg-white/5 text-white/60 border-white/10 hover:bg-white/10'
              } ${selected && !active ? 'opacity-40' : ''}`}
            >
              {p} <span className="opacity-50">· {ROLE_LABELS[STAFF_ROLE[p]]}</span>
            </button>
          )
        })}
        {selected && (
          <button
            type="button"
            onClick={() => setSelected(null)}
            className="px-3 py-1.5 rounded-lg border border-white/15 text-white/50 hover:text-white hover:bg-white/5 transition-colors"
          >
            Pokaži vse
          </button>
        )}
      </div>

      {/* Hours summary */}
      <div className="no-print grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {KITCHEN_STAFF.map((p) => {
          const s = stats[p]
          return (
            <div key={p} className="rounded-2xl border border-[#f1d07a]/20 bg-[#f1d07a]/5 p-4">
              <div className="font-semibold text-[#f1d07a] mb-1">{p}</div>
              <div className="text-2xl font-bold text-[#f1d07a]">{s.hours} <span className="text-sm font-medium opacity-70">ur</span></div>
              <div className="text-xs text-white/40 mt-1">{s.shifts} izmen × 6 ur</div>
              <div className="text-[11px] text-white/30 mt-0.5">{ROLE_LABELS[STAFF_ROLE[p]]}</div>
            </div>
          )
        })}
      </div>

      {/* On-screen schedule table */}
      <div className="no-print rounded-2xl bg-white/[0.03] border border-white/10 p-3 sm:p-4 overflow-x-auto">
        <div className="no-print flex flex-wrap items-center gap-4 mb-3 text-xs text-white/50">
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-3 w-3 rounded-sm bg-[#f1d07a]/40 border border-[#f1d07a]/60" />
            Jutranja 6-12
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-3 w-3 rounded-sm bg-[#78b7ff]/40 border border-[#78b7ff]/60" />
            Srednja 11-17
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-3 w-3 rounded-sm bg-[#c79bff]/40 border border-[#c79bff]/60" />
            Večerna 16-22
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-3 w-3 rounded-sm bg-[#e8915b]/40 border border-[#e8915b]/60" />
            Dopust
          </span>
        </div>
        <table className="w-full min-w-[720px] border-collapse text-sm">
          <thead>
            <tr className="text-white/40 text-xs uppercase tracking-wider">
              <th className="text-left py-2 px-2 font-semibold">Dan</th>
              <th className="text-left py-2 px-2 font-semibold">Datum</th>
              {visibleStaff.map((p) => (
                <th key={p} className="text-left py-2 px-2 font-semibold">{p}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {schedule.map((day, i) => {
              const dayNum = i + 1
              const weekday = new Date(year, month - 1, dayNum).getDay()
              return (
                <tr key={day.date} className="border-t border-white/5">
                  <td className="py-1.5 px-2 text-white/50">{DAY_NAMES[weekday]}</td>
                  <td className="py-1.5 px-2 text-white/70">{dayNum}. {MONTHS[month - 1].slice(0, 3).toLowerCase()}</td>
                  {visibleStaff.map((p) => {
                    const shift = (day.assignments[p] || 'OFF') as KitchenShift
                    const leave = leaveByStaff[p]?.[dayNum]
                    return (
                      <td key={p} className="py-1.5 px-2">
                        {leave ? (
                          <span
                            className="inline-flex flex-col gap-0.5 rounded-md border border-[#e8915b]/40 bg-[#e8915b]/15 px-2 py-0.5 text-xs text-[#e8915b]"
                            title={LEAVE_TYPES[leave.type as LeaveType]?.sl}
                          >
                            <span className="font-semibold">DOPUST</span>
                            <span className="text-[10px] opacity-70">{SHIFT_LABELS[shift]}</span>
                          </span>
                        ) : (
                          <span className={`inline-block rounded-md px-2 py-0.5 text-xs ${shiftClasses(shift)}`}>
                            {SHIFT_LABELS[shift]}
                          </span>
                        )}
                      </td>
                    )
                  })}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* Hidden French print sheet (no colors) */}
      <div className="kitchen-print" aria-hidden="true" style={{ display: 'none' }}>
        <div className="doc-header">
          <img className="doc-logo" src="/images/komba-logo-color.png" alt="Komba Cabana" />
          <p className="doc-location">Nosy Komba, Madagascar</p>
        </div>
        <div className="doc-title-block">
          <h2 className="doc-title">PLANNING DE LA CUISINE {year}</h2>
          <p className="doc-subtitle">Cuisine</p>
        </div>
        <div className="doc-fields">
          {selected && <p><strong>Nom:</strong> {selected} ({ROLE_LABELS_FR[STAFF_ROLE[selected as keyof typeof STAFF_ROLE]]})</p>}
          <p><strong>Mois:</strong> {MONTHS_FR[month - 1]} {year}</p>
        </div>
        <table>
          <thead>
            <tr>
              <th>Jour</th>
              <th>Date</th>
              {visibleStaff.map((p) => (
                <th key={p}>{p}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {schedule.map((day, i) => {
              const dayNum = i + 1
              const weekday = new Date(year, month - 1, dayNum).getDay()
              return (
                <tr key={day.date}>
                  <td className="g-day">{DAY_NAMES_FR[weekday]}</td>
                  <td className="g-day">{dayNum} {MONTHS_FR[month - 1].slice(0, 4).toLowerCase()}.</td>
                  {visibleStaff.map((p) => {
                    const shift = (day.assignments[p] || 'OFF') as KitchenShift
                    return <td key={p}>{shift === 'OFF' ? '—' : SHIFT_LABELS_FR[shift]}</td>
                  })}
                </tr>
              )
            })}
            <tr className="g-total">
              <td colSpan={2} style={{ textAlign: 'right' }}>Total heures</td>
              {visibleStaff.map((p) => (
                <td key={p}>{stats[p].hours} h</td>
              ))}
            </tr>
          </tbody>
        </table>
        <div className="doc-legend">
          <span><strong>Matin</strong> 6h-12h &nbsp;·&nbsp; <strong>Après-midi</strong> 11h-17h &nbsp;·&nbsp; <strong>Soir</strong> 16h-22h &nbsp;·&nbsp; <strong>—</strong> Repos</span>
        </div>
      </div>

      {/* Hidden French attendance sheets — one full page per person (no colors) */}
      <div className="kitchen-att-print" aria-hidden="true" style={{ display: 'none' }}>
        {visibleStaff.map((p) => (
          <div key={p} className="att-page">
            <div className="doc-header">
              <img className="doc-logo" src="/images/komba-logo-color.png" alt="Komba Cabana" />
              <p className="doc-location">Nosy Komba, Madagascar</p>
            </div>
            <div className="doc-title-block">
              <h2 className="doc-title">REGISTRE DE PRÉSENCE {year}</h2>
              <p className="doc-subtitle">Cuisine</p>
            </div>
            <div className="doc-fields">
              <p><span className="doc-label">Nom:</span> <strong>{p}</strong></p>
              <p><span className="doc-label">Poste:</span> <strong>{ROLE_LABELS_FR[STAFF_ROLE[p]]}</strong></p>
              <p><span className="doc-label">Mois:</span> <strong>{MONTHS_FR[month - 1]} {year}</strong></p>
            </div>
            <table>
              <thead>
                <tr>
                  <th className="att-col-day">Jour</th>
                  <th className="att-col-date">Date</th>
                  <th>Arrivée</th>
                  <th>Départ</th>
                  <th>Signature</th>
                </tr>
              </thead>
              <tbody>
                {Array.from({ length: lastDay }).map((_, i) => {
                  const dayNum = i + 1
                  const weekday = new Date(year, month - 1, dayNum).getDay()
                  return (
                    <tr key={dayNum}>
                      <td className="att-col-day">{DAY_NAMES_FR[weekday]}</td>
                      <td className="att-col-date">{dayNum} {MONTHS_FR[month - 1].slice(0, 4).toLowerCase()}.</td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
            <div className="doc-legend">
              <span>Total heures prévues: <strong>{stats[p].hours} h</strong> ({stats[p].shifts} services × 6 h)</span>
              <span>Signature du responsable: ______________________</span>
            </div>
            <p className="doc-note">Par ma signature, je confirme ma présence au travail pour les jours indiqués.</p>
          </div>
        ))}
      </div>
    </div>
  )
}
