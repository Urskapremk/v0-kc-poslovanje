'use client'

import { useState } from 'react'
import useSWR, { mutate } from 'swr'
import { CalendarPlus, Printer, Trash2, X, Check, Upload, FileText } from 'lucide-react'
import { getAllStaffMembers } from '@/app/actions/statistics'
import { getCompany } from '@/lib/payroll'
import {
  getLeaveRequests,
  createLeaveRequest,
  deleteLeaveRequest,
  setLeaveSigned,
  setLeaveSignedDocument,
} from '@/app/actions/leave'
import {
  LeaveDepartment,
  LEAVE_DEPARTMENTS,
  LEAVE_TYPES,
  LeaveType,
  daysBetween,
  leaveDateSl,
  leaveDateFr,
  LeaveRequest,
  proratedAnnualQuota,
  usedDaysInYear,
} from '@/lib/leave'

const todayStr = () => new Date().toISOString().slice(0, 10)

export default function LeaveDocument({ department }: { department: LeaveDepartment }) {
  const { data: allStaff } = useSWR('all-staff', getAllStaffMembers)
  const { data: leaves } = useSWR(`leaves-${department}`, () => getLeaveRequests(department))

  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [printDoc, setPrintDoc] = useState<LeaveRequest | null>(null)
  const [selectedStaffId, setSelectedStaffId] = useState<string>('')
  const [year, setYear] = useState(new Date().getFullYear())
  const [uploadingId, setUploadingId] = useState<string | null>(null)

  async function handleUploadSigned(leaveId: string, file: File) {
    setUploadingId(leaveId)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const res = await fetch('/api/upload-leave-document', { method: 'POST', body: fd })
      if (!res.ok) throw new Error('Upload failed')
      const { pathname } = await res.json()
      await setLeaveSignedDocument(leaveId, pathname)
      mutate(`leaves-${department}`)
    } catch (e) {
      console.error('[v0] leave signed upload error:', e)
      alert('Nalaganje podpisanega dokumenta ni uspelo.')
    } finally {
      setUploadingId(null)
    }
  }

  const [form, setForm] = useState({
    staffId: '',
    leaveType: 'annual' as LeaveType,
    startDate: todayStr(),
    endDate: todayStr(),
    reason: '',
  })

  // Osebje tega oddelka
  const deptStaff = (allStaff ?? []).filter(
    s => s.active && (s.staffType === department || s.allocateTo === department)
  )

  const selectedStaff = deptStaff.find(s => s.id === form.staffId)
  const days = daysBetween(form.startDate, form.endDate)

  // Pregled po delavcu
  const viewedStaff = deptStaff.find(s => s.id === selectedStaffId)
  const allLeaves = leaves ?? []
  const viewedLeaves = selectedStaffId
    ? allLeaves.filter(l => l.staffId === selectedStaffId)
    : allLeaves
  // Dopusti izbranega delavca v izbranem letu
  const staffLeavesAllYears = selectedStaffId
    ? allLeaves.filter(l => l.staffId === selectedStaffId)
    : []
  const usedDays = usedDaysInYear(staffLeavesAllYears, year)
  const annualQuota = proratedAnnualQuota(year, viewedStaff?.startDate)
  const isProrated = viewedStaff?.startDate
    ? new Date(viewedStaff.startDate + 'T00:00:00').getFullYear() === year
    : false
  const remainingDays = annualQuota - usedDays
  // Leta, ki se pojavijo (za izbirnik)
  const availableYears = Array.from(
    new Set(allLeaves.map(l => new Date(l.startDate + 'T00:00:00').getFullYear()))
  ).sort((a, b) => b - a)
  if (!availableYears.includes(new Date().getFullYear())) availableYears.unshift(new Date().getFullYear())

  async function handleSave() {
    if (!selectedStaff || days <= 0) return
    setSaving(true)
    try {
      await createLeaveRequest({
        staffId: selectedStaff.id,
        staffName: selectedStaff.staffName,
        department,
        company: selectedStaff.company || 'tourism',
        leaveType: form.leaveType,
        startDate: form.startDate,
        endDate: form.endDate,
        reason: form.reason,
      })
      await mutate(`leaves-${department}`)
      setForm({ staffId: '', leaveType: 'annual', startDate: todayStr(), endDate: todayStr(), reason: '' })
      setShowForm(false)
    } catch (e) {
      console.error('[v0] leave save error', e)
    }
    setSaving(false)
  }

  async function handleDelete(id: string) {
    await deleteLeaveRequest(id)
    await mutate(`leaves-${department}`)
  }

  function handlePrint(leave: LeaveRequest) {
    const staff = (allStaff ?? []).find(s => s.id === leave.staffId)
    setPrintDoc({ ...leave, ...(staff ? {} : {}) })
    // Sklicujemo se na HR podatke prek staffId; shranimo tudi za print
    ;(window as any).__leaveStaff = staff
    document.body.classList.add('printing-leave')
    setTimeout(() => {
      window.print()
      document.body.classList.remove('printing-leave')
      if (!leave.signedAt) {
        setLeaveSigned(leave.id).then(() => mutate(`leaves-${department}`))
      }
    }, 100)
  }

  const printStaff: any = printDoc ? (window as any).__leaveStaff : null
  const printCompany = printDoc ? getCompany(printDoc.company) : null

  return (
    <>
    <div className="rounded-2xl border border-[#78b7ff]/20 bg-[#78b7ff]/[0.04] p-4 no-print">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-medium text-white">Dopust — {LEAVE_DEPARTMENTS[department].sl}</h3>
          <p className="text-xs text-white/50">Dodeli dopust in natisni dokument za podpis</p>
        </div>
        <button
          onClick={() => setShowForm(v => !v)}
          className="flex items-center gap-2 rounded-xl bg-[#78b7ff]/20 px-4 py-2 text-sm font-medium text-[#78b7ff] border border-[#78b7ff]/30 hover:bg-[#78b7ff]/30 transition-colors"
        >
          <CalendarPlus className="h-4 w-4" />
          Dopust
        </button>
      </div>

      {/* Obrazec */}
      {showForm && (
        <div className="mt-4 rounded-xl border border-white/10 bg-black/20 p-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-[10px] uppercase tracking-wider text-white/40">Delavec</label>
              <select
                value={form.staffId}
                onChange={e => setForm(p => ({ ...p, staffId: e.target.value }))}
                className="w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
              >
                <option value="">Izberi delavca</option>
                {deptStaff.map(s => (
                  <option key={s.id} value={s.id}>{s.staffName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1 block text-[10px] uppercase tracking-wider text-white/40">Vrsta dopusta</label>
              <select
                value={form.leaveType}
                onChange={e => setForm(p => ({ ...p, leaveType: e.target.value as LeaveType }))}
                className="w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
              >
                {Object.entries(LEAVE_TYPES).map(([k, v]) => (
                  <option key={k} value={k}>{v.sl}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1 block text-[10px] uppercase tracking-wider text-white/40">Od</label>
              <input
                type="date"
                value={form.startDate}
                onChange={e => setForm(p => ({ ...p, startDate: e.target.value }))}
                className="w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-1 block text-[10px] uppercase tracking-wider text-white/40">Do</label>
              <input
                type="date"
                value={form.endDate}
                onChange={e => setForm(p => ({ ...p, endDate: e.target.value }))}
                className="w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="mb-1 block text-[10px] uppercase tracking-wider text-white/40">Opomba (neobvezno)</label>
              <input
                type="text"
                value={form.reason}
                onChange={e => setForm(p => ({ ...p, reason: e.target.value }))}
                placeholder="npr. razlog ali opomba"
                className="w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-4 py-3 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
              />
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between">
            <div>
              <p className="text-sm text-white/60">
                Št. dni: <span className="font-medium text-white">{days > 0 ? days : '—'}</span>
              </p>
              {!form.staffId && (
                <p className="mt-1 text-xs text-amber-400/80">Izberi delavca za shranjevanje.</p>
              )}
              {form.staffId && days <= 0 && (
                <p className="mt-1 text-xs text-amber-400/80">
                  Vnesi veljaven datum &quot;Od&quot; in &quot;Do&quot; (preveri, da datum obstaja).
                </p>
              )}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowForm(false)}
                className="flex items-center gap-1 rounded-xl bg-white/5 px-4 py-2 text-sm text-white/60 hover:bg-white/10"
              >
                <X className="h-4 w-4" /> Prekliči
              </button>
              <button
                onClick={handleSave}
                disabled={saving || !form.staffId || days <= 0}
                className="flex items-center gap-1 rounded-xl bg-[#78b7ff] px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
              >
                <Check className="h-4 w-4" /> {saving ? 'Shranjujem…' : 'Shrani dopust'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Izbira delavca za pregled dopustov */}
      {deptStaff.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedStaffId('')}
            className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
              selectedStaffId === ''
                ? 'bg-[#78b7ff] text-white'
                : 'bg-white/5 text-white/60 hover:bg-white/10'
            }`}
          >
            Vsi
          </button>
          {deptStaff.map(s => (
            <button
              key={s.id}
              onClick={() => setSelectedStaffId(s.id)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                selectedStaffId === s.id
                  ? 'bg-[#78b7ff] text-white'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              {s.staffName}
            </button>
          ))}
        </div>
      )}

      {/* Stevec dopusta za izbranega delavca */}
      {viewedStaff && (
        <div className="mt-4 rounded-xl border border-white/10 bg-black/20 p-4">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-sm font-medium text-white">{viewedStaff.staffName}</p>
            <select
              value={year}
              onChange={e => setYear(Number(e.target.value))}
              className="rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-1.5 text-xs text-white focus:border-[#78b7ff]/40 focus:outline-none"
            >
              {availableYears.map(y => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="rounded-lg bg-white/[0.03] py-3">
              <p className="text-2xl font-semibold text-white">{annualQuota}</p>
              <p className="mt-1 text-[10px] uppercase tracking-wider text-white/40">Na razpolago</p>
            </div>
            <div className="rounded-lg bg-white/[0.03] py-3">
              <p className="text-2xl font-semibold text-[#78b7ff]">{usedDays}</p>
              <p className="mt-1 text-[10px] uppercase tracking-wider text-white/40">Koriščeno</p>
            </div>
            <div className="rounded-lg bg-white/[0.03] py-3">
              <p className={`text-2xl font-semibold ${remainingDays < 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                {remainingDays}
              </p>
              <p className="mt-1 text-[10px] uppercase tracking-wider text-white/40">Preostalo</p>
            </div>
          </div>
          <p className="mt-3 text-[11px] text-white/40">
            Šteje vse vrste dopusta v koledarskem letu {year}.{' '}
            {isProrated && viewedStaff?.startDate ? (
              <>
                Sorazmerna kvota: zaposlitev {leaveDateSl(viewedStaff.startDate)} → {annualQuota} dni
                (2,5 dni/mesec).
              </>
            ) : (
              <>Letna kvota: {annualQuota} dni (Madagaskar, 2,5 dni/mesec).</>
            )}
          </p>
        </div>
      )}

      {/* Seznam dopustov */}
      {viewedLeaves && viewedLeaves.length > 0 && (
        <div className="mt-4 space-y-2">
          {viewedLeaves.map(l => (
            <div
              key={l.id}
              className="flex items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-white">
                  {l.staffName}
                  <span className="ml-2 text-xs text-[#78b7ff]">{LEAVE_TYPES[l.leaveType as LeaveType]?.sl}</span>
                </p>
                <p className="text-xs text-white/50">
                  {leaveDateSl(l.startDate)} – {leaveDateSl(l.endDate)} · {l.days} dni
                  {l.signedAt ? ' · izdano' : ''}
                  {l.signedDocumentPath ? ' · podpisano ✓' : ''}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                {l.signedDocumentPath ? (
                  <a
                    href={`/api/image?pathname=${encodeURIComponent(l.signedDocumentPath)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 rounded-lg bg-[#6fc8a3]/15 px-3 py-2 text-xs text-[#6fc8a3] hover:bg-[#6fc8a3]/25"
                  >
                    <FileText className="h-3.5 w-3.5" /> Poglej
                  </a>
                ) : null}
                <label
                  className={`flex cursor-pointer items-center gap-1 rounded-lg px-3 py-2 text-xs ${
                    l.signedDocumentPath
                      ? 'bg-white/5 text-white/60 hover:bg-white/10'
                      : 'bg-[#78b7ff]/15 text-[#78b7ff] hover:bg-[#78b7ff]/25'
                  } ${uploadingId === l.id ? 'pointer-events-none opacity-60' : ''}`}
                >
                  <Upload className="h-3.5 w-3.5" />
                  {uploadingId === l.id
                    ? 'Nalagam…'
                    : l.signedDocumentPath
                      ? 'Zamenjaj'
                      : 'Dodaj podpisano'}
                  <input
                    type="file"
                    accept="image/*,application/pdf"
                    className="hidden"
                    onChange={e => {
                      const f = e.target.files?.[0]
                      if (f) handleUploadSigned(l.id, f)
                      e.target.value = ''
                    }}
                  />
                </label>
                <button
                  onClick={() => handlePrint(l)}
                  className="flex items-center gap-1 rounded-lg bg-white/5 px-3 py-2 text-xs text-white/70 hover:bg-white/10"
                >
                  <Printer className="h-3.5 w-3.5" /> Natisni
                </button>
                <button
                  onClick={() => handleDelete(l.id)}
                  className="flex items-center gap-1 rounded-lg bg-red-500/10 px-3 py-2 text-xs text-red-300 hover:bg-red-500/20"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>

      {/* Tiskovni dokument (skrit, viden samo pri tisku) — IZVEN no-print ovoja */}
      {printDoc && printCompany && (
        <div className="leave-print">
          <div className="doc-page">
            <div className="doc-header">
              <img src="/images/komba-logo-color.png" alt="Komba Cabana" className="doc-logo" />
              <p className="doc-company">{printCompany.name}</p>
              <p className="doc-location">{printCompany.address}</p>
              <p className="doc-location">Nosy Komba, Madagascar</p>
            </div>

            <div className="doc-title-block">
              <p className="doc-title">AUTORISATION DE CONGÉ</p>
              <p className="doc-title-en">LEAVE AUTHORISATION</p>
              <p className="doc-subtitle">
                {LEAVE_TYPES[printDoc.leaveType as LeaveType]?.fr} / {LEAVE_TYPES[printDoc.leaveType as LeaveType]?.en}
              </p>
            </div>

            <div className="doc-fields">
              <p><span className="doc-label">Nom et prénom / Full name :</span>
                {' '}
                {printStaff
                  ? `${printStaff.lastName || ''} ${printStaff.firstName || ''}`.trim() || printDoc.staffName
                  : printDoc.staffName}
              </p>
              {printStaff?.dateOfBirth && (
                <p><span className="doc-label">Date de naissance / Date of birth :</span> {leaveDateFr(printStaff.dateOfBirth)}</p>
              )}
              {printStaff?.placeOfBirth && (
                <p><span className="doc-label">Lieu de naissance / Place of birth :</span> {printStaff.placeOfBirth}</p>
              )}
              {printStaff?.documentNumber && (
                <p><span className="doc-label">N° pièce d&apos;identité / ID number :</span> {printStaff.documentNumber}</p>
              )}
              <p><span className="doc-label">Poste / Position :</span> {LEAVE_DEPARTMENTS[department].fr} / {LEAVE_DEPARTMENTS[department].en}</p>
            </div>

            <p className="doc-para">
              {`L'employé(e) susnommé(e) est autorisé(e) à prendre un ${LEAVE_TYPES[printDoc.leaveType as LeaveType]?.fr.toLowerCase()} `}
              <strong>{`du ${leaveDateFr(printDoc.startDate)} au ${leaveDateFr(printDoc.endDate)}`}</strong>
              {`, soit ${printDoc.days} jour(s).`}
            </p>
            <p className="doc-para doc-para-en">
              {`The above-named employee is authorised to take ${LEAVE_TYPES[printDoc.leaveType as LeaveType]?.en.toLowerCase()} `}
              <strong>{`from ${leaveDateFr(printDoc.startDate)} to ${leaveDateFr(printDoc.endDate)}`}</strong>
              {`, i.e. ${printDoc.days} day(s).`}
            </p>

            {printDoc.reason && (
              <p className="doc-para">
                <span className="doc-label">Observation / Note :</span> {printDoc.reason}
              </p>
            )}

            <div className="doc-signatures">
              <div>
                <div className="doc-sign-line">L&apos;employé(e) / The employee</div>
              </div>
              <div>
                <div className="doc-sign-line">L&apos;employeur / The employer</div>
              </div>
            </div>
          </div>
        </div>
      )}

      <style jsx global>{`
        .leave-print { display: none; }

        @media print {
          @page { size: portrait; margin: 14mm; }
          body { background: #fff !important; }
          .no-print { display: none !important; }

          body.printing-leave * { visibility: hidden; }
          body.printing-leave .leave-print,
          body.printing-leave .leave-print * { visibility: visible; }
          body.printing-leave .leave-print {
            display: block !important;
            position: absolute; left: 0; top: 0; width: 100%;
          }

          .leave-print .doc-page { color: #111; font-family: Georgia, 'Times New Roman', serif; }
          .leave-print .doc-header { text-align: center; border-bottom: 2px solid #111; padding-bottom: 8px; margin-bottom: 4px; }
          .leave-print .doc-logo { display: block; margin: 0 auto; height: 56px; width: auto; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .leave-print .doc-company { font-size: 14px; font-weight: 700; letter-spacing: 0.5px; margin: 6px 0 0; }
          .leave-print .doc-location { font-size: 12px; font-style: italic; color: #333; margin: 2px 0 0; }
          .leave-print .doc-title-block { text-align: center; border-bottom: 1px solid #111; padding-bottom: 10px; margin-bottom: 16px; }
          .leave-print .doc-title { font-size: 20px; font-weight: 700; letter-spacing: 1px; margin: 12px 0 0; }
          .leave-print .doc-title-en { font-size: 14px; font-weight: 700; letter-spacing: 1px; color: #444; margin: 2px 0 0; }
          .leave-print .doc-subtitle { font-size: 12px; color: #777; margin: 3px 0 0; }
          .leave-print .doc-fields { font-size: 13px; line-height: 1.8; margin-bottom: 16px; }
          .leave-print .doc-fields p { margin: 0; }
          .leave-print .doc-label { display: inline-block; min-width: 220px; }
          .leave-print .doc-para { font-size: 13px; line-height: 1.8; margin: 8px 0 12px; }
          .leave-print .doc-para-en { color: #444; font-style: italic; }
          .leave-print .doc-signatures { display: flex; justify-content: space-between; margin-top: 64px; gap: 40px; }
          .leave-print .doc-signatures > div { flex: 1; }
          .leave-print .doc-sign-line { border-top: 1px solid #111; padding-top: 4px; font-size: 12px; text-align: center; }
        }
      `}</style>
    </>
  )
}
