'use client'

import React, { useState, useMemo } from 'react'
import useSWR from 'swr'
import { Printer, Wallet, AlertTriangle, Check, Receipt, ChevronDown, ChevronUp, Save, Palmtree, LogOut } from 'lucide-react'
import { getAllStaffMembers } from '@/app/actions/statistics'
import {
  getPayrollEntries,
  upsertPayrollEntry,
  getQuarterlyContributions,
  setContributionPaid,
  getPayrollSettings,
  getAllStaffPayrollInfo,
  getStaffLeaveSummaries,
} from '@/app/actions/payroll'
import {
  calcPayslip,
  getQuarter,
  getQuarterDeadline,
  DEFAULT_NET_SALARY,
  DEFAULT_PAYROLL_SETTINGS,
  formatAr,
  getCompany,
  type PayslipInput,
  type PayrollSettings,
} from '@/lib/payroll'
import { computeLeavePay, dailyLeaveAllowance, type LeaveSummary } from '@/lib/leave'

const MONTHS_FR = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre',
]

const QUARTER_DEADLINE_LABEL: Record<number, string> = {
  1: 'do konca aprila',
  2: 'do konca julija',
  3: 'do konca oktobra',
  4: 'do konca januarja (naslednje leto)',
}

function formatDateSl(iso: string) {
  const d = new Date(iso)
  return d.toLocaleDateString('sl-SI', { day: 'numeric', month: 'long', year: 'numeric' })
}

function formatDateFr(iso: string | null) {
  if (!iso) return ''
  const d = new Date(iso)
  if (isNaN(d.getTime())) return ''
  return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' })
}

// Mesecni vnos delavca (obrazec)
type EntryForm = {
  baseGrossSalary: number
  overtimeFirst8Hours: number
  overtimeAfter8Hours: number
  nightRegularHours: number
  nightOccasionalHours: number
  sundayHours: number
  publicHolidayHours: number
  bonuses: number
  taxableBenefits: number
  unusedLeaveCompensation: number
  employeeAdvances: number
  otherEmployeeDeductions: number
}

const EMPTY_FORM: EntryForm = {
  baseGrossSalary: DEFAULT_NET_SALARY,
  overtimeFirst8Hours: 0,
  overtimeAfter8Hours: 0,
  nightRegularHours: 0,
  nightOccasionalHours: 0,
  sundayHours: 0,
  publicHolidayHours: 0,
  bonuses: 0,
  taxableBenefits: 0,
  unusedLeaveCompensation: 0,
  employeeAdvances: 0,
  otherEmployeeDeductions: 0,
}

type PrintStaff = {
  id: string
  name: string
  form: EntryForm
  dependents: number
  firstName: string
  lastName: string
  dateOfBirth: string | null
  placeOfBirth: string
  documentNumber: string
  company: string
  position: string
  cnapsNumber: string
  leave: LeaveSummary | null
}

export default function PlaceTab({ year, month }: { year: number; month: number }) {
  const [printStaff, setPrintStaff] = useState<PrintStaff | null>(null)
  const [selectedQuarter, setSelectedQuarter] = useState<number>(getQuarter(month))
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [drafts, setDrafts] = useState<Record<string, EntryForm>>({})
  const [saving, setSaving] = useState<Record<string, boolean>>({})

  const { data: allStaff } = useSWR('all-staff', () => getAllStaffMembers(), { refreshInterval: 0 })
  const { data: settings } = useSWR('payroll-settings', () => getPayrollSettings(), { refreshInterval: 0 })
  const { data: staffInfo } = useSWR('staff-payroll-info', () => getAllStaffPayrollInfo(), { refreshInterval: 0 })

  const { data: entries, mutate: mutateEntries } = useSWR(
    ['payroll', year, month],
    () => getPayrollEntries(year, month),
    { refreshInterval: 0 }
  )

  const { data: quarterly, mutate: mutateQuarterly } = useSWR(
    ['quarterly', year, selectedQuarter],
    () => getQuarterlyContributions(year, selectedQuarter),
    { refreshInterval: 0 }
  )

  const { data: leaveSummaries } = useSWR(
    ['leave-summaries', year, month],
    () => getStaffLeaveSummaries(year, month),
    { refreshInterval: 0 }
  )

  const cfg: PayrollSettings = settings || DEFAULT_PAYROLL_SETTINGS
  const regularStaff = (allStaff || []).filter((s) => s.isRegularEmployee)

  // map staffId -> shranjeni vnos za izbrani mesec
  const entryByStaff = useMemo(() => {
    const m: Record<string, EntryForm> = {}
    for (const e of entries || []) {
      m[e.staffId] = {
        baseGrossSalary: e.baseSalary,
        overtimeFirst8Hours: e.overtimeFirst8Hours,
        overtimeAfter8Hours: e.overtimeAfter8Hours,
        nightRegularHours: e.nightRegularHours,
        nightOccasionalHours: e.nightOccasionalHours,
        sundayHours: e.sundayHours,
        publicHolidayHours: e.publicHolidayHours,
        bonuses: e.bonus,
        taxableBenefits: e.taxableBenefits,
        unusedLeaveCompensation: e.unusedLeaveCompensation,
        employeeAdvances: e.advances,
        otherEmployeeDeductions: e.otherDeductions,
      }
    }
    return m
  }, [entries])

  const leaveOf = (staffId: string): LeaveSummary | null => leaveSummaries?.[staffId] ?? null

  // Vrne obrazec: draft (ce obstaja) -> shranjeni vnos -> prazno
  const getForm = (staffId: string): EntryForm =>
    drafts[staffId] ?? entryByStaff[staffId] ?? EMPTY_FORM

  const dependentsOf = (staffId: string) => staffInfo?.[staffId]?.numberOfDependents ?? 0

  const updateDraft = (staffId: string, patch: Partial<EntryForm>) => {
    setDrafts((prev) => ({
      ...prev,
      [staffId]: { ...getForm(staffId), ...patch },
    }))
  }

  // Poracun ob odhodu: preostali dopust x dnevno nadomestilo (zakonska referenca / delitelj).
  // Referenca = 1/12 placila prejsnjih 12 mesecev (LeaveSummary.referenceAmount).
  const dailyLeaveRate = (referenceAmount: number) =>
    dailyLeaveAllowance(referenceAmount, cfg.leaveAllowanceDivisor)

  const handleSettlement = (staffId: string, referenceAmount: number, remainingDays: number) => {
    const comp = Math.round(Math.max(0, remainingDays) * dailyLeaveRate(referenceAmount))
    updateDraft(staffId, { unusedLeaveCompensation: comp })
    setExpanded((p) => ({ ...p, [staffId]: true }))
  }

  const handleSave = async (staffId: string, staffName: string) => {
    const form = getForm(staffId)
    setSaving((p) => ({ ...p, [staffId]: true }))
    try {
      await upsertPayrollEntry({
        staffId,
        staffName,
        year,
        month,
        baseSalary: form.baseGrossSalary,
        overtimeFirst8Hours: form.overtimeFirst8Hours,
        overtimeAfter8Hours: form.overtimeAfter8Hours,
        nightRegularHours: form.nightRegularHours,
        nightOccasionalHours: form.nightOccasionalHours,
        sundayHours: form.sundayHours,
        publicHolidayHours: form.publicHolidayHours,
        bonus: form.bonuses,
        taxableBenefits: form.taxableBenefits,
        unusedLeaveCompensation: form.unusedLeaveCompensation,
        advances: form.employeeAdvances,
        otherDeductions: form.otherEmployeeDeductions,
      })
      await mutateEntries()
      await mutateQuarterly()
      setDrafts((prev) => {
        const next = { ...prev }
        delete next[staffId]
        return next
      })
    } finally {
      setSaving((p) => ({ ...p, [staffId]: false }))
    }
  }

  const handleTogglePaid = async (paid: boolean) => {
    await setContributionPaid(year, selectedQuarter, paid)
    mutateQuarterly()
  }

  const handlePrint = (staff: PrintStaff) => {
    setPrintStaff(staff)
    setTimeout(() => {
      document.body.classList.add('printing-payslip')
      window.print()
      document.body.classList.remove('printing-payslip')
    }, 50)
  }

  // Placilo dopusta po metodi (le ce ni SALARY_MAINTENANCE in je dopust izkoriscen ta mesec).
  const leavePayFor = (form: EntryForm, leave: LeaveSummary | null) =>
    computeLeavePay({
      method: cfg.leaveCalculationMethod,
      daysTaken: leave?.takenThisMonth ?? 0,
      baseSalary: form.baseGrossSalary,
      referenceAmount: leave?.referenceAmount ?? 0,
      deductionDivisor: cfg.leaveDeductionDivisor,
      allowanceDivisor: cfg.leaveAllowanceDivisor,
    })

  const toInput = (form: EntryForm, dependents: number, leave: LeaveSummary | null = null): PayslipInput => {
    const lp = leavePayFor(form, leave)
    return {
      baseGrossSalary: form.baseGrossSalary,
      overtimeFirst8Hours: form.overtimeFirst8Hours,
      overtimeAfter8Hours: form.overtimeAfter8Hours,
      nightRegularHours: form.nightRegularHours,
      nightOccasionalHours: form.nightOccasionalHours,
      sundayHours: form.sundayHours,
      publicHolidayHours: form.publicHolidayHours,
      bonuses: form.bonuses,
      taxableBenefits: form.taxableBenefits,
      unusedLeaveCompensation: form.unusedLeaveCompensation,
      leaveAllowance: lp.allowance,
      leaveDeduction: lp.deduction,
      employeeAdvances: form.employeeAdvances,
      otherEmployeeDeductions: form.otherEmployeeDeductions,
      numberOfDependents: dependents,
    }
  }

  // skupni mesecni stroski (vsi redni zaposleni)
  let monthTotalNet = 0
  let monthTotalEmployerCost = 0
  for (const s of regularStaff) {
    const slip = calcPayslip(toInput(getForm(s.id), dependentsOf(s.id), leaveOf(s.id)), cfg)
    monthTotalNet += slip.netToPay
    monthTotalEmployerCost += slip.totalEmployerCost
  }

  const printPayslip = printStaff
    ? calcPayslip(toInput(printStaff.form, printStaff.dependents, printStaff.leave), cfg)
    : null

  const deadlineDate = quarterly ? new Date(quarterly.deadline) : null
  const daysLeft = deadlineDate
    ? Math.ceil((deadlineDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
    : null
  const deadlineUrgent = quarterly && !quarterly.paid && daysLeft !== null && daysLeft <= 30

  const pct = (r: number) => `${(r * 100).toFixed(r * 100 % 1 === 0 ? 0 : 1)}%`

  return (
    <div className="space-y-6">
      {/* Header / povzetek */}
      <div className="no-print rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#78b7ff]/15">
              <Wallet className="h-5 w-5 text-[#78b7ff]" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Obračun plač</h3>
              <p className="text-xs text-white/40">
                {MONTHS_FR[month - 1]} {year} — redno zaposleni ({regularStaff.length})
              </p>
            </div>
          </div>
          <div className="flex gap-6">
            <div className="text-right">
              <p className="text-[11px] uppercase tracking-wider text-white/40">Skupaj neto</p>
              <p className="text-lg font-bold text-white">{formatAr(monthTotalNet)}</p>
            </div>
            <div className="text-right">
              <p className="text-[11px] uppercase tracking-wider text-white/40">Strošek delodajalca</p>
              <p className="text-lg font-bold text-[#6fc8a3]">{formatAr(monthTotalEmployerCost)}</p>
            </div>
          </div>
        </div>
      </div>

      {regularStaff.length === 0 && (
        <div className="no-print rounded-2xl border border-white/[0.06] bg-white/[0.02] p-8 text-center">
          <p className="text-sm text-white/50">
            Ni rednih zaposlenih. Označite delavce kot &quot;redno zaposlen&quot; v zavihku &quot;Seznam osebja&quot;.
          </p>
        </div>
      )}

      {/* Seznam rednih zaposlenih z obracunom */}
      <div className="no-print space-y-3">
        {regularStaff.map((s) => {
          const form = getForm(s.id)
          const dependents = dependentsOf(s.id)
          const leave = leaveOf(s.id)
          const slip = calcPayslip(toInput(form, dependents, leave), cfg)
          const isOpen = expanded[s.id]
          const isDirty = !!drafts[s.id]
          return (
            <div key={s.id} className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
              {/* glava vrstice */}
              <div className="flex flex-wrap items-center justify-between gap-4">
                <button
                  onClick={() => setExpanded((p) => ({ ...p, [s.id]: !p[s.id] }))}
                  className="flex items-center gap-2 text-left"
                >
                  {isOpen ? (
                    <ChevronUp className="h-4 w-4 text-white/40" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-white/40" />
                  )}
                  <div>
                    <p className="text-sm font-semibold text-[#f1d07a]">{s.staffName}</p>
                    <p className="text-[11px] text-white/40">
                      {dependents > 0 ? `${dependents} vzdrževanih oseb` : 'Brez vzdrževanih oseb'}
                      {leave && <span className="text-[#6fc8a3]"> · dopust: {leave.remaining.toFixed(1)} dni</span>}
                    </p>
                  </div>
                </button>

                <div className="flex flex-wrap items-center gap-5">
                  <div className="text-right">
                    <p className="text-[10px] uppercase tracking-wider text-white/40">Bruto</p>
                    <p className="text-sm font-semibold text-white tabular-nums">{formatAr(slip.grossSalary)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] uppercase tracking-wider text-white/40">Neto za izplačilo (plačilo delavcu)</p>
                    <p className="text-sm font-bold text-[#78b7ff] tabular-nums">{formatAr(slip.netToPay)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] uppercase tracking-wider text-white/40">Strošek delodajalca</p>
                    <p className="text-sm font-semibold text-[#6fc8a3] tabular-nums">{formatAr(slip.totalEmployerCost)}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {isDirty && (
                      <button
                        onClick={() => handleSave(s.id, s.staffName)}
                        disabled={saving[s.id]}
                        className="flex items-center gap-2 rounded-xl border border-[#6fc8a3]/30 bg-[#6fc8a3]/10 px-3 py-2 text-sm font-medium text-[#6fc8a3] transition hover:bg-[#6fc8a3]/20 disabled:opacity-50"
                      >
                        <Save className="h-4 w-4" />
                        {saving[s.id] ? 'Shranjujem…' : 'Shrani'}
                      </button>
                    )}
                    <button
                      onClick={() =>
                        handlePrint({
                          id: s.id,
                          name: s.staffName,
                          form,
                          dependents,
                          firstName: s.firstName,
                          lastName: s.lastName,
                          dateOfBirth: s.dateOfBirth,
                          placeOfBirth: s.placeOfBirth,
                          documentNumber: s.documentNumber,
                          company: s.company,
                          position: staffInfo?.[s.id]?.position ?? '',
                          cnapsNumber: s.cnapsNumber,
                          leave,
                        } as PrintStaff)
                      }
                      className="flex items-center gap-2 rounded-xl border border-[#78b7ff]/30 bg-[#78b7ff]/10 px-3 py-2 text-sm font-medium text-[#78b7ff] transition hover:bg-[#78b7ff]/20"
                    >
                      <Printer className="h-4 w-4" />
                      Lista
                    </button>
                  </div>
                </div>
              </div>

              {/* razsirjeni vnos + razclenitev */}
              {isOpen && (
                <div className="mt-5 grid gap-6 lg:grid-cols-2">
                  {/* VNOS */}
                  <div>
                    <p className="mb-3 text-[11px] uppercase tracking-wider text-white/40">Mesečni vnos</p>
                    <div className="grid grid-cols-2 gap-3">
                      <NumInput label="Osnovna bruto plača (Ar)" value={form.baseGrossSalary} onChange={(v) => updateDraft(s.id, { baseGrossSalary: v })} wide />
                      <NumInput label="Nadure 1–8 (ure)" value={form.overtimeFirst8Hours} onChange={(v) => updateDraft(s.id, { overtimeFirst8Hours: v })} />
                      <NumInput label="Nadure nad 8 (ure)" value={form.overtimeAfter8Hours} onChange={(v) => updateDraft(s.id, { overtimeAfter8Hours: v })} />
                      <NumInput label="Redno nočno (ure)" value={form.nightRegularHours} onChange={(v) => updateDraft(s.id, { nightRegularHours: v })} />
                      <NumInput label="Občasno nočno (ure)" value={form.nightOccasionalHours} onChange={(v) => updateDraft(s.id, { nightOccasionalHours: v })} />
                      <NumInput label="Nedeljsko delo (ure)" value={form.sundayHours} onChange={(v) => updateDraft(s.id, { sundayHours: v })} />
                      <NumInput label="Praznično delo (ure)" value={form.publicHolidayHours} onChange={(v) => updateDraft(s.id, { publicHolidayHours: v })} />
                      <NumInput label="Bonusi (Ar)" value={form.bonuses} onChange={(v) => updateDraft(s.id, { bonuses: v })} />
                      <NumInput label="Obdavčljive ugodnosti (Ar)" value={form.taxableBenefits} onChange={(v) => updateDraft(s.id, { taxableBenefits: v })} />
                      <NumInput label="Poračun dopusta ob odhodu (Ar)" value={form.unusedLeaveCompensation} onChange={(v) => updateDraft(s.id, { unusedLeaveCompensation: v })} wide />
                      <NumInput label="Predujmi (Ar)" value={form.employeeAdvances} onChange={(v) => updateDraft(s.id, { employeeAdvances: v })} />
                      <NumInput label="Ostali odbitki (Ar)" value={form.otherEmployeeDeductions} onChange={(v) => updateDraft(s.id, { otherEmployeeDeductions: v })} />
                    </div>
                    <p className="mt-2 text-[11px] text-white/30">
                      Urna postavka: {formatAr(slip.hourlyRate)} ({cfg.monthlyHours} h/mesec)
                    </p>
                  </div>

                  {/* RAZCLENITEV */}
                  <div className="space-y-4">
                    <div>
                      <p className="mb-2 text-[11px] uppercase tracking-wider text-white/40">Zaslužek</p>
                      <div className="space-y-1 text-sm">
                        <Row label="Osnovna bruto plača" value={formatAr(slip.baseGrossSalary)} />
                        {slip.overtimeFirst8Amount > 0 && <Row label={`Nadure 1–8 (×${cfg.overtimeFirst8})`} value={formatAr(slip.overtimeFirst8Amount)} />}
                        {slip.overtimeAfter8Amount > 0 && <Row label={`Nadure nad 8 (×${cfg.overtimeAfter8})`} value={formatAr(slip.overtimeAfter8Amount)} />}
                        {slip.nightRegularAmount > 0 && <Row label={`Redno nočno (×${cfg.nightRegular})`} value={formatAr(slip.nightRegularAmount)} />}
                        {slip.nightOccasionalAmount > 0 && <Row label={`Občasno nočno (×${cfg.nightOccasional})`} value={formatAr(slip.nightOccasionalAmount)} />}
                        {slip.sundayAmount > 0 && <Row label={`Nedelje (×${cfg.sundayWork})`} value={formatAr(slip.sundayAmount)} />}
                        {slip.publicHolidayAmount > 0 && <Row label={`Prazniki (×${cfg.publicHoliday})`} value={formatAr(slip.publicHolidayAmount)} />}
                        {slip.bonuses > 0 && <Row label="Bonusi" value={formatAr(slip.bonuses)} />}
                        {slip.taxableBenefits > 0 && <Row label="Obdavčljive ugodnosti" value={formatAr(slip.taxableBenefits)} />}
                        {slip.unusedLeaveCompensation > 0 && <Row label="Poračun neizkoriščenega dopusta" value={formatAr(slip.unusedLeaveCompensation)} />}
                        {/* Obdavcljivo nadomestilo dopusta (samo ce congeTaxable=true) */}
                        {slip.leaveAllowance > 0 && slip.nonTaxableLeaveAllowance === 0 && <Row label={`Nadomestilo dopusta (${(leave?.takenThisMonth ?? 0).toFixed(1)} dni)`} value={formatAr(slip.leaveAllowance)} />}
                        {slip.leaveDeduction > 0 && <Row label={`Odbitek dopusta (${(leave?.takenThisMonth ?? 0).toFixed(1)} dni)`} value={`− ${formatAr(slip.leaveDeduction)}`} />}
                        <Row label="BRUTO IMPOSABLE (obdavčljiva)" value={formatAr(slip.taxableGross)} strong />
                      </div>
                    </div>
                    <div>
                      <p className="mb-2 text-[11px] uppercase tracking-wider text-white/40">Odbitki zaposlenega</p>
                      <div className="space-y-1 text-sm">
                        <Row label={`CNAPS zaposleni (${pct(cfg.employeeCNAPS)})`} value={formatAr(slip.employeeCNAPS)} />
                        <Row label={`OSTIE zaposleni (${pct(cfg.employeeOSTIE)})`} value={formatAr(slip.employeeOSTIE)} />
                        <Row label="IRSA (dohodnina)" value={formatAr(slip.finalIRSA)} />
                        {slip.employeeAdvances > 0 && <Row label="Predujmi" value={formatAr(slip.employeeAdvances)} />}
                        {slip.otherEmployeeDeductions > 0 && <Row label="Ostali odbitki" value={formatAr(slip.otherEmployeeDeductions)} />}
                        <Row label="Skupaj odbitki" value={formatAr(slip.totalEmployeeDeductions)} muted />
                        <Row label="NET IMPOSABLE (neto obdavčljive)" value={formatAr(slip.netSalary)} strong />
                        {slip.nonTaxableLeaveAllowance > 0 && <Row label={`Nadomestilo dopusta — neobdavčljivo (${(leave?.takenThisMonth ?? 0).toFixed(1)} dni)`} value={`+ ${formatAr(slip.nonTaxableLeaveAllowance)}`} />}
                        <Row label="NETO ZA IZPLAČILO (PLAČILO DELAVCU)" value={formatAr(slip.netToPay)} strong accent />
                      </div>
                    </div>
                    <div>
                      <p className="mb-2 text-[11px] uppercase tracking-wider text-white/40">Prispevki delodajalca</p>
                      <div className="space-y-1 text-sm">
                        <Row label={`CNAPS delodajalec (${pct(cfg.employerCNAPS)})`} value={formatAr(slip.employerCNAPS)} />
                        <Row label={`OSTIE delodajalec (${pct(cfg.employerOSTIE)})`} value={formatAr(slip.employerOSTIE)} />
                        <Row label={`FMFP (${pct(cfg.employerFMFP)})`} value={formatAr(slip.employerFMFP)} />
                        <Row label="Skupaj prispevki" value={formatAr(slip.employerContributions)} muted />
                        <Row label="SKUPNI STROŠEK" value={formatAr(slip.totalEmployerCost)} strong />
                      </div>
                    </div>

                    {/* DOPUST */}
                    <div className="rounded-xl border border-[#6fc8a3]/20 bg-[#6fc8a3]/[0.04] p-4">
                      <div className="mb-2 flex items-center gap-2">
                        <Palmtree className="h-4 w-4 text-[#6fc8a3]" />
                        <p className="text-[11px] uppercase tracking-wider text-[#6fc8a3]">Dopust (letni plačan)</p>
                      </div>
                      <div className="space-y-1 text-sm">
                        <Row label="Stanje pred mesecem" value={`${(leave?.balanceBefore ?? 0).toFixed(1)} dni`} muted />
                        <Row label="Priraslo ta mesec" value={`+ ${(leave?.earnedThisMonth ?? 0).toFixed(1)} dni`} />
                        <Row label="Izkoriščeno ta mesec" value={`− ${(leave?.takenThisMonth ?? 0).toFixed(1)} dni`} />
                        <Row label="PREOSTALO STANJE" value={`${(leave?.remaining ?? 0).toFixed(1)} dni`} strong accent />
                        <Row label="Referenca (1/12 zadnjih 12 mes)" value={formatAr(leave?.referenceAmount ?? 0)} muted />
                      </div>
                      <div className="mt-3 flex items-center justify-between gap-3">
                        <p className="text-[11px] text-white/40">
                          Dnevno nadomestilo: {formatAr(dailyLeaveRate(leave?.referenceAmount ?? 0))}
                        </p>
                        <button
                          onClick={() => handleSettlement(s.id, leave?.referenceAmount ?? 0, leave?.remaining ?? 0)}
                          disabled={(leave?.remaining ?? 0) <= 0}
                          className="flex items-center gap-2 rounded-lg border border-[#f1d07a]/30 bg-[#f1d07a]/10 px-3 py-1.5 text-xs font-medium text-[#f1d07a] transition hover:bg-[#f1d07a]/20 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          <LogOut className="h-3.5 w-3.5" />
                          Poračun ob odhodu
                        </button>
                      </div>
                      <p className="mt-2 text-[11px] text-white/30">
                        Poračun = preostali dnevi × dnevna postavka. Doda se v bruto (obdavčeno + prispevki).
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Cetrtletni prispevki */}
      <div className="no-print rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#6fc8a3]/15">
              <Receipt className="h-5 w-5 text-[#6fc8a3]" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Četrtletni prispevki</h3>
              <p className="text-xs text-white/40">Za plačilo prispevkov državi (osnova = bruto s stropom)</p>
            </div>
          </div>
          <div className="flex gap-2">
            {[1, 2, 3, 4].map((q) => (
              <button
                key={q}
                onClick={() => setSelectedQuarter(q)}
                className={`rounded-xl px-4 py-2 text-sm font-medium transition ${
                  selectedQuarter === q
                    ? 'bg-[#78b7ff]/20 text-[#78b7ff]'
                    : 'border border-white/[0.06] text-white/50 hover:bg-white/[0.04]'
                }`}
              >
                Q{q}
              </button>
            ))}
          </div>
        </div>

        {quarterly && (
          <div className="mt-5">
            {deadlineUrgent && (
              <div className="mb-4 flex items-center gap-3 rounded-xl border border-[#e08a8a]/30 bg-[#e08a8a]/10 px-4 py-3">
                <AlertTriangle className="h-5 w-5 shrink-0 text-[#e08a8a]" />
                <p className="text-sm text-[#e08a8a]">
                  {daysLeft !== null && daysLeft < 0
                    ? `Rok za plačilo je potekel pred ${Math.abs(daysLeft)} dnevi!`
                    : `Rok za plačilo čez ${daysLeft} dni!`}{' '}
                  Rok: {formatDateSl(quarterly.deadline)}
                </p>
              </div>
            )}

            <div className="grid gap-4 md:grid-cols-4">
              <StatBox label={`CNAPS (${pct(cfg.employerCNAPS)})`} value={formatAr(quarterly.cnaps)} />
              <StatBox label={`OSTIE (${pct(cfg.employerOSTIE)})`} value={formatAr(quarterly.omino)} />
              <StatBox label={`FMFP (${pct(cfg.employerFMFP)})`} value={formatAr(quarterly.fmfp)} />
              <StatBox label="SKUPAJ" value={formatAr(quarterly.total)} accent />
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
              <div className="text-sm text-white/50">
                <p>
                  Osnova prispevkov v Q{selectedQuarter}:{' '}
                  <span className="text-white">{formatAr(quarterly.sumOfBaseSalaries)}</span>
                </p>
                <p>
                  Rok plačila: <span className="text-white">{QUARTER_DEADLINE_LABEL[selectedQuarter]}</span>{' '}
                  ({formatDateSl(quarterly.deadline)})
                </p>
              </div>
              <div className="flex items-center gap-3">
                {quarterly.paid ? (
                  <span className="flex items-center gap-2 rounded-xl border border-[#6fc8a3]/30 bg-[#6fc8a3]/10 px-4 py-2 text-sm font-medium text-[#6fc8a3]">
                    <Check className="h-4 w-4" /> Plačano
                    {quarterly.paidAt && ` (${formatDateSl(quarterly.paidAt)})`}
                  </span>
                ) : (
                  <span className="rounded-xl border border-[#e08a8a]/30 bg-[#e08a8a]/10 px-4 py-2 text-sm font-medium text-[#e08a8a]">
                    Neplačano
                  </span>
                )}
                <button
                  onClick={() => handleTogglePaid(!quarterly.paid)}
                  className="rounded-xl border border-white/[0.06] bg-white/[0.04] px-4 py-2 text-sm font-medium text-white transition hover:bg-white/[0.08]"
                >
                  {quarterly.paid ? 'Označi kot neplačano' : 'Označi kot plačano'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ===== PRINT: Bulletin de paie (francosko, brez barv) ===== */}
      {printStaff && printPayslip && (
        <div className="payslip-print" aria-hidden="true">
          <div className="doc-page">
            <div className="doc-header">
              <img className="doc-logo" src="/images/komba-logo-color.png" alt="Komba Cabana" />
              <p className="doc-company">{getCompany(printStaff.company).name}</p>
              <p className="doc-location">{getCompany(printStaff.company).address}</p>
              <p className="doc-location">Nosy Komba, Madagascar</p>
            </div>
            <div className="doc-title-block">
              <h2 className="doc-title">BULLETIN DE PAIE</h2>
              <p className="doc-subtitle">Fiche de paie mensuelle</p>
            </div>
            <div className="doc-fields">
              {(() => {
                const fullName =
                  [printStaff.lastName, printStaff.firstName].filter(Boolean).join(' ').trim() ||
                  printStaff.name
                const dob = formatDateFr(printStaff.dateOfBirth)
                return (
                  <>
                    <p><span className="doc-label">Nom et prénom:</span> <strong>{fullName}</strong></p>
                    {printStaff.position && (
                      <p><span className="doc-label">Poste:</span> <strong>{printStaff.position}</strong></p>
                    )}
                    {dob && <p><span className="doc-label">Date de naissance:</span> <strong>{dob}</strong></p>}
                    {printStaff.placeOfBirth && (
                      <p><span className="doc-label">Lieu de naissance:</span> <strong>{printStaff.placeOfBirth}</strong></p>
                    )}
                    {printStaff.documentNumber && (
                      <p><span className="doc-label">N° pièce d&apos;identité:</span> <strong>{printStaff.documentNumber}</strong></p>
                    )}
                    {printStaff.cnapsNumber && (
                      <p><span className="doc-label">N° CNAPS:</span> <strong>{printStaff.cnapsNumber}</strong></p>
                    )}
                    <p><span className="doc-label">Personnes à charge:</span> <strong>{printStaff.dependents}</strong></p>
                    <p><span className="doc-label">Mois:</span> <strong>{MONTHS_FR[month - 1]} {year}</strong></p>
                  </>
                )
              })()}
            </div>

            <table className="doc-table pay-table">
              <thead>
                <tr><th>Désignation</th><th className="pay-amount">Montant (Ar)</th></tr>
              </thead>
              <tbody>
                <tr><td>Salaire de base brut</td><td className="pay-amount">{formatAr(printPayslip.baseGrossSalary)}</td></tr>
                <tr><td>Taux horaire</td><td className="pay-amount">{formatAr(printPayslip.hourlyRate)}</td></tr>
                {printPayslip.overtimeFirst8Amount > 0 && <tr><td>Heures supp. (1–8)</td><td className="pay-amount">{formatAr(printPayslip.overtimeFirst8Amount)}</td></tr>}
                {printPayslip.overtimeAfter8Amount > 0 && <tr><td>Heures supp. (au-delà de 8)</td><td className="pay-amount">{formatAr(printPayslip.overtimeAfter8Amount)}</td></tr>}
                {printPayslip.nightRegularAmount > 0 && <tr><td>Travail de nuit régulier</td><td className="pay-amount">{formatAr(printPayslip.nightRegularAmount)}</td></tr>}
                {printPayslip.nightOccasionalAmount > 0 && <tr><td>Travail de nuit occasionnel</td><td className="pay-amount">{formatAr(printPayslip.nightOccasionalAmount)}</td></tr>}
                {printPayslip.sundayAmount > 0 && <tr><td>Travail du dimanche</td><td className="pay-amount">{formatAr(printPayslip.sundayAmount)}</td></tr>}
                {printPayslip.publicHolidayAmount > 0 && <tr><td>Jours fériés</td><td className="pay-amount">{formatAr(printPayslip.publicHolidayAmount)}</td></tr>}
                {printPayslip.bonuses > 0 && <tr><td>Primes</td><td className="pay-amount">{formatAr(printPayslip.bonuses)}</td></tr>}
                {printPayslip.taxableBenefits > 0 && <tr><td>Avantages imposables</td><td className="pay-amount">{formatAr(printPayslip.taxableBenefits)}</td></tr>}
                {printPayslip.unusedLeaveCompensation > 0 && <tr><td>Indemnité de congé non pris</td><td className="pay-amount">{formatAr(printPayslip.unusedLeaveCompensation)}</td></tr>}
                {/* Obdavcljivo nadomestilo dopusta (samo ce congeTaxable=true) */}
                {printPayslip.leaveAllowance > 0 && printPayslip.nonTaxableLeaveAllowance === 0 && <tr><td>Indemnité de congé{printStaff.leave ? ` (${printStaff.leave.takenThisMonth.toFixed(1)} j)` : ''}</td><td className="pay-amount">{formatAr(printPayslip.leaveAllowance)}</td></tr>}
                {printPayslip.leaveDeduction > 0 && <tr><td>Retenue congé{printStaff.leave ? ` (${printStaff.leave.takenThisMonth.toFixed(1)} j)` : ''}</td><td className="pay-amount">− {formatAr(printPayslip.leaveDeduction)}</td></tr>}
                <tr className="pay-total"><td>SALAIRE BRUT IMPOSABLE</td><td className="pay-amount">{formatAr(printPayslip.taxableGross)}</td></tr>
                <tr className="pay-section"><td colSpan={2}>Retenues salariales</td></tr>
                <tr><td>CNAPS salarié</td><td className="pay-amount">{formatAr(printPayslip.employeeCNAPS)}</td></tr>
                <tr><td>OSTIE salarié</td><td className="pay-amount">{formatAr(printPayslip.employeeOSTIE)}</td></tr>
                <tr><td>IRSA</td><td className="pay-amount">{formatAr(printPayslip.finalIRSA)}</td></tr>
                {printPayslip.employeeAdvances > 0 && <tr><td>Avances</td><td className="pay-amount">{formatAr(printPayslip.employeeAdvances)}</td></tr>}
                {printPayslip.otherEmployeeDeductions > 0 && <tr><td>Autres retenues</td><td className="pay-amount">{formatAr(printPayslip.otherEmployeeDeductions)}</td></tr>}
                <tr className="pay-subtotal"><td>Total des retenues</td><td className="pay-amount">{formatAr(printPayslip.totalEmployeeDeductions)}</td></tr>
                <tr className="pay-subtotal"><td>NET IMPOSABLE</td><td className="pay-amount">{formatAr(printPayslip.netSalary)}</td></tr>
                {printPayslip.nonTaxableLeaveAllowance > 0 && <tr><td>Indemnité de congé payé{printStaff.leave ? ` (${printStaff.leave.takenThisMonth.toFixed(1)} j)` : ''}</td><td className="pay-amount">+ {formatAr(printPayslip.nonTaxableLeaveAllowance)}</td></tr>}
                <tr className="pay-total"><td>SALAIRE NET À PAYER</td><td className="pay-amount">{formatAr(printPayslip.netToPay)}</td></tr>
                <tr className="pay-section"><td colSpan={2}>Charges patronales</td></tr>
                <tr><td>CNAPS employeur</td><td className="pay-amount">{formatAr(printPayslip.employerCNAPS)}</td></tr>
                <tr><td>OSTIE employeur</td><td className="pay-amount">{formatAr(printPayslip.employerOSTIE)}</td></tr>
                <tr><td>FMFP employeur</td><td className="pay-amount">{formatAr(printPayslip.employerFMFP)}</td></tr>
                <tr className="pay-total"><td>COÛT TOTAL EMPLOYEUR</td><td className="pay-amount">{formatAr(printPayslip.totalEmployerCost)}</td></tr>
              </tbody>
            </table>

            {/* CONGÉ PAYÉ — informativni prikaz stanja dopusta */}
            {printStaff.leave && (
              <div className="contrib-note">
                <p className="contrib-title">Congé annuel payé</p>
                <table className="doc-table pay-table">
                  <tbody>
                    <tr><td>Congé acquis (droit du salarié)</td><td className="pay-amount">{(printStaff.leave.openingBalance + printStaff.leave.earnedYtd).toFixed(1)} j</td></tr>
                    <tr><td>Congé déjà pris</td><td className="pay-amount">− {printStaff.leave.takenYtd.toFixed(1)} j</td></tr>
                    <tr className="pay-total"><td>CONGÉ DISPONIBLE (mois suivants)</td><td className="pay-amount">{printStaff.leave.remaining.toFixed(1)} j</td></tr>
                    {printPayslip.unusedLeaveCompensation > 0 && (
                      <tr><td>Indemnité de congé non pris</td><td className="pay-amount">{formatAr(printPayslip.unusedLeaveCompensation)}</td></tr>
                    )}
                  </tbody>
                </table>
                <p className="contrib-hint">
                  Le congé payé pris est rémunéré comme salaire normal (acquisition 2,5 jours par mois travaillé).
                  Il reste {printStaff.leave.remaining.toFixed(1)} jour(s) de congé disponible(s) pour les mois suivants.
                </p>
              </div>
            )}

            {/* TEST: ÉCHÉANCIER DES COTISATIONS — samo na testni placilni listi */}
            {printStaff.id === 'staff-test-DELETE-ME' && (() => {
              const q = getQuarter(month)
              const dl = getQuarterDeadline(year, q)
              const quarterDeadlineFr = dl.toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })
              const irsaMonth = month === 12 ? 1 : month + 1
              const irsaYear = month === 12 ? year + 1 : year
              const irsaDeadline = new Date(irsaYear, irsaMonth - 1, 15).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })
              const cnapsTotal = printPayslip.employeeCNAPS + printPayslip.employerCNAPS
              const ostieTotal = printPayslip.employeeOSTIE + printPayslip.employerOSTIE
              return (
                <div className="contrib-note">
                  <p className="contrib-title">ÉCHÉANCIER DES COTISATIONS (TEST) — Quand &amp; à qui payer</p>
                  <table className="doc-table pay-table">
                    <thead>
                      <tr>
                        <th>Organisme</th>
                        <th className="pay-amount">Part salarié</th>
                        <th className="pay-amount">Part employeur</th>
                        <th className="pay-amount">Total</th>
                        <th>Échéance</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>CNAPS (retraite)</td>
                        <td className="pay-amount">{formatAr(printPayslip.employeeCNAPS)}</td>
                        <td className="pay-amount">{formatAr(printPayslip.employerCNAPS)}</td>
                        <td className="pay-amount">{formatAr(cnapsTotal)}</td>
                        <td>Trimestriel — avant le {quarterDeadlineFr} (T{q})</td>
                      </tr>
                      <tr>
                        <td>OSTIE (santé)</td>
                        <td className="pay-amount">{formatAr(printPayslip.employeeOSTIE)}</td>
                        <td className="pay-amount">{formatAr(printPayslip.employerOSTIE)}</td>
                        <td className="pay-amount">{formatAr(ostieTotal)}</td>
                        <td>Trimestriel — avant le {quarterDeadlineFr} (T{q})</td>
                      </tr>
                      <tr>
                        <td>FMFP (formation)</td>
                        <td className="pay-amount">—</td>
                        <td className="pay-amount">{formatAr(printPayslip.employerFMFP)}</td>
                        <td className="pay-amount">{formatAr(printPayslip.employerFMFP)}</td>
                        <td>Trimestriel — avant le {quarterDeadlineFr} (T{q})</td>
                      </tr>
                      <tr>
                        <td>IRSA (impôt)</td>
                        <td className="pay-amount">{formatAr(printPayslip.finalIRSA)}</td>
                        <td className="pay-amount">—</td>
                        <td className="pay-amount">{formatAr(printPayslip.finalIRSA)}</td>
                        <td>Mensuel — avant le {irsaDeadline}</td>
                      </tr>
                    </tbody>
                  </table>
                  <p className="contrib-hint">
                    CNAPS, OSTIE et FMFP sont versés trimestriellement aux caisses respectives ;
                    l&apos;IRSA est reversé mensuellement à l&apos;administration fiscale (impôts).
                  </p>
                </div>
              )
            })()}

            <div className="doc-signatures">
              <div><p className="doc-sign-line">Signature de l&apos;employé</p></div>
              <div><p className="doc-sign-line">Signature de l&apos;employeur</p></div>
            </div>
          </div>
        </div>
      )}

      <style jsx global>{`
        .payslip-print { display: none; }

        @media print {
          @page { size: portrait; margin: 14mm; }
          body { background: #fff !important; }
          .no-print { display: none !important; }

          body.printing-payslip * { visibility: hidden; }
          body.printing-payslip .payslip-print,
          body.printing-payslip .payslip-print * { visibility: visible; }
          body.printing-payslip .payslip-print {
            display: block !important;
            position: absolute; left: 0; top: 0; width: 100%;
          }

          .payslip-print .doc-page { color: #111; font-family: Georgia, 'Times New Roman', serif; }
          .payslip-print .doc-header { text-align: center; border-bottom: 2px solid #111; padding-bottom: 8px; margin-bottom: 4px; }
          .payslip-print .doc-logo { display: block; margin: 0 auto; height: 56px; width: auto; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .payslip-print .doc-company { font-size: 14px; font-weight: 700; letter-spacing: 0.5px; margin: 6px 0 0; }
          .payslip-print .doc-location { font-size: 12px; font-style: italic; color: #333; margin: 2px 0 0; }
          .payslip-print .doc-title-block { text-align: center; border-bottom: 1px solid #111; padding-bottom: 10px; margin-bottom: 16px; }
          .payslip-print .doc-title { font-size: 20px; font-weight: 700; letter-spacing: 1px; margin: 12px 0 0; }
          .payslip-print .doc-subtitle { font-size: 12px; color: #777; margin: 3px 0 0; }
          .payslip-print .doc-fields { font-size: 13px; line-height: 1.7; margin-bottom: 16px; }
          .payslip-print .doc-fields p { margin: 0; }
          .payslip-print .doc-label { display: inline-block; min-width: 150px; }
          .payslip-print .pay-table { width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 4px; }
          .payslip-print .pay-table th, .payslip-print .pay-table td { border: 1px solid #999; padding: 5px 10px; }
          .payslip-print .pay-table th { background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; font-size: 12px; text-align: left; }
          .payslip-print .pay-amount { text-align: right; white-space: nowrap; }
          .payslip-print .pay-section td { font-weight: 700; background: #f2f2f2 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; }
          .payslip-print .pay-subtotal td { font-weight: 600; background: #f6f6f6 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .payslip-print .pay-total td { font-weight: 700; background: #ececec !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .payslip-print .doc-signatures { display: flex; justify-content: space-between; margin-top: 48px; gap: 40px; }
          .payslip-print .doc-signatures > div { flex: 1; }
          .payslip-print .doc-sign-line { border-top: 1px solid #111; padding-top: 4px; font-size: 12px; text-align: center; }
          .payslip-print .contrib-note { margin-top: 18px; border: 1px solid #999; padding: 10px 12px; }
          .payslip-print .contrib-title { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 8px; }
          .payslip-print .contrib-hint { font-size: 11px; font-style: italic; color: #444; margin: 8px 0 0; }
        }
      `}</style>
    </div>
  )
}

function NumInput({
  label,
  value,
  onChange,
  wide,
}: {
  label: string
  value: number
  onChange: (v: number) => void
  wide?: boolean
}) {
  return (
    <div className={wide ? 'col-span-2' : ''}>
      <label className="block text-[11px] font-medium uppercase tracking-wider text-white/40">{label}</label>
      <input
        type="number"
        className="mt-1 w-full rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 py-2 text-sm text-white focus:border-[#78b7ff]/40 focus:outline-none"
        value={value === 0 ? '' : value}
        placeholder="0"
        onChange={(e) => onChange(Number(e.target.value) || 0)}
      />
    </div>
  )
}

function Row({
  label,
  value,
  muted,
  strong,
  accent,
}: {
  label: string
  value: string
  muted?: boolean
  strong?: boolean
  accent?: boolean
}) {
  return (
    <div className="flex items-center justify-between">
      <span className={`${muted ? 'text-white/40' : 'text-white/60'}`}>{label}</span>
      <span
        className={`tabular-nums ${
          accent ? 'text-[#6fc8a3]' : strong ? 'text-white' : 'text-white/80'
        } ${strong ? 'font-semibold' : ''}`}
      >
        {value}
      </span>
    </div>
  )
}

function StatBox({
  label,
  value,
  accent,
}: {
  label: string
  value: string
  accent?: boolean
}) {
  return (
    <div
      className={`rounded-xl border p-4 ${
        accent ? 'border-[#6fc8a3]/30 bg-[#6fc8a3]/10' : 'border-white/[0.06] bg-white/[0.02]'
      }`}
    >
      <p className="text-[11px] uppercase tracking-wider text-white/40">{label}</p>
      <p className={`mt-1 text-base font-bold ${accent ? 'text-[#6fc8a3]' : 'text-white'}`}>{value}</p>
    </div>
  )
}
