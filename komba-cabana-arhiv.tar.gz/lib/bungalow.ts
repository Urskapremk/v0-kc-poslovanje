// Pomozne funkcije za prikaz naziva nastanitvene enote (bungalova).
// Naziv iz Bentrala je pogosto sestavljen niz z vec segmenti, npr.
//   "Garden Bungalov III / Garden Bungalov III (2+0); Garden Bungalov III / Garden Bungalov III (2+0)"
// Te funkcije iz njega izpeljejo cist, kratek prikaz.

// Cist, kratek naziv enote: vzame prvi segment (pred ';' in '/') brez ponovitev.
export function bungalowLabel(raw: string | null | undefined): string {
  if (!raw) return ''
  const first = raw.split(';')[0]?.split('/')[0]?.trim()
  return first || raw.trim()
}

// Kratka znacka za kvadratek: rimska/arabska oznaka enote (npr. "III", "2"),
// sicer zacetnice besed (npr. "GB"). Nikoli ne vrne sestavljenega niza stevilk.
export function bungalowBadge(raw: string | null | undefined): string {
  const label = bungalowLabel(raw)
  if (!label) return 'B'
  // koncna rimska stevilka ali stevilo, npr. "Garden Bungalov III" -> "III", "Bungalow 2" -> "2"
  const trailing = label.match(/\b([IVXLCDM]+|\d+)\s*$/i)
  if (trailing) return trailing[1].toUpperCase()
  // sicer prve arabske stevilke kjerkoli
  const digits = label.replace(/\D/g, '')
  if (digits) return digits
  // sicer zacetnice besed
  return label
    .split(/\s+/)
    .map(w => w[0])
    .join('')
    .slice(0, 3)
    .toUpperCase()
}
